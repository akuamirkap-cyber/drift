import { fish3d } from "./fish3d";
import type { Fish3DPose } from "./fish3d";
import type { Species } from "./species";
import { WORLD_W, WORLD_H, floorY } from "./ocean";
import type { Ocean } from "./ocean";

export interface Decor3DCreature {
  id: number;
  kind: "spanish_dancer" | "comb_jelly";
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  face: 1 | -1;
  turnFlip: number;
  tilt: number;
  ph: number;
  tx: number;
  ty: number;
  timer: number;
}

const SPANISH_DANCER_SP: Species = {
  id: "decor-spanish-dancer",
  name: "Penari Spanyol",
  style: "spanish_dancer",
  hRatio: 0.54,
  eye: 0.16,
  blush: false,
  angry: false,
  teeth: false,
  stripes: [],
  spots: true,
  is3D: true,
  pal: {
    body: "#e11d48",
    dark: "#9f1239",
    belly: "#ffedd5",
    fin: "#fb923c",
    tail: "#ef4444",
    outline: "#4c0519",
    spot: "#ffedd5",
  },
  minR: 15,
  maxR: 19,
  speed: 32,
  predator: false,
  weight: 0,
};

const COMB_JELLY_SP: Species = {
  id: "decor-comb-jelly",
  name: "Ubur-Ubur Sisir",
  style: "comb_jelly",
  hRatio: 1.18,
  eye: 0,
  blush: false,
  angry: false,
  teeth: false,
  stripes: [],
  spots: false,
  is3D: true,
  pal: {
    body: "#a5f3fc",
    dark: "#0ea5e9",
    belly: "#e0f2fe",
    fin: "#c084fc",
    tail: "#67e8f9",
    outline: "#083344",
  },
  minR: 15,
  maxR: 20,
  speed: 18,
  predator: false,
  weight: 0,
};

const decorPose: Fish3DPose = {
  jaw: 0,
  chompPhase: 0,
  chompDur: 0,
  chompBitFired: false,
  biteLunge: 0,
  tailPh: 0,
  wag2: 0,
  bend: 0,
  turnFlip: 1,
  turnVel: 0,
  boostAmt: 0,
  tilt: 0,
  gulpT: 0,
  gulpK: 0,
  swallowT: 0,
  gulpColor: "",
  gulpTailColor: "",
  sq: 0,
  expr: "normal",
  puff: false,
  sucking: false,
  swimSpeed: 0.45,
  depthFactor: 0,
  lightingAfter: false,
  sunBeam: 0,
  caustic: 0,
  ventWarm: 0,
  lampCool: 0,
};

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export class Decor3DManager {
  items: Decor3DCreature[] = [];

  reset(ocean: Ocean, isInsideRock: (x: number, y: number, pad: number) => boolean) {
    this.items = [];
    let seq = 1;

    // 1. 11 x Penari Spanyol (Spanish Dancer) dancing gracefully over reef crowns & upper-mid corals
    const reefForms = ocean.formations.filter((f) => f.zone <= 1 && f.rx > 80);
    for (let i = 0; i < 11; i++) {
      let x = 220 + (i / 11) * (WORLD_W - 440) + (Math.random() - 0.5) * 180;
      let y = 320 + Math.random() * 820;
      if (reefForms.length) {
        const f = reefForms[(i * 3 + Math.floor(Math.random() * reefForms.length)) % reefForms.length];
        const col = Math.round(f.cxl + (Math.random() - 0.5) * f.rx * 1.1);
        const cx = clamp(col, 0, Math.max(0, f.top.length - 1));
        const topY = f.top[cx];
        if (topY >= 0) {
          x = clamp(f.x + cx, 120, WORLD_W - 120);
          y = clamp(f.y + topY - (48 + Math.random() * 56), 140, 1280);
        }
      }
      if (isInsideRock(x, y, 28)) y = Math.max(130, y - 95);
      const face: 1 | -1 = Math.random() < 0.5 ? 1 : -1;
      this.items.push({
        id: seq++,
        kind: "spanish_dancer",
        x,
        y,
        vx: face * 24,
        vy: 0,
        r: 16 + Math.random() * 4,
        face,
        turnFlip: face,
        tilt: 0,
        ph: Math.random() * Math.PI * 2,
        tx: clamp(x + face * 220, 120, WORLD_W - 120),
        ty: clamp(y + (Math.random() - 0.5) * 90, 140, 1320),
        timer: 3 + Math.random() * 4,
      });
    }

    // 2. 13 x Ubur-Ubur Sisir (Comb Jelly / Ctenophora) drifting in Zona Malam & Palung Abisal
    for (let i = 0; i < 13; i++) {
      let x = 180 + (i / 13) * (WORLD_W - 360) + (Math.random() - 0.5) * 160;
      let y = 1180 + Math.random() * (WORLD_H - 1380);
      for (let tries = 0; tries < 14; tries++) {
        if (!isInsideRock(x, y, 30)) break;
        x = 180 + Math.random() * (WORLD_W - 360);
        y = 1150 + Math.random() * (WORLD_H - 1350);
      }
      y = clamp(y, 1100, floorY(x) - 85);
      this.items.push({
        id: seq++,
        kind: "comb_jelly",
        x,
        y,
        vx: (Math.random() - 0.5) * 14,
        vy: (Math.random() - 0.5) * 10,
        r: 17 + Math.random() * 4.5,
        face: 1,
        turnFlip: 1,
        tilt: 0,
        ph: Math.random() * Math.PI * 2,
        tx: clamp(x + (Math.random() - 0.5) * 260, 120, WORLD_W - 120),
        ty: clamp(y + (Math.random() - 0.5) * 180, 1080, floorY(x) - 85),
        timer: 4 + Math.random() * 5,
      });
    }
  }

  update(dt: number, t: number, ocean: Ocean) {
    for (const d of this.items) {
      d.timer -= dt;
      const isDancer = d.kind === "spanish_dancer";
      if (d.timer <= 0 || Math.hypot(d.tx - d.x, d.ty - d.y) < 28) {
        d.tx = clamp(d.x + (Math.random() - 0.5) * (isDancer ? 480 : 320), 100, WORLD_W - 100);
        const minY = isDancer ? 140 : 1080;
        const maxY = Math.min(isDancer ? 1320 : WORLD_H - 95, floorY(d.tx) - 68);
        d.ty = clamp(d.y + (Math.random() - 0.5) * (isDancer ? 180 : 240), minY, Math.max(minY + 30, maxY));
        d.timer = 4 + Math.random() * 4.5;
      }

      const dx = d.tx - d.x;
      const dy = d.ty - d.y;
      const dist = Math.hypot(dx, dy) || 1;
      const spd = isDancer ? 28 : 14;
      const bob = isDancer ? Math.sin(t * 2.4 + d.ph) * 9 : Math.sin(t * 1.4 + d.ph) * 6;
      d.vx += ((dx / dist) * spd - d.vx) * Math.min(1, dt * 1.4);
      d.vy += ((dy / dist) * spd * 0.65 + bob - d.vy) * Math.min(1, dt * 1.4);

      d.x += d.vx * dt;
      d.y += d.vy * dt;

      for (const form of ocean.formations) {
        const pad = d.r + 16;
        if (d.x < form.x - pad || d.x > form.x + form.w + pad || d.y < form.y - pad || d.y > form.y + form.h + pad) {
          continue;
        }
        const hit = ocean.sampleRockSDF(form, d.x, d.y, false);
        if (hit.dist < pad) {
          const pen = pad - hit.dist;
          d.x += hit.nx * pen;
          d.y += hit.ny * pen;
          d.vx += hit.nx * 24 * dt;
          d.vy += hit.ny * 24 * dt;
        }
      }

      d.x = clamp(d.x, 80, WORLD_W - 80);
      const fy = floorY(d.x);
      d.y = clamp(d.y, isDancer ? 110 : 1020, fy - 58);

      if (isDancer) {
        if (Math.abs(d.vx) > 3) d.face = d.vx >= 0 ? 1 : -1;
        d.turnFlip += (d.face - d.turnFlip) * Math.min(1, dt * 4.5);
        const targetTilt = clamp((d.vy / Math.max(25, Math.abs(d.vx))) * 0.22 * d.face, -0.32, 0.32);
        d.tilt += (targetTilt - d.tilt) * Math.min(1, dt * 5);
      } else {
        d.face = 1;
        d.turnFlip = 1;
        d.tilt = clamp(d.vx * 0.014, -0.24, 0.24) + Math.sin(t * 1.1 + d.ph) * 0.08;
      }
    }
  }

  draw(
    ctx: CanvasRenderingContext2D,
    camLeft: number,
    camTop: number,
    vw: number,
    vh: number,
    t: number,
    S0: number,
    dancerHalo: HTMLCanvasElement,
    combHalo: HTMLCanvasElement,
    litAfter: boolean,
    sampleLight: (wx: number, wy: number) => { sunBeam: number; caustic: number; ventWarm: number; lampCool: number; subWarm: number } | null
  ) {
    for (const d of this.items) {
      const sx = d.x - camLeft;
      const sy = d.y - camTop;
      const m = d.r * 3.0 + 36;
      if (sx < -m || sx > vw + m || sy < -m || sy > vh + m) continue;

      const isDancer = d.kind === "spanish_dancer";
      const halo = isDancer ? dancerHalo : combHalo;
      const hr = d.r * (isDancer ? 2.1 : 2.55);

      ctx.save();
      ctx.setTransform(S0, 0, 0, S0, 0, 0);
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = isDancer ? 0.22 + Math.sin(t * 3.0 + d.ph) * 0.06 : 0.34 + Math.sin(t * 2.5 + d.ph) * 0.12;
      ctx.drawImage(halo, sx - hr, sy - hr, hr * 2, hr * 2);
      ctx.restore();

      const ol = litAfter ? sampleLight(d.x, d.y) : null;
      decorPose.tailPh = t * 3.4 + d.ph;
      decorPose.wag2 = t * 5.0 + d.ph;
      decorPose.turnFlip = isDancer ? (Math.abs(d.turnFlip) < 0.22 ? (d.turnFlip >= 0 ? 0.22 : -0.22) : d.turnFlip) : 1;
      decorPose.tilt = d.tilt;
      decorPose.swimSpeed = isDancer ? 0.65 : 0.3;
      decorPose.depthFactor = clamp((d.y - 350) / 1400, 0, 1);
      decorPose.lightingAfter = litAfter;
      decorPose.sunBeam = ol ? ol.sunBeam : 0;
      decorPose.caustic = ol ? ol.caustic : 0;
      decorPose.ventWarm = ol ? clamp(ol.ventWarm + ol.subWarm * 0.72, 0, 1) : 0;
      decorPose.lampCool = ol ? ol.lampCool : 0;

      const worldSpan = d.r * (isDancer ? 3.55 : 3.25);
      ctx.save();
      ctx.setTransform(S0, 0, 0, S0, sx * S0, sy * S0);
      fish3d.renderToCanvas(
        isDancer ? SPANISH_DANCER_SP : COMB_JELLY_SP,
        ctx,
        -worldSpan * 0.5,
        -worldSpan * 0.5,
        worldSpan,
        worldSpan,
        decorPose,
        worldSpan * S0 * 1.15
      );
      ctx.restore();
    }
  }
}
