import { fish3d } from "./fish3d";
import type { Fish3DPose } from "./fish3d";
import type { Species } from "./species";

export interface SunfishBite {
  /** Bite crater center in Sunfish 3D body space (+x = front/snout, +y = top/dorsal) */
  x: number;
  y: number;
  /** Bite crater radius in Sunfish 3D local units */
  r: number;
  /** Tooth-scallop angular seed */
  seed: number;
}

export interface SunfishBonus {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: 6 | 5 | 4 | 3 | 2 | 1;
  maxHp: 6;
  bites: SunfishBite[];
  face: 1 | -1;
  turnFlip: number;
  tilt: number;
  ph: number;
  tx: number;
  ty: number;
  timer: number;
  biteCd: number;
  hurtFlash: number;
  panicT: number;
  wobbleV: number;
  dead: boolean;
}

/**
 * Signed distance to the combined directional bite craters (matches GPU GLSL sunfishBiteSDF).
 * Negative values are inside carved/eaten space.
 */
export function sunfishBiteSdfCPU(
  bites: ReadonlyArray<SunfishBite>,
  px: number,
  py: number
): number {
  let minD = 10;
  for (let i = 0; i < bites.length; i++) {
    const b = bites[i];
    if (b.r <= 0.001) continue;
    const dx = px - b.x;
    const dy = py - b.y;
    const dist = Math.hypot(dx, dy);
    const ang = dist > 0.0001 ? Math.atan2(dy, dx) : 0;
    const arc = 1 - Math.abs(Math.sin(ang * 6.5 + b.seed * 5));
    const effR = b.r + (arc - 0.42) * (b.r * 0.13);
    const d = dist - effR;
    if (d < minD) minD = d;
  }
  return minD;
}

function estimateSunfishRimDist(ux: number, uy: number): number {
  const ellipR = 1 / Math.hypot(ux / 0.228, uy / 0.212);
  let finBump = 0;
  if (uy > 0.42 && ux < 0.25) {
    const k = Math.min(1, (uy - 0.42) / 0.48) * (1 - Math.min(1, Math.abs(ux + 0.32) / 0.58));
    finBump = Math.max(finBump, k * 0.072);
  }
  if (uy < -0.42 && ux < 0.25) {
    const k = Math.min(1, (-uy - 0.42) / 0.48) * (1 - Math.min(1, Math.abs(ux + 0.3) / 0.58));
    finBump = Math.max(finBump, k * 0.068);
  }
  if (ux < -0.58) {
    const k = Math.min(1, (-ux - 0.58) / 0.35);
    finBump = Math.max(finBump, k * 0.036);
  }
  return ellipR + finBump;
}

/**
 * Computes a 3D bite crater aligned to the exact incoming attack direction (ux, uy)
 * in Sunfish local body space (+x = snout, +y = dorsal). If that perimeter edge was
 * already eaten by an earlier bite, marches inward or sweeps neighboring arcs on the
 * same attack side so every single bite visibly removes a fresh chunk.
 */
export function computeDirectionalSunfishBite(
  existingBites: ReadonlyArray<SunfishBite>,
  dirX: number,
  dirY: number,
  biteIndex: number
): SunfishBite {
  const len = Math.hypot(dirX, dirY) || 1;
  const baseUx = dirX / len;
  const baseUy = dirY / len;
  const baseAng = Math.atan2(baseUy, baseUx);
  const br = 0.114 + Math.min(4, biteIndex) * 0.0045 + (Math.random() - 0.5) * 0.008;

  const angleOffsets = [0, 0.34, -0.34, 0.68, -0.68];
  for (const off of angleOffsets) {
    const a = baseAng + off;
    const ux = Math.cos(a);
    const uy = Math.sin(a);
    const rRim = estimateSunfishRimDist(ux, uy);

    for (let dist = rRim; dist >= 0.018; dist -= 0.022) {
      const cx = ux * dist;
      const cy = uy * dist;
      const probeDist = Math.max(-0.08, dist - br * 0.36);
      const px = ux * probeDist;
      const py = uy * probeDist;
      if (sunfishBiteSdfCPU(existingBites, px, py) > 0.024) {
        return {
          x: cx,
          y: cy,
          r: br,
          seed: Math.random() * Math.PI * 2,
        };
      }
    }
  }

  // Fallback: deeper core bite along the incoming vector
  const rim = estimateSunfishRimDist(baseUx, baseUy) * 0.42;
  return {
    x: baseUx * rim,
    y: baseUy * rim,
    r: br * 1.08,
    seed: Math.random() * Math.PI * 2,
  };
}

const SUNFISH_SPECIES: Species = {
  id: "bonus-sunfish",
  variant: "mola6",
  name: "Sunfish Mola-Mola",
  style: "sunfish",
  hRatio: 0.96,
  eye: 0.28,
  blush: false,
  angry: false,
  teeth: false,
  stripes: [],
  spots: true,
  is3D: true,
  pal: {
    body: "#8eb6d6",
    dark: "#466e99",
    belly: "#eef8ff",
    fin: "#4b749f",
    tail: "#7da7c9",
    outline: "#16304d",
    iris: "#38bdf8",
    spot: "#e0f2fe",
  },
  minR: 46,
  maxR: 55,
  speed: 40,
  predator: false,
  weight: 0,
};

export function getSunfishSpecies(): Species {
  return SUNFISH_SPECIES;
}

const sunfishPose: Fish3DPose = {
  jaw: 0,
  chompPhase: 0,
  chompDur: 0,
  chompBitFired: false,
  biteLunge: 0,
  tailPh: 0,
  wag2: 0,
  bend: 0,
  turnFlip: 1,
  turnVel: 0,
  boostAmt: 0,
  tilt: 0,
  gulpT: 0,
  gulpK: 0,
  swallowT: 0,
  gulpColor: "",
  gulpTailColor: "",
  sq: 0,
  expr: "normal",
  puff: false,
  sucking: false,
  swimSpeed: 0.5,
  depthFactor: 0,
  lightingAfter: false,
  sunBeam: 0,
  caustic: 0,
  ventWarm: 0,
  lampCool: 0,
  sunfishBites: [],
};

export interface SunfishLightSample {
  sunBeam: number;
  caustic: number;
  ventWarm: number;
  lampCool: number;
  subWarm?: number;
}

export function drawSunfish(
  ctx: CanvasRenderingContext2D,
  sf: SunfishBonus,
  camLeft: number,
  camTop: number,
  t: number,
  S0: number,
  haloImg: HTMLCanvasElement,
  litAfter: boolean,
  ol: SunfishLightSample | null
) {
  const sx = sf.x - camLeft;
  const sy = sf.y - camTop;

  // Soft shimmering golden-aqua Food Bonus aura behind 3D Sunfish
  const pulse = 1 + Math.sin(t * 3.8 + sf.ph) * 0.07;
  const hr = sf.r * 2.3 * pulse;
  ctx.save();
  ctx.setTransform(S0, 0, 0, S0, 0, 0);
  ctx.globalCompositeOperation = "lighter";
  ctx.globalAlpha = sf.hurtFlash > 0 ? 0.62 : 0.24 + Math.sin(t * 3.1 + sf.ph) * 0.08;
  ctx.drawImage(haloImg, sx - hr, sy - hr, hr * 2, hr * 2);
  ctx.restore();

  const spd = Math.hypot(sf.vx, sf.vy);
  const swim = Math.min(1, spd / 110);
  const tailRate = sf.panicT > 0 ? 9.5 : 3.8;
  sunfishPose.tailPh = t * tailRate + sf.ph;
  sunfishPose.wag2 = t * 5.2 + sf.ph;
  sunfishPose.turnFlip = Math.abs(sf.turnFlip) < 0.22 ? (sf.turnFlip >= 0 ? 0.22 : -0.22) : sf.turnFlip;
  sunfishPose.tilt = sf.tilt;
  sunfishPose.swimSpeed = swim;
  sunfishPose.boostAmt = sf.panicT > 0 ? 0.65 : 0;
  sunfishPose.sq = sf.hurtFlash > 0 ? Math.sin(sf.hurtFlash * 35) * 0.22 : 0;
  sunfishPose.expr = sf.hurtFlash > 0 || sf.panicT > 0.4 ? "panic" : "normal";
  sunfishPose.depthFactor = Math.max(0, Math.min(1, (sf.y - 350) / 1400));
  sunfishPose.lightingAfter = litAfter;
  sunfishPose.sunBeam = ol ? ol.sunBeam : 0;
  sunfishPose.caustic = ol ? ol.caustic : 0;
  sunfishPose.ventWarm = ol ? Math.min(1, ol.ventWarm + (ol.subWarm ?? 0) * 0.72) : 0;
  sunfishPose.lampCool = ol ? ol.lampCool : 0;
  sunfishPose.sunfishBites = sf.bites;

  const worldSpan = sf.r * 3.65;
  ctx.save();
  ctx.setTransform(S0, 0, 0, S0, sx * S0, sy * S0);
  fish3d.renderToCanvas(
    getSunfishSpecies(),
    ctx,
    -worldSpan * 0.5,
    -worldSpan * 0.5,
    worldSpan,
    worldSpan,
    sunfishPose,
    worldSpan * S0 * 1.18
  );
  ctx.restore();

}
