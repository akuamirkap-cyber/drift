import * as THREE from "three";
import type { Species } from "./species";
import {
  baseGroups,
  buildLoftedSurface,
  buildOutlineGeometry,
  clamp,
  computeEyeZ,
  createBiteRing,
  createEyePair,
  createExtrudedFin,
  createOralParts,
  createRigContext,
  createWorldMapper,
  drawGlow,
  injectSpineShader,
  interpCurveY,
  makeLin,
  makePaintedFinTex,
  mixHex,
  rgbaHex,
  sampleBezierChain,
  smoothstep,
  surfaceZAt,
} from "./fish3dShared";
import type { Fish3DRig, Pt } from "./fish3dShared";

function sortAscX(pts: Pt[]): Pt[] {
  return [...pts].sort((a, b) => a[0] - b[0]);
}

// =====================================================================================
// 1. SUNFISH / MOLA-MOLA (6-Bite Non-Playable Food Bonus, Dynamic Directional 3D Bites)
// =====================================================================================
function sunfishPointSdf(
  bites: ReadonlyArray<{ x: number; y: number; r: number; seed: number }>,
  px: number,
  py: number
): number {
  let minD = 10;
  for (let i = 0; i < bites.length; i++) {
    const b = bites[i];
    if (b.r <= 0.001) continue;
    const dx = px - b.x;
    const dy = py - b.y;
    const dist = Math.hypot(dx, dy);
    const ang = dist > 0.0001 ? Math.atan2(dy, dx) : 0;
    const arc = 1 - Math.abs(Math.sin(ang * 6.5 + b.seed * 5));
    const effR = b.r + (arc - 0.42) * (b.r * 0.13);
    const d = dist - effR;
    if (d < minD) minD = d;
  }
  return minD;
}

const SUNFISH_BITE_GLSL = `
uniform vec4 uBites[5];
float sunfishBiteSDF(vec2 p) {
  float minD = 10.0;
  for (int i = 0; i < 5; i++) {
    vec4 b = uBites[i];
    if (b.z > 0.001) {
      vec2 d = p - b.xy;
      float dist = length(d);
      float ang = (dist > 0.0001) ? atan(d.y, d.x) : 0.0;
      float arc = 1.0 - abs(sin(ang * 6.5 + b.w * 5.0));
      float effR = b.z + (arc - 0.42) * (b.z * 0.13);
      minD = min(minD, dist - effR);
    }
  }
  return minD;
}
`;

function injectSunfishBiteShader(
  mat: THREE.MeshStandardMaterial,
  uniforms: ReturnType<typeof createRigContext>["uniforms"],
  uBites: THREE.Vector4[],
  spineOffX: number,
  spineOffY: number,
  bodyOffX: number,
  bodyOffY: number,
  pinchZ: boolean,
  useSpine: boolean
) {
  mat.side = THREE.DoubleSide;
  mat.customProgramCacheKey = () =>
    `sunfish-bite-v2-${spineOffX.toFixed(3)}-${spineOffY.toFixed(3)}-${bodyOffX.toFixed(3)}-${bodyOffY.toFixed(3)}-${pinchZ ? 1 : 0}-${useSpine ? 1 : 0}`;
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTailPh = uniforms.uTailPh;
    shader.uniforms.uSwimAmp = uniforms.uSwimAmp;
    shader.uniforms.uBend = uniforms.uBend;
    shader.uniforms.uTurnBend = uniforms.uTurnBend;
    shader.uniforms.uBoost = uniforms.uBoost;
    shader.uniforms.uGulpT = uniforms.uGulpT;
    shader.uniforms.uGulpK = uniforms.uGulpK;
    shader.uniforms.uSquash = uniforms.uSquash;
    shader.uniforms.uPuff = uniforms.uPuff;
    shader.uniforms.uBites = { value: uBites };

    shader.vertexShader = shader.vertexShader
      .replace(
        "#include <common>",
        `#include <common>
        uniform float uTailPh;
        uniform float uSwimAmp;
        uniform float uBend;
        uniform float uTurnBend;
        uniform float uBoost;
        uniform float uGulpT;
        uniform float uGulpK;
        uniform float uSquash;
        uniform float uPuff;
        varying vec2 vSunBodyXY;
        ${SUNFISH_BITE_GLSL}`
      )
      .replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
        vec2 sfPos = vec2(transformed.x + (${bodyOffX.toFixed(4)}), transformed.y + (${bodyOffY.toFixed(4)}));
        vSunBodyXY = sfPos;
        ${
          pinchZ
            ? `float bSdfV = sunfishBiteSDF(sfPos);
        float pinchV = smoothstep(0.002, 0.036, bSdfV);
        transformed.z *= pinchV;`
            : ""
        }
        ${
          useSpine
            ? `float wx = transformed.x + (${spineOffX.toFixed(4)});
        float wy = transformed.y + (${spineOffY.toFixed(4)});
        float bAmt = clamp(uBoost, 0.0, 1.0);
        float rear40 = clamp((0.08 - wx) / 0.34, 0.0, 1.0);
        float rearCurve = mix(rear40 * rear40, pow(rear40, 1.24), bAmt);
        float turnT = clamp((0.22 - wx) / 0.48, 0.0, 1.0);
        float turnCurve = pow(turnT, 1.45);
        float waveFreq = mix(8.0, 11.2, bAmt);
        float sWave = sin(uTailPh - (0.08 - wx) * waveFreq) * uSwimAmp;
        float dz = rearCurve * sWave + turnCurve * (uTurnBend * 0.28 + uBend * 0.16);
        transformed.z += dz;
        transformed.x -= min(0.055, dz * dz * 1.35) * turnT;`
            : ""
        }`
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
        varying vec2 vSunBodyXY;
        ${SUNFISH_BITE_GLSL}`
      )
      .replace(
        "#include <clipping_planes_fragment>",
        `#include <clipping_planes_fragment>
        float sfSdf = sunfishBiteSDF(vSunBodyXY);
        if (sfSdf < 0.0) discard;`
      )
      .replace(
        "#include <color_fragment>",
        `#include <color_fragment>
        if (sfSdf < 0.028) {
          float meatBlend = smoothstep(0.028, 0.013, sfSdf);
          float boneRim = smoothstep(0.014, 0.0085, sfSdf) * smoothstep(0.0032, 0.0068, sfSdf);
          float darkInk = smoothstep(0.0042, 0.0014, sfSdf);
          vec3 pinkMeat = vec3(0.985, 0.58, 0.65);
          vec3 ivoryRim = vec3(1.0, 0.94, 0.95);
          vec3 inkOutline = vec3(0.086, 0.188, 0.302);
          vec3 cutCol = mix(pinkMeat, ivoryRim, boneRim * 0.85);
          diffuseColor.rgb = mix(diffuseColor.rgb, cutCol, meatBlend);
          diffuseColor.rgb = mix(diffuseColor.rgb, inkOutline, darkInk * 0.94);
        }
        if (!gl_FrontFacing) {
          diffuseColor.rgb = vec3(0.96, 0.54, 0.62);
        }`
      )
      .replace(
        "#include <emissivemap_fragment>",
        `#include <emissivemap_fragment>
        if (sfSdf < 0.026) {
          float meatMixE = smoothstep(0.026, 0.011, sfSdf);
          float edgeInkE = smoothstep(0.0042, 0.0015, sfSdf);
          vec3 fleshEmit = vec3(0.99, 0.64, 0.69) * 0.24;
          totalEmissiveRadiance = mix(totalEmissiveRadiance, fleshEmit, meatMixE);
          totalEmissiveRadiance *= (1.0 - edgeInkE * 0.92);
        }
        if (!gl_FrontFacing) {
          totalEmissiveRadiance = vec3(0.96, 0.56, 0.64) * 0.28;
        }`
      );
  };
}

function createSunfish3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#16304d";
  const BACK = pal.dark || "#466e99";
  const BODY = pal.body || "#8eb6d6";
  const BEL = pal.belly || "#eef8ff";
  const FIN = pal.fin || "#4b749f";

  const ctx = createRigContext(OL, "#565656");
  const { track, uniforms, makeFishMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  const uBites: THREE.Vector4[] = [
    new THREE.Vector4(0, 0, -1, 0),
    new THREE.Vector4(0, 0, -1, 0),
    new THREE.Vector4(0, 0, -1, 0),
    new THREE.Vector4(0, 0, -1, 0),
    new THREE.Vector4(0, 0, -1, 0),
  ];

  const xTail = -0.235;
  const xSnout = 0.235;
  const spanX = xSnout - xTail;

  // Tall rounded disc profile with scalloped clavus edge along -X
  const evalTop = (x: number) => {
    const u = clamp((x - xTail) / spanX, 0, 1);
    const oval = Math.sin(Math.pow(clamp(u, 0.005, 0.995), 0.92) * Math.PI);
    const clavus = u < 0.16 ? 0.025 + Math.sin(u * 95) * 0.012 : 0;
    return Math.max(0.014, 0.215 * Math.pow(oval, 0.68) + clavus * (1 - u / 0.18));
  };

  const evalBot = (x: number) => {
    const u = clamp((x - xTail) / spanX, 0, 1);
    const oval = Math.sin(Math.pow(clamp(u, 0.005, 0.995), 0.92) * Math.PI);
    const clavus = u < 0.16 ? 0.022 + Math.cos(u * 90) * 0.011 : 0;
    return -Math.max(0.014, 0.210 * Math.pow(oval, 0.68) + clavus * (1 - u / 0.18));
  };

  const evalZ = (_x: number, t: number) =>
    Math.max(0.008, 0.014 + 0.072 * Math.sin(Math.pow(clamp(t, 0.01, 0.99), 0.8) * Math.PI));

  const { mapUV, beginCanvas2D } = createWorldMapper(-0.26, 0.26, -0.25, 0.25, 512);
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);

  bc.fillStyle = makeLin(bc, 0, -0.22, 0, 0.22, [
    [0, BACK],
    [0.34, BODY],
    [0.68, mixHex(BODY, BEL, 0.65)],
    [1, BEL],
  ]);
  bc.fillRect(-0.3, -0.3, 0.62, 0.62);

  // Dappled silver-pearl sunfish flank shimmer & golden belly tint
  const spots: [number, number, number, string][] = [
    [-0.08, -0.08, 0.028, "rgba(232,248,255,0.45)"],
    [-0.14, -0.02, 0.022, "rgba(232,248,255,0.38)"],
    [-0.06, 0.05, 0.032, "rgba(186,230,253,0.34)"],
    [-0.15, 0.08, 0.022, "rgba(255,250,210,0.34)"],
    [0.02, -0.11, 0.024, "rgba(255,250,210,0.38)"],
    [-0.19, -0.05, 0.018, "rgba(255,255,255,0.40)"],
  ];
  for (const [sx, sy, sr, col] of spots) {
    bc.fillStyle = col;
    bc.beginPath();
    bc.arc(sx, sy, sr, 0, Math.PI * 2);
    bc.fill();
  }
  drawGlow(bc, 0.04, 0.06, 0.14, 0.09, 0, "254,240,138", 0.30);

  // Rosy cheek & subtle gill crescent
  drawGlow(bc, 0.13, 0.03, 0.035, 0.024, 0, "251,146,160", 0.36);
  bc.strokeStyle = rgbaHex(OL, 0.45);
  bc.lineWidth = 0.005;
  bc.beginPath();
  bc.arc(0.082, 0.012, 0.055, -Math.PI * 0.32, Math.PI * 0.32);
  bc.stroke();

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const bodyGeo = track(
    buildLoftedSurface({
      xStart: xTail,
      xEnd: xSnout,
      uSteps: 58,
      vSteps: 38,
      evalTopY: evalTop,
      evalBotY: evalBot,
      evalHalfZ: evalZ,
      mapUV,
      roundFront: true,
      roundFrontStart: 0.85,
      roundFrontZ: true,
    })
  );
  const bodyMat = makeFishMat(bodyTex, { roughness: 0.42, emissiveIntensity: 0.22 });
  injectSunfishBiteShader(bodyMat, uniforms, uBites, 0.05, 0.05, 0, 0, true, true);
  const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
  bodyGroup.add(bodyMesh);

  // Scalloped Clavus Tail Rudder Blade along -X
  const clavusShape = new THREE.Shape();
  clavusShape.moveTo(0.01, 0.13);
  clavusShape.quadraticCurveTo(-0.055, 0.09, -0.025, 0.048);
  clavusShape.quadraticCurveTo(-0.068, 0.0, -0.025, -0.048);
  clavusShape.quadraticCurveTo(-0.055, -0.09, 0.01, -0.13);
  clavusShape.closePath();
  const { geo: clavusGeo, bounds: clavusBounds } = createExtrudedFin(clavusShape, 0.008, 0.0022, 14);
  track(clavusGeo);
  const clavusTex = track(
    makePaintedFinTex(maxAnisotropy, clavusBounds, (fc) => {
      fc.fillStyle = makeLin(fc, -0.06, 0, 0.02, 0, [
        [0, BACK],
        [0.5, BODY],
        [1, mixHex(BODY, BEL, 0.4)],
      ]);
      fc.fillRect(-0.08, -0.15, 0.12, 0.30);
    })
  );
  const clavusMat = makeFishMat(clavusTex, { roughness: 0.44 });
  injectSunfishBiteShader(clavusMat, uniforms, uBites, 0, 0, xTail + 0.016, 0, false, true);
  const tailPivot = new THREE.Group();
  tailPivot.position.set(xTail + 0.016, 0, 0);
  const clavusMesh = new THREE.Mesh(clavusGeo, clavusMat);
  tailPivot.add(clavusMesh);
  bodyGroup.add(tailPivot);

  // Iconic Tall Swept 3D Dorsal & Anal Blade Fins (animated side-to-side flapping!)
  const dorsalShape = new THREE.Shape();
  dorsalShape.moveTo(0.036, 0);
  dorsalShape.bezierCurveTo(-0.02, 0.11, -0.065, 0.21, -0.112, 0.242);
  dorsalShape.bezierCurveTo(-0.105, 0.15, -0.088, 0.06, -0.072, -0.008);
  dorsalShape.closePath();
  const { geo: dorsalGeo, bounds: dorsalBounds } = createExtrudedFin(dorsalShape, 0.010, 0.0028, 16);
  track(dorsalGeo);
  const bladeTex = track(
    makePaintedFinTex(maxAnisotropy, dorsalBounds, (fc) => {
      fc.fillStyle = makeLin(fc, 0, 0, -0.1, 0.24, [
        [0, BODY],
        [0.5, FIN],
        [1, BACK],
      ]);
      fc.fillRect(-0.14, -0.02, 0.2, 0.28);
    })
  );
  const dorsalMat = makeFishMat(bladeTex, { roughness: 0.42 });
  injectSunfishBiteShader(dorsalMat, uniforms, uBites, 0, 0, -0.095, 0.155, false, false);
  const dorsalPivot = new THREE.Group();
  dorsalPivot.position.set(-0.095, 0.155, 0);
  const dorsalMesh = new THREE.Mesh(dorsalGeo, dorsalMat);
  dorsalPivot.add(dorsalMesh);
  bodyGroup.add(dorsalPivot);

  const analShape = new THREE.Shape();
  analShape.moveTo(0.036, 0);
  analShape.bezierCurveTo(-0.018, -0.105, -0.062, -0.20, -0.105, -0.232);
  analShape.bezierCurveTo(-0.098, -0.145, -0.082, -0.058, -0.068, 0.008);
  analShape.closePath();
  const { geo: analGeo } = createExtrudedFin(analShape, 0.010, 0.0028, 16);
  track(analGeo);
  const analMat = makeFishMat(bladeTex, { roughness: 0.42 });
  injectSunfishBiteShader(analMat, uniforms, uBites, 0, 0, -0.085, -0.152, false, false);
  const analPivot = new THREE.Group();
  analPivot.position.set(-0.085, -0.152, 0);
  const analMesh = new THREE.Mesh(analGeo, analMat);
  analPivot.add(analMesh);
  bodyGroup.add(analPivot);

  // Cute Pectoral Paddle Fins
  const pecShape = new THREE.Shape();
  pecShape.moveTo(0, 0.014);
  pecShape.bezierCurveTo(-0.036, 0.034, -0.068, 0.014, -0.064, -0.012);
  pecShape.bezierCurveTo(-0.048, -0.034, -0.016, -0.028, 0, -0.012);
  pecShape.closePath();
  const { geo: pecGeo, bounds: pecBounds } = createExtrudedFin(pecShape, 0.004, 0.0012, 12);
  track(pecGeo);
  const pecTex = track(
    makePaintedFinTex(maxAnisotropy, pecBounds, (fc) => {
      fc.fillStyle = "#bae6fd";
      fc.fillRect(-0.08, -0.05, 0.1, 0.1);
    })
  );
  const pecMat = makeFishMat(pecTex, { roughness: 0.42 });
  injectSunfishBiteShader(pecMat, uniforms, uBites, 0, 0, 0.04, -0.02, false, false);
  const pecZ = surfaceZAt((x) => evalZ(x, (x - xTail) / spanX), evalTop, evalBot, 0.04, -0.02) + 0.004;
  const pecLeft = new THREE.Group();
  pecLeft.position.set(0.04, -0.02, pecZ);
  const pLm = new THREE.Mesh(pecGeo, pecMat);
  pLm.rotation.y = -0.35;
  pecLeft.add(pLm);
  const pecRight = new THREE.Group();
  pecRight.position.set(0.04, -0.02, -pecZ);
  const pRm = new THREE.Mesh(pecGeo, pecMat);
  pRm.rotation.y = 0.35;
  pecRight.add(pRm);
  bodyGroup.add(pecLeft, pecRight);

  const pelvicFin = new THREE.Group();
  bodyGroup.add(pelvicFin);

  // Cute puckered coral lips at front snout
  const lipGeo = track(new THREE.TorusGeometry(0.016, 0.007, 10, 20));
  const lipMat = track(
    new THREE.MeshStandardMaterial({
      color: "#fca5a5",
      roughness: 0.48,
      emissive: "#fb7185",
      emissiveIntensity: 0.18,
    })
  );
  injectSunfishBiteShader(lipMat, uniforms, uBites, 0, 0, xSnout - 0.004, -0.004, false, false);
  const lipMesh = new THREE.Mesh(lipGeo, lipMat);
  lipMesh.position.set(xSnout - 0.004, -0.004, 0);
  lipMesh.rotation.y = Math.PI * 0.5;
  bodyGroup.add(lipMesh);

  const upperJawGroup = new THREE.Group();
  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(xSnout - 0.024, -0.01, 0);
  bodyGroup.add(upperJawGroup, lowerJawGroup);
  const { mouthInterior, tongueMesh } = createOralParts(
    ctx,
    bodyGroup,
    lowerJawGroup,
    xSnout - 0.015,
    -0.005,
    "#7f1d1d",
    "#fda4af",
    [0.024, 0.02, 0.018],
    [0.015, 0.008, 0.012],
    0.018
  );

  // Expressive Mola-mola Eyes
  const ez = computeEyeZ(evalTop, evalBot, (x) => evalZ(x, (x - xTail) / spanX), 0.135, 0.046, 0.036);
  const { eyesNormal, eyesPupil, eyesHappy } = createEyePair(ctx, bodyGroup, {
    ex: 0.135,
    ey: 0.046,
    ez,
    er: 0.036,
    sx: 0.96,
    yawRot: 0.25,
    irisColor: pal.iris || "#38bdf8",
    rimColor: OL,
    happyColor: "#fde047",
  });

  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, xSnout + 0.01, 0, "#7dd3fc", 0.046);

  return {
    speciesKey: sp.id + "|" + (sp.variant || "mola6"),
    tailPivotX: xTail + 0.016,
    skipDefaultFins: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p) => {
      const bites = p.sunfishBites ?? [];
      for (let i = 0; i < 5; i++) {
        if (i < bites.length) {
          const b = bites[i];
          uBites[i].set(b.x, b.y, b.r, b.seed);
        } else {
          uBites[i].set(0, 0, -1, 0);
        }
      }

      const lipEaten = bites.length > 0 && sunfishPointSdf(bites, xSnout - 0.004, -0.004) < 0.008;
      lipMesh.visible = !lipEaten;

      const eyeEaten = bites.length > 0 && sunfishPointSdf(bites, 0.135, 0.046) < 0.01;
      for (let i = 0; i < eyesNormal.length; i++) {
        eyesNormal[i].userData.bittenOff = eyeEaten;
      }

      // Iconic Mola-mola sculling motion: dorsal & anal blade fins sweep side-to-side smoothly
      const flap = Math.sin(p.tailPh * 1.15);
      dorsalPivot.rotation.x = flap * (0.28 + p.swimSpeed * 0.18);
      analPivot.rotation.x = -flap * (0.28 + p.swimSpeed * 0.18);
      pecLeft.rotation.y = Math.sin(p.wag2 * 1.6) * 0.34;
      pecRight.rotation.y = -Math.sin(p.wag2 * 1.6) * 0.34;
      lipMesh.scale.setScalar(1 + Math.sin(p.wag2 * 0.9) * 0.06);
      mouthInterior.visible = false;
      tongueMesh.visible = false;
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 2. GURITA CINCIN BIRU / BLUE-RINGED OCTOPUS (Playable Pure-3D Hero Creature)
// =====================================================================================
function createOctopus3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#3b1d02";
  const GOLD = pal.body || "#f4b41a";
  const DARK = pal.dark || "#a15807";
  const CREAM = pal.belly || "#ffe8a3";
  const RING_CYAN = pal.fin || "#00f2ff";
  const RING_DEEP = pal.stripe || "#1e1b4b";

  const ctx = createRigContext(OL, "#525252");
  const { track, uniforms, makeOutlineMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  // ===================================================================================
  // 1. TENTACLE CURVE DEFINITIONS FIRST (So 3D SDF Metaball Roots Merge 1:1 With Arms!)
  // ===================================================================================
  const ARM_ARC_LEN = 0.78;
  const U_SEGS = 52;
  const V_SEGS = 16;
  const SUCKER_TS = [0.22, 0.29, 0.36, 0.43, 0.50, 0.57, 0.64, 0.71, 0.78, 0.85];

  const resampleExactLen = (rawPts: THREE.Vector3[], targetLen: number): THREE.CatmullRomCurve3 => {
    const baseCurve = new THREE.CatmullRomCurve3(rawPts);
    const baseLen = Math.max(1e-4, baseCurve.getLength());
    const scale = targetLen / baseLen;
    const uniformPts: THREE.Vector3[] = [];
    for (let i = 0; i <= 16; i++) {
      uniformPts.push(baseCurve.getPointAt(i / 16).multiplyScalar(scale));
    }
    return new THREE.CatmullRomCurve3(uniformPts);
  };

  const makeArmCurves = (variant: 0 | 1 | 2 | 3, feedSide = 0) => {
    // Shared diagonal neck-collar root (0,0,0) -> (0.048,-0.084,0) so metaball socket stays identical across ALL poses!
    const restRaw =
      variant === 0
        ? [
            new THREE.Vector3(0, 0, 0),
            new THREE.Vector3(0.048, -0.084, 0),
            new THREE.Vector3(0.145, -0.195, 0.032),
            new THREE.Vector3(0.265, -0.310, -0.025),
            new THREE.Vector3(0.375, -0.385, -0.038),
            new THREE.Vector3(0.445, -0.365, 0.015),
          ]
        : variant === 1
          ? [
              new THREE.Vector3(0, 0, 0),
              new THREE.Vector3(0.048, -0.084, 0),
              new THREE.Vector3(0.118, -0.215, -0.024),
              new THREE.Vector3(0.185, -0.365, 0.026),
              new THREE.Vector3(0.255, -0.465, 0.036),
              new THREE.Vector3(0.310, -0.455, -0.022),
            ]
          : variant === 3
            ? [
                new THREE.Vector3(0, 0, 0),
                new THREE.Vector3(0.048, -0.084, 0),
                new THREE.Vector3(0.145, -0.205, 0.036),
                new THREE.Vector3(0.255, -0.320, 0.052),
                new THREE.Vector3(0.345, -0.365, -0.024),
                new THREE.Vector3(0.395, -0.320, -0.052),
              ]
            : [
                new THREE.Vector3(0, 0, 0),
                new THREE.Vector3(0.048, -0.084, 0),
                new THREE.Vector3(0.145, -0.195, feedSide * 0.042),
                new THREE.Vector3(0.270, -0.265, feedSide * 0.072),
                new THREE.Vector3(0.375, -0.245, feedSide * 0.058),
                new THREE.Vector3(0.435, -0.305, feedSide * 0.018),
              ];

    const zBias = variant === 0 ? 1.0 : variant === 1 ? -1.0 : variant === 3 ? 0.72 : (feedSide || 0.85);
    const swimRaw = [
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0.048, -0.084, 0),
      new THREE.Vector3(0.168, -0.118, zBias * 0.026),
      new THREE.Vector3(0.325, -0.148, -zBias * 0.036),
      new THREE.Vector3(0.490, -0.178, zBias * 0.028),
      new THREE.Vector3(0.645, -0.205, -zBias * 0.016),
    ];

    const restCurve = resampleExactLen(restRaw, ARM_ARC_LEN);
    const swimCurve = resampleExactLen(swimRaw, ARM_ARC_LEN);
    let reachCurve: THREE.CatmullRomCurve3 | null = null;
    let pullCurve: THREE.CatmullRomCurve3 | null = null;
    if (variant === 2) {
      // 2 front feeding arms bow slightly outward to scoop, then wrap INWARD to pinch & clasp prey in front!
      reachCurve = resampleExactLen(
        [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0.048, -0.084, 0),
          new THREE.Vector3(0.214, -0.085, feedSide * 0.055),
          new THREE.Vector3(0.293, -0.055, -feedSide * 0.059),
          new THREE.Vector3(0.273, -0.045, -feedSide * 0.172),
          new THREE.Vector3(0.192, -0.035, -feedSide * 0.156),
        ],
        ARM_ARC_LEN
      );
      // Sweeps & tucks clasped prey inward and UP into the hidden beak underneath the head!
      pullCurve = resampleExactLen(
        [
          new THREE.Vector3(0, 0, 0),
          new THREE.Vector3(0.048, -0.084, 0),
          new THREE.Vector3(0.110, -0.185, feedSide * 0.035),
          new THREE.Vector3(0.045, -0.245, -feedSide * 0.040),
          new THREE.Vector3(-0.065, -0.180, -feedSide * 0.095),
          new THREE.Vector3(-0.140, -0.115, -feedSide * 0.075),
        ],
        ARM_ARC_LEN
      );
    }
    return { restCurve, swimCurve, reachCurve, pullCurve };
  };

  // 8 arms anchored on a compact neck ring (cx=0.026, cy=0.015) flaring radially at ±25°, ±68°, ±110°, ±152°
  const armSpecs: Array<{
    ang: number;
    backAng: number;
    backLift: number;
    variant: 0 | 1 | 2 | 3;
    feedSide: number;
    phase: number;
  }> = [
    { ang: 2.66, backAng: 2.86, backLift: 0.14, variant: 0, feedSide: 0, phase: 0.0 },
    { ang: -2.66, backAng: -2.86, backLift: 0.14, variant: 0, feedSide: 0, phase: 3.14 },
    { ang: 1.92, backAng: 2.62, backLift: 0.44, variant: 1, feedSide: 0, phase: 1.55 },
    { ang: -1.92, backAng: -2.62, backLift: 0.44, variant: 1, feedSide: 0, phase: 4.70 },
    { ang: 1.18, backAng: 2.34, backLift: 0.24, variant: 3, feedSide: 0, phase: 0.82 },
    { ang: -1.18, backAng: -2.34, backLift: 0.24, variant: 3, feedSide: 0, phase: 3.96 },
    { ang: 0.44, backAng: 2.00, backLift: 0.28, variant: 2, feedSide: 1, phase: 0.45 },
    { ang: -0.44, backAng: -2.00, backLift: 0.28, variant: 2, feedSide: -1, phase: 2.65 },
  ];

  const armConfigs = armSpecs.map((s) => {
    const pos: [number, number, number] = [
      0.026 + Math.cos(s.ang) * 0.048,
      0.015,
      Math.sin(s.ang) * 0.044,
    ];
    return {
      ...s,
      pos,
      yaw: -s.ang, // Three.js Ry(-ang) maps +X to (+cos(ang), 0, +sin(ang))
      backSweep: s.backAng - s.ang,
      curves: makeArmCurves(s.variant, s.feedSide),
    };
  });

  // ===================================================================================
  // 2. TRUE 3D METABALL / MESHBALL MERGE SYSTEM (SDF Smooth-Union + Surface Nets + Newton)
  //    Plump Round Balloon Head + Smooth Neck + Webbing + 8 Merged Arm Sockets
  // ===================================================================================
  const xBack = -0.305;
  const { mapUV, beginCanvas2D } = createWorldMapper(-0.34, 0.28, -0.18, 0.44, 512);

  interface CapsuleSeg {
    ax: number; ay: number; az: number;
    bx: number; by: number; bz: number;
    dx: number; dy: number; dz: number;
    invLenSq: number;
    ra: number;
    rb: number;
  }

  const armRootChains: CapsuleSeg[][] = armConfigs.map((cfg) => {
    const euler = new THREE.Euler(0, cfg.yaw, 0, "XYZ");
    const ts = [0.0, 0.055, 0.110, 0.165, 0.215, 0.255];
    const pts: THREE.Vector3[] = [];
    const rads: number[] = [];
    for (let i = 0; i < ts.length; i++) {
      const t = ts[i];
      const lp = cfg.curves.restCurve.getPointAt(t).applyEuler(euler);
      lp.x += cfg.pos[0];
      lp.y += cfg.pos[1];
      lp.z += cfg.pos[2];
      pts.push(lp);
      const baseR = 0.047 * Math.pow(1 - t * 0.78, 0.72);
      // After t=0.215, tuck SDF root inside the emerging tentacle tube cleanly
      const capShrink = t > 0.215 ? 0.56 : 1.0;
      rads.push(baseR * capShrink);
    }
    const segs: CapsuleSeg[] = [];
    for (let i = 0; i < ts.length - 1; i++) {
      const a = pts[i];
      const b = pts[i + 1];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const dz = b.z - a.z;
      segs.push({
        ax: a.x, ay: a.y, az: a.z,
        bx: b.x, by: b.y, bz: b.z,
        dx, dy, dz,
        invLenSq: 1 / Math.max(1e-7, dx * dx + dy * dy + dz * dz),
        ra: rads[i],
        rb: rads[i + 1],
      });
    }
    return segs;
  });

  const sminPoly = (a: number, b: number, k: number) => {
    const h = Math.max(k - Math.abs(a - b), 0.0) / k;
    return Math.min(a, b) - h * h * k * 0.25;
  };

  const evalOctoSDF = (x: number, y: number, z: number): number => {
    // 1. Plump, chubby, round Balloon Head (centered at -0.045, +0.205, 0)
    const hx = x + 0.045;
    const hy = y - 0.205;
    const hz = z;
    const irx = 1 / 0.255;
    const iry = 1 / 0.200;
    const irz = 1 / 0.195;
    const k0 = Math.hypot(hx * irx, hy * iry, hz * irz);
    let dHead: number;
    if (k0 < 1e-6) {
      dHead = -0.195;
    } else {
      const k1 = Math.hypot(hx * irx * irx, hy * iry * iry, hz * irz * irz);
      dHead = (k0 * (k0 - 1.0)) / k1;
    }

    // 2. Smooth Hourglass Neck Capsule connecting balloon dome down to tentacle collar hub
    const nax = 0.028, nay = 0.004;
    const nbx = 0.005, nby = 0.150;
    const ndx = nbx - nax, ndy = nby - nay;
    const nt = clamp(((x - nax) * ndx + (y - nay) * ndy) / (ndx * ndx + ndy * ndy), 0, 1);
    const dNeck = Math.hypot(x - (nax + ndx * nt), y - (nay + ndy * nt), z) - 0.080;

    // Liquid smooth-union between Balloon Head & Neck
    const dBody = sminPoly(dHead, dNeck, 0.115);

    // 3. 8 Arm Shoulder Chains: exact min within each arm, smooth-union between arms + body
    let dArms = 10.0;
    if (y < 0.14) {
      for (let ai = 0; ai < armRootChains.length; ai++) {
        const segs = armRootChains[ai];
        let dArm = 10.0;
        for (let si = 0; si < segs.length; si++) {
          const s = segs[si];
          const t = clamp(
            ((x - s.ax) * s.dx + (y - s.ay) * s.dy + (z - s.az) * s.dz) * s.invLenSq,
            0,
            1
          );
          const dist = Math.hypot(
            x - (s.ax + s.dx * t),
            y - (s.ay + s.dy * t),
            z - (s.az + s.dz * t)
          );
          const r = s.ra + (s.rb - s.ra) * t;
          const ds = dist - r;
          if (ds < dArm) dArm = ds;
        }
        dArms = ai === 0 ? dArm : sminPoly(dArms, dArm, 0.064);
      }
      return sminPoly(dBody, dArms, 0.092);
    }
    return dBody;
  };

  const buildMetaballBodyGeo = (): THREE.BufferGeometry => {
    const nx = 46, ny = 48, nz = 38;
    const minX = -0.35, maxX = 0.26;
    const minY = -0.18, maxY = 0.44;
    const minZ = -0.25, maxZ = 0.25;
    const dx = (maxX - minX) / (nx - 1);
    const dy = (maxY - minY) / (ny - 1);
    const dz = (maxZ - minZ) / (nz - 1);

    const field = new Float32Array(nx * ny * nz);
    const idxAt = (i: number, j: number, k: number) => (k * ny + j) * nx + i;

    for (let k = 0; k < nz; k++) {
      const z = minZ + k * dz;
      for (let j = 0; j < ny; j++) {
        const y = minY + j * dy;
        for (let i = 0; i < nx; i++) {
          field[idxAt(i, j, k)] = evalOctoSDF(minX + i * dx, y, z);
        }
      }
    }

    const cNx = nx - 1, cNy = ny - 1, cNz = nz - 1;
    const cellVert = new Int32Array(cNx * cNy * cNz).fill(-1);
    const cIdx = (i: number, j: number, k: number) => (k * cNy + j) * cNx + i;

    const positions: number[] = [];
    const normals: number[] = [];
    const uvs: number[] = [];
    const edgeVerts: [number, number][] = [
      [0, 1], [2, 3], [4, 5], [6, 7],
      [0, 2], [1, 3], [4, 6], [5, 7],
      [0, 4], [1, 5], [2, 6], [3, 7],
    ];
    const cornerOff: [number, number, number][] = [
      [0, 0, 0], [1, 0, 0], [0, 1, 0], [1, 1, 0],
      [0, 0, 1], [1, 0, 1], [0, 1, 1], [1, 1, 1],
    ];
    const cornerVals = new Float32Array(8);
    const eps = 0.0022;

    for (let k = 0; k < cNz; k++) {
      for (let j = 0; j < cNy; j++) {
        for (let i = 0; i < cNx; i++) {
          let mask = 0;
          for (let c = 0; c < 8; c++) {
            const o = cornerOff[c];
            const v = field[idxAt(i + o[0], j + o[1], k + o[2])];
            cornerVals[c] = v;
            if (v < 0) mask |= 1 << c;
          }
          if (mask === 0 || mask === 255) continue;

          let sx = 0, sy = 0, sz = 0, hits = 0;
          for (let e = 0; e < 12; e++) {
            const [a, b] = edgeVerts[e];
            const va = cornerVals[a];
            const vb = cornerVals[b];
            if ((va < 0) === (vb < 0)) continue;
            const frac = va / (va - vb);
            const oa = cornerOff[a];
            const ob = cornerOff[b];
            sx += oa[0] + (ob[0] - oa[0]) * frac;
            sy += oa[1] + (ob[1] - oa[1]) * frac;
            sz += oa[2] + (ob[2] - oa[2]) * frac;
            hits++;
          }

          let px = minX + (i + sx / hits) * dx;
          let py = minY + (j + sy / hits) * dy;
          let pz = minZ + (k + sz / hits) * dz;

          // 2 Newton projection iterations onto exact zero-isosurface for sub-millimeter smoothness
          for (let it = 0; it < 2; it++) {
            const v = evalOctoSDF(px, py, pz);
            const gx = evalOctoSDF(px + eps, py, pz) - evalOctoSDF(px - eps, py, pz);
            const gy = evalOctoSDF(px, py + eps, pz) - evalOctoSDF(px, py - eps, pz);
            const gz = evalOctoSDF(px, py, pz + eps) - evalOctoSDF(px, py, pz - eps);
            const gl = Math.hypot(gx, gy, gz);
            if (gl > 1e-6) {
              const step = clamp(v / gl, -dx * 0.65, dx * 0.65);
              px -= (gx / gl) * step;
              py -= (gy / gl) * step;
              pz -= (gz / gl) * step;
            }
          }

          const gx = evalOctoSDF(px + eps, py, pz) - evalOctoSDF(px - eps, py, pz);
          const gy = evalOctoSDF(px, py + eps, pz) - evalOctoSDF(px, py - eps, pz);
          const gz = evalOctoSDF(px, py, pz + eps) - evalOctoSDF(px, py, pz - eps);
          const gl = Math.hypot(gx, gy, gz) || 1;

          const vIdx = positions.length / 3;
          cellVert[cIdx(i, j, k)] = vIdx;
          positions.push(px, py, pz);
          normals.push(gx / gl, gy / gl, gz / gl);
          const [tu, tv] = mapUV(px, py);
          uvs.push(tu, tv);
        }
      }
    }

    const indices: number[] = [];
    const emitQuad = (a: number, b: number, c: number, d: number, flip: boolean) => {
      if (a < 0 || b < 0 || c < 0 || d < 0) return;
      if (flip) {
        indices.push(a, c, b, a, d, c);
      } else {
        indices.push(a, b, c, a, c, d);
      }
    };

    for (let k = 1; k < nz - 1; k++) {
      for (let j = 1; j < ny - 1; j++) {
        for (let i = 1; i < nx - 1; i++) {
          const v0 = field[idxAt(i, j, k)];
          const s0 = v0 < 0;

          // X-edge (i -> i+1)
          const vx = field[idxAt(i + 1, j, k)];
          if (s0 !== (vx < 0)) {
            emitQuad(
              cellVert[cIdx(i, j - 1, k - 1)],
              cellVert[cIdx(i, j, k - 1)],
              cellVert[cIdx(i, j, k)],
              cellVert[cIdx(i, j - 1, k)],
              !s0
            );
          }
          // Y-edge (j -> j+1)
          const vy = field[idxAt(i, j + 1, k)];
          if (s0 !== (vy < 0)) {
            emitQuad(
              cellVert[cIdx(i - 1, j, k - 1)],
              cellVert[cIdx(i - 1, j, k)],
              cellVert[cIdx(i, j, k)],
              cellVert[cIdx(i, j, k - 1)],
              !s0
            );
          }
          // Z-edge (k -> k+1)
          const vz = field[idxAt(i, j, k + 1)];
          if (s0 !== (vz < 0)) {
            emitQuad(
              cellVert[cIdx(i - 1, j - 1, k)],
              cellVert[cIdx(i, j - 1, k)],
              cellVert[cIdx(i, j, k)],
              cellVert[cIdx(i - 1, j, k)],
              !s0
            );
          }
        }
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    return geo;
  };

  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);

  bc.fillStyle = makeLin(bc, -0.10, -0.36, 0.14, 0.14, [
    [0, DARK],
    [0.42, GOLD],
    [0.82, "#fbbf24"],
    [1, GOLD],
  ]);
  bc.fillRect(-0.42, -0.48, 0.80, 0.72);

  // Paint Blue-Ringed Octopus ocellated rings strictly onto the plump Balloon Dome (clean skin on neck/roots!)
  const emissiveCv = document.createElement("canvas");
  emissiveCv.width = 512;
  emissiveCv.height = 512;
  const ec = emissiveCv.getContext("2d")!;
  ec.fillStyle = "#000000";
  ec.fillRect(0, 0, 512, 512);
  beginCanvas2D(ec);

  const drawBlueRing = (rx: number, ry: number, rad: number) => {
    bc.save();
    bc.fillStyle = RING_DEEP;
    bc.beginPath();
    bc.arc(rx, ry, rad * 1.24, 0, Math.PI * 2);
    bc.fill();
    bc.strokeStyle = RING_CYAN;
    bc.lineWidth = rad * 0.42;
    bc.beginPath();
    bc.arc(rx, ry, rad * 0.72, 0, Math.PI * 2);
    bc.stroke();
    bc.fillStyle = GOLD;
    bc.beginPath();
    bc.arc(rx, ry, rad * 0.42, 0, Math.PI * 2);
    bc.fill();
    bc.restore();

    ec.save();
    ec.strokeStyle = RING_CYAN;
    ec.lineWidth = rad * 0.46;
    ec.beginPath();
    ec.arc(rx, ry, rad * 0.72, 0, Math.PI * 2);
    ec.stroke();
    ec.restore();
  };
  const mantleRings: [number, number, number][] = [
    [-0.20, -0.27, 0.041],
    [-0.06, -0.32, 0.045],
    [0.075, -0.27, 0.036],
    [-0.24, -0.17, 0.036],
    [-0.12, -0.20, 0.043],
    [0.005, -0.18, 0.035],
    [-0.17, -0.10, 0.032],
    [-0.04, -0.10, 0.030],
  ];
  for (const [rx, ry, rad] of mantleRings) drawBlueRing(rx, ry, rad);
  bc.restore();
  ec.restore();

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const ringEmissiveTex = track(new THREE.CanvasTexture(emissiveCv));
  ringEmissiveTex.colorSpace = THREE.SRGBColorSpace;
  ringEmissiveTex.anisotropy = maxAnisotropy;

  const OCTO_NECK_LAG_GLSL = `
    vec2 evalOctoNeckAngles(vec3 pBody, float trail, float vertLag, float turnLag, float floatPh, float wavePh, float feedAct) {
      // Hinge smoothly & supplely right from under eyes & konde (y <= 0.148) down to collar without stretching neck length!
      float downT = smoothstep(0.148, -0.025, pBody.y);
      float kondeGuard = 1.0 - smoothstep(-0.042, -0.115, pBody.x) * smoothstep(-0.010, 0.075, pBody.y);
      float eyeGuard = smoothstep(0.110, 0.045, pBody.y);
      float neckFlex = clamp(downT * kondeGuard * mix(1.0, eyeGuard, smoothstep(0.045, 0.145, pBody.x)), 0.0, 1.0);
      float bendW = pow(neckFlex, 0.88);

      float nTrail = clamp(trail, 0.0, 1.35) * (1.0 - feedAct * 0.45);
      float idleMix = 1.0 - smoothstep(0.05, 0.55, trail);
      float swimActive = smoothstep(0.08, 0.70, trail) * (1.0 - feedAct * 0.70);
      float neckPhaseOff = clamp(0.14 - pBody.y, 0.0, 0.22) * 4.5;
      float idleSway = (sin(floatPh + 0.5 - neckPhaseOff * 0.6) * 0.085 + cos(floatPh * 0.7 + 0.2) * 0.030) * idleMix * (1.0 - feedAct);
      float swimNeckWave = sin(wavePh - 0.55 - neckPhaseOff) * 0.072 * swimActive;
      float rollWave = cos(wavePh - 0.35 - neckPhaseOff * 0.8) * 0.055 * swimActive;

      // Supple rubbery pitch & lateral twist/roll through neck so it feels fluid and never stiff
      float pitchAng = clamp(-nTrail * 0.34 - vertLag * 0.30 * (1.0 - feedAct * 0.45) + idleSway + swimNeckWave, -0.54, 0.32) * bendW;
      float rollAng  = clamp(-turnLag * 0.40 * (1.0 - feedAct * 0.45) + rollWave, -0.50, 0.50) * bendW;
      return vec2(pitchAng, rollAng);
    }

    vec3 applyOctoNeckRot(vec3 pBody, vec2 ang) {
      vec3 piv = vec3(0.016, 0.128, 0.0);
      vec3 rel = pBody - piv;
      float cp = cos(ang.x);
      float sp = sin(ang.x);
      vec3 r1 = vec3(cp * rel.x - sp * rel.y, sp * rel.x + cp * rel.y, rel.z);
      float cr = cos(ang.y);
      float sr = sin(ang.y);
      vec3 r2 = vec3(r1.x, cr * r1.y - sr * r1.z, sr * r1.y + cr * r1.z);
      return piv + r2;
    }

    vec3 applyOctoNeckRotDir(vec3 dir, vec2 ang) {
      float cp = cos(ang.x);
      float sp = sin(ang.x);
      vec3 r1 = vec3(cp * dir.x - sp * dir.y, sp * dir.x + cp * dir.y, dir.z);
      float cr = cos(ang.y);
      float sr = sin(ang.y);
      return vec3(r1.x, cr * r1.y - sr * r1.z, sr * r1.y + cr * r1.z);
    }
  `;

  interface OctoSquishUniforms {
    uWave: { value: number };
    uSquish: { value: number };
    uJiggle: { value: number };
    uSwimAmp: { value: number };
    uTrail: { value: number };
    uVertLag: { value: number };
    uTurnLag: { value: number };
    uFloatPh: { value: number };
    uFeedActive: { value: number };
    uGulpT: { value: number };
    uGulpK: { value: number };
  }
  const squishUniforms: OctoSquishUniforms = {
    uWave: { value: 0 },
    uSquish: { value: 0 },
    uJiggle: { value: 0 },
    uSwimAmp: { value: 0.02 },
    uTrail: { value: 0 },
    uVertLag: { value: 0 },
    uTurnLag: { value: 0 },
    uFloatPh: { value: 0 },
    uFeedActive: { value: 0 },
    uGulpT: { value: 0 },
    uGulpK: { value: 0 },
  };

  const injectOctopusSquishShader = (
    mat: THREE.MeshPhysicalMaterial | THREE.MeshBasicMaterial,
    isOutline = false
  ) => {
    mat.customProgramCacheKey = () => `octo-head-squish-v8-${isOutline ? 1 : 0}`;
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.uWave = squishUniforms.uWave;
      shader.uniforms.uSquish = squishUniforms.uSquish;
      shader.uniforms.uJiggle = squishUniforms.uJiggle;
      shader.uniforms.uSwimAmp = squishUniforms.uSwimAmp;
      shader.uniforms.uTrail = squishUniforms.uTrail;
      shader.uniforms.uVertLag = squishUniforms.uVertLag;
      shader.uniforms.uTurnLag = squishUniforms.uTurnLag;
      shader.uniforms.uFloatPh = squishUniforms.uFloatPh;
      shader.uniforms.uFeedActive = squishUniforms.uFeedActive;
      shader.uniforms.uGulpT = squishUniforms.uGulpT;
      shader.uniforms.uGulpK = squishUniforms.uGulpK;
      shader.vertexShader = shader.vertexShader
        .replace(
          "#include <common>",
          `#include <common>
          uniform float uWave;
          uniform float uSquish;
          uniform float uJiggle;
          uniform float uSwimAmp;
          uniform float uTrail;
          uniform float uVertLag;
          uniform float uTurnLag;
          uniform float uFloatPh;
          uniform float uFeedActive;
          uniform float uGulpT;
          uniform float uGulpK;
          ${OCTO_NECK_LAG_GLSL}`
        );
      if (shader.vertexShader.includes("#include <beginnormal_vertex>")) {
        shader.vertexShader = shader.vertexShader.replace(
          "#include <beginnormal_vertex>",
          `#include <beginnormal_vertex>
          vec2 neckAngN = evalOctoNeckAngles(position, uTrail, uVertLag, uTurnLag, uFloatPh, uWave, uFeedActive);
          objectNormal = normalize(applyOctoNeckRotDir(objectNormal, neckAngN));`
        );
      }
      shader.vertexShader = shader.vertexShader.replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
        vec3 pRest = transformed;
        float hNorm = clamp((pRest.y - 0.02) / 0.39, 0.0, 1.0);
        // Keep neck & tentacle root sockets (y <= 0.08) free of squish so neck rotation stays exact!
        float baseAnchor = smoothstep(0.080, 0.165, pRest.y);
        float midSwell = sin(hNorm * 3.14159);
        // Volume-preserving mochi squish + soft jelly bob on the front head & plump konde dome
        float sqTotal = clamp(uSquish, -0.45, 0.55)
          + sin(uWave * 0.85) * 0.056
          + sin(uWave * 1.95 - hNorm * 4.2) * uJiggle;
        transformed.y -= sqTotal * 0.105 * hNorm * baseAnchor;
        float radialExpand = 1.0 + sqTotal * (0.26 * midSwell + 0.05 * baseAnchor);
        // Swallow bolus bulge traveling upward from throat under neck into round balloon mantle after "HAP!"
        float gProg = 1.0 - clamp(uGulpT, 0.0, 1.0);
        float gulpEnv = sin(clamp(gProg, 0.0, 1.0) * 3.14159) * clamp(uGulpK, 0.0, 1.5);
        float gulpY = mix(0.03, 0.25, gProg);
        float gulpDist = (pRest.y - gulpY) / 0.11;
        float gulpBulge = gulpEnv * exp(-gulpDist * gulpDist) * 0.16 * smoothstep(0.01, 0.07, pRest.y);
        radialExpand += gulpBulge;
        transformed.x = mix(transformed.x, (transformed.x + 0.03) * radialExpand - 0.03, baseAnchor);
        transformed.z *= mix(1.0, radialExpand, baseAnchor);
        transformed.z += sign(pRest.z + 0.0001) * gulpBulge * 0.04 * (1.0 - baseAnchor);
        transformed.z += sin(uWave * 0.92 - hNorm * 1.8) * (0.014 + uSwimAmp * 0.45) * hNorm * hNorm;
        // Length-preserving rotational hinge on neck & shoulders, leaving front head & konde leading!
        vec2 neckAng = evalOctoNeckAngles(pRest, uTrail, uVertLag, uTurnLag, uFloatPh, uWave, uFeedActive);
        transformed = applyOctoNeckRot(transformed, neckAng);`
      );
    };
  };

  const bodyGeo = track(buildMetaballBodyGeo());

  const bodyMat = track(
    new THREE.MeshPhysicalMaterial({
      map: bodyTex,
      emissiveMap: bodyTex,
      emissive: new THREE.Color("#ffffff"),
      emissiveIntensity: 0.18,
      roughness: 0.42,
      metalness: 0,
      sheen: 0.65,
      sheenRoughness: 0.48,
      sheenColor: new THREE.Color(CREAM),
      clearcoat: 0.32,
      clearcoatRoughness: 0.34,
      envMapIntensity: 0.18,
    })
  );
  injectOctopusSquishShader(bodyMat, false);

  const headOutlineMat = makeOutlineMat(0, 0);
  injectOctopusSquishShader(headOutlineMat, true);

  const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
  bodyMesh.add(new THREE.Mesh(track(buildOutlineGeometry(bodyGeo, 0.0056)), headOutlineMat));
  bodyGroup.add(bodyMesh);

  const ringShellMat = track(
    new THREE.MeshBasicMaterial({
      map: ringEmissiveTex,
      color: RING_CYAN,
      transparent: true,
      opacity: 0.12,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    })
  );
  injectOctopusSquishShader(ringShellMat, false);
  const ringShellMesh = new THREE.Mesh(bodyGeo, ringShellMat);
  ringShellMesh.renderOrder = 2;
  bodyGroup.add(ringShellMesh);

  // ===================================================================================
  // 3. SEAMLESS MERGED TENTACLE TUBES + MATCHED SKIN SHADING + GLOW BANDS
  // ===================================================================================
  const tentCv = document.createElement("canvas");
  tentCv.width = 512;
  tentCv.height = 256;
  const tc = tentCv.getContext("2d")!;
  const tentEmCv = document.createElement("canvas");
  tentEmCv.width = 512;
  tentEmCv.height = 256;
  const tec = tentEmCv.getContext("2d")!;
  tec.fillStyle = "#000000";
  tec.fillRect(0, 0, 512, 256);

  // V: 0.0 / 1.0 = dorsal/outer (+n), 0.5 = ventral/inner cream underside (-n)
  const tGrad = tc.createLinearGradient(0, 0, 0, 256);
  tGrad.addColorStop(0.0, GOLD);
  tGrad.addColorStop(0.22, GOLD);
  tGrad.addColorStop(0.36, "#fbbf24");
  tGrad.addColorStop(0.45, CREAM);
  tGrad.addColorStop(0.55, CREAM);
  tGrad.addColorStop(0.64, "#fbbf24");
  tGrad.addColorStop(0.78, GOLD);
  tGrad.addColorStop(1.0, GOLD);
  tc.fillStyle = tGrad;
  tc.fillRect(0, 0, 512, 256);

  const tipGrad = tc.createLinearGradient(420, 0, 512, 0);
  tipGrad.addColorStop(0, "rgba(255,232,163,0)");
  tipGrad.addColorStop(1, "rgba(255,244,204,0.42)");
  tc.fillStyle = tipGrad;
  tc.fillRect(420, 0, 92, 256);

  // Cyan rings start at t=0.26 cleanly past the metaball merge zone (t=0..0.21)
  const bandTs = [0.26, 0.40, 0.54, 0.68, 0.82];
  for (const bt of bandTs) {
    const bx = bt * 512;
    const bw = 15 * (1 - bt * 0.25);
    tc.fillStyle = RING_DEEP;
    tc.fillRect(bx - bw, 0, bw * 2, 92);
    tc.fillRect(bx - bw, 164, bw * 2, 92);
    tc.fillStyle = RING_CYAN;
    tc.fillRect(bx - bw * 0.46, 0, bw * 0.92, 86);
    tc.fillRect(bx - bw * 0.46, 170, bw * 0.92, 86);

    tec.fillStyle = RING_CYAN;
    tec.fillRect(bx - bw * 0.52, 0, bw * 1.04, 88);
    tec.fillRect(bx - bw * 0.52, 168, bw * 1.04, 88);
  }

  const tentTex = track(new THREE.CanvasTexture(tentCv));
  tentTex.colorSpace = THREE.SRGBColorSpace;
  tentTex.wrapS = THREE.ClampToEdgeWrapping;
  tentTex.wrapT = THREE.RepeatWrapping;
  tentTex.anisotropy = maxAnisotropy;

  const tentEmissiveTex = track(new THREE.CanvasTexture(tentEmCv));
  tentEmissiveTex.colorSpace = THREE.SRGBColorSpace;
  tentEmissiveTex.wrapS = THREE.ClampToEdgeWrapping;
  tentEmissiveTex.wrapT = THREE.RepeatWrapping;
  tentEmissiveTex.anisotropy = maxAnisotropy;

  interface TentacleWaveUniforms {
    uWave: { value: number };
    uFloatPh: { value: number };
    uFlare: { value: number };
    uPhase: { value: number };
    uFeedSide: { value: number };
    uReach: { value: number };
    uPull: { value: number };
    uFeedActive: { value: number };
    uTrail: { value: number };
    uVertLag: { value: number };
    uTurnLag: { value: number };
    uArmCos: { value: number };
    uArmSin: { value: number };
    uBackSweep: { value: number };
    uBackLift: { value: number };
    uArmPos: { value: THREE.Vector3 };
  }

  const sampleCurveMeshData = (
    curve: THREE.CatmullRomCurve3,
    midUp: THREE.Vector3
  ) => {
    const cols = V_SEGS + 1;
    const centers: THREE.Vector3[] = [];
    const tangents: THREE.Vector3[] = [];
    const framesN: THREE.Vector3[] = new Array(U_SEGS + 1);
    const framesB: THREE.Vector3[] = new Array(U_SEGS + 1);
    const radii: number[] = [];

    for (let i = 0; i <= U_SEGS; i++) {
      const t = i / U_SEGS;
      centers.push(curve.getPointAt(t));
      tangents.push(curve.getTangentAt(t).normalize());
      const coreRad = 0.047 * Math.pow(1 - t * 0.78, 0.72);
      // Recessed inside metaball shoulder for t < 0.14, expanding smoothly flush at exact coreRad by t = 0.21!
      const socketBlend = 0.76 + 0.24 * smoothstep(0.14, 0.21, t);
      const tipCap = t > 0.92 ? Math.sqrt(Math.max(0.09, 1 - Math.pow((t - 0.92) / 0.08, 2))) : 1.0;
      radii.push(Math.max(0.0042, coreRad * socketBlend * tipCap));
    }

    const midIdx = Math.floor(U_SEGS * 0.45);
    const midT = tangents[midIdx];
    const nMid = midUp.clone().addScaledVector(midT, -midUp.dot(midT));
    if (nMid.lengthSq() < 1e-5) nMid.set(0, 0, 1).cross(midT);
    nMid.normalize();
    framesN[midIdx] = nMid;
    framesB[midIdx] = new THREE.Vector3().crossVectors(midT, nMid).normalize();

    const rotQ = new THREE.Quaternion();
    for (let i = midIdx - 1; i >= 0; i--) {
      rotQ.setFromUnitVectors(tangents[i + 1], tangents[i]);
      const nPrev = framesN[i + 1].clone().applyQuaternion(rotQ).normalize();
      framesN[i] = nPrev;
      framesB[i] = new THREE.Vector3().crossVectors(tangents[i], nPrev).normalize();
    }
    for (let i = midIdx + 1; i <= U_SEGS; i++) {
      rotQ.setFromUnitVectors(tangents[i - 1], tangents[i]);
      const nNext = framesN[i - 1].clone().applyQuaternion(rotQ).normalize();
      framesN[i] = nNext;
      framesB[i] = new THREE.Vector3().crossVectors(tangents[i], nNext).normalize();
    }

    const pos: number[] = [];
    const nrm: number[] = [];
    const uv: number[] = [];
    const armT: number[] = [];
    const idx: number[] = [];

    for (let i = 0; i <= U_SEGS; i++) {
      const t = i / U_SEGS;
      const cPt = centers[i];
      const n = framesN[i];
      const b = framesB[i];
      const rad = radii[i];
      for (let j = 0; j <= V_SEGS; j++) {
        const v = j / V_SEGS;
        const ang = v * Math.PI * 2;
        const cosA = Math.cos(ang);
        const sinA = Math.sin(ang);
        const nx = n.x * cosA + b.x * sinA;
        const ny = n.y * cosA + b.y * sinA;
        const nz = n.z * cosA + b.z * sinA;
        pos.push(cPt.x + nx * rad, cPt.y + ny * rad, cPt.z + nz * rad);
        nrm.push(nx, ny, nz);
        uv.push(t, v);
        armT.push(t);
      }
    }

    for (let i = 0; i < U_SEGS; i++) {
      for (let j = 0; j < V_SEGS; j++) {
        const a = i * cols + j;
        const b = (i + 1) * cols + j;
        const c = (i + 1) * cols + (j + 1);
        const d = i * cols + (j + 1);
        idx.push(a, d, b, b, d, c);
      }
    }
    const tipCenterIdx = pos.length / 3;
    const tipEnd = centers[U_SEGS];
    const tipTang = tangents[U_SEGS];
    pos.push(tipEnd.x + tipTang.x * 0.0028, tipEnd.y + tipTang.y * 0.0028, tipEnd.z + tipTang.z * 0.0028);
    nrm.push(tipTang.x, tipTang.y, tipTang.z);
    uv.push(0.99, 0.5);
    armT.push(1.0);
    const lastRing = U_SEGS * cols;
    for (let j = 0; j < V_SEGS; j++) {
      idx.push(tipCenterIdx, lastRing + j, lastRing + j + 1);
    }

    const sPos: number[] = [];
    const sNrm: number[] = [];
    const sArmT: number[] = [];
    const sIdx: number[] = [];
    const cupTmpl = new THREE.SphereGeometry(0.0132, 10, 8);
    cupTmpl.scale(1.0, 0.62, 1.0);
    const cupPosAttr = cupTmpl.attributes.position as THREE.BufferAttribute;
    const cupNrmAttr = cupTmpl.attributes.normal as THREE.BufferAttribute;
    const cupIndex = cupTmpl.index!;
    const qMat = new THREE.Matrix4();
    const xAxis = new THREE.Vector3();
    const yAxis = new THREE.Vector3();
    const zAxis = new THREE.Vector3();
    const tmpP = new THREE.Vector3();
    const tmpN = new THREE.Vector3();

    for (let k = 0; k < SUCKER_TS.length; k++) {
      const st = SUCKER_TS[k];
      const si = Math.min(U_SEGS - 1, Math.round(st * U_SEGS));
      const cPt = centers[si];
      const n = framesN[si];
      const b = framesB[si];
      const rad = radii[si];
      const cupScale = (1 - st * 0.45) * (rad / 0.036);

      for (const sideS of [-1, 1]) {
        const latOff = sideS * rad * 0.28;
        const offX = -n.x * (rad * 0.78) + b.x * latOff;
        const offY = -n.y * (rad * 0.78) + b.y * latOff;
        const offZ = -n.z * (rad * 0.78) + b.z * latOff;

        yAxis.copy(n).multiplyScalar(-1).normalize();
        zAxis.copy(b).normalize();
        xAxis.crossVectors(yAxis, zAxis).normalize();
        qMat.makeBasis(xAxis, yAxis, zAxis);

        const vOffset = sPos.length / 3;
        for (let vi = 0; vi < cupPosAttr.count; vi++) {
          tmpP.set(
            cupPosAttr.getX(vi) * cupScale,
            cupPosAttr.getY(vi) * cupScale,
            cupPosAttr.getZ(vi) * cupScale
          ).applyMatrix4(qMat);
          tmpN.set(cupNrmAttr.getX(vi), cupNrmAttr.getY(vi), cupNrmAttr.getZ(vi)).applyMatrix4(qMat).normalize();
          sPos.push(cPt.x + offX + tmpP.x, cPt.y + offY + tmpP.y, cPt.z + offZ + tmpP.z);
          sNrm.push(tmpN.x, tmpN.y, tmpN.z);
          sArmT.push(st);
        }
        for (let ii = 0; ii < cupIndex.count; ii++) {
          sIdx.push(vOffset + cupIndex.getX(ii));
        }
      }
    }
    cupTmpl.dispose();

    return { pos, nrm, uv, armT, idx, sPos, sNrm, sArmT, sIdx };
  };

  const buildTentacleMeshes = (
    curves: {
      restCurve: THREE.CatmullRomCurve3;
      swimCurve: THREE.CatmullRomCurve3;
      reachCurve: THREE.CatmullRomCurve3 | null;
      pullCurve: THREE.CatmullRomCurve3 | null;
    },
    feedSide: number
  ) => {
    const restData = sampleCurveMeshData(curves.restCurve, new THREE.Vector3(0.32, 0.95, 0).normalize());
    const swimData = sampleCurveMeshData(curves.swimCurve, new THREE.Vector3(0.0, 1.0, 0).normalize());
    const reachData = curves.reachCurve
      ? sampleCurveMeshData(curves.reachCurve, new THREE.Vector3(0.32, 0.95, 0).normalize())
      : restData;
    const pullData = curves.pullCurve
      ? sampleCurveMeshData(curves.pullCurve, new THREE.Vector3(-0.22, -0.92, feedSide * 0.30).normalize())
      : restData;

    const tentGeo = track(new THREE.BufferGeometry());
    tentGeo.setAttribute("position", new THREE.Float32BufferAttribute(restData.pos, 3));
    tentGeo.setAttribute("normal", new THREE.Float32BufferAttribute(restData.nrm, 3));
    tentGeo.setAttribute("uv", new THREE.Float32BufferAttribute(restData.uv, 2));
    tentGeo.setAttribute("aTentT", new THREE.Float32BufferAttribute(restData.armT, 1));
    tentGeo.setAttribute("aSwimPos", new THREE.Float32BufferAttribute(swimData.pos, 3));
    tentGeo.setAttribute("aSwimNrm", new THREE.Float32BufferAttribute(swimData.nrm, 3));
    tentGeo.setAttribute("aReachPos", new THREE.Float32BufferAttribute(reachData.pos, 3));
    tentGeo.setAttribute("aPullPos", new THREE.Float32BufferAttribute(pullData.pos, 3));
    tentGeo.setAttribute("aReachNrm", new THREE.Float32BufferAttribute(reachData.nrm, 3));
    tentGeo.setAttribute("aPullNrm", new THREE.Float32BufferAttribute(pullData.nrm, 3));
    tentGeo.setIndex(restData.idx);

    const suckerGeo = track(new THREE.BufferGeometry());
    suckerGeo.setAttribute("position", new THREE.Float32BufferAttribute(restData.sPos, 3));
    suckerGeo.setAttribute("normal", new THREE.Float32BufferAttribute(restData.sNrm, 3));
    suckerGeo.setAttribute("aTentT", new THREE.Float32BufferAttribute(restData.sArmT, 1));
    suckerGeo.setAttribute("aSwimPos", new THREE.Float32BufferAttribute(swimData.sPos, 3));
    suckerGeo.setAttribute("aSwimNrm", new THREE.Float32BufferAttribute(swimData.sNrm, 3));
    suckerGeo.setAttribute("aReachPos", new THREE.Float32BufferAttribute(reachData.sPos, 3));
    suckerGeo.setAttribute("aPullPos", new THREE.Float32BufferAttribute(pullData.sPos, 3));
    suckerGeo.setAttribute("aReachNrm", new THREE.Float32BufferAttribute(reachData.sNrm, 3));
    suckerGeo.setAttribute("aPullNrm", new THREE.Float32BufferAttribute(pullData.sNrm, 3));
    suckerGeo.setIndex(restData.sIdx);

    return { tentGeo, suckerGeo };
  };

  const injectTentacleWaveShader = (
    mat: THREE.MeshStandardMaterial | THREE.MeshPhysicalMaterial | THREE.MeshBasicMaterial,
    wUniforms: TentacleWaveUniforms
  ) => {
    const isBasic = mat instanceof THREE.MeshBasicMaterial;
    mat.customProgramCacheKey = () => `octo-tentacle-wave-v11-${isBasic ? 1 : 0}`;
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.uWave = wUniforms.uWave;
      shader.uniforms.uFloatPh = wUniforms.uFloatPh;
      shader.uniforms.uFlare = wUniforms.uFlare;
      shader.uniforms.uPhase = wUniforms.uPhase;
      shader.uniforms.uFeedSide = wUniforms.uFeedSide;
      shader.uniforms.uReach = wUniforms.uReach;
      shader.uniforms.uPull = wUniforms.uPull;
      shader.uniforms.uFeedActive = wUniforms.uFeedActive;
      shader.uniforms.uTrail = wUniforms.uTrail;
      shader.uniforms.uVertLag = wUniforms.uVertLag;
      shader.uniforms.uTurnLag = wUniforms.uTurnLag;
      shader.uniforms.uArmCos = wUniforms.uArmCos;
      shader.uniforms.uArmSin = wUniforms.uArmSin;
      shader.uniforms.uBackSweep = wUniforms.uBackSweep;
      shader.uniforms.uBackLift = wUniforms.uBackLift;
      shader.uniforms.uArmPos = wUniforms.uArmPos;
      shader.vertexShader = shader.vertexShader
        .replace(
          "#include <common>",
          `#include <common>
          attribute float aTentT;
          attribute vec3 aSwimPos;
          attribute vec3 aSwimNrm;
          attribute vec3 aReachPos;
          attribute vec3 aPullPos;
          attribute vec3 aReachNrm;
          attribute vec3 aPullNrm;
          uniform float uWave;
          uniform float uFloatPh;
          uniform float uFlare;
          uniform float uPhase;
          uniform float uFeedSide;
          uniform float uReach;
          uniform float uPull;
          uniform float uFeedActive;
          uniform float uTrail;
          uniform float uVertLag;
          uniform float uTurnLag;
          uniform float uArmCos;
          uniform float uArmSin;
          uniform float uBackSweep;
          uniform float uBackLift;
          uniform vec3 uArmPos;
          ${OCTO_NECK_LAG_GLSL}`
        );
      if (shader.vertexShader.includes("#include <beginnormal_vertex>")) {
        shader.vertexShader = shader.vertexShader.replace(
          "#include <beginnormal_vertex>",
          `#include <beginnormal_vertex>
          float ttN = clamp(aTentT, 0.0, 1.0);
          float uN = clamp((ttN - 0.18) / 0.82, 0.0, 1.0);
          float rootLockN = smoothstep(0.18, 0.34, ttN);
          float feedOverN = abs(uFeedSide) > 0.5 ? clamp(max(uReach, uPull), 0.0, 1.0) : 0.0;
          float swimMixN = smoothstep(0.08, 0.82, uTrail) * (1.0 - feedOverN) * rootLockN * pow(uN, 1.38);
          vec3 nWork = normalize(mix(objectNormal, aSwimNrm, swimMixN));
          if (abs(uFeedSide) > 0.5) {
            float rWN = clamp(uReach, 0.0, 1.0) * rootLockN;
            float pWN = clamp(uPull, 0.0, 1.0) * rootLockN;
            vec3 nBlend = mix(nWork, aReachNrm, rWN);
            nBlend = mix(nBlend, aPullNrm, pWN);
            float nLen = length(nBlend);
            if (nLen > 0.0001) nWork = nBlend / nLen;
          }
          objectNormal = nWork;

          float sweepAmtN = clamp(uTrail * 0.88, 0.0, 1.05) * (1.0 - feedOverN);
          float sweepThetaN = -uBackSweep * sweepAmtN * rootLockN * pow(uN, 1.55);
          float cN = cos(sweepThetaN);
          float sN = sin(sweepThetaN);
          objectNormal = vec3(cN * objectNormal.x + sN * objectNormal.z, objectNormal.y, -sN * objectNormal.x + cN * objectNormal.z);

          vec3 pBodyN = vec3(
            uArmPos.x + uArmCos * position.x - uArmSin * position.z,
            uArmPos.y + position.y,
            uArmPos.z + uArmSin * position.x + uArmCos * position.z
          );
          vec2 neckAngTN = evalOctoNeckAngles(pBodyN, uTrail, uVertLag, uTurnLag, uFloatPh, uWave, uFeedActive);
          vec3 nBody = vec3(uArmCos * objectNormal.x - uArmSin * objectNormal.z, objectNormal.y, uArmSin * objectNormal.x + uArmCos * objectNormal.z);
          nBody = applyOctoNeckRotDir(nBody, neckAngTN);
          objectNormal = normalize(vec3(uArmCos * nBody.x + uArmSin * nBody.z, nBody.y, -uArmSin * nBody.x + uArmCos * nBody.z));`
        );
      }
      shader.vertexShader = shader.vertexShader.replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
        float tt = clamp(aTentT, 0.0, 1.0);
        // Normalized percentage along free arm from neck socket (u=0) to trailing tip (u=1)
        float u = clamp((tt - 0.18) / 0.82, 0.0, 1.0);
        // Entire t <= 0.18 metaball shoulder stays 100% locked to evalOctoNeckRot with the bending neck!
        float rootLock = smoothstep(0.18, 0.34, tt);
        float tipEnv = smoothstep(0.24, 1.0, tt);
        float feedOverride = abs(uFeedSide) > 0.5 ? clamp(max(uReach, uPull), 0.0, 1.0) : 0.0;

        vec3 pBodyRest = vec3(
          uArmPos.x + uArmCos * transformed.x - uArmSin * transformed.z,
          uArmPos.y + transformed.y,
          uArmPos.z + uArmSin * transformed.x + uArmCos * transformed.z
        );
        vec2 neckAng = evalOctoNeckAngles(pBodyRest, uTrail, uVertLag, uTurnLag, uFloatPh, uWave, uFeedActive);

        float moveMix = smoothstep(0.05, 0.55, uTrail);
        float idleMix = 1.0 - moveMix;

        // 1. Progressive ribbon unfurl: near-neck percentage follows the supple neck smoothly, outer tips stream fully back!
        float swimMix = smoothstep(0.08, 0.82, uTrail) * (1.0 - feedOverride) * rootLock * pow(u, 1.38);
        vec3 pos = mix(transformed, aSwimPos, swimMix);

        // Progressive azimuth sweep: base preserves collar spacing cleanly while outer tips gather gracefully behind
        float sweepAmt = clamp(uTrail * 0.88, 0.0, 1.05) * (1.0 - feedOverride);
        float sweepTheta = -uBackSweep * sweepAmt * rootLock * pow(u, 1.55);
        float cSw = cos(sweepTheta);
        float sSw = sin(sweepTheta);
        float relX = pos.x - 0.048;
        float relZ = pos.z;
        pos.x = 0.048 + (cSw * relX + sSw * relZ);
        pos.z = -sSw * relX + cSw * relZ;

        // 2. Idle treading-water buoyancy stroke (gentle near neck, sweeping gracefully at outer 65%)
        float idleProg = rootLock * pow(u, 1.50);
        float treadPh = uFloatPh - tt * 3.1 + uPhase * 0.24;
        float treadStroke = sin(treadPh) + 0.28 * sin(2.0 * treadPh - 0.75);
        float treadRadial = sin(treadPh + 0.85) * 0.048 * idleProg;
        float treadVert = -treadStroke * 0.052 * idleProg;
        float driftPh = uFloatPh * 1.15 + uPhase * 1.35 - tt * 4.2;
        float driftOut = sin(driftPh) * 0.030 * idleProg;
        float driftTan = cos(driftPh * 0.88 + 0.5) * 0.034 * idleProg;
        float idleWeight = idleMix * (1.0 - feedOverride);
        pos.x += (treadRadial + driftOut) * idleWeight;
        pos.y += treadVert * idleWeight;
        pos.z += driftTan * idleWeight;

        // 3. Progressive traveling S-waves: subtle & calm near neck (u^1.75), lush fluid ribbon & curled whip at tips (u^2.50)
        float waveFreq = mix(4.2, 5.6, clamp(uTrail, 0.0, 1.0));
        float ph1 = uWave + uPhase - tt * waveFreq;
        float ph2 = uWave * 1.18 + uPhase * 1.25 - tt * (waveFreq + 1.8);
        float tailAmp = mix(0.45, 1.18, clamp(uTrail, 0.0, 1.25));
        float wEnv = rootLock * pow(u, 1.75) * tailAmp * (1.0 - feedOverride * 0.75);
        float tipCurl = rootLock * pow(u, 2.50) * tailAmp * (1.0 - feedOverride * 0.75);
        pos.y += sin(ph1) * 0.072 * wEnv + sin(ph2) * 0.038 * tipCurl;
        pos.z += cos(ph1 * 0.90 + 0.4) * 0.044 * wEnv + cos(ph2 * 0.85) * 0.028 * tipCurl;
        pos.x += sin(ph1 - 1.35) * 0.024 * wEnv;

        // 4. Feeding clasp & pull under head for front 2 arms (only when not sucking!)
        if (abs(uFeedSide) > 0.5) {
          float reachW = clamp(uReach, 0.0, 1.0) * rootLock;
          float pullW  = clamp(uPull, 0.0, 1.0) * rootLock;
          float fWaveY = sin(ph1) * 0.016 * tipEnv;
          float fWaveZ = cos(ph1 * 0.92 + 0.5) * 0.014 * tipEnv;

          vec3 reachPos = aReachPos + vec3(0.0, fWaveY, fWaveZ);
          vec3 pullPos  = aPullPos  + vec3(fWaveY * 0.6, fWaveY * 0.5, 0.0);

          vec3 morphed = mix(pos, reachPos, reachW);
          morphed = mix(morphed, pullPos, pullW);
          float sweepArc = sin(3.14159 * max(reachW, pullW)) * 0.032 * tt * rootLock;
          morphed.y -= sweepArc;
          pos = morphed;
        } else {
          pos.x -= uFlare * 0.014 * rootLock * pow(u, 1.4);
          pos.y -= uFlare * 0.020 * rootLock * pow(u, 1.4);
          pos.z += sin(ph1) * uFlare * 0.010 * rootLock * pow(u, 1.4);
        }

        // 5. Progressive fluid whip lag: near neck (~3% extra lag) ramps smoothly up to 100% trailing whip at tips!
        vec3 backDir = vec3(-uArmCos, 0.0, uArmSin);
        vec3 latDir  = vec3(uArmSin, 0.0, uArmCos);
        float lagCurve = rootLock * pow(u, 2.10) * (1.0 - feedOverride * 0.65);
        float tipDrag = clamp(uTrail, 0.0, 1.35) * rootLock * pow(u, 2.25) * (1.0 - feedOverride);
        pos.y += uVertLag * 0.135 * lagCurve - tipDrag * 0.030;
        pos += backDir * (abs(uVertLag) * 0.028 * lagCurve + tipDrag * 0.072);
        pos += latDir * (uTurnLag * 0.145 * lagCurve);

        // Apply exact same neck hinge rotation in body space so neck & sockets stay 100% flush without stretching!
        vec3 pBodyDef = vec3(
          uArmPos.x + uArmCos * pos.x - uArmSin * pos.z,
          uArmPos.y + pos.y,
          uArmPos.z + uArmSin * pos.x + uArmCos * pos.z
        );
        pBodyDef = applyOctoNeckRot(pBodyDef, neckAng);
        vec3 relBody = pBodyDef - uArmPos;
        transformed = vec3(
          uArmCos * relBody.x + uArmSin * relBody.z,
          relBody.y,
          -uArmSin * relBody.x + uArmCos * relBody.z
        );`
      );
    };
  };

  const sharedPair0 = buildTentacleMeshes(armConfigs[0].curves, 0);
  const sharedPair1 = buildTentacleMeshes(armConfigs[2].curves, 0);
  const sharedPair3 = buildTentacleMeshes(armConfigs[4].curves, 0);
  const sharedPair2L = buildTentacleMeshes(armConfigs[6].curves, 1);
  const sharedPair2R = buildTentacleMeshes(armConfigs[7].curves, -1);

  interface CuteTentacleArm {
    pivot: THREE.Group;
    wUniforms: TentacleWaveUniforms;
    ringMat: THREE.MeshBasicMaterial;
    isFeeder: boolean;
    phase: number;
  }
  const arms: CuteTentacleArm[] = [];

  for (const cfg of armConfigs) {
    const pivot = new THREE.Group();
    pivot.position.set(cfg.pos[0], cfg.pos[1], cfg.pos[2]);
    pivot.rotation.y = cfg.yaw;

    const wUniforms: TentacleWaveUniforms = {
      uWave: { value: 0 },
      uFloatPh: { value: 0 },
      uFlare: { value: 0 },
      uPhase: { value: cfg.phase },
      uFeedSide: { value: cfg.feedSide },
      uReach: { value: 0 },
      uPull: { value: 0 },
      uFeedActive: { value: 0 },
      uTrail: { value: 0 },
      uVertLag: { value: 0 },
      uTurnLag: { value: 0 },
      uArmCos: { value: Math.cos(cfg.ang) },
      uArmSin: { value: Math.sin(cfg.ang) },
      uBackSweep: { value: cfg.backSweep },
      uBackLift: { value: cfg.backLift },
      uArmPos: { value: new THREE.Vector3(cfg.pos[0], cfg.pos[1], cfg.pos[2]) },
    };

    // Identical skin material & 0.18 self-illumination as bodyMat so metaball merge has ZERO brightness step!
    const tentMat = track(
      new THREE.MeshPhysicalMaterial({
        map: tentTex,
        emissiveMap: tentTex,
        emissive: new THREE.Color("#ffffff"),
        emissiveIntensity: 0.18,
        roughness: 0.42,
        metalness: 0,
        sheen: 0.65,
        sheenRoughness: 0.48,
        sheenColor: new THREE.Color(CREAM),
        clearcoat: 0.32,
        clearcoatRoughness: 0.34,
        envMapIntensity: 0.18,
      })
    );
    injectTentacleWaveShader(tentMat, wUniforms);

    const tentRingMat = track(
      new THREE.MeshBasicMaterial({
        map: tentEmissiveTex,
        color: RING_CYAN,
        transparent: true,
        opacity: 0.24,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -1,
      })
    );
    injectTentacleWaveShader(tentRingMat, wUniforms);

    const suckerMat = track(
      new THREE.MeshStandardMaterial({
        color: CREAM,
        emissive: new THREE.Color(GOLD),
        emissiveIntensity: 0.14,
        roughness: 0.50,
        metalness: 0,
      })
    );
    injectTentacleWaveShader(suckerMat, wUniforms);

    const pair =
      cfg.variant === 0
        ? sharedPair0
        : cfg.variant === 1
          ? sharedPair1
          : cfg.variant === 3
            ? sharedPair3
            : cfg.feedSide > 0
              ? sharedPair2L
              : sharedPair2R;
    const tMesh = new THREE.Mesh(pair.tentGeo, tentMat);
    const trMesh = new THREE.Mesh(pair.tentGeo, tentRingMat);
    trMesh.renderOrder = 2;
    const sMesh = new THREE.Mesh(pair.suckerGeo, suckerMat);
    pivot.add(tMesh, trMesh, sMesh);
    bodyGroup.add(pivot);

    arms.push({
      pivot,
      wUniforms,
      ringMat: tentRingMat,
      isFeeder: cfg.feedSide !== 0,
      phase: cfg.phase,
    });
  }

  // Hidden cephalopod beak/mouth tucked underneath the central collar
  const upperJawGroup = new THREE.Group();
  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(0.026, -0.04, 0);
  bodyGroup.add(upperJawGroup, lowerJawGroup);
  const { mouthInterior, tongueMesh } = createOralParts(
    ctx,
    bodyGroup,
    lowerJawGroup,
    0.028,
    -0.04,
    "#2a0814",
    "#2a0814",
    [0.026, 0.020, 0.022],
    [0.008, 0.004, 0.006],
    0.008
  );
  mouthInterior.rotation.z = -Math.PI * 0.5;
  mouthInterior.visible = false;
  tongueMesh.visible = false;

  // ===================================================================================
  // 4. WIDE-OPEN 1.6x ("MELEK") GOLDEN EYES + FAST-SWIM TRANSLUCENT EYE MEMBRANE
  // ===================================================================================
  const er = 0.064 * 1.6;
  const eyeCv = document.createElement("canvas");
  eyeCv.width = 256;
  eyeCv.height = 256;
  const eyc = eyeCv.getContext("2d")!;
  const eg = eyc.createRadialGradient(128, 128, 10, 128, 128, 128);
  eg.addColorStop(0.0, "#fefce8");
  eg.addColorStop(0.35, "#fef08a");
  eg.addColorStop(0.74, "#facc15");
  eg.addColorStop(0.92, "#eab308");
  eg.addColorStop(1.0, "#d97706");
  eyc.fillStyle = eg;
  eyc.fillRect(0, 0, 256, 256);
  eyc.fillStyle = "rgba(217, 119, 6, 0.22)";
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2;
    const dist = 64 + (i % 3) * 16;
    eyc.beginPath();
    eyc.arc(128 + Math.cos(a) * dist, 128 + Math.sin(a) * dist, 5 + (i % 2) * 2.5, 0, Math.PI * 2);
    eyc.fill();
  }
  const eyeBallTex = track(new THREE.CanvasTexture(eyeCv));
  eyeBallTex.colorSpace = THREE.SRGBColorSpace;
  eyeBallTex.anisotropy = maxAnisotropy;

  // Translucent aquatic swim membrane (nictitating goggle) texture
  const memCv = document.createElement("canvas");
  memCv.width = 256;
  memCv.height = 128;
  const mc = memCv.getContext("2d")!;
  const mg = mc.createLinearGradient(0, 0, 0, 128);
  mg.addColorStop(0.0, "rgba(186, 230, 253, 0.34)");
  mg.addColorStop(0.68, "rgba(207, 250, 254, 0.42)");
  mg.addColorStop(0.88, "rgba(125, 211, 252, 0.72)");
  mg.addColorStop(0.96, "rgba(224, 248, 255, 0.94)");
  mg.addColorStop(1.0, "rgba(186, 230, 253, 0.80)");
  mc.fillStyle = mg;
  mc.fillRect(0, 0, 256, 128);
  mc.strokeStyle = "rgba(255, 255, 255, 0.65)";
  mc.lineWidth = 4;
  mc.beginPath();
  mc.moveTo(0, 121);
  mc.lineTo(256, 121);
  mc.stroke();
  const memTex = track(new THREE.CanvasTexture(memCv));
  memTex.colorSpace = THREE.SRGBColorSpace;
  memTex.anisotropy = maxAnisotropy;

  const browRimMat = track(
    new THREE.MeshPhysicalMaterial({
      color: GOLD,
      emissive: DARK,
      emissiveIntensity: 0.14,
      roughness: 0.42,
      sheen: 0.55,
      sheenColor: new THREE.Color(CREAM),
      metalness: 0,
    })
  );
  const eyeBallMat = track(
    new THREE.MeshPhysicalMaterial({
      map: eyeBallTex,
      emissiveMap: eyeBallTex,
      emissive: new THREE.Color("#fde047"),
      emissiveIntensity: 0.34,
      roughness: 0.18,
      clearcoat: 0.78,
      clearcoatRoughness: 0.12,
      envMapIntensity: 0.22,
    })
  );
  const memMat = track(
    new THREE.MeshPhysicalMaterial({
      map: memTex,
      color: "#e0f7ff",
      emissive: new THREE.Color("#7dd3fc"),
      emissiveIntensity: 0.24,
      transparent: true,
      opacity: 0,
      roughness: 0.14,
      metalness: 0,
      clearcoat: 0.9,
      clearcoatRoughness: 0.08,
      depthWrite: false,
      side: THREE.DoubleSide,
    })
  );
  const pupilMat = track(new THREE.MeshBasicMaterial({ color: "#05070e" }));
  const glintMat = track(new THREE.MeshBasicMaterial({ color: "#ffffff" }));
  const happyMat = track(new THREE.MeshBasicMaterial({ color: RING_CYAN }));

  const hoodGeo = track(new THREE.SphereGeometry(er * 0.98, 22, 16));
  hoodGeo.scale(1.0, 1.0, 0.48);
  const rimTorusGeo = track(new THREE.TorusGeometry(er * 0.90, er * 0.105, 12, 28));
  const eyeGlobeGeo = track(new THREE.SphereGeometry(er * 0.98, 28, 20));
  eyeGlobeGeo.rotateY(-Math.PI * 0.5);
  eyeGlobeGeo.scale(0.98, 1.04, 0.94);

  const memGeo = track(new THREE.SphereGeometry(er * 1.08, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55));
  memGeo.scale(0.98, 1.04, 0.98);

  const pupilGeo = track(new THREE.SphereGeometry(er * 0.43, 20, 14));
  pupilGeo.scale(1.0, 1.04, 0.38);
  const glint1Geo = track(new THREE.SphereGeometry(er * 0.125, 12, 10));
  glint1Geo.scale(1.0, 1.0, 0.35);
  const glint2Geo = track(new THREE.SphereGeometry(er * 0.065, 10, 8));
  glint2Geo.scale(1.0, 1.0, 0.35);

  const happyCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-er * 0.68, -er * 0.12, 0),
    new THREE.Vector3(-er * 0.28, er * 0.36, er * 0.08),
    new THREE.Vector3(er * 0.28, er * 0.36, er * 0.08),
    new THREE.Vector3(er * 0.68, -er * 0.12, 0),
  ]);
  const happyGeo = track(new THREE.TubeGeometry(happyCurve, 12, er * 0.11, 8, false));

  const eyesContainer = new THREE.Group();
  bodyGroup.add(eyesContainer);

  const eyesNormal: THREE.Group[] = [];
  const eyesPupil: THREE.Mesh[] = [];
  const eyesHappy: THREE.Group[] = [];
  const memPivots: THREE.Group[] = [];

  for (const side of [1, -1]) {
    const eyeSocket = new THREE.Group();
    // Enlarged 1.6x globes seated proudly side-by-side on front brow of the plump balloon head
    eyeSocket.position.set(0.165, 0.185, side * 0.094);
    eyeSocket.rotation.order = "YXZ";
    eyeSocket.rotation.y = side > 0 ? 1.18 : Math.PI - 1.18;
    eyeSocket.rotation.x = -0.05;
    eyesContainer.add(eyeSocket);

    const normalEye = new THREE.Group();
    const hoodMesh = new THREE.Mesh(hoodGeo, browRimMat);
    hoodMesh.position.set(0, 0, -er * 0.32);

    const rimMesh = new THREE.Mesh(rimTorusGeo, browRimMat);
    rimMesh.position.set(0, 0, -er * 0.14);

    const eyeBall = new THREE.Mesh(eyeGlobeGeo, eyeBallMat);
    eyeBall.position.set(0, 0, er * 0.06);

    const pupil = new THREE.Mesh(pupilGeo, pupilMat);
    pupil.position.set(0, 0, er * 0.86);

    const gl1 = new THREE.Mesh(glint1Geo, glintMat);
    gl1.position.set(-er * 0.20, er * 0.22, er * 0.99);
    const gl2 = new THREE.Mesh(glint2Geo, glintMat);
    gl2.position.set(er * 0.18, -er * 0.18, er * 0.99);

    const memPivot = new THREE.Group();
    memPivot.position.set(0, 0, er * 0.06);
    const memMesh = new THREE.Mesh(memGeo, memMat);
    memMesh.renderOrder = 3;
    memPivot.add(memMesh);
    memPivot.visible = false;
    memPivots.push(memPivot);

    normalEye.add(hoodMesh, rimMesh, eyeBall, pupil, gl1, gl2, memPivot);

    const happyEye = new THREE.Group();
    const happyHood = new THREE.Mesh(hoodGeo, browRimMat);
    happyHood.position.set(0, 0, -er * 0.32);
    const happyRim = new THREE.Mesh(rimTorusGeo, browRimMat);
    happyRim.position.set(0, 0, -er * 0.14);
    const happyBall = new THREE.Mesh(eyeGlobeGeo, eyeBallMat);
    happyBall.position.set(0, 0, er * 0.06);
    const hArc = new THREE.Mesh(happyGeo, happyMat);
    hArc.position.set(0, 0, er * 0.96);
    happyEye.add(happyHood, happyRim, happyBall, hArc);
    happyEye.visible = false;

    eyeSocket.add(normalEye, happyEye);
    eyesNormal.push(normalEye);
    eyesPupil.push(pupil);
    eyesHappy.push(happyEye);
  }

  // Glowing electric-cyan bite/hap aura ring positioned underneath head where tentacles tuck prey into beak
  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, 0.04, -0.065, RING_CYAN, 0.078);

  const tailPivot = new THREE.Group();
  tailPivot.position.set(xBack, 0, 0);
  bodyGroup.add(tailPivot);
  const pecLeft = new THREE.Group();
  const pecRight = new THREE.Group();
  const pelvicFin = new THREE.Group();

  return {
    speciesKey: sp.id,
    tailPivotX: xBack,
    isFluke: true,
    skipDefaultFins: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p, open, swimAmp) => {
      const pullSignal = clamp(p.tentaclePull ?? 0, 0, 1);
      // Idle suction keeps hands back (handled in engine); during active catch-and-pull, allow clasp -> pull -> hap!
      const reachSignal = clamp((p.tentacleReach ?? 0) * (1 - pullSignal * 0.85), 0, 1);
      const trailSignal = clamp(p.tentacleTrail ?? (p.swimSpeed * 0.9 + (p.boostAmt ?? 0) * 0.4), 0, 1.45);
      const vertLagSignal = clamp(p.tentacleVertLag ?? 0, -1.15, 1.15);
      const turnLagSignal = clamp(p.tentacleTurnLag ?? (p.turnVel ?? 0), -1.35, 1.35);

      const glowPulse = p.sucking ? 1.0 : clamp(Math.max(open * 0.65, pullSignal, reachSignal) * 1.05, 0, 1);
      const pulseWave = p.sucking ? 0.5 + 0.5 * Math.sin(p.wag2 * 4.5) : 0;
      const ringOpacity = 0.14 + glowPulse * 0.82 + pulseWave * 0.14;
      ringShellMat.opacity = ringOpacity;

      // Monotonically integrated tailPh keeps wave phase continuous across speed changes!
      const wave = p.tailPh * 1.18 + (p.sucking ? p.wag2 * 0.95 : 0);
      const floatPh = p.wag2 * 0.44;
      const flare = clamp(pullSignal * 0.45 + (p.sucking ? 0.35 : 0), 0, 1.0);
      const feedActive = clamp(Math.max(reachSignal, pullSignal), 0, 1);
      for (const a of arms) {
        a.wUniforms.uWave.value = wave;
        a.wUniforms.uFloatPh.value = floatPh;
        a.wUniforms.uFlare.value = flare;
        a.wUniforms.uReach.value = a.isFeeder ? reachSignal : 0;
        a.wUniforms.uPull.value = a.isFeeder ? pullSignal : 0;
        a.wUniforms.uFeedActive.value = feedActive;
        a.wUniforms.uTrail.value = trailSignal;
        a.wUniforms.uVertLag.value = vertLagSignal;
        a.wUniforms.uTurnLag.value = turnLagSignal;
        a.ringMat.opacity = ringOpacity;
      }

      // Drive soft squishy jelly dome deformation + seamless neck lag + gulp bulge + eye cushion
      const idleFloatPulse = (1 - clamp(trailSignal * 1.8, 0, 1)) * Math.sin(floatPh) * 0.045;
      const sqVal = clamp(p.sq, -0.4, 0.55) + pullSignal * 0.12 + idleFloatPulse;
      const jiggleAmp = 0.026 + Math.abs(p.sq) * 0.14 + pullSignal * 0.055 + (p.sucking ? 0.032 : 0);
      squishUniforms.uWave.value = wave;
      squishUniforms.uSquish.value = sqVal;
      squishUniforms.uJiggle.value = jiggleAmp;
      squishUniforms.uSwimAmp.value = swimAmp;
      squishUniforms.uTrail.value = trailSignal;
      squishUniforms.uVertLag.value = vertLagSignal;
      squishUniforms.uTurnLag.value = turnLagSignal;
      squishUniforms.uFloatPh.value = floatPh;
      squishUniforms.uFeedActive.value = feedActive;
      squishUniforms.uGulpT.value = clamp(p.gulpT ?? 0, 0, 1);
      squishUniforms.uGulpK.value = clamp(p.gulpK ?? 0, 0, 1.5);

      const eyeSq = sqVal + Math.sin(wave * 0.85) * 0.056;
      eyesContainer.position.set(eyeSq * 0.026, -eyeSq * 0.042, 0);
      eyesContainer.scale.set(1 + eyeSq * 0.040, 1 - eyeSq * 0.052, 1 + eyeSq * 0.040);

      // Protective translucent swim membrane slides smoothly down over front cornea when swimming fast or boosting
      const fastSwim = clamp((trailSignal - 0.38) / 0.55 + (p.boostAmt ?? 0) * 0.65, 0, 1);
      const memCover = fastSwim * fastSwim * (3 - 2 * fastSwim);
      memMat.opacity = memCover * 0.86;
      for (const mp of memPivots) {
        mp.visible = memCover > 0.02;
        if (mp.visible) {
          mp.rotation.x = -0.25 + memCover * 1.48;
        }
      }

      mouthInterior.visible = false;
      tongueMesh.visible = false;
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 3. HIU PAUS / WHALE SHARK (Playable Pure-3D Gentle Giant with Constellation Dots & Wide Mouth)
// =====================================================================================
function createWhaleShark3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const pal = sp.pal;
  const OL = pal.outline || "#061024";
  const NAVY = pal.body || "#193a6a";
  const DARK = pal.dark || "#0a1936";
  const BEL = pal.belly || "#f8fafc";
  const FIN = pal.fin || "#254e88";
  const DOT = pal.spot || "#e0f7ff";
  const BAR = pal.stripe || "#bae6fd";

  const ctx = createRigContext(OL, "#565656");
  const { track, uniforms, makeOutlineMat, makeFishMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  const xTail = -0.34;
  const xSnout = 0.335;
  const spanX = xSnout - xTail;
  const hx = 0.22;
  const hy = -0.012;

  // Massive broad blunt-snout Whale Shark silhouette
  const topPts = sortAscX(
    sampleBezierChain(
      [
        [[-0.34, 0.024], [-0.22, 0.068], [-0.04, 0.135], [0.16, 0.138]],
        [[0.16, 0.138], [0.26, 0.128], [0.318, 0.095], [xSnout, 0.025]],
      ],
      24
    )
  );
  const botPts = sortAscX(
    sampleBezierChain(
      [
        [[-0.34, -0.022], [-0.20, -0.062], [0.02, -0.105], [0.22, -0.095]],
        [[0.22, -0.095], [0.295, -0.082], [0.328, -0.046], [xSnout, -0.015]],
      ],
      24
    )
  );
  const evalTop = (x: number) => interpCurveY(topPts, x);
  const evalBot = (x: number) => interpCurveY(botPts, x);
  // Broad flat blunt Whale Shark head Z width!
  const evalZ = (x: number, t: number) => {
    const base = 0.022 + 0.108 * Math.sin(Math.pow(clamp(t, 0.01, 0.99), 0.72) * Math.PI);
    return x > 0.20 ? Math.max(base, 0.092 * Math.sqrt(clamp(1 - Math.pow((x - 0.20) / 0.145, 2) * 0.72, 0.08, 1))) : base;
  };

  const { mapUV, beginCanvas2D } = createWorldMapper(-0.36, 0.36, -0.16, 0.16, 512);
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);

  bc.fillStyle = makeLin(bc, 0, -0.14, 0, 0.12, [
    [0, DARK],
    [0.44, NAVY],
    [0.70, mixHex(NAVY, BEL, 0.35)],
    [0.76, BEL],
    [1, "#e2e8f0"],
  ]);
  bc.fillRect(-0.4, -0.2, 0.8, 0.42);

  // Checkerboard Constellation: pale vertical stripes & bright star-dots along dorsal + flanks!
  for (let col = 0; col < 10; col++) {
    const bx = 0.22 - col * 0.052;
    const topY = -0.11 + col * 0.006;
    const botY = 0.045 - col * 0.002;
    // Pale checkerboard bar
    bc.strokeStyle = rgbaHex(BAR, 0.48);
    bc.lineWidth = 0.005;
    bc.beginPath();
    bc.moveTo(bx, topY);
    bc.lineTo(bx - 0.008, botY);
    bc.stroke();

    // Rows of crisp glowing constellation spots between bars
    const rows = 4;
    for (let r = 0; r < rows; r++) {
      const sy = topY + 0.018 + (r / rows) * (botY - topY);
      const sx = bx + 0.022 + (r % 2) * 0.006;
      const rad = 0.0075 - r * 0.0008;
      bc.fillStyle = DOT;
      bc.beginPath();
      bc.arc(sx, sy, rad, 0, Math.PI * 2);
      bc.fill();
    }
  }

  // Gill cleft lines
  bc.strokeStyle = rgbaHex(OL, 0.72);
  bc.lineWidth = 0.004;
  for (let g = 0; g < 5; g++) {
    const gx = 0.155 - g * 0.015;
    bc.beginPath();
    bc.arc(gx, 0.01, 0.045, -Math.PI * 0.3, Math.PI * 0.3);
    bc.stroke();
  }

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const bodyGeo = track(
    buildLoftedSurface({
      xStart: xTail,
      xEnd: xSnout,
      uSteps: 46,
      vSteps: 30,
      evalTopY: evalTop,
      evalBotY: evalBot,
      evalHalfZ: evalZ,
      mapUV,
      roundFront: false,
    })
  );
  const bodyMat = makeFishMat(bodyTex, { roughness: 0.42, emissiveIntensity: 0.24 });
  injectSpineShader(bodyMat, uniforms, 0.10, 0.12);
  const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
  bodyMesh.add(new THREE.Mesh(track(buildOutlineGeometry(bodyGeo, 0.0044)), makeOutlineMat(0.10, 0.12)));
  bodyGroup.add(bodyMesh);

  // Tall Rounded 1st Dorsal Fin with spots
  const d1Shape = new THREE.Shape();
  d1Shape.moveTo(0.055, 0);
  d1Shape.bezierCurveTo(0.01, 0.095, -0.045, 0.165, -0.088, 0.162);
  d1Shape.bezierCurveTo(-0.078, 0.10, -0.068, 0.04, -0.062, -0.008);
  d1Shape.closePath();
  const { geo: d1Geo, bounds: d1Bounds } = createExtrudedFin(d1Shape, 0.010, 0.0028, 16);
  track(d1Geo);
  const dottedFinTex = track(
    makePaintedFinTex(maxAnisotropy, d1Bounds, (fc) => {
      fc.fillStyle = makeLin(fc, 0, 0, -0.04, 0.16, [
        [0, NAVY],
        [0.6, FIN],
        [1, DARK],
      ]);
      fc.fillRect(-0.12, -0.02, 0.2, 0.22);
      fc.fillStyle = DOT;
      for (const [dx, dy] of [[-0.02, 0.04], [-0.04, 0.08], [-0.01, 0.09], [-0.06, 0.12], [-0.03, 0.125]]) {
        fc.beginPath();
        fc.arc(dx, dy, 0.007, 0, Math.PI * 2);
        fc.fill();
      }
    })
  );
  const d1Mat = makeFishMat(dottedFinTex, { roughness: 0.42 });
  injectSpineShader(d1Mat, uniforms, 0, 0);
  const d1Mesh = new THREE.Mesh(d1Geo, d1Mat);
  d1Mesh.position.set(-0.04, 0.124, 0);
  d1Mesh.add(new THREE.Mesh(track(buildOutlineGeometry(d1Geo, 0.0028)), makeOutlineMat(0, 0, true)));
  bodyGroup.add(d1Mesh);

  // Sweeping Heterocercal Whale Shark Caudal Tail
  const tailShape = new THREE.Shape();
  tailShape.moveTo(0.015, 0.028);
  tailShape.bezierCurveTo(-0.055, 0.088, -0.14, 0.175, -0.20, 0.205);
  tailShape.bezierCurveTo(-0.155, 0.095, -0.12, 0.02, -0.105, -0.005);
  tailShape.bezierCurveTo(-0.12, -0.06, -0.145, -0.115, -0.165, -0.145);
  tailShape.bezierCurveTo(-0.095, -0.105, -0.045, -0.055, 0.015, -0.024);
  tailShape.closePath();
  const { geo: tailGeo, bounds: tailBounds } = createExtrudedFin(tailShape, 0.009, 0.0024, 16);
  track(tailGeo);
  const tailTex = track(
    makePaintedFinTex(maxAnisotropy, tailBounds, (fc) => {
      fc.fillStyle = makeLin(fc, -0.18, 0.2, 0.02, -0.1, [
        [0, DARK],
        [0.5, NAVY],
        [1, FIN],
      ]);
      fc.fillRect(-0.24, -0.18, 0.28, 0.42);
      fc.fillStyle = rgbaHex(DOT, 0.8);
      for (const [dx, dy] of [[-0.08, 0.06], [-0.12, 0.11], [-0.15, 0.15], [-0.09, -0.05], [-0.12, -0.09]]) {
        fc.beginPath();
        fc.arc(dx, dy, 0.0065, 0, Math.PI * 2);
        fc.fill();
      }
    })
  );
  const tailMat = makeFishMat(tailTex, { roughness: 0.44 });
  injectSpineShader(tailMat, uniforms, 0, 0);
  const tailPivot = new THREE.Group();
  tailPivot.position.set(xTail + 0.022, 0.006, 0);
  const tailMesh = new THREE.Mesh(tailGeo, tailMat);
  tailMesh.add(new THREE.Mesh(track(buildOutlineGeometry(tailGeo, 0.0028)), makeOutlineMat(0, 0)));
  tailPivot.add(tailMesh);
  bodyGroup.add(tailPivot);

  // Broad Swept Pectoral Flippers
  const pecShape = new THREE.Shape();
  pecShape.moveTo(0.032, 0.018);
  pecShape.bezierCurveTo(-0.02, 0.04, -0.12, -0.05, -0.15, -0.12);
  pecShape.bezierCurveTo(-0.08, -0.10, -0.01, -0.04, 0.032, -0.014);
  pecShape.closePath();
  const { geo: pecGeo } = createExtrudedFin(pecShape, 0.006, 0.0018, 14);
  track(pecGeo);
  const pecMat = d1Mat;
  const pecZ = surfaceZAt((x) => evalZ(x, (x - xTail) / spanX), evalTop, evalBot, 0.085, -0.068) - 0.006;
  const pecLeft = new THREE.Group();
  pecLeft.position.set(0.085, -0.068, pecZ);
  const plMesh = new THREE.Mesh(pecGeo, pecMat);
  plMesh.rotation.x = Math.PI * 0.36;
  pecLeft.add(plMesh);
  const pecRight = new THREE.Group();
  pecRight.position.set(0.085, -0.068, -pecZ);
  const prMesh = new THREE.Mesh(pecGeo, pecMat);
  prMesh.rotation.x = -Math.PI * 0.36;
  pecRight.add(prMesh);
  bodyGroup.add(pecLeft, pecRight);

  const pelvicFin = new THREE.Group();
  bodyGroup.add(pelvicFin);

  // Extra-Wide Front Filter-Feeding Jaw
  const upperJawGroup = new THREE.Group();
  const lowerJawGroup = new THREE.Group();
  lowerJawGroup.position.set(hx, hy - 0.012, 0);
  bodyGroup.add(upperJawGroup, lowerJawGroup);
  const jawGeo = track(new THREE.BoxGeometry(0.11, 0.036, 0.14));
  jawGeo.translate(0.052, -0.008, 0);
  const jawMat = track(new THREE.MeshStandardMaterial({ color: BEL, roughness: 0.45 }));
  lowerJawGroup.add(new THREE.Mesh(jawGeo, jawMat));

  const { mouthInterior, tongueMesh } = createOralParts(ctx, bodyGroup, lowerJawGroup, xSnout - 0.016, hy, "#3b0724", "#f472b6", [0.062, 0.056, 0.095], [0.044, 0.015, 0.045], 0.052);

  const ez = computeEyeZ(evalTop, evalBot, (x) => evalZ(x, (x - xTail) / spanX), 0.278, 0.038, 0.025);
  const { eyesNormal, eyesPupil, eyesHappy } = createEyePair(ctx, bodyGroup, {
    ex: 0.278,
    ey: 0.038,
    ez,
    er: 0.025,
    sx: 0.96,
    yawRot: 0.32,
    irisColor: pal.iris || "#38bdf8",
    rimColor: OL,
    happyColor: DOT,
  });

  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, xSnout + 0.022, hy, DOT, 0.072);

  return {
    speciesKey: sp.id,
    tailPivotX: xTail + 0.022,
    skipDefaultFins: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal,
    eyesPupil,
    eyesHappy,
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p, open) => {
      const wideOpen = clamp(open * 1.15 + (p.sucking ? 0.55 : 0), 0, 1.35);
      lowerJawGroup.rotation.z = -wideOpen * 0.72;
      mouthInterior.visible = wideOpen > 0.03;
      if (mouthInterior.visible) {
        mouthInterior.scale.set(0.95 + wideOpen * 0.3, 0.42 + wideOpen * 1.15, 1.0 + wideOpen * 0.38);
      }
      tongueMesh.visible = wideOpen > 0.06;
      pecLeft.rotation.x = Math.sin(p.tailPh) * 0.14;
      pecRight.rotation.x = -Math.sin(p.tailPh) * 0.14;
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 4. PENARI SPANYOL / SPANISH DANCER (Pure 3D Coral Reef Nudibranch — Flamenco Undulating Skirt)
// =====================================================================================
function createSpanishDancer3DRig(sp: Species, maxAnisotropy: number): Fish3DRig {
  const ctx = createRigContext("#4c0519", "#4a4a4a");
  const { track, uniforms, makeOutlineMat, makeFishMat } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  const CRIMSON = "#e11d48";
  const SCARLET = "#ef4444";
  const ORANGE = "#fb923c";
  const CREAM = "#ffedd5";

  const xTail = -0.23;
  const xSnout = 0.23;
  const topProf = sampleBezierChain(
    [
      [[-0.23, -0.01], [-0.15, 0.055], [0.02, 0.068], [0.16, 0.055]],
      [[0.16, 0.055], [0.21, 0.038], [0.228, 0.005], [xSnout, -0.015]],
    ],
    20
  );
  const botProf = sampleBezierChain(
    [
      [[-0.23, -0.02], [-0.12, -0.052], [0.06, -0.052], [0.20, -0.042]],
      [[0.20, -0.042], [0.224, -0.030], [0.23, -0.020], [xSnout, -0.015]],
    ],
    20
  );
  const evalTop = (x: number) => interpCurveY(topProf, x);
  const evalBot = (x: number) => interpCurveY(botProf, x);
  const evalZ = (_x: number, t: number) => 0.016 + 0.068 * Math.sin(Math.pow(clamp(t, 0.01, 0.99), 0.72) * Math.PI);

  const { mapUV, beginCanvas2D } = createWorldMapper(-0.25, 0.25, -0.08, 0.09, 512);
  const bodyCv = document.createElement("canvas");
  bodyCv.width = 512;
  bodyCv.height = 512;
  const bc = bodyCv.getContext("2d")!;
  beginCanvas2D(bc);
  bc.fillStyle = makeLin(bc, 0, -0.07, 0, 0.06, [
    [0, "#9f1239"],
    [0.42, CRIMSON],
    [0.82, ORANGE],
    [1, CREAM],
  ]);
  bc.fillRect(-0.28, -0.1, 0.56, 0.2);

  // Cream-orange spotted flamenco mantle flecks
  bc.fillStyle = rgbaHex(CREAM, 0.78);
  for (let i = 0; i < 16; i++) {
    const sx = -0.16 + i * 0.022;
    const sy = Math.sin(i * 2.3) * 0.026;
    bc.beginPath();
    bc.arc(sx, sy, 0.0055, 0, Math.PI * 2);
    bc.fill();
  }

  const bodyTex = track(new THREE.CanvasTexture(bodyCv));
  bodyTex.colorSpace = THREE.SRGBColorSpace;
  bodyTex.anisotropy = maxAnisotropy;

  const bodyGeo = track(
    buildLoftedSurface({
      xStart: xTail,
      xEnd: xSnout,
      uSteps: 36,
      vSteps: 24,
      evalTopY: evalTop,
      evalBotY: evalBot,
      evalHalfZ: evalZ,
      mapUV,
      roundFront: true,
      roundFrontStart: 0.85,
      roundFrontZ: true,
    })
  );
  const bodyMat = makeFishMat(bodyTex, { roughness: 0.38, emissiveIntensity: 0.34 });
  injectSpineShader(bodyMat, uniforms, 0.14, 0.16);
  const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
  bodyMesh.add(new THREE.Mesh(track(buildOutlineGeometry(bodyGeo, 0.0036)), makeOutlineMat(0.14, 0.16)));
  bodyGroup.add(bodyMesh);

  // Signature Undulating Ruffled 3D Flamenco Skirt Wings!
  const waveUniform = { value: 0 };
  const buildFlamencoSkirtGeo = (side: 1 | -1) => {
    const uS = 44;
    const vS = 14;
    const pos: number[] = [];
    const uv: number[] = [];
    const idx: number[] = [];
    for (let i = 0; i <= uS; i++) {
      const u = i / uS;
      const x = -0.21 + u * 0.41;
      const envelope = Math.sin(clamp(u, 0.02, 0.98) * Math.PI);
      for (let j = 0; j <= vS; j++) {
        const v = j / vS;
        const flare = v * v;
        const z = side * (0.042 + v * 0.145 * Math.pow(envelope, 0.65));
        const ruffle = Math.sin(u * 26.0 + side * 0.8) * 0.036 * flare + Math.sin(u * 13.0) * 0.022 * flare;
        const y = -0.025 + ruffle + v * 0.018;
        pos.push(x, y, z);
        uv.push(u, v);
      }
    }
    for (let i = 0; i < uS; i++) {
      for (let j = 0; j < vS; j++) {
        const a = i * (vS + 1) + j;
        const b = a + 1;
        const c = a + (vS + 1);
        const d = c + 1;
        if (side > 0) idx.push(a, c, b, b, c, d);
        else idx.push(a, b, c, b, d, c);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    return geo;
  };

  const skirtCv = document.createElement("canvas");
  skirtCv.width = 256;
  skirtCv.height = 128;
  const skc = skirtCv.getContext("2d")!;
  const skg = skc.createLinearGradient(0, 128, 0, 0);
  skg.addColorStop(0, "#9f1239");
  skg.addColorStop(0.35, CRIMSON);
  skg.addColorStop(0.68, SCARLET);
  skg.addColorStop(0.88, ORANGE);
  skg.addColorStop(1, CREAM);
  skc.fillStyle = skg;
  skc.fillRect(0, 0, 256, 128);
  const skirtTex = track(new THREE.CanvasTexture(skirtCv));
  skirtTex.colorSpace = THREE.SRGBColorSpace;
  skirtTex.anisotropy = maxAnisotropy;

  const skirtMat = track(
    new THREE.MeshStandardMaterial({
      map: skirtTex,
      emissive: SCARLET,
      emissiveIntensity: 0.28,
      roughness: 0.34,
      side: THREE.DoubleSide,
    })
  );
  skirtMat.onBeforeCompile = (shader) => {
    shader.uniforms.uWavePh = waveUniform;
    shader.vertexShader =
      "uniform float uWavePh;\n" +
      shader.vertexShader.replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
        float edgeK = smoothstep(0.0, 1.0, uv.y);
        float w1 = sin(position.x * 20.0 - uWavePh * 3.2) * 0.044;
        float w2 = cos(position.x * 11.0 - uWavePh * 2.1) * 0.024;
        transformed.y += (w1 + w2) * edgeK;`
      );
  };

  const skirtL = new THREE.Mesh(track(buildFlamencoSkirtGeo(1)), skirtMat);
  const skirtR = new THREE.Mesh(track(buildFlamencoSkirtGeo(-1)), skirtMat);
  bodyGroup.add(skirtL, skirtR);

  // Pair of Scarlet-Gold Rhinophore Antennae up front + Blooming Gill Rosette at rear!
  const rhinoMat = track(new THREE.MeshStandardMaterial({ color: ORANGE, emissive: CRIMSON, emissiveIntensity: 0.32, roughness: 0.35 }));
  const rhinoGeo = track(new THREE.ConeGeometry(0.010, 0.068, 10));
  rhinoGeo.translate(0, 0.032, 0);
  for (const s of [1, -1]) {
    const rh = new THREE.Mesh(rhinoGeo, rhinoMat);
    rh.position.set(0.165, 0.042, s * 0.022);
    rh.rotation.z = -0.35;
    rh.rotation.x = s * 0.25;
    bodyGroup.add(rh);
  }

  const gillRosette = new THREE.Group();
  gillRosette.position.set(-0.145, 0.052, 0);
  const plumeMat = track(new THREE.MeshStandardMaterial({ color: "#fb7185", emissive: CRIMSON, emissiveIntensity: 0.45, roughness: 0.35 }));
  const plumeGeo = track(new THREE.ConeGeometry(0.011, 0.048, 8));
  plumeGeo.translate(0, 0.022, 0);
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const pm = new THREE.Mesh(plumeGeo, plumeMat);
    pm.rotation.z = Math.cos(a) * 0.45;
    pm.rotation.x = Math.sin(a) * 0.45;
    gillRosette.add(pm);
  }
  bodyGroup.add(gillRosette);

  const upperJawGroup = new THREE.Group();
  const lowerJawGroup = new THREE.Group();
  const mouthInterior = new THREE.Group();
  mouthInterior.visible = false;
  const tongueMesh = new THREE.Mesh(track(new THREE.BufferGeometry()));
  tongueMesh.visible = false;
  const tailPivot = new THREE.Group();
  const pecLeft = new THREE.Group();
  const pecRight = new THREE.Group();
  const pelvicFin = new THREE.Group();
  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, xSnout, 0, ORANGE, 0.04);

  return {
    speciesKey: sp.id,
    tailPivotX: xTail,
    isFluke: true,
    skipDefaultFins: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal: [],
    eyesPupil: [],
    eyesHappy: [],
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p) => {
      waveUniform.value = p.wag2 * 0.55;
      skirtL.rotation.x = Math.sin(p.wag2 * 1.3) * 0.14;
      skirtR.rotation.x = -Math.sin(p.wag2 * 1.3 + 0.8) * 0.14;
      gillRosette.rotation.y = p.wag2 * 0.25;
      mouthInterior.visible = false;
      tongueMesh.visible = false;
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// 5. UBUR-UBUR SISIR / COMB JELLY (CTENOPHORA) (Pure 3D Translucent Bell + 8 RGB Comb Rows)
// =====================================================================================
function createCombJelly3DRig(sp: Species, _maxAnisotropy: number): Fish3DRig {
  const ctx = createRigContext("#083344", "#222222");
  const { track, uniforms } = ctx;
  const { root, pitchGroup, yawGroup, bodyGroup } = baseGroups();

  // Translucent crystal-glass oval/pear dome oriented vertically along Y (swimming gracefully)
  const bellGeo = track(new THREE.SphereGeometry(0.195, 28, 22));
  bellGeo.scale(0.86, 1.18, 0.86);
  const bellMat = track(
    new THREE.MeshPhysicalMaterial({
      color: "#a5f3fc",
      emissive: "#0ea5e9",
      emissiveIntensity: 0.22,
      roughness: 0.08,
      metalness: 0.05,
      transmission: 0.25,
      clearcoat: 1.0,
      clearcoatRoughness: 0.08,
      transparent: true,
      opacity: 0.42,
      depthWrite: false,
      side: THREE.DoubleSide,
    })
  );
  const bellMesh = new THREE.Mesh(bellGeo, bellMat);
  bodyGroup.add(bellMesh);

  // Inner Glowing Bioluminescent Digestive Core
  const coreGeo = track(new THREE.SphereGeometry(0.068, 18, 14));
  coreGeo.scale(0.65, 1.35, 0.65);
  const coreMat = track(
    new THREE.MeshStandardMaterial({
      color: "#c084fc",
      emissive: "#67e8f9",
      emissiveIntensity: 0.95,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    })
  );
  const coreMesh = new THREE.Mesh(coreGeo, coreMat);
  coreMesh.position.set(0, 0.025, 0);
  bodyGroup.add(coreMesh);

  // 8 Longitudinal Rainbow RGB Comb-Plate Cilia Rows (*ctenes*)!
  const uRgbTime = { value: 0 };
  const rowPos: number[] = [];
  const rowUv: number[] = [];
  const rowPhase: number[] = [];
  const rowIdx: number[] = [];
  const segs = 26;
  const rows = 8;

  for (let r = 0; r < rows; r++) {
    const phi = (r / rows) * Math.PI * 2;
    const cp = Math.cos(phi);
    const sp2 = Math.sin(phi);
    const tx = -sp2 * 0.011;
    const tz = cp * 0.011;
    const baseVertex = rowPos.length / 3;
    for (let i = 0; i <= segs; i++) {
      const u = i / segs; // 0 bottom .. 1 top apex
      const theta = 0.22 + u * (Math.PI - 0.44); // avoid sharp pinch poles
      const rad = Math.sin(theta) * 0.172;
      const y = -Math.cos(theta) * 0.232;
      const cx = cp * rad;
      const cz = sp2 * rad;
      rowPos.push(cx - tx, y, cz - tz, cx + tx, y, cz + tz);
      rowUv.push(0, u, 1, u);
      rowPhase.push(phi, phi);
    }
    for (let i = 0; i < segs; i++) {
      const a = baseVertex + i * 2;
      rowIdx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
  }

  const combGeo = track(new THREE.BufferGeometry());
  combGeo.setAttribute("position", new THREE.Float32BufferAttribute(rowPos, 3));
  combGeo.setAttribute("uv", new THREE.Float32BufferAttribute(rowUv, 2));
  combGeo.setAttribute("aRow", new THREE.Float32BufferAttribute(rowPhase, 1));
  combGeo.setIndex(rowIdx);

  const combMat = track(
    new THREE.ShaderMaterial({
      uniforms: { uTime: uRgbTime },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      vertexShader: /* glsl */ `
        attribute float aRow;
        varying vec2 vUv;
        varying float vRow;
        void main() {
          vUv = uv;
          vRow = aRow;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: /* glsl */ `
        uniform float uTime;
        varying vec2 vUv;
        varying float vRow;
        vec3 hsvRainbow(float h) {
          vec3 k = vec3(1.0, 2.0 / 3.0, 1.0 / 3.0);
          vec3 p = abs(fract(vec3(h) + k) * 6.0 - 3.0);
          return clamp(p - 1.0, 0.0, 1.0);
        }
        void main() {
          float edgeSoft = sin(vUv.x * 3.14159);
          // Traveling rainbow comb-plate wave + subtle cilia beat segments
          float ciliaBeat = 0.55 + 0.45 * sin(vUv.y * 54.0 - uTime * 9.5 + vRow);
          float pulse = 0.62 + 0.38 * sin(uTime * 2.2 - vUv.y * 5.0 + vRow * 0.5);
          float hue = fract(vUv.y * 1.15 - uTime * 0.42 + vRow * 0.15915);
          vec3 col = mix(hsvRainbow(hue), vec3(1.0), 0.22);
          float alpha = edgeSoft * ciliaBeat * pulse * 0.92;
          gl_FragColor = vec4(col * 1.25, alpha);
        }
      `,
    })
  );
  const combMesh = new THREE.Mesh(combGeo, combMat);
  bodyGroup.add(combMesh);

  // Two Delicate Trailing Tentilla Filaments
  const tentMat = track(
    new THREE.MeshBasicMaterial({
      color: "#a5f3fc",
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    })
  );
  const tentPivots: THREE.Group[] = [];
  for (const s of [-1, 1]) {
    const pv = new THREE.Group();
    pv.position.set(s * 0.055, -0.185, 0);
    const pts = [
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(s * 0.02, -0.08, 0.015),
      new THREE.Vector3(-s * 0.01, -0.16, -0.015),
      new THREE.Vector3(s * 0.015, -0.23, 0.01),
    ];
    const tGeo = track(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 16, 0.0055, 6, false));
    pv.add(new THREE.Mesh(tGeo, tentMat));
    bodyGroup.add(pv);
    tentPivots.push(pv);
  }

  const upperJawGroup = new THREE.Group();
  const lowerJawGroup = new THREE.Group();
  const mouthInterior = new THREE.Group();
  mouthInterior.visible = false;
  const tongueMesh = new THREE.Mesh(track(new THREE.BufferGeometry()));
  tongueMesh.visible = false;
  const tailPivot = new THREE.Group();
  const pecLeft = new THREE.Group();
  const pecRight = new THREE.Group();
  const pelvicFin = new THREE.Group();
  const { biteRing, biteRingMat } = createBiteRing(ctx, bodyGroup, 0, 0, "#67e8f9", 0.04);

  return {
    speciesKey: sp.id,
    tailPivotX: -0.15,
    isFluke: true,
    skipDefaultFins: true,
    root,
    pitchGroup,
    yawGroup,
    bodyGroup,
    upperJawGroup,
    lowerJawGroup,
    mouthInterior,
    tongueMesh,
    tailPivot,
    pecLeft,
    pecRight,
    pelvicFin,
    eyesNormal: [],
    eyesPupil: [],
    eyesHappy: [],
    biteRing,
    biteRingMat,
    uniforms,
    onCustomPose: (p) => {
      uRgbTime.value = p.wag2 * 0.42;
      // Gentle rhythmic gelatinous bell pulse
      const pulse = Math.sin(p.wag2 * 1.15);
      bellMesh.scale.set(1 - pulse * 0.055, 1 + pulse * 0.065, 1 - pulse * 0.055);
      combMesh.scale.copy(bellMesh.scale);
      coreMat.emissiveIntensity = 0.78 + pulse * 0.25;
      for (let i = 0; i < tentPivots.length; i++) {
        tentPivots[i].rotation.z = Math.sin(p.wag2 * 1.4 + i * 1.4) * 0.24;
        tentPivots[i].rotation.x = Math.cos(p.wag2 * 1.1 + i) * 0.16;
      }
      mouthInterior.visible = false;
      tongueMesh.visible = false;
    },
    dispose: () => {
      for (const d of ctx.disposables) d.dispose();
    },
  };
}

// =====================================================================================
// DISPATCHER
// =====================================================================================
export function createExtraFish3DRig(sp: Species, maxAnisotropy = 4): Fish3DRig | null {
  switch (sp.style) {
    case "sunfish":
      return createSunfish3DRig(sp, maxAnisotropy);
    case "octopus":
      return createOctopus3DRig(sp, maxAnisotropy);
    case "whaleshark":
      return createWhaleShark3DRig(sp, maxAnisotropy);
    case "spanish_dancer":
      return createSpanishDancer3DRig(sp, maxAnisotropy);
    case "comb_jelly":
      return createCombJelly3DRig(sp, maxAnisotropy);
    default:
      return null;
  }
}
