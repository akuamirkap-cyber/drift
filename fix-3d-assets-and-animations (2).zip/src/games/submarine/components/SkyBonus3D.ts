import * as THREE from "three";

/**
 * 3D sky-bonus assets: glossy helium balloons and the rewards dangling under them (pocket stopwatch,
 * pearl gold coin and the turbo / vortex / shield skill medallions).
 *
 * They are rendered by the shared 3D showcase renderer (MenuAssets3D pool, no extra WebGL context) and
 * baked once into transparent sprite frames, so the 2D canvas engine draws real 3D-lit, PBR-shaded
 * assets at zero per-frame WebGL cost.
 */
export type SkyRigKind = "skyBalloon" | "skyStopwatch" | "skyCoin" | "skyTurbo" | "skyVortex" | "skyShield";
export type SkyItemKind = Exclude<SkyRigKind, "skyBalloon">;

export interface SkyRig {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  update: (t: number, hoverAmt: number, dt: number, dragYaw: number, dragPitch: number, customState: number) => void;
  dispose: () => void;
}

/** Balloon colours in BalloonKind order: stopwatch, turbo, vortex, shield, pearl */
export const SKY_BALLOON_COLORS = [0xf0244f, 0x10c4e2, 0xff7a1a, 0x14c98c, 0xf2459b];

/** Seconds per baked loop and frame counts of the dangling reward items */
export const SKY_ITEM_CYCLE: Record<SkyItemKind, number> = {
  skyStopwatch: 3,
  skyCoin: 2.4,
  skyTurbo: 3,
  skyVortex: 3,
  skyShield: 3,
};
export const SKY_ITEM_FRAMES: Record<SkyItemKind, number> = {
  skyStopwatch: 36,
  skyCoin: 32,
  skyTurbo: 24,
  skyVortex: 24,
  skyShield: 24,
};

const TAU = Math.PI * 2;

function makeKit(envMap: THREE.Texture, envIntensity: number) {
  const disposables: { dispose: () => void }[] = [];
  const track = <T extends { dispose: () => void }>(o: T): T => {
    disposables.push(o);
    return o;
  };
  const scene = new THREE.Scene();
  scene.environment = envMap;
  scene.environmentIntensity = envIntensity;
  const hemi = new THREE.HemisphereLight(0xffffff, 0x3b4a66, 0.9);
  const key = new THREE.DirectionalLight(0xffffff, 1.45);
  key.position.set(-2.6, 3.4, 3.8); // upper-left key light, same side as the 2D art highlights
  const rim = new THREE.DirectionalLight(0xc6f2ff, 0.6);
  rim.position.set(2.8, 1.4, -2.4);
  const fill = new THREE.DirectionalLight(0xfff1e0, 0.35);
  fill.position.set(2.2, -1.6, 3.0);
  scene.add(hemi, key, rim, fill);
  // square sprite showing 2.6 world units at the origin plane
  const camera = new THREE.PerspectiveCamera(26, 1, 0.1, 30);
  camera.position.set(0, 0, 1.3 / Math.tan(THREE.MathUtils.degToRad(13)));
  camera.lookAt(0, 0, 0);
  const root = new THREE.Group();
  scene.add(root);
  return {
    scene,
    camera,
    root,
    track,
    dispose: () => {
      for (const d of disposables) d.dispose();
    },
  };
}

/* ------------------------------------------------------------------ glossy helium balloon */
function buildBalloon(envMap: THREE.Texture): SkyRig {
  const k = makeKit(envMap, 0.55);
  const pts: THREE.Vector2[] = [];
  const N = 44;
  for (let i = 0; i <= N; i++) {
    const v = i / N; // 0 = knot end, 1 = crown
    const a = v * Math.PI;
    const r = Math.pow(Math.sin(a), 0.9) * (0.58 + 0.42 * Math.pow(v, 0.6)) * 0.97;
    const y = -Math.cos(a) * 1.02 + 0.05 * Math.sin(a);
    pts.push(new THREE.Vector2(Math.max(1e-4, r), y));
  }
  const bodyMat = k.track(
    new THREE.MeshPhysicalMaterial({
      color: SKY_BALLOON_COLORS[0],
      roughness: 0.22,
      metalness: 0,
      clearcoat: 1,
      clearcoatRoughness: 0.05,
      sheen: 0.35,
      sheenRoughness: 0.4,
      sheenColor: new THREE.Color(0xffffff),
    })
  );
  const body = new THREE.Mesh(k.track(new THREE.LatheGeometry(pts, 56)), bodyMat);
  const knotMat = k.track(new THREE.MeshPhysicalMaterial({ color: 0x9f1239, roughness: 0.4, clearcoat: 0.6, clearcoatRoughness: 0.2 }));
  const neck = new THREE.Mesh(k.track(new THREE.CylinderGeometry(0.05, 0.085, 0.12, 18)), knotMat);
  neck.position.y = -1.07;
  const lip = new THREE.Mesh(k.track(new THREE.TorusGeometry(0.075, 0.032, 10, 24)), knotMat);
  lip.rotation.x = Math.PI / 2;
  lip.position.y = -1.14;
  k.root.add(body, neck, lip);
  k.root.position.y = 0.016;
  const tmp = new THREE.Color();
  return {
    scene: k.scene,
    camera: k.camera,
    dispose: k.dispose,
    update: (t, _h, _dt, _yaw, _pitch, state) => {
      const idx = Math.max(0, Math.min(SKY_BALLOON_COLORS.length - 1, Math.round(state)));
      bodyMat.color.setHex(SKY_BALLOON_COLORS[idx]);
      knotMat.color.copy(tmp.setHex(SKY_BALLOON_COLORS[idx]).multiplyScalar(0.6));
      k.root.rotation.set(0.06, t * 0.4, 0);
    },
  };
}

/* ------------------------------------------------------------------ pocket stopwatch */
function makeDialTexture(): THREE.CanvasTexture {
  const S = 256;
  const cv = document.createElement("canvas");
  cv.width = cv.height = S;
  const g = cv.getContext("2d")!;
  const grd = g.createRadialGradient(S * 0.42, S * 0.4, 10, S / 2, S / 2, S / 2);
  grd.addColorStop(0, "#ffffff");
  grd.addColorStop(0.72, "#eef5ff");
  grd.addColorStop(1, "#c4d8f2");
  g.fillStyle = grd;
  g.beginPath();
  g.arc(S / 2, S / 2, S / 2, 0, TAU);
  g.fill();
  g.strokeStyle = "#1e293b";
  g.lineCap = "round";
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    const major = i % 3 === 0;
    g.lineWidth = major ? 13 : 8;
    const r0 = S * (major ? 0.33 : 0.37);
    const r1 = S * 0.45;
    g.beginPath();
    g.moveTo(S / 2 + Math.cos(a) * r0, S / 2 + Math.sin(a) * r0);
    g.lineTo(S / 2 + Math.cos(a) * r1, S / 2 + Math.sin(a) * r1);
    g.stroke();
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function buildStopwatch(envMap: THREE.Texture): SkyRig {
  const k = makeKit(envMap, 0.7);
  const steel = k.track(new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 1, roughness: 0.22 }));
  const gold = k.track(new THREE.MeshStandardMaterial({ color: 0xffc843, metalness: 1, roughness: 0.26 }));
  const watch = new THREE.Group();

  const caseM = new THREE.Mesh(k.track(new THREE.CylinderGeometry(1, 1, 0.34, 64)), steel);
  caseM.rotation.x = Math.PI / 2;
  const bezel = new THREE.Mesh(k.track(new THREE.TorusGeometry(0.95, 0.1, 18, 72)), steel);
  bezel.position.z = 0.17;
  const back = new THREE.Mesh(bezel.geometry, steel);
  back.position.z = -0.17;
  const face = new THREE.Mesh(
    k.track(new THREE.CircleGeometry(0.86, 64)),
    k.track(new THREE.MeshStandardMaterial({ map: k.track(makeDialTexture()), roughness: 0.45, metalness: 0 }))
  );
  face.position.z = 0.172;

  const handMat = k.track(new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.35, metalness: 0.2 }));
  const redMat = k.track(new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.3, metalness: 0.1 }));
  const minute = new THREE.Group();
  const mBar = new THREE.Mesh(k.track(new THREE.BoxGeometry(0.075, 0.6, 0.03)), handMat);
  mBar.position.y = 0.27;
  minute.add(mBar);
  minute.position.z = 0.19;
  minute.rotation.z = -1.05;
  const hour = new THREE.Group();
  const hBar = new THREE.Mesh(k.track(new THREE.BoxGeometry(0.09, 0.42, 0.03)), handMat);
  hBar.position.y = 0.18;
  hour.add(hBar);
  hour.position.z = 0.2;
  hour.rotation.z = 2.1;
  const second = new THREE.Group();
  const sBar = new THREE.Mesh(k.track(new THREE.BoxGeometry(0.034, 0.8, 0.02)), redMat);
  sBar.position.y = 0.3;
  second.add(sBar);
  second.position.z = 0.215;
  const cap = new THREE.Mesh(k.track(new THREE.CylinderGeometry(0.075, 0.075, 0.06, 20)), gold);
  cap.rotation.x = Math.PI / 2;
  cap.position.z = 0.235;

  // shallow crystal dome over the dial
  const R = 2.0;
  const th = Math.asin(0.86 / R);
  const glass = new THREE.Mesh(
    k.track(new THREE.SphereGeometry(R, 48, 12, 0, TAU, 0, th)),
    k.track(
      new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        roughness: 0.04,
        metalness: 0,
        transparent: true,
        opacity: 0.16,
        clearcoat: 1,
        depthWrite: false,
      })
    )
  );
  glass.rotation.x = Math.PI / 2;
  glass.position.z = 0.172 - R * Math.cos(th);

  // crown winder, hanging ring & side pushers
  const stem = new THREE.Mesh(k.track(new THREE.CylinderGeometry(0.1, 0.1, 0.2, 20)), steel);
  stem.position.y = 1.08;
  const crown = new THREE.Mesh(k.track(new THREE.CylinderGeometry(0.17, 0.17, 0.14, 24)), gold);
  crown.position.y = 1.2;
  const ring = new THREE.Mesh(k.track(new THREE.TorusGeometry(0.17, 0.045, 12, 32)), steel);
  ring.position.y = 1.43;
  const pushGeo = k.track(new THREE.CylinderGeometry(0.07, 0.07, 0.16, 16));
  const pushL = new THREE.Mesh(pushGeo, steel);
  pushL.position.set(-0.72, 0.76, 0);
  pushL.rotation.z = 0.75;
  const pushR = new THREE.Mesh(pushGeo, steel);
  pushR.position.set(0.72, 0.76, 0);
  pushR.rotation.z = -0.75;

  watch.add(caseM, bezel, back, face, minute, hour, second, cap, glass, stem, crown, ring, pushL, pushR);
  watch.scale.setScalar(0.9);
  watch.position.y = -0.27;
  k.root.add(watch);
  return {
    scene: k.scene,
    camera: k.camera,
    dispose: k.dispose,
    update: (t) => {
      const u = t / SKY_ITEM_CYCLE.skyStopwatch;
      second.rotation.z = -TAU * 2 * u; // two sweeps per loop (seamless)
      k.root.rotation.set(0.1 + Math.sin(TAU * u) * 0.05, Math.sin(TAU * u) * 0.45, Math.sin(TAU * u + 1) * 0.04);
    },
  };
}

/* ------------------------------------------------------------------ pearl gold coin */
function buildCoin(envMap: THREE.Texture): SkyRig {
  const k = makeKit(envMap, 0.75);
  const gold = k.track(new THREE.MeshStandardMaterial({ color: 0xffc533, metalness: 1, roughness: 0.24 }));
  const goldDeep = k.track(new THREE.MeshStandardMaterial({ color: 0xe3a41c, metalness: 1, roughness: 0.34 }));
  const coin = new THREE.Group();
  const disc = new THREE.Mesh(k.track(new THREE.CylinderGeometry(0.94, 0.94, 0.2, 64)), goldDeep);
  disc.rotation.x = Math.PI / 2;
  const edge = new THREE.Mesh(k.track(new THREE.CylinderGeometry(1.0, 1.0, 0.2, 72, 1, true)), gold);
  edge.rotation.x = Math.PI / 2;
  const rimGeo = k.track(new THREE.TorusGeometry(0.93, 0.09, 16, 72));
  const bezelGeo = k.track(new THREE.TorusGeometry(0.5, 0.06, 12, 48));
  const rayGeo = k.track(new THREE.BoxGeometry(0.06, 0.2, 0.05));
  for (const z of [0.1, -0.1]) {
    const rim = new THREE.Mesh(rimGeo, gold);
    rim.position.z = z;
    const bezel = new THREE.Mesh(bezelGeo, gold);
    bezel.position.z = z * 1.1;
    coin.add(rim, bezel);
    // embossed sun rays between the rim and the pearl setting
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * TAU;
      const ray = new THREE.Mesh(rayGeo, gold);
      ray.position.set(Math.cos(a) * 0.71, Math.sin(a) * 0.71, z * 1.05);
      ray.rotation.z = a - Math.PI / 2;
      coin.add(ray);
    }
  }
  const pearl = new THREE.Mesh(
    k.track(new THREE.SphereGeometry(0.44, 40, 28)),
    k.track(
      new THREE.MeshPhysicalMaterial({
        color: 0xfff4ec,
        roughness: 0.16,
        metalness: 0,
        clearcoat: 1,
        clearcoatRoughness: 0.05,
        iridescence: 0.85,
        iridescenceIOR: 1.5,
        sheen: 0.6,
        sheenColor: new THREE.Color(0xffd3ec),
      })
    )
  );
  coin.add(disc, edge, pearl);
  k.root.add(coin);
  return {
    scene: k.scene,
    camera: k.camera,
    dispose: k.dispose,
    update: (t) => {
      const u = t / SKY_ITEM_CYCLE.skyCoin;
      coin.rotation.y = TAU * u; // full coin spin per loop shows the thick milled edge
      k.root.rotation.x = 0.08;
    },
  };
}

/* ------------------------------------------------------------------ skill medallions */
function buildMedallion(envMap: THREE.Texture, kind: "skyTurbo" | "skyVortex" | "skyShield"): SkyRig {
  const k = makeKit(envMap, 0.6);
  const gold = k.track(new THREE.MeshStandardMaterial({ color: 0xffd34d, metalness: 1, roughness: 0.25 }));
  const enamel = k.track(
    new THREE.MeshPhysicalMaterial({ color: 0x0f2a52, roughness: 0.32, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.1 })
  );
  const med = new THREE.Group();
  const disc = new THREE.Mesh(k.track(new THREE.CylinderGeometry(0.98, 0.98, 0.22, 64)), enamel);
  disc.rotation.x = Math.PI / 2;
  const rim = new THREE.Mesh(k.track(new THREE.TorusGeometry(0.98, 0.12, 18, 72)), gold);
  med.add(disc, rim);

  const col = kind === "skyTurbo" ? 0x22d3ee : kind === "skyVortex" ? 0xfb923c : 0x34d399;
  const iconMat = k.track(
    new THREE.MeshPhysicalMaterial({
      color: col,
      emissive: col,
      emissiveIntensity: 0.22,
      roughness: 0.22,
      metalness: 0.05,
      clearcoat: 1,
      clearcoatRoughness: 0.06,
    })
  );
  const extrude = (shape: THREE.Shape) => {
    const g = k.track(
      new THREE.ExtrudeGeometry(shape, {
        depth: 0.14,
        bevelEnabled: true,
        bevelThickness: 0.05,
        bevelSize: 0.045,
        bevelSegments: 3,
        curveSegments: 18,
      })
    );
    g.center();
    return g;
  };

  let swirl: THREE.Object3D | null = null;
  if (kind === "skyTurbo") {
    const s = 0.125;
    const P = [
      [1.6, -5.8],
      [-3.8, 0.5],
      [0, 0.5],
      [-1.6, 5.8],
      [4.0, -0.5],
      [0.2, -0.5],
    ];
    const sh = new THREE.Shape();
    P.forEach(([x, y], i) => (i ? sh.lineTo(x * s, -y * s) : sh.moveTo(x * s, -y * s)));
    sh.closePath();
    const bolt = new THREE.Mesh(extrude(sh), iconMat);
    bolt.position.z = 0.2;
    med.add(bolt);
  } else if (kind === "skyShield") {
    const s = 0.12;
    const sh = new THREE.Shape();
    sh.moveTo(0, 5.4 * s);
    sh.lineTo(4.8 * s, 2.6 * s);
    sh.quadraticCurveTo(4.5 * s, -3.0 * s, 0, -5.8 * s);
    sh.quadraticCurveTo(-4.5 * s, -3.0 * s, -4.8 * s, 2.6 * s);
    sh.closePath();
    const shield = new THREE.Mesh(extrude(sh), iconMat);
    shield.position.z = 0.2;
    med.add(shield);
  } else {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 80; i++) {
      const v = i / 80;
      const a = v * TAU * 1.6;
      const r = 0.14 + v * 0.56;
      pts.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, 0));
    }
    const tube = new THREE.Mesh(k.track(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 160, 0.075, 12, false)), iconMat);
    tube.position.z = 0.2;
    const core = new THREE.Mesh(
      k.track(new THREE.SphereGeometry(0.17, 24, 16)),
      k.track(new THREE.MeshPhysicalMaterial({ color: 0xfed7aa, emissive: 0xffb36b, emissiveIntensity: 0.35, roughness: 0.2, clearcoat: 1 }))
    );
    core.position.z = 0.22;
    med.add(tube, core);
    swirl = tube;
  }
  k.root.add(med);
  return {
    scene: k.scene,
    camera: k.camera,
    dispose: k.dispose,
    update: (t) => {
      const u = t / SKY_ITEM_CYCLE[kind];
      med.rotation.set(0.06, Math.sin(TAU * u) * 0.5, 0);
      if (swirl) swirl.rotation.z = -TAU * u;
    },
  };
}

export function buildSkyRig(kind: SkyRigKind, envMap: THREE.Texture): SkyRig {
  switch (kind) {
    case "skyBalloon":
      return buildBalloon(envMap);
    case "skyStopwatch":
      return buildStopwatch(envMap);
    case "skyCoin":
      return buildCoin(envMap);
    default:
      return buildMedallion(envMap, kind);
  }
}
