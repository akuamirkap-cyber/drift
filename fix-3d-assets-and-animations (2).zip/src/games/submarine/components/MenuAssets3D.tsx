import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { buildSkyRig, SKY_ITEM_CYCLE, SKY_ITEM_FRAMES, type SkyRigKind, type SkyItemKind } from "./SkyBonus3D";

export type Asset3DKind = "crown" | "island" | "wheel" | "clam" | "trophy" | SkyRigKind;

interface AssetRig {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  update: (
    t: number,
    hoverAmt: number,
    dt: number,
    dragYaw: number,
    dragPitch: number,
    customState: number
  ) => void;
  dispose: () => void;
}

let cachedSoftGL: boolean | null = null;
function detectSoftwareWebGL(): boolean {
  if (cachedSoftGL !== null) return cachedSoftGL;
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (!gl) {
      cachedSoftGL = false;
      return false;
    }
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    const ren = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || "") : "";
    cachedSoftGL = /swiftshader|llvmpipe|software|mesa offscreen/i.test(ren);
    return cachedSoftGL;
  } catch {
    cachedSoftGL = false;
    return false;
  }
}

function smooth01(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  return c * c * (3 - 2 * c);
}

/* ---------------- Procedural Painterly Pixar PBR Textures ---------------- */

function makeWoodGrainTexture(): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 512;
  cv.height = 512;
  const ctx = cv.getContext("2d")!;

  const g = ctx.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, "#c2702c");
  g.addColorStop(0.28, "#9e511a");
  g.addColorStop(0.65, "#7f3d12");
  g.addColorStop(1, "#612b0a");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 68; i++) {
    const y = (i / 68) * 512;
    const isLight = i % 3 === 0;
    ctx.strokeStyle = isLight ? "rgba(255, 206, 134, 0.27)" : "rgba(42, 14, 3, 0.34)";
    ctx.lineWidth = isLight ? 2.2 : 3.2;
    ctx.beginPath();
    for (let x = 0; x <= 512; x += 24) {
      const wave =
        Math.sin((x / 512) * Math.PI * 2 + i * 0.72) * 5.6 +
        Math.cos((x / 512) * Math.PI * 4 - i * 1.12) * 2.4;
      if (x === 0) ctx.moveTo(x, y + wave);
      else ctx.lineTo(x, y + wave);
    }
    ctx.stroke();
  }

  for (const [kx, ky, rx, ry] of [
    [132, 146, 38, 11],
    [368, 356, 44, 12],
  ]) {
    ctx.strokeStyle = "rgba(42, 14, 3, 0.42)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(kx, ky, rx, ry, 0.08, 0, Math.PI * 2);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function makeRichMahoganyTexture(): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 256;
  cv.height = 256;
  const ctx = cv.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, "#8f431a");
  g.addColorStop(0.5, "#6b2d10");
  g.addColorStop(1, "#4a1c08");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 36; i++) {
    const y = (i / 36) * 256;
    ctx.strokeStyle = i % 3 === 0 ? "rgba(235, 160, 96, 0.18)" : "rgba(30, 9, 2, 0.3)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let x = 0; x <= 256; x += 16) {
      const w = Math.sin((x / 256) * Math.PI * 2 + i * 0.9) * 3;
      if (x === 0) ctx.moveTo(x, y + w);
      else ctx.lineTo(x, y + w);
    }
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function makeBarkTexture(): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 256;
  cv.height = 512;
  const ctx = cv.getContext("2d")!;
  ctx.fillStyle = "#9c5922";
  ctx.fillRect(0, 0, 256, 512);

  const rings = 9;
  for (let i = 0; i < rings; i++) {
    const y = (i / rings) * 512;
    const h = 512 / rings;
    const g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, "#592b0a");
    g.addColorStop(0.2, "#b06828");
    g.addColorStop(0.62, "#d68f44");
    g.addColorStop(0.86, "#a65e20");
    g.addColorStop(1, "#592b0a");
    ctx.fillStyle = g;
    ctx.fillRect(0, y, 256, h);
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}

function makeSandTexture(): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 512;
  cv.height = 512;
  const ctx = cv.getContext("2d")!;
  const g = ctx.createRadialGradient(244, 228, 28, 256, 256, 264);
  g.addColorStop(0, "#ffe78c");
  g.addColorStop(0.48, "#fcc84a");
  g.addColorStop(0.78, "#ec9f2a");
  g.addColorStop(0.94, "#cf7c1b");
  g.addColorStop(1, "#b46513");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 512);

  let s = 9187;
  const rnd = () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
  for (let i = 0; i < 1100; i++) {
    const x = rnd() * 512;
    const y = rnd() * 512;
    const r = 1.2 + rnd() * 2.6;
    ctx.fillStyle = rnd() > 0.52 ? "rgba(255, 250, 206, 0.36)" : "rgba(148, 76, 12, 0.2)";
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeLagoonTexture(): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 512;
  cv.height = 512;
  const ctx = cv.getContext("2d")!;
  const g = ctx.createRadialGradient(256, 256, 60, 256, 256, 254);
  g.addColorStop(0, "#dcfeff");
  g.addColorStop(0.56, "#4ee6ff");
  g.addColorStop(0.76, "#16c2f2");
  g.addColorStop(0.91, "#0284c7");
  g.addColorStop(1, "#074f8c");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 512);

  for (const [rad, alpha, lw] of [
    [176, 0.84, 12],
    [208, 0.5, 7],
    [234, 0.36, 4.6],
  ] as [number, number, number][]) {
    ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
    ctx.lineWidth = lw;
    ctx.lineCap = "round";
    for (let k = 0; k < 6; k++) {
      const a0 = (k / 6) * Math.PI * 2 + 0.12;
      ctx.beginPath();
      ctx.arc(256, 256, rad, a0, a0 + 0.68);
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeLeafTexture(tipHex: string, midHex: string, baseHex: string): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 256;
  cv.height = 128;
  const ctx = cv.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, 256, 0);
  g.addColorStop(0, baseHex);
  g.addColorStop(0.48, midHex);
  g.addColorStop(1, tipHex);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 128);

  ctx.strokeStyle = "rgba(222, 255, 136, 0.76)";
  ctx.lineWidth = 6.5;
  ctx.beginPath();
  ctx.moveTo(0, 64);
  ctx.lineTo(246, 64);
  ctx.stroke();

  ctx.strokeStyle = "rgba(8, 64, 24, 0.32)";
  ctx.lineWidth = 3.4;
  for (let x = 22; x < 242; x += 22) {
    ctx.beginPath();
    ctx.moveTo(x, 64);
    ctx.lineTo(x + 22, 4);
    ctx.moveTo(x, 64);
    ctx.lineTo(x + 22, 124);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeGoldGradientTexture(): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 64;
  cv.height = 256;
  const ctx = cv.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, "#fff47e");
  g.addColorStop(0.28, "#ffd528");
  g.addColorStop(0.68, "#f7a80c");
  g.addColorStop(1, "#d47306");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 256);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeShellOuterTexture(ribs: number): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 512;
  cv.height = 512;
  const ctx = cv.getContext("2d")!;

  // Vertical UV: y=0 outer scalloped front margin -> y=512 rear hinged umbo peak
  // Rich luxurious ocean royal orchid-magenta -> vibrant coral-rose -> sunny apricot blush!
  const g = ctx.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, "#8f2c86");
  g.addColorStop(0.16, "#b83d95");
  g.addColorStop(0.42, "#dc5ca0");
  g.addColorStop(0.72, "#f08db4");
  g.addColorStop(1, "#fbd0c8");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 512);

  // Rich dramatic Pixar ribbed valley grooves + bright sunlit scalloped crown crests
  for (let x = 0; x < 512; x++) {
    const u = x / 512;
    const ribVal = Math.cos((u * ribs + 0.5) * Math.PI * 2); // aligned cleanly with central hero rib
    if (ribVal < 0) {
      const a = Math.pow(-ribVal, 1.1) * 0.42;
      ctx.fillStyle = `rgba(74, 14, 72, ${a.toFixed(3)})`;
      ctx.fillRect(x, 0, 1, 512);
    } else {
      const a = Math.pow(ribVal, 1.4) * 0.34;
      ctx.fillStyle = `rgba(255, 224, 212, ${a.toFixed(3)})`;
      ctx.fillRect(x, 0, 1, 512);
    }
  }

  // Graceful curved pearlescent shell growth stripes catching top sunlight
  for (const [ry, h, color] of [
    [62, 10, "rgba(255, 224, 236, 0.32)"],
    [122, 13, "rgba(92, 18, 86, 0.22)"],
    [194, 10, "rgba(255, 232, 226, 0.28)"],
    [274, 13, "rgba(112, 24, 92, 0.18)"],
    [358, 9, "rgba(255, 240, 228, 0.26)"],
  ] as [number, number, string][]) {
    ctx.fillStyle = color;
    ctx.fillRect(0, ry, 512, h);
  }

  // Crisp saturated plum-rose trim right along scalloped outer lip for rich contrast against bright ocean blue
  const edge = ctx.createLinearGradient(0, 0, 0, 44);
  edge.addColorStop(0, "rgba(96, 18, 92, 0.48)");
  edge.addColorStop(1, "rgba(96, 18, 92, 0)");
  ctx.fillStyle = edge;
  ctx.fillRect(0, 0, 512, 44);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeShellNacreTexture(ribs: number): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 512;
  cv.height = 512;
  const ctx = cv.getContext("2d")!;

  // Rich velvety jewel-box rose-pink & pearly salmon-lavender mother-of-pearl interior
  // (darker, warm, deeply shaded so the glowing bright iridescent pearl pops like pure magic!)
  const g = ctx.createLinearGradient(0, 0, 0, 512);
  g.addColorStop(0, "#d86ca2");
  g.addColorStop(0.18, "#f099c0");
  g.addColorStop(0.45, "#f7bdd0");
  g.addColorStop(0.72, "#e8b4d8");
  g.addColorStop(0.9, "#c47db8");
  g.addColorStop(1, "#9a4f96");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 512);

  // Subtle opalescent abalone sky-aqua, lavender & soft golden shimmer wash
  const prism = ctx.createLinearGradient(0, 60, 512, 440);
  prism.addColorStop(0, "rgba(182, 130, 228, 0.22)");
  prism.addColorStop(0.32, "rgba(130, 224, 248, 0.24)");
  prism.addColorStop(0.56, "rgba(255, 228, 178, 0.24)");
  prism.addColorStop(0.78, "rgba(255, 162, 206, 0.22)");
  prism.addColorStop(1, "rgba(176, 148, 240, 0.22)");
  ctx.fillStyle = prism;
  ctx.fillRect(0, 0, 512, 512);

  // Distinct sculptural radial inner scallop rib shading (never washes out flat!)
  for (let x = 0; x < 512; x++) {
    const rv = Math.cos(((x / 512) * ribs + 0.5) * Math.PI * 2);
    if (rv > 0) {
      ctx.fillStyle = `rgba(255, 240, 246, ${(rv * 0.34).toFixed(3)})`;
    } else {
      ctx.fillStyle = `rgba(128, 36, 98, ${(-rv * 0.3).toFixed(3)})`;
    }
    ctx.fillRect(x, 0, 1, 512);
  }

  // Deep velvety plum-rose ambient occlusion nestled toward inner center behind pearl
  const ao = ctx.createRadialGradient(256, 360, 20, 256, 360, 220);
  ao.addColorStop(0, "rgba(116, 32, 92, 0.38)");
  ao.addColorStop(0.6, "rgba(148, 48, 112, 0.14)");
  ao.addColorStop(1, "rgba(148, 48, 112, 0)");
  ctx.fillStyle = ao;
  ctx.fillRect(0, 0, 512, 512);

  // Thin bright mother-of-pearl glazed highlight lining rim
  const rim = ctx.createLinearGradient(0, 0, 0, 28);
  rim.addColorStop(0, "rgba(255, 226, 238, 0.55)");
  rim.addColorStop(1, "rgba(255, 226, 238, 0)");
  ctx.fillStyle = rim;
  ctx.fillRect(0, 0, 512, 28);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makePearlTexture(): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = 512;
  cv.height = 256;
  const ctx = cv.getContext("2d")!;

  // True breathtaking museum-grade Akoya/Opal mother-of-pearl gradient:
  // sculpted creamy luminous silver-ivory top -> iridescent dreamy aqua/rose/champagne middle -> warm silky orchid-lilac bottom glow!
  const base = ctx.createLinearGradient(0, 0, 0, 256);
  base.addColorStop(0, "#f6f8ff");
  base.addColorStop(0.24, "#e6f5ff");
  base.addColorStop(0.46, "#fff0dc");
  base.addColorStop(0.68, "#f8cfe8");
  base.addColorStop(0.86, "#d9b8f2");
  base.addColorStop(1, "#b89ae0");
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 512, 256);

  // Rich enchanted nacre mother-of-pearl rainbow orient clouds — unmistakable opalescent lagoon luster!
  const bands: [number, number, number, string][] = [
    [95, 86, 136, "rgba(122, 236, 255, 0.68)"],
    [245, 72, 144, "rgba(255, 236, 164, 0.64)"],
    [392, 104, 144, "rgba(255, 162, 214, 0.68)"],
    [162, 168, 142, "rgba(198, 152, 255, 0.62)"],
    [330, 174, 136, "rgba(128, 246, 220, 0.58)"],
    [475, 128, 118, "rgba(122, 236, 255, 0.58)"],
    [12, 128, 118, "rgba(122, 236, 255, 0.58)"],
  ];
  for (const [gx, gy, gr, col] of bands) {
    const rg = ctx.createRadialGradient(gx, gy, 6, gx, gy, gr);
    rg.addColorStop(0, col);
    rg.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, 512, 256);
  }

  // Luminous soft bright pearly crown ring for realistic Akoya skin depth
  const sheen = ctx.createLinearGradient(0, 0, 0, 82);
  sheen.addColorStop(0, "rgba(255, 255, 255, 0.55)");
  sheen.addColorStop(1, "rgba(255, 255, 255, 0)");
  ctx.fillStyle = sheen;
  ctx.fillRect(0, 0, 512, 82);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  return tex;
}

function makeSparkleGeometry(outerR: number, innerR: number): THREE.ShapeGeometry {
  const s = new THREE.Shape();
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const r = i % 2 === 0 ? outerR : innerR;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) s.moveTo(x, y);
    else s.lineTo(x, y);
  }
  s.closePath();
  return new THREE.ShapeGeometry(s);
}

function makeStarShape(outerR: number, innerR: number, points = 5): THREE.Shape {
  const s = new THREE.Shape();
  for (let i = 0; i < points * 2; i++) {
    const a = (i / (points * 2)) * Math.PI * 2 + Math.PI / 2;
    const r = i % 2 === 0 ? outerR : innerR;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) s.moveTo(x, y);
    else s.lineTo(x, y);
  }
  s.closePath();
  return s;
}

function addPixarLights(scene: THREE.Scene, warm = false) {
  const hemi = new THREE.HemisphereLight(warm ? 0xfff5d8 : 0xeafaff, warm ? 0x6b3a12 : 0x1a548e, 0.9);
  const key = new THREE.DirectionalLight(0xfffaf0, 1.08);
  key.position.set(2.3, 3.6, 3.9);
  const rim = new THREE.DirectionalLight(warm ? 0xffe280 : 0x70e8ff, 0.62);
  rim.position.set(-2.7, 1.6, -2.5);
  const lowBounce = new THREE.DirectionalLight(warm ? 0xf59e0b : 0x38bdf8, 0.3);
  lowBounce.position.set(0.3, -2.8, 2.0);
  scene.add(hemi, key, rim, lowBounce);
}

/* ---------------- 1. MAHKOTA 3D (GOLDEN CROWN) ---------------- */

function buildCrownRig(envMap: THREE.Texture): AssetRig {
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(o: T): T => {
    disposables.push(o);
    return o;
  };

  const scene = new THREE.Scene();
  scene.environment = envMap;
  scene.environmentIntensity = 0.44;
  addPixarLights(scene, true);

  const camera = new THREE.PerspectiveCamera(27, 1, 0.1, 20);
  camera.position.set(0, 0.68, 4.32);
  camera.lookAt(0, 0.12, 0);

  const root = new THREE.Group();
  scene.add(root);

  const goldTex = track(makeGoldGradientTexture());
  const goldBodyMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xffd024,
      map: goldTex,
      emissive: 0x703400,
      emissiveIntensity: 0.16,
      metalness: 0.36,
      roughness: 0.19,
      clearcoat: 0.94,
      clearcoatRoughness: 0.07,
    })
  );
  const goldLipMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xffe552,
      emissive: 0x7a4200,
      emissiveIntensity: 0.15,
      metalness: 0.32,
      roughness: 0.13,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
    })
  );
  const goldBandMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xf59b0a,
      emissive: 0x5c2600,
      emissiveIntensity: 0.18,
      metalness: 0.42,
      roughness: 0.23,
      clearcoat: 0.82,
      clearcoatRoughness: 0.11,
    })
  );
  const goldInnerMat = track(
    new THREE.MeshStandardMaterial({ color: 0xc26508, metalness: 0.45, roughness: 0.34 })
  );
  const goldOutlineMat = track(new THREE.MeshBasicMaterial({ color: 0x5e2602, side: THREE.BackSide }));
  const velvetMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xc81432,
      emissive: 0x4a0410,
      emissiveIntensity: 0.22,
      roughness: 0.78,
      metalness: 0.02,
      sheen: 0.6,
      sheenColor: new THREE.Color(0xff5272),
    })
  );
  const rubyMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xef193c,
      emissive: 0x990622,
      emissiveIntensity: 0.32,
      metalness: 0.06,
      roughness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
    })
  );
  const sapphireMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0x0ea5f5,
      emissive: 0x035aa6,
      emissiveIntensity: 0.32,
      metalness: 0.06,
      roughness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
    })
  );
  const emeraldMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0x10cf74,
      emissive: 0x046b38,
      emissiveIntensity: 0.28,
      metalness: 0.06,
      roughness: 0.06,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
    })
  );
  const gemGlintMat = track(new THREE.MeshBasicMaterial({ color: 0xffffff }));
  const sparkleMat = track(new THREE.MeshBasicMaterial({ color: 0xfffce0, transparent: true, opacity: 0.94 }));

  const cap = new THREE.Mesh(
    track(new THREE.SphereGeometry(0.54, 36, 22, 0, Math.PI * 2, 0, Math.PI * 0.52)),
    velvetMat
  );
  cap.scale.set(1.0, 0.72, 1.0);
  cap.position.y = -0.06;
  root.add(cap);

  const radSegs = 96;
  const hSegs = 16;
  const baseR = 0.56;
  const wallT = 0.082;
  const crownTopH = (theta: number) => {
    const c = Math.cos(theta * 5);
    const peak = Math.pow(Math.max(0, (c + 1) * 0.5), 1.5);
    const frontBoost = Math.pow(Math.max(0, Math.cos(theta)), 4) * 0.16;
    return 0.11 + peak * 0.48 + frontBoost;
  };
  const crownFlare = (theta: number, v: number) =>
    baseR + Math.pow(v, 1.2) * 0.21 + Math.pow(Math.max(0, Math.cos(theta)), 4) * 0.03 * v;

  const buildShell = (offset: number, flip: boolean) => {
    const pos: number[] = [];
    const uvs: number[] = [];
    const idx: number[] = [];
    for (let j = 0; j <= hSegs; j++) {
      const v = j / hSegs;
      for (let i = 0; i <= radSegs; i++) {
        const theta = (i / radSegs) * Math.PI * 2;
        const y = -0.22 + v * (crownTopH(theta) + 0.22);
        const r = crownFlare(theta, v) + offset;
        pos.push(Math.sin(theta) * r, y, Math.cos(theta) * r);
        uvs.push(i / radSegs, 1 - v);
      }
    }
    const stride = radSegs + 1;
    for (let j = 0; j < hSegs; j++) {
      for (let i = 0; i < radSegs; i++) {
        const a = j * stride + i;
        const b = a + 1;
        const c = a + stride;
        const d = c + 1;
        if (!flip) idx.push(a, b, d, a, d, c);
        else idx.push(a, d, b, a, c, d);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    return track(geo);
  };

  root.add(new THREE.Mesh(buildShell(0, false), goldBodyMat));
  root.add(new THREE.Mesh(buildShell(-wallT, true), goldInnerMat));
  root.add(new THREE.Mesh(buildShell(0.02, false), goldOutlineMat));

  const lipPts: THREE.Vector3[] = [];
  for (let i = 0; i < radSegs; i++) {
    const theta = (i / radSegs) * Math.PI * 2;
    const r = crownFlare(theta, 1) - wallT * 0.45;
    lipPts.push(new THREE.Vector3(Math.sin(theta) * r, crownTopH(theta), Math.cos(theta) * r));
  }
  root.add(
    new THREE.Mesh(
      track(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(lipPts, true), 120, wallT * 0.58, 16, true)),
      goldLipMat
    )
  );

  const band = new THREE.Mesh(track(new THREE.CylinderGeometry(0.585, 0.578, 0.23, 64)), goldBandMat);
  band.position.y = -0.255;
  const bandOut = new THREE.Mesh(track(new THREE.CylinderGeometry(0.61, 0.604, 0.248, 56)), goldOutlineMat);
  bandOut.position.y = -0.255;
  const botRim = new THREE.Mesh(track(new THREE.TorusGeometry(0.59, 0.06, 20, 72)), goldLipMat);
  botRim.rotation.x = Math.PI / 2;
  botRim.position.y = -0.35;
  const midRim = new THREE.Mesh(track(new THREE.TorusGeometry(0.596, 0.048, 18, 72)), goldLipMat);
  midRim.rotation.x = Math.PI / 2;
  midRim.position.y = -0.145;
  root.add(band, bandOut, botRim, midRim);

  const orbGeo = track(new THREE.SphereGeometry(0.115, 28, 22));
  const orbOutGeo = track(new THREE.SphereGeometry(0.13, 22, 16));
  const tipOrbs: THREE.Mesh[] = [];
  for (let k = 0; k < 5; k++) {
    const theta = (k / 5) * Math.PI * 2;
    const r = crownFlare(theta, 1) - wallT * 0.34;
    const y = crownTopH(theta) + (k === 0 ? 0.095 : 0.072);
    const s = k === 0 ? 1.2 : 0.96;
    const orb = new THREE.Mesh(orbGeo, goldLipMat);
    orb.scale.setScalar(s);
    orb.position.set(Math.sin(theta) * r, y, Math.cos(theta) * r);
    const ol = new THREE.Mesh(orbOutGeo, goldOutlineMat);
    ol.scale.setScalar(s);
    ol.position.copy(orb.position);
    root.add(orb, ol);
    tipOrbs.push(orb);
  }

  const bezelGeo = track(new THREE.TorusGeometry(0.102, 0.028, 14, 30));
  const gemGeo = track(new THREE.SphereGeometry(0.092, 22, 16));
  gemGeo.scale(1.0, 1.12, 0.56);
  const glintGeo = track(new THREE.SphereGeometry(0.026, 10, 8));

  const gems: { theta: number; y: number; scale: number; mat: THREE.Material; band?: boolean }[] = [
    { theta: 0, y: 0.11, scale: 1.38, mat: rubyMat },
    { theta: -0.62, y: 0.05, scale: 0.98, mat: sapphireMat },
    { theta: 0.62, y: 0.05, scale: 0.98, mat: sapphireMat },
    { theta: 1.26, y: 0.08, scale: 0.98, mat: rubyMat },
    { theta: -1.26, y: 0.08, scale: 0.98, mat: rubyMat },
    { theta: 1.88, y: 0.05, scale: 0.92, mat: sapphireMat },
    { theta: -1.88, y: 0.05, scale: 0.92, mat: sapphireMat },
    { theta: 2.51, y: 0.08, scale: 0.98, mat: rubyMat },
    { theta: -2.51, y: 0.08, scale: 0.98, mat: rubyMat },
    { theta: Math.PI, y: 0.05, scale: 0.92, mat: emeraldMat },
    ...Array.from({ length: 10 }, (_, idx) => ({
      theta: (idx / 10) * Math.PI * 2,
      y: -0.25,
      scale: idx % 2 === 0 ? 0.78 : 0.64,
      mat: idx % 2 === 1 ? emeraldMat : idx % 4 === 0 ? sapphireMat : rubyMat,
      band: true,
    })),
  ];

  for (const g of gems) {
    const holder = new THREE.Group();
    const rad = g.band ? 0.612 : crownFlare(g.theta, 0.46) + 0.014;
    holder.position.set(Math.sin(g.theta) * rad, g.y, Math.cos(g.theta) * rad);
    holder.rotation.y = g.theta;
    if (!g.band) holder.rotation.x = -0.15;
    holder.scale.setScalar(g.scale);
    const bezel = new THREE.Mesh(bezelGeo, goldBandMat);
    const gem = new THREE.Mesh(gemGeo, g.mat);
    gem.position.z = 0.012;
    const glint = new THREE.Mesh(glintGeo, gemGlintMat);
    glint.position.set(0.028, 0.036, 0.054);
    holder.add(bezel, gem, glint);
    root.add(holder);
  }

  const starGeo = track(makeSparkleGeometry(0.12, 0.028));
  const star1 = new THREE.Mesh(starGeo, sparkleMat);
  star1.position.set(0.54, 0.7, 0.52);
  const star2 = new THREE.Mesh(starGeo, sparkleMat);
  star2.position.set(-0.64, 0.48, 0.42);
  scene.add(star1, star2);

  return {
    scene,
    camera,
    update: (t, hoverAmt, _dt, dragYaw, dragPitch) => {
      root.rotation.order = "YXZ";
      root.position.y = Math.sin(t * 2.1) * 0.042 + hoverAmt * 0.045;
      root.rotation.y = Math.sin(t * 1.0) * 0.36 + dragYaw;
      root.rotation.x = 0.1 + Math.cos(t * 1.25) * 0.03 + dragPitch;
      root.rotation.z = Math.sin(t * 1.6 + 0.6) * 0.048;
      root.scale.setScalar(1.0 + hoverAmt * 0.06);

      star1.scale.setScalar(0.32 + Math.max(0, Math.sin(t * 3.1)) * 0.85);
      star1.rotation.z = t * 0.7;
      star2.scale.setScalar(0.24 + Math.max(0, Math.sin(t * 2.5 + 2.2)) * 0.65);
      star2.rotation.z = -t * 0.65;

      rubyMat.emissiveIntensity = 0.28 + Math.sin(t * 3.0) * 0.14;
      sapphireMat.emissiveIntensity = 0.3 + Math.cos(t * 2.7) * 0.14;
      tipOrbs[0].scale.setScalar(1.2 + Math.sin(t * 2.8) * 0.03);
    },
    dispose: () => {
      for (const d of disposables) d.dispose();
    },
  };
}

/* ---------------- 2. PULAU 3D (TROPICAL ISLAND) ---------------- */

function buildIslandRig(envMap: THREE.Texture): AssetRig {
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(o: T): T => {
    disposables.push(o);
    return o;
  };

  const scene = new THREE.Scene();
  scene.environment = envMap;
  scene.environmentIntensity = 0.34;
  addPixarLights(scene, false);

  const camera = new THREE.PerspectiveCamera(28, 1, 0.1, 20);
  camera.position.set(0, 1.04, 4.46);
  camera.lookAt(0, 0.22, 0);

  const root = new THREE.Group();
  root.position.y = -0.36;
  scene.add(root);

  const lagoonTex = track(makeLagoonTexture());
  const sandTex = track(makeSandTexture());
  const barkTex = track(makeBarkTexture());
  const leafTexSun = track(makeLeafTexture("#5df252", "#22c54a", "#128534"));
  const leafTexLush = track(makeLeafTexture("#45e056", "#18ae44", "#0e6f2d"));
  const leafTexRich = track(makeLeafTexture("#34c950", "#14943a", "#0b5c25"));

  const waterMat = track(
    new THREE.MeshPhysicalMaterial({ map: lagoonTex, roughness: 0.11, metalness: 0.02, clearcoat: 1.0, clearcoatRoughness: 0.04 })
  );
  const waterEdgeMat = track(
    new THREE.MeshPhysicalMaterial({ color: 0x0668ad, roughness: 0.2, clearcoat: 0.85 })
  );
  const waterTop = new THREE.Mesh(track(new THREE.CylinderGeometry(1.06, 0.96, 0.17, 64)), [
    waterEdgeMat,
    waterMat,
    waterEdgeMat,
  ]);
  waterTop.position.y = -0.05;
  root.add(waterTop);

  const rimWave = new THREE.Mesh(
    track(new THREE.TorusGeometry(1.03, 0.052, 18, 64)),
    track(
      new THREE.MeshPhysicalMaterial({
        color: 0x38d9ff,
        emissive: 0x066da8,
        emissiveIntensity: 0.18,
        roughness: 0.13,
        clearcoat: 1.0,
      })
    )
  );
  rimWave.rotation.x = Math.PI / 2;
  rimWave.position.y = 0.012;
  root.add(rimWave);

  const foamMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xcff7ff,
      emissiveIntensity: 0.24,
      roughness: 0.3,
      transparent: true,
      opacity: 0.94,
    })
  );
  const foam = new THREE.Mesh(track(new THREE.TorusGeometry(0.81, 0.056, 16, 64)), foamMat);
  foam.rotation.x = Math.PI / 2;
  foam.position.y = 0.036;
  root.add(foam);

  const sandGeo = track(new THREE.SphereGeometry(0.81, 48, 28, 0, Math.PI * 2, 0, Math.PI * 0.52));
  const sp = sandGeo.attributes.position;
  for (let i = 0; i < sp.count; i++) {
    const x = sp.getX(i);
    const y = sp.getY(i);
    const z = sp.getZ(i);
    const a = Math.atan2(z, x);
    const wobble = 1 + 0.055 * Math.sin(a * 3 + 0.5) + 0.035 * Math.cos(a * 2 - 0.3);
    sp.setXYZ(i, x * wobble, y * 0.49, z * wobble * 0.92);
  }
  sandGeo.computeVertexNormals();
  const sand = new THREE.Mesh(
    sandGeo,
    track(new THREE.MeshPhysicalMaterial({ map: sandTex, roughness: 0.5, clearcoat: 0.24, clearcoatRoughness: 0.4 }))
  );
  sand.position.y = 0.01;
  root.add(sand);

  const rockMat = track(new THREE.MeshPhysicalMaterial({ color: 0x7c8d9e, roughness: 0.6, clearcoat: 0.18 }));
  const rockGeo = track(new THREE.DodecahedronGeometry(0.15, 2));
  const r1 = new THREE.Mesh(rockGeo, rockMat);
  r1.scale.set(1.22, 0.72, 0.98);
  r1.position.set(-0.5, 0.18, 0.24);
  const r2 = new THREE.Mesh(rockGeo, rockMat);
  r2.scale.set(0.74, 0.58, 0.78);
  r2.position.set(-0.34, 0.16, 0.42);
  root.add(r1, r2);

  const starMat = track(
    new THREE.MeshPhysicalMaterial({ color: 0xff5a3d, emissive: 0x7c1606, emissiveIntensity: 0.16, roughness: 0.26, clearcoat: 0.68 })
  );
  const starArmGeo = track(new THREE.ConeGeometry(0.05, 0.16, 12));
  const starfish = new THREE.Group();
  starfish.position.set(0.36, 0.26, 0.42);
  starfish.rotation.set(0.42, 0.18, -0.34);
  for (let k = 0; k < 5; k++) {
    const arm = new THREE.Mesh(starArmGeo, starMat);
    const ang = (k / 5) * Math.PI * 2;
    arm.position.set(Math.cos(ang) * 0.052, 0, Math.sin(ang) * 0.052);
    arm.rotation.z = -Math.PI / 2;
    arm.rotation.y = -ang;
    starfish.add(arm);
  }
  const starCore = new THREE.Mesh(track(new THREE.SphereGeometry(0.054, 12, 10)), starMat);
  starCore.scale.set(1, 0.6, 1);
  starfish.add(starCore);
  root.add(starfish);

  const bushMat = track(new THREE.MeshPhysicalMaterial({ color: 0x1fb848, roughness: 0.38, clearcoat: 0.38 }));
  const bushGeo = track(new THREE.SphereGeometry(0.145, 18, 14));
  for (const [bx, by, bz, sc] of [
    [0.24, 0.36, 0.06, 0.94],
    [0.14, 0.35, -0.14, 0.86],
    [0.34, 0.31, -0.04, 0.7],
  ]) {
    const b = new THREE.Mesh(bushGeo, bushMat);
    b.scale.set(sc * 1.15, sc * 0.82, sc);
    b.position.set(bx, by, bz);
    root.add(b);
  }
  const bloom = new THREE.Mesh(
    track(new THREE.SphereGeometry(0.06, 14, 10)),
    track(new THREE.MeshPhysicalMaterial({ color: 0xff4ea3, emissive: 0x6b0b3c, emissiveIntensity: 0.2, roughness: 0.28, clearcoat: 0.55 }))
  );
  bloom.scale.set(1.12, 0.66, 1.12);
  bloom.position.set(0.28, 0.435, 0.14);
  root.add(bloom);

  const barkMat = track(new THREE.MeshPhysicalMaterial({ map: barkTex, roughness: 0.56, clearcoat: 0.16 }));
  const cocoMat = track(
    new THREE.MeshPhysicalMaterial({ color: 0x6b3410, roughness: 0.28, clearcoat: 0.62, clearcoatRoughness: 0.18 })
  );
  const leafMats = [leafTexSun, leafTexLush, leafTexRich].map((tex) =>
    track(
      new THREE.MeshPhysicalMaterial({ map: tex, roughness: 0.29, clearcoat: 0.54, clearcoatRoughness: 0.18, side: THREE.DoubleSide })
    )
  );

  const makeFrondGeo = (len: number, width: number) => {
    const segU = 18;
    const segV = 6;
    const verts: number[] = [];
    const uvs: number[] = [];
    const idx: number[] = [];
    for (let iu = 0; iu <= segU; iu++) {
      const u = iu / segU;
      const x = u * len;
      const archY = Math.sin(u * Math.PI * 0.78) * len * 0.28 - Math.pow(u, 2.15) * len * 0.48;
      const wEnv = Math.sin(Math.pow(u, 0.58) * Math.PI) * width * (1.02 - 0.08 * u);
      for (let iv = 0; iv <= segV; iv++) {
        const v = (iv / segV) * 2 - 1;
        const fold = -Math.abs(v) * width * 0.34 * (0.35 + 0.65 * u);
        verts.push(x, archY + fold, v * wEnv);
        uvs.push(u, (v + 1) * 0.5);
      }
    }
    const stride = segV + 1;
    for (let iu = 0; iu < segU; iu++) {
      for (let iv = 0; iv < segV; iv++) {
        const a = iu * stride + iv;
        const b = a + 1;
        const c = a + stride;
        const d = c + 1;
        idx.push(a, c, b, b, c, d);
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(verts, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    return track(geo);
  };

  const mainFrondGeo = makeFrondGeo(0.84, 0.27);
  const smallFrondGeo = makeFrondGeo(0.56, 0.19);
  const frondNodes: { pivot: THREE.Group; basePitch: number; ph: number }[] = [];

  const buildPalm = (pts: THREE.Vector3[], baseR: number, topR: number, frondCount: number, isHero: boolean) => {
    const curve = new THREE.CatmullRomCurve3(pts);
    const tubeSegs = 28;
    const radSegs = 18;
    const pos: number[] = [];
    const uvs: number[] = [];
    const idx: number[] = [];
    const frames = curve.computeFrenetFrames(tubeSegs, false);
    for (let i = 0; i <= tubeSegs; i++) {
      const u = i / tubeSegs;
      const pt = curve.getPointAt(u);
      const r = (baseR + (topR - baseR) * Math.pow(u, 0.72)) * (1 + 0.09 * Math.sin(u * Math.PI * 16));
      const N = frames.normals[i];
      const B = frames.binormals[i];
      for (let j = 0; j <= radSegs; j++) {
        const a = (j / radSegs) * Math.PI * 2;
        const ca = Math.cos(a);
        const sa = Math.sin(a);
        pos.push(pt.x + r * (ca * N.x + sa * B.x), pt.y + r * (ca * N.y + sa * B.y), pt.z + r * (ca * N.z + sa * B.z));
        uvs.push(j / radSegs, u);
      }
    }
    const stride = radSegs + 1;
    for (let i = 0; i < tubeSegs; i++) {
      for (let j = 0; j < radSegs; j++) {
        const a = i * stride + j;
        const b = a + 1;
        const c = a + stride;
        const d = c + 1;
        idx.push(a, b, d, a, d, c);
      }
    }
    const trunkGeo = track(new THREE.BufferGeometry());
    trunkGeo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    trunkGeo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    trunkGeo.setIndex(idx);
    trunkGeo.computeVertexNormals();
    root.add(new THREE.Mesh(trunkGeo, barkMat));

    const crown = new THREE.Group();
    crown.position.copy(curve.getPointAt(1));
    root.add(crown);

    const cGeo = track(new THREE.SphereGeometry(isHero ? 0.105 : 0.072, 18, 14));
    const cocoN = isHero ? 3 : 2;
    for (let c = 0; c < cocoN; c++) {
      const a = (c / cocoN) * Math.PI * 2 + 0.5;
      const m = new THREE.Mesh(cGeo, cocoMat);
      m.position.set(Math.cos(a) * (isHero ? 0.11 : 0.072), isHero ? -0.078 : -0.052, Math.sin(a) * (isHero ? 0.11 : 0.072));
      crown.add(m);
    }

    const geo = isHero ? mainFrondGeo : smallFrondGeo;
    for (let f = 0; f < frondCount; f++) {
      const upper = f % 2 === 0;
      const piv = new THREE.Group();
      piv.rotation.y = (f / frondCount) * Math.PI * 2 + (isHero ? 0.18 : 0.62);
      const basePitch = upper ? 0.22 : -0.1;
      const leaf = new THREE.Mesh(geo, leafMats[f % leafMats.length]);
      leaf.scale.setScalar(upper ? 0.94 : 1.05);
      piv.rotation.z = basePitch;
      piv.add(leaf);
      crown.add(piv);
      frondNodes.push({ pivot: piv, basePitch, ph: f * 1.15 + (isHero ? 0 : 2.1) });
    }
  };

  buildPalm(
    [
      new THREE.Vector3(-0.04, 0.28, 0.02),
      new THREE.Vector3(-0.13, 0.62, 0.05),
      new THREE.Vector3(-0.01, 0.94, 0.04),
      new THREE.Vector3(0.14, 1.2, 0.02),
    ],
    0.13,
    0.072,
    8,
    true
  );
  buildPalm(
    [
      new THREE.Vector3(-0.14, 0.26, -0.05),
      new THREE.Vector3(-0.36, 0.52, -0.06),
      new THREE.Vector3(-0.52, 0.77, -0.02),
    ],
    0.084,
    0.05,
    6,
    false
  );

  return {
    scene,
    camera,
    update: (t, hoverAmt, _dt, dragYaw, dragPitch) => {
      root.rotation.order = "YXZ";
      root.position.y = -0.36 + Math.sin(t * 1.85) * 0.036 + hoverAmt * 0.045;
      root.rotation.y = Math.sin(t * 0.65) * 0.3 + hoverAmt * 0.22 + dragYaw;
      root.rotation.x = dragPitch * 0.85;
      root.rotation.z = Math.sin(t * 1.25 + 0.5) * 0.03;
      root.scale.setScalar(1.0 + hoverAmt * 0.06);

      const fs = 1 + Math.sin(t * 2.4) * 0.042;
      foam.scale.set(fs, fs, 1);
      foamMat.opacity = 0.82 + Math.sin(t * 2.4) * 0.14;

      const breezeAmp = 0.082 + hoverAmt * 0.08;
      for (const fn of frondNodes) {
        fn.pivot.rotation.z = fn.basePitch + Math.sin(t * 2.3 + fn.ph) * breezeAmp;
      }
    },
    dispose: () => {
      for (const d of disposables) d.dispose();
    },
  };
}

/* ---------------- 3. SETIR KAPAL 3D (SHIP WHEEL) ---------------- */

function buildShipWheelRig(envMap: THREE.Texture): AssetRig {
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(o: T): T => {
    disposables.push(o);
    return o;
  };

  const scene = new THREE.Scene();
  scene.environment = envMap;
  scene.environmentIntensity = 0.46;
  addPixarLights(scene, true);

  const camera = new THREE.PerspectiveCamera(27, 1, 0.1, 20);
  camera.position.set(0, 0.06, 5.02);
  camera.lookAt(0, 0, 0);

  const pivot = new THREE.Group();
  scene.add(pivot);
  const wheel = new THREE.Group();
  pivot.add(wheel);

  const woodMat = track(
    new THREE.MeshPhysicalMaterial({ map: track(makeWoodGrainTexture()), roughness: 0.3, metalness: 0.04, clearcoat: 0.76, clearcoatRoughness: 0.16 })
  );
  const darkWoodMat = track(
    new THREE.MeshPhysicalMaterial({ color: 0x56260a, roughness: 0.38, metalness: 0.04, clearcoat: 0.5, clearcoatRoughness: 0.22 })
  );
  const handleWoodMat = track(
    new THREE.MeshPhysicalMaterial({ color: 0xc26e28, emissive: 0x3b1804, emissiveIntensity: 0.12, roughness: 0.27, metalness: 0.04, clearcoat: 0.78, clearcoatRoughness: 0.14 })
  );
  const brassMat = track(
    new THREE.MeshPhysicalMaterial({ color: 0xffd22e, emissive: 0x6e3a00, emissiveIntensity: 0.18, metalness: 0.5, roughness: 0.15, clearcoat: 0.96, clearcoatRoughness: 0.05 })
  );
  const bronzeMat = track(
    new THREE.MeshPhysicalMaterial({ color: 0xd98714, emissive: 0x4f2400, emissiveIntensity: 0.14, metalness: 0.54, roughness: 0.23, clearcoat: 0.7 })
  );

  const rimGeo = track(new THREE.TorusGeometry(0.64, 0.135, 32, 80));
  rimGeo.scale(1, 1, 1.18);
  wheel.add(new THREE.Mesh(rimGeo, woodMat));

  const brassRingGeo = track(new THREE.TorusGeometry(0.64, 0.032, 16, 80));
  const fRing = new THREE.Mesh(brassRingGeo, brassMat);
  fRing.position.z = 0.138;
  const bRing = new THREE.Mesh(brassRingGeo, brassMat);
  bRing.position.z = -0.138;
  wheel.add(fRing, bRing);

  wheel.add(new THREE.Mesh(track(new THREE.TorusGeometry(0.505, 0.032, 16, 72)), darkWoodMat));

  const spokeProfile = [
    new THREE.Vector2(0.056, 0.18),
    new THREE.Vector2(0.072, 0.28),
    new THREE.Vector2(0.05, 0.37),
    new THREE.Vector2(0.065, 0.5),
    new THREE.Vector2(0.06, 0.68),
    new THREE.Vector2(0.064, 0.76),
    new THREE.Vector2(0.098, 0.87),
    new THREE.Vector2(0.104, 0.95),
    new THREE.Vector2(0.08, 1.02),
    new THREE.Vector2(0.044, 1.055),
    new THREE.Vector2(0.0, 1.065),
  ];
  const spokeGeo = track(new THREE.LatheGeometry(spokeProfile, 26));
  const tipCapGeo = track(new THREE.SphereGeometry(0.058, 18, 14));
  const neckRingGeo = track(new THREE.TorusGeometry(0.07, 0.024, 14, 28));
  const rivetGeo = track(new THREE.SphereGeometry(0.048, 16, 12));
  rivetGeo.scale(1, 1, 0.64);

  for (let i = 0; i < 8; i++) {
    const arm = new THREE.Group();
    arm.rotation.z = (i / 8) * Math.PI * 2;
    arm.add(new THREE.Mesh(spokeGeo, handleWoodMat));

    const collar = new THREE.Mesh(neckRingGeo, brassMat);
    collar.rotation.x = Math.PI / 2;
    collar.position.y = 0.775;
    arm.add(collar);

    const cap = new THREE.Mesh(tipCapGeo, brassMat);
    cap.position.y = 1.045;
    arm.add(cap);

    const rF = new THREE.Mesh(rivetGeo, brassMat);
    rF.position.set(0, 0.64, 0.158);
    const rB = new THREE.Mesh(rivetGeo, brassMat);
    rB.position.set(0, 0.64, -0.158);
    arm.add(rF, rB);
    wheel.add(arm);
  }

  const hubGeo = track(new THREE.CylinderGeometry(0.268, 0.268, 0.3, 48));
  hubGeo.rotateX(Math.PI / 2);
  wheel.add(new THREE.Mesh(hubGeo, bronzeMat));

  const hubLipGeo = track(new THREE.TorusGeometry(0.25, 0.052, 20, 52));
  const hlF = new THREE.Mesh(hubLipGeo, brassMat);
  hlF.position.z = 0.132;
  const hlB = new THREE.Mesh(hubLipGeo, brassMat);
  hlB.position.z = -0.132;
  wheel.add(hlF, hlB);

  const innerDarkGeo = track(new THREE.CylinderGeometry(0.168, 0.168, 0.35, 36));
  innerDarkGeo.rotateX(Math.PI / 2);
  wheel.add(new THREE.Mesh(innerDarkGeo, darkWoodMat));

  const bossGeo = track(new THREE.SphereGeometry(0.13, 28, 20));
  bossGeo.scale(1, 1, 0.68);
  const bossF = new THREE.Mesh(bossGeo, brassMat);
  bossF.position.z = 0.165;
  const bossB = new THREE.Mesh(bossGeo, brassMat);
  bossB.position.z = -0.165;
  wheel.add(bossF, bossB);

  const miniBoltGeo = track(new THREE.SphereGeometry(0.025, 10, 10));
  for (let k = 0; k < 8; k++) {
    const a = (k / 8) * Math.PI * 2;
    const bf = new THREE.Mesh(miniBoltGeo, bronzeMat);
    bf.position.set(Math.cos(a) * 0.248, Math.sin(a) * 0.248, 0.184);
    const bb = new THREE.Mesh(miniBoltGeo, bronzeMat);
    bb.position.set(Math.cos(a) * 0.248, Math.sin(a) * 0.248, -0.184);
    wheel.add(bf, bb);
  }

  let spinAngle = 0.2;

  return {
    scene,
    camera,
    update: (t, hoverAmt, dt, dragYaw, dragPitch) => {
      if (hoverAmt > 0.02) spinAngle += (0.45 + hoverAmt * 1.75) * dt;
      wheel.rotation.z = spinAngle + Math.sin(t * 1.15) * 0.24;

      pivot.rotation.order = "YXZ";
      pivot.rotation.y = -0.24 + Math.sin(t * 0.88) * 0.2 + dragYaw;
      pivot.rotation.x = 0.12 + Math.cos(t * 1.05) * 0.065 + dragPitch;
      pivot.position.y = Math.sin(t * 1.85 + 1.1) * 0.034 + hoverAmt * 0.03;
      pivot.scale.setScalar(1.0 + hoverAmt * 0.06);
    },
    dispose: () => {
      for (const d of disposables) d.dispose();
    },
  };
}

/* ---------------- 4. KERANG MUTIARA 3D (OPENING & CLOSING PEARL CLAM) ---------------- */

function buildClamRig(envMap: THREE.Texture): AssetRig {
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(o: T): T => {
    disposables.push(o);
    return o;
  };

  const scene = new THREE.Scene();
  scene.environment = envMap;
  // Balanced vibrant daylight PBR lighting (crisp modeled rose-orchid ridges & dreamy glowing rainbow pearl, ZERO blowout!)
  scene.environmentIntensity = 0.34;
  const hemi = new THREE.HemisphereLight(0xfff6fc, 0x4b1f62, 0.72);
  const key = new THREE.DirectionalLight(0xfffaf2, 0.92);
  key.position.set(2.2, 3.4, 3.8);
  const rim = new THREE.DirectionalLight(0x8beeff, 0.52);
  rim.position.set(-2.6, 1.8, -2.4);
  const fill = new THREE.DirectionalLight(0xffd2ec, 0.28);
  fill.position.set(-1.6, -1.8, 2.6);
  scene.add(hemi, key, rim, fill);

  const camera = new THREE.PerspectiveCamera(27, 1, 0.1, 20);
  camera.position.set(0, 0.86, 4.92);
  camera.lookAt(0, 0.12, 0.04);

  const root = new THREE.Group();
  scene.add(root);

  const RIBS = 7;
  const outerTex = track(makeShellOuterTexture(RIBS));
  const nacreTex = track(makeShellNacreTexture(RIBS));
  const pearlTex = track(makePearlTexture());

  // Glossy lush Pixar violet-coral-pink deeply scalloped carapace
  const outerMat = track(
    new THREE.MeshPhysicalMaterial({
      map: outerTex,
      roughness: 0.26,
      metalness: 0.04,
      clearcoat: 0.88,
      clearcoatRoughness: 0.12,
    })
  );
  // Velvety glowing pearl-rose mother-of-pearl inner vault with authentic soft pastel prism shimmer
  const innerMat = track(
    new THREE.MeshPhysicalMaterial({
      map: nacreTex,
      roughness: 0.2,
      metalness: 0.04,
      clearcoat: 0.92,
      clearcoatRoughness: 0.08,
      iridescence: 0.55,
      iridescenceIOR: 1.36,
      iridescenceThicknessRange: [180, 440],
    })
  );
  // Thick plump glossy coral-berry rolled scalloped edge lip joining both outer & inner skins seamlessly
  const lipMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xe873ae,
      emissive: 0x450b30,
      emissiveIntensity: 0.1,
      roughness: 0.22,
      metalness: 0.04,
      clearcoat: 0.94,
      clearcoatRoughness: 0.08,
      side: THREE.DoubleSide,
    })
  );
  // Sumptuous deep coral-rose scalloped oyster mantle bed cushioning the jewel pearl with vivid jewel-box contrast!
  const bedMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xd94b8c,
      emissive: 0x5c0e3a,
      emissiveIntensity: 0.16,
      roughness: 0.42,
      clearcoat: 0.45,
      clearcoatRoughness: 0.24,
    })
  );
  const ruffleMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xf7a4cb,
      emissive: 0x611a44,
      emissiveIntensity: 0.1,
      roughness: 0.34,
      clearcoat: 0.62,
      clearcoatRoughness: 0.16,
    })
  );
  // Exquisite museum-grade radiant iridescent Rainbow Akoya Pearl — sculptural luminous pastel luster + crisp wet glaze!
  const pearlMat = track(
    new THREE.MeshPhysicalMaterial({
      map: pearlTex,
      color: 0xfff8fc,
      emissive: 0xffe4f4,
      emissiveIntensity: 0.07,
      metalness: 0.1,
      roughness: 0.1,
      clearcoat: 1.0,
      clearcoatRoughness: 0.03,
      iridescence: 0.95,
      iridescenceIOR: 1.42,
      iridescenceThicknessRange: [180, 540],
      reflectivity: 1.0,
    })
  );
  // Subtle dreamy warm-gold rim dot collar + razor-crisp twin Pixar eye-like window highlight reflections on the pearl!
  const catchMat = track(new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.94 }));
  const sparkleMat = track(
    new THREE.MeshBasicMaterial({ color: 0xfffdf0, transparent: true, opacity: 0.95, side: THREE.DoubleSide })
  );
  const goldPipMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xffe26b,
      emissive: 0x6b3a00,
      emissiveIntensity: 0.14,
      metalness: 0.42,
      roughness: 0.16,
      clearcoat: 1.0,
    })
  );

  // Sculpt solid, plump, watertight dual-surface fluted giant scallop valve anchored cleanly at hinge z = 0 -> front +Z
  const buildScallopValve = (sign: 1 | -1) => {
    const grp = new THREE.Group();
    const uSegs = 92;
    const rSegs = 34;
    const halfFan = 1.2; // lush iconic classic wide heart-scallop contour
    const lenMax = 1.14;
    const baseThick = 0.092;

    const evalPoint = (u: number, v: number, isOuter: boolean): [number, number, number] => {
      const s = u * 2 - 1; // -1 left .. +1 right
      const theta = s * halfFan;
      // Plump balanced wide round fan contour with distinct joyful scalloped petals along the front rim
      const fanShape = 0.8 + 0.22 * Math.cos(s * Math.PI * 0.5);
      // Use +0.5 phase so a lush hero scallop sits dead center at u=0.5!
      const flute = Math.cos((u * RIBS + 0.5) * Math.PI * 2); // [-1..+1], smooth rounded arches
      const edgeFade = smooth01(Math.min(u, 1 - u) * 7.0);
      const petalOut = Math.pow(v, 2.8) * 0.068 * Math.max(0, flute) * edgeFade;
      const rad = (0.06 + v * (lenMax - 0.06)) * fanShape + petalOut;

      const x = Math.sin(theta) * rad * 1.08;
      const z = Math.cos(theta) * rad * 0.95;

      // Deep round storybook vault cupping safely over the big pearl with crisp sealed lip at v = 1!
      const vCup = Math.sin(Math.pow(v, 0.72) * Math.PI);
      const sCup = Math.pow(Math.max(0.0, Math.cos(s * Math.PI * 0.495)), 0.62);
      const vault = (sign === 1 ? 0.38 : 0.34) * vCup * sCup;

      // Smooth pronounced scalloped fan-ribs flowing naturally out from hinge to wavy lip
      const ribH = (isOuter ? 0.062 : 0.028) * flute * Math.pow(v, 0.78) * (0.25 + 0.75 * edgeFade);
      // Matching symmetric wave seam around meeting edge -> upper & lower nest together airtight when closed!
      const lipWave = 0.03 * flute * Math.pow(v, 3.0) * edgeFade;

      const tVal = baseThick * (0.68 + 0.42 * Math.sin(v * Math.PI * 0.82)) * (0.76 + 0.24 * sCup);
      const midY = sign * vault + lipWave;
      const y = isOuter ? midY + sign * (tVal + ribH * 0.72) : midY + sign * (ribH * 0.28);
      return [x, y, z];
    };

    const buildFace = (isOuter: boolean) => {
      const pos: number[] = [];
      const uvs: number[] = [];
      const idx: number[] = [];
      const flip = (sign === 1 && !isOuter) || (sign === -1 && isOuter);
      for (let j = 0; j <= rSegs; j++) {
        const v = j / rSegs;
        for (let i = 0; i <= uSegs; i++) {
          const u = i / uSegs;
          const [x, y, z] = evalPoint(u, v, isOuter);
          pos.push(x, y, z);
          uvs.push(u, 1 - v);
        }
      }
      const st = uSegs + 1;
      for (let j = 0; j < rSegs; j++) {
        for (let i = 0; i < uSegs; i++) {
          const a = j * st + i;
          const b = a + 1;
          const c = a + st;
          const d = c + 1;
          if (!flip) idx.push(a, c, b, b, c, d);
          else idx.push(a, b, c, b, d, c);
        }
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
      geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
      geo.setIndex(idx);
      geo.computeVertexNormals();
      return track(geo);
    };

    // Thick buttery-smooth beveled rolled tube sealing the entire outer scalloped rim AND side wing edges cleanly!
    const buildRolledBorder = (ptsUV: Array<[number, number]>, rBase: number) => {
      const curvePts: THREE.Vector3[] = [];
      for (const [u, v] of ptsUV) {
        const o = evalPoint(u, v, true);
        const inn = evalPoint(u, v, false);
        curvePts.push(new THREE.Vector3((o[0] + inn[0]) * 0.5, (o[1] + inn[1]) * 0.5, (o[2] + inn[2]) * 0.5));
      }
      const curve = new THREE.CatmullRomCurve3(curvePts, false);
      return track(new THREE.TubeGeometry(curve, ptsUV.length, rBase, 14, false));
    };

    grp.add(new THREE.Mesh(buildFace(true), outerMat));
    grp.add(new THREE.Mesh(buildFace(false), innerMat));

    // Continuous juicy plump scalloped lip tube bridging outer & inner edges from left hinge -> front scallops -> right hinge!
    const rimPath: Array<[number, number]> = [];
    for (let j = 2; j <= rSegs; j += 2) rimPath.push([0, j / rSegs]);
    for (let i = 1; i < uSegs; i++) rimPath.push([i / uSegs, 1]);
    for (let j = rSegs; j >= 2; j -= 2) rimPath.push([1, j / rSegs]);
    grp.add(new THREE.Mesh(buildRolledBorder(rimPath, 0.056), lipMat));

    // Subtle gleaming golden-rose hinge ears (auricles) & smooth sculpted rounded rear umbo dome
    const earGeo = track(new THREE.SphereGeometry(0.175, 22, 16));
    earGeo.scale(1.62, 0.52, 0.9);
    const earL = new THREE.Mesh(earGeo, outerMat);
    earL.position.set(-0.27, sign * 0.085, 0.04);
    earL.rotation.y = 0.2;
    const earR = new THREE.Mesh(earGeo, outerMat);
    earR.position.set(0.27, sign * 0.085, 0.04);
    earR.rotation.y = -0.2;
    const umboGeo = track(new THREE.SphereGeometry(0.19, 24, 18));
    umboGeo.scale(1.38, 0.72, 1.0);
    const umbo = new THREE.Mesh(umboGeo, outerMat);
    umbo.position.set(0, sign * 0.11, 0.08);
    grp.add(earL, earR, umbo);

    return grp;
  };

  // Hinge neatly balanced at z = -0.52 so open & closed views sit square center-frame
  const shellCenter = new THREE.Group();
  shellCenter.position.set(0, -0.02, -0.52);
  root.add(shellCenter);

  const lowerValve = buildScallopValve(-1);
  shellCenter.add(lowerValve);

  // Sumptuous velvet deep coral-rose nested oyster pillow & dainty ruffled collar right inside lower bowl
  const bed = new THREE.Mesh(track(new THREE.SphereGeometry(0.46, 36, 20)), bedMat);
  bed.scale.set(1.22, 0.24, 1.0);
  bed.position.set(0, -0.17, 0.56);
  lowerValve.add(bed);

  // Soft puffy ring-collar cushion cupping bottom of pearl cleanly with jewel-case contrast
  const seatRing = new THREE.Mesh(track(new THREE.TorusGeometry(0.29, 0.068, 18, 48)), ruffleMat);
  seatRing.rotation.x = Math.PI / 2;
  seatRing.position.set(0, -0.105, 0.58);
  lowerValve.add(seatRing);

  // Delicate gleaming golden beaded cradle ring nested softly around pearl like a fairy-tale jewel box!
  const crownRim = new THREE.Mesh(track(new THREE.TorusGeometry(0.255, 0.026, 14, 52)), goldPipMat);
  crownRim.rotation.x = Math.PI / 2;
  crownRim.position.set(0, -0.064, 0.58);
  lowerValve.add(crownRim);
  const seedGeo = track(new THREE.SphereGeometry(0.028, 10, 8));
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    const pip = new THREE.Mesh(seedGeo, goldPipMat);
    pip.position.set(Math.cos(a) * 0.275, -0.058, 0.58 + Math.sin(a) * 0.275);
    lowerValve.add(pip);
  }

  // Glorious luminous 3D Rainbow Akoya Pearl — crisp sculptural mother-of-pearl pastel glow, sized safely to fit sealed tight inside!
  const pearlGroup = new THREE.Group();
  pearlGroup.position.set(0, 0.06, 0.58);
  shellCenter.add(pearlGroup);

  const pearlMesh = new THREE.Mesh(track(new THREE.SphereGeometry(0.305, 56, 42)), pearlMat);
  pearlGroup.add(pearlMesh);

  // Razor-crisp gleaming double window catchlight anchored on the viewer-facing sphere surface (stays fixed as orient spins!)
  const glintA = new THREE.Mesh(track(new THREE.SphereGeometry(0.066, 16, 12)), catchMat);
  glintA.scale.set(1.22, 0.72, 0.24);
  glintA.position.set(0.115, 0.16, 0.228);
  glintA.rotation.set(-0.42, 0.36, 0.52);
  const glintB = new THREE.Mesh(track(new THREE.SphereGeometry(0.028, 12, 10)), catchMat);
  glintB.scale.set(1, 1, 0.32);
  glintB.position.set(0.195, 0.092, 0.214);
  glintB.rotation.set(-0.2, 0.55, 0);
  pearlGroup.add(glintA, glintB);

  // Upper articulated scallop lid — swings cleanly from 0° (flush airtight seal!) up to ~64° grand fairy-tale open!
  const upperPivot = new THREE.Group();
  const upperValve = buildScallopValve(1);
  upperPivot.add(upperValve);
  shellCenter.add(upperPivot);

  // Crisp glossy cylindrical rear hinge knuckle unifying both valves neatly from back & sides
  const hingeRod = new THREE.Mesh(track(new THREE.CylinderGeometry(0.072, 0.072, 0.56, 20)), lipMat);
  hingeRod.rotation.z = Math.PI / 2;
  hingeRod.position.set(0, 0, 0.01);
  shellCenter.add(hingeRod);

  // Delicate radiant 4-point pearl sparkles blooming gently above the jewel only while shell is open
  const spGeo = track(makeSparkleGeometry(0.125, 0.028));
  const sparkles: Array<{ mesh: THREE.Mesh; bx: number; by: number; bz: number; ph: number; sc: number }> = [
    { mesh: new THREE.Mesh(spGeo, sparkleMat), bx: -0.42, by: 0.46, bz: 0.72, ph: 0.3, sc: 0.96 },
    { mesh: new THREE.Mesh(spGeo, sparkleMat), bx: 0.44, by: 0.5, bz: 0.68, ph: 1.9, sc: 1.08 },
    { mesh: new THREE.Mesh(spGeo, sparkleMat), bx: 0.16, by: 0.62, bz: 0.78, ph: 3.7, sc: 0.68 },
  ];
  for (const sk of sparkles) {
    sk.mesh.position.set(sk.bx, sk.by, sk.bz);
    shellCenter.add(sk.mesh);
  }

  // Automatic smooth breathing open/close rhythm + instant snappy open/close when clicked!
  let smoothOpen = 0.96;

  return {
    scene,
    camera,
    update: (t, hoverAmt, dt, dragYaw, dragPitch, customState) => {
      let targetOpen: number;
      if (customState >= 10) {
        // Explicit open amount (10 + 0..1) used by the deterministic sprite baker
        smoothOpen = Math.max(0, Math.min(1, customState - 10));
        targetOpen = smoothOpen;
      } else if (customState === 1) {
        targetOpen = 0.0; // sealed completely tight!
      } else if (customState === 2) {
        targetOpen = 1.0; // gracefully wide open!
      } else {
        // 5.6s satisfying continuous showpiece loop:
        // 0.00..0.44 bloom wide open | 0.44..0.60 silky seal close | 0.60..0.82 hold sealed shut | 0.82..1.00 silky bloom open!
        const cyc = (t % 5.6) / 5.6;
        if (cyc < 0.44) {
          targetOpen = 0.94 + Math.sin(t * 2.2) * 0.05;
        } else if (cyc < 0.6) {
          targetOpen = 1 - smooth01((cyc - 0.44) / 0.16);
        } else if (cyc < 0.82) {
          targetOpen = 0.0;
        } else {
          targetOpen = smooth01((cyc - 0.82) / 0.18);
        }
      }

      const damp = 1 - Math.exp(-10.5 * dt);
      smoothOpen += (targetOpen - smoothOpen) * damp;
      if (targetOpen === 0 && smoothOpen < 0.004) smoothOpen = 0;

      // Exact flush seal at smoothOpen = 0; wide picturesque ~62° presentation bloom at 1!
      upperPivot.rotation.x = -smoothOpen * 1.08;
      // Tilts gently to present both valves symmetrically at closed pose, leans open dramatically to display pearl!
      lowerValve.rotation.x = smoothOpen * 0.08;

      // Pearl cradles deeper safely inside sealed shell at 0, floats gently proud as jewel crown when open!
      const bob = Math.sin(t * 2.3) * 0.02 * smoothOpen;
      pearlGroup.position.y = 0.01 + smoothOpen * 0.135 + bob;
      // Scale delicately ensures ZERO edge clipping through outer scallop ridges when shut!
      const pScale = 0.86 + smoothOpen * 0.14;
      pearlGroup.scale.setScalar(pScale);
      pearlGroup.visible = smoothOpen > 0.04;
      // Smooth continuous shimmering rainbow orient turns gracefully over silk pearl skin
      pearlMesh.rotation.y = t * 0.62;
      pearlMesh.rotation.z = Math.sin(t * 0.55) * 0.16;

      // Radiant gem sparkles bloom softly above open pearl & disappear when shut!
      const openVis = smooth01((smoothOpen - 0.22) / 0.42);
      pearlMat.emissiveIntensity = 0.05 + openVis * (0.06 + Math.sin(t * 2.8) * 0.03);
      for (const sk of sparkles) {
        const tw = 0.36 + 0.64 * Math.max(0, Math.sin(t * 3.1 + sk.ph));
        const sc = openVis * sk.sc * tw;
        sk.mesh.visible = sc > 0.05;
        sk.mesh.scale.setScalar(Math.max(0.001, sc));
        sk.mesh.position.y = sk.by + Math.sin(t * 2.0 + sk.ph) * 0.042;
        sk.mesh.rotation.z = t * 0.55 + sk.ph;
      }

      // Smooth buoyant poise; leans very slightly toward camera when closed to flaunt luscious domed ribbed stripes!
      root.rotation.order = "YXZ";
      root.position.y = -0.1 + (1 - smoothOpen) * 0.12 + Math.sin(t * 1.9 + 0.8) * 0.036 + hoverAmt * 0.04;
      root.rotation.y = Math.sin(t * 0.78 + 0.4) * 0.28 + dragYaw;
      root.rotation.x = 0.04 + (1 - smoothOpen) * 0.18 + dragPitch * 0.85;
      root.rotation.z = Math.sin(t * 1.35) * 0.026;
      root.scale.setScalar(1.0 + hoverAmt * 0.06);
    },
    dispose: () => {
      for (const d of disposables) d.dispose();
    },
  };
}

/* ---------------- 5. TROFI EMAS 3D (GOLDEN CHAMPION TROPHY) ---------------- */

function buildTrophyRig(envMap: THREE.Texture): AssetRig {
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(o: T): T => {
    disposables.push(o);
    return o;
  };

  const scene = new THREE.Scene();
  scene.environment = envMap;
  scene.environmentIntensity = 0.5;
  addPixarLights(scene, true);

  const camera = new THREE.PerspectiveCamera(27, 1, 0.1, 20);
  camera.position.set(0, 0.5, 4.92);
  camera.lookAt(0, 0.04, 0);

  const root = new THREE.Group();
  scene.add(root);

  const goldTex = track(makeGoldGradientTexture());
  const woodTex = track(makeRichMahoganyTexture());

  // Saturated Pixar-style 24k polished gold pairing seamlessly with Mahkota 3D!
  const goldCupMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xffd226,
      map: goldTex,
      emissive: 0x6e3400,
      emissiveIntensity: 0.16,
      metalness: 0.42,
      roughness: 0.16,
      clearcoat: 0.98,
      clearcoatRoughness: 0.05,
    })
  );
  const goldBrightMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xffe858,
      emissive: 0x7c4500,
      emissiveIntensity: 0.18,
      metalness: 0.36,
      roughness: 0.12,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
    })
  );
  const goldDeepMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xe89008,
      emissive: 0x5c2600,
      emissiveIntensity: 0.18,
      metalness: 0.48,
      roughness: 0.22,
      clearcoat: 0.85,
      clearcoatRoughness: 0.09,
    })
  );
  const goldCavityMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x9e4f04,
      emissive: 0x3b1700,
      emissiveIntensity: 0.16,
      metalness: 0.52,
      roughness: 0.3,
    })
  );
  const baseWoodMat = track(
    new THREE.MeshPhysicalMaterial({
      map: woodTex,
      roughness: 0.28,
      metalness: 0.04,
      clearcoat: 0.78,
      clearcoatRoughness: 0.14,
    })
  );
  const rubyAccMat = track(
    new THREE.MeshPhysicalMaterial({
      color: 0xf41d42,
      emissive: 0x920620,
      emissiveIntensity: 0.3,
      roughness: 0.06,
      clearcoat: 1.0,
    })
  );
  const sparkleMat = track(new THREE.MeshBasicMaterial({ color: 0xfffde6, transparent: true, opacity: 0.95 }));

  // 1) Classic opulent stepped varnished-mahogany wooden championship pedestal base (y: -0.94 .. -0.50)
  const pedProfile = [
    new THREE.Vector2(0.0, -0.94),
    new THREE.Vector2(0.56, -0.94),
    new THREE.Vector2(0.585, -0.90),
    new THREE.Vector2(0.57, -0.82),
    new THREE.Vector2(0.50, -0.78),
    new THREE.Vector2(0.47, -0.56),
    new THREE.Vector2(0.42, -0.52),
    new THREE.Vector2(0.0, -0.52),
  ];
  root.add(new THREE.Mesh(track(new THREE.LatheGeometry(pedProfile, 64)), baseWoodMat));

  // Twin gleaming gold molding bands dressing lower & upper tiers of wooden pedestal
  const baseRingLow = new THREE.Mesh(track(new THREE.TorusGeometry(0.575, 0.036, 16, 64)), goldBrightMat);
  baseRingLow.rotation.x = Math.PI / 2;
  baseRingLow.position.y = -0.89;
  const baseRingTop = new THREE.Mesh(track(new THREE.TorusGeometry(0.47, 0.034, 16, 64)), goldBrightMat);
  baseRingTop.rotation.x = Math.PI / 2;
  baseRingTop.position.y = -0.535;
  root.add(baseRingLow, baseRingTop);

  // Curved shiny inlaid golden-brass trophy engraving nameplate right on front face of pedestal
  const plaqueGeo = track(new THREE.CylinderGeometry(0.495, 0.508, 0.165, 32, 1, true, -0.52, 1.04));
  const plaque = new THREE.Mesh(plaqueGeo, goldBrightMat);
  plaque.position.y = -0.675;
  root.add(plaque);
  // Crisp thin gold border frame edge bars + tiny corner brass studs on plaque
  const barGeo = track(new THREE.TorusGeometry(0.502, 0.015, 10, 28, 1.04));
  const barTop = new THREE.Mesh(barGeo, goldDeepMat);
  barTop.rotation.x = Math.PI / 2;
  barTop.rotation.z = Math.PI / 2 - 0.52;
  barTop.position.y = -0.596;
  const barBot = new THREE.Mesh(barGeo, goldDeepMat);
  barBot.rotation.x = Math.PI / 2;
  barBot.rotation.z = Math.PI / 2 - 0.52;
  barBot.position.y = -0.754;
  // Tiny engraved center horizontal bar line giving genuine engraved-badge look
  const lineBar = new THREE.Mesh(track(new THREE.TorusGeometry(0.506, 0.012, 8, 22, 0.56)), goldDeepMat);
  lineBar.rotation.x = Math.PI / 2;
  lineBar.rotation.z = Math.PI / 2 - 0.28;
  lineBar.position.y = -0.675;
  root.add(barTop, barBot, lineBar);

  // 2) Graceful turned 24k golden champion chalice stem with gleaming sculpted lotus collars & sphere knop
  const stemProfile = [
    new THREE.Vector2(0.0, -0.52),
    new THREE.Vector2(0.39, -0.52),
    new THREE.Vector2(0.36, -0.45),
    new THREE.Vector2(0.24, -0.39),
    new THREE.Vector2(0.145, -0.33),
    new THREE.Vector2(0.115, -0.25),
    new THREE.Vector2(0.195, -0.175), // classic sculptural golden trophy knop bulge!
    new THREE.Vector2(0.118, -0.10),
    new THREE.Vector2(0.155, -0.02),
    new THREE.Vector2(0.24, 0.04),
    new THREE.Vector2(0.0, 0.04),
  ];
  root.add(new THREE.Mesh(track(new THREE.LatheGeometry(stemProfile, 60)), goldDeepMat));

  // Fine mirror-bright triple collar accent beads on stem
  for (const [ry, rr, rt] of [
    [-0.49, 0.38, 0.036],
    [-0.175, 0.198, 0.032],
    [0.015, 0.21, 0.034],
  ] as [number, number, number][]) {
    const ring = new THREE.Mesh(track(new THREE.TorusGeometry(rr, rt, 16, 56)), goldBrightMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = ry;
    root.add(ring);
  }

  // 3) Grand, iconic plump rounded-bell 24k golden victory goblet (outer mirror wall + hollow real cup interior!)
  const cupOuter = [
    new THREE.Vector2(0.0, 0.02),
    new THREE.Vector2(0.22, 0.04),
    new THREE.Vector2(0.36, 0.14),
    new THREE.Vector2(0.49, 0.30),
    new THREE.Vector2(0.565, 0.50),
    new THREE.Vector2(0.59, 0.68),
    new THREE.Vector2(0.625, 0.84),
    new THREE.Vector2(0.655, 0.90),
    new THREE.Vector2(0.57, 0.90), // thick rolled lip transition inside
  ];
  root.add(new THREE.Mesh(track(new THREE.LatheGeometry(cupOuter, 72)), goldCupMat));

  // Authentic recessed shadowed warm golden inner cup wall (visible gracefully from top tilt!)
  const cupInner = [
    new THREE.Vector2(0.575, 0.895),
    new THREE.Vector2(0.51, 0.66),
    new THREE.Vector2(0.44, 0.40),
    new THREE.Vector2(0.26, 0.22),
    new THREE.Vector2(0.0, 0.18),
  ];
  root.add(new THREE.Mesh(track(new THREE.LatheGeometry(cupInner, 64)), goldCavityMat));

  // Plush chunky double-rolled gleaming crown rim lip around mouth of chalice + delicate body girdle band
  const cupLip = new THREE.Mesh(track(new THREE.TorusGeometry(0.618, 0.056, 22, 76)), goldBrightMat);
  cupLip.rotation.x = Math.PI / 2;
  cupLip.position.y = 0.885;
  const subLip = new THREE.Mesh(track(new THREE.TorusGeometry(0.602, 0.026, 14, 72)), goldDeepMat);
  subLip.rotation.x = Math.PI / 2;
  subLip.position.y = 0.785;
  root.add(cupLip, subLip);

  // 4) Iconic sweeping twin curved golden champion ribbon handles (symmetric smooth C/S-scroll arcs!)
  const buildHandle = (side: 1 | -1) => {
    const pts = [
      new THREE.Vector3(side * 0.56, 0.77, 0),
      new THREE.Vector3(side * 0.84, 0.80, 0),
      new THREE.Vector3(side * 0.96, 0.58, 0),
      new THREE.Vector3(side * 0.85, 0.30, 0),
      new THREE.Vector3(side * 0.62, 0.19, 0),
      new THREE.Vector3(side * 0.39, 0.19, 0),
    ];
    const curve = new THREE.CatmullRomCurve3(pts);
    const handle = new THREE.Mesh(track(new THREE.TubeGeometry(curve, 52, 0.068, 18, false)), goldBrightMat);
    root.add(handle);

    // Sculpted decorative cast-gold mounting knuckles anchoring top & bottom handle joins snugly to body
    const topPin = new THREE.Mesh(track(new THREE.SphereGeometry(0.088, 18, 14)), goldDeepMat);
    topPin.position.set(side * 0.585, 0.768, 0);
    const botPin = new THREE.Mesh(track(new THREE.SphereGeometry(0.084, 18, 14)), goldDeepMat);
    botPin.position.set(side * 0.425, 0.192, 0);
    // Cute tiny ornate scroll flourish pearl perched on upper outer crest of handle
    const flourish = new THREE.Mesh(track(new THREE.SphereGeometry(0.052, 14, 12)), goldBrightMat);
    flourish.position.set(side * 0.95, 0.64, 0);
    root.add(topPin, botPin, flourish);
  };
  buildHandle(-1);
  buildHandle(1);

  // 5) Prominent plush beveled 3D Victory Star medal + ruby micro-gem on front & back of golden bowl!
  const emblemStarGeo = track(
    new THREE.ExtrudeGeometry(makeStarShape(0.24, 0.108, 5), {
      depth: 0.055,
      bevelEnabled: true,
      bevelThickness: 0.032,
      bevelSize: 0.024,
      bevelSegments: 5,
    })
  );
  emblemStarGeo.translate(0, 0, -0.027);
  const centerGemGeo = track(new THREE.SphereGeometry(0.062, 16, 14));
  centerGemGeo.scale(1, 1, 0.56);
  const glintDotGeo = track(new THREE.SphereGeometry(0.02, 8, 8));
  const glintMat = track(new THREE.MeshBasicMaterial({ color: 0xffffff }));
  // Sleek recessed laurel-medallion disc framing the beveled victory star snugly against the curved goblet wall
  const medalDiscGeo = track(new THREE.CylinderGeometry(0.26, 0.28, 0.07, 44));
  medalDiscGeo.rotateX(Math.PI / 2);
  const frameRingGeo = track(new THREE.TorusGeometry(0.262, 0.026, 14, 48));

  for (const dir of [1, -1]) {
    const medal = new THREE.Group();
    // Follows exact outer taper slope of cup belly so full golden medallion halo sits unbroken & flush!
    medal.position.set(0, 0.49, dir * 0.562);
    if (dir === -1) medal.rotation.y = Math.PI;
    medal.rotation.x = -0.22;
    const disc = new THREE.Mesh(medalDiscGeo, goldDeepMat);
    disc.position.z = -0.022;
    const rim = new THREE.Mesh(frameRingGeo, goldBrightMat);
    rim.position.z = 0.014;
    const starMesh = new THREE.Mesh(emblemStarGeo, goldBrightMat);
    starMesh.scale.setScalar(0.95);
    starMesh.position.z = 0.036;
    const ruby = new THREE.Mesh(centerGemGeo, rubyAccMat);
    ruby.position.set(0, 0, 0.092);
    const gd = new THREE.Mesh(glintDotGeo, glintMat);
    gd.position.set(0.02, 0.022, 0.121);
    medal.add(disc, rim, starMesh, ruby, gd);
    root.add(medal);
  }

  // Cheerful dancing victory gold-white sparkle stars flanking chalice rim
  const spGeo = track(makeSparkleGeometry(0.135, 0.032));
  const sp1 = new THREE.Mesh(spGeo, sparkleMat);
  sp1.position.set(0.68, 0.96, 0.42);
  const sp2 = new THREE.Mesh(spGeo, sparkleMat);
  sp2.position.set(-0.74, 0.84, 0.34);
  scene.add(sp1, sp2);

  return {
    scene,
    camera,
    update: (t, hoverAmt, _dt, dragYaw, dragPitch) => {
      root.rotation.order = "YXZ";
      root.position.y = Math.sin(t * 2.0 + 1.5) * 0.042 + hoverAmt * 0.05;
      root.rotation.y = Math.sin(t * 0.95 + 0.5) * 0.34 + dragYaw;
      root.rotation.x = 0.06 + Math.cos(t * 1.15) * 0.03 + dragPitch;
      root.rotation.z = Math.sin(t * 1.45) * 0.036;
      root.scale.setScalar(1.0 + hoverAmt * 0.065);

      sp1.scale.setScalar(0.32 + Math.max(0, Math.sin(t * 3.2 + 0.6)) * (0.86 + hoverAmt * 0.25));
      sp1.rotation.z = t * 0.72;
      sp2.scale.setScalar(0.24 + Math.max(0, Math.sin(t * 2.6 + 2.6)) * (0.72 + hoverAmt * 0.22));
      sp2.rotation.z = -t * 0.68;

      rubyAccMat.emissiveIntensity = 0.28 + Math.sin(t * 3.0) * 0.14;
    },
    dispose: () => {
      for (const d of disposables) d.dispose();
    },
  };
}

/* ---------------- Shared Single-Context Ultra-Crisp Renderer Pool ---------------- */

interface TargetSlot {
  kind: Asset3DKind;
  canvas: HTMLCanvasElement;
  ctx2d: CanvasRenderingContext2D;
  hovered: boolean;
  hoverAmt: number;
  dragging: boolean;
  targetYaw: number;
  targetPitch: number;
  curYaw: number;
  curPitch: number;
  customState: number; // for clam: 0=auto open/close, 1=closed, 2=open
}

class Asset3DShowcasePool {
  private renderer: THREE.WebGLRenderer | null = null;
  private envRT: THREE.WebGLRenderTarget | null = null;
  private rigs = new Map<Asset3DKind, AssetRig>();
  private targets: TargetSlot[] = [];
  private failed = false;
  private rafId = 0;
  private running = false;
  private lastNow = 0;
  private lastDraw = 0;
  private elapsed = 0;
  private bufSize = 512;
  private readonly sizeVec = new THREE.Vector2();

  private ensureInit(): boolean {
    if (this.failed) return false;
    if (this.renderer) return true;
    try {
      const soft = detectSoftwareWebGL();
      this.bufSize = soft ? 340 : 540;
      const renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: true,
        powerPreference: "high-performance",
        preserveDrawingBuffer: true,
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.NoToneMapping;
      renderer.setClearColor(0x000000, 0);
      renderer.setPixelRatio(1);
      renderer.setSize(this.bufSize, this.bufSize, false);

      const pmrem = new THREE.PMREMGenerator(renderer);
      const envRT = pmrem.fromScene(new RoomEnvironment(), 0.04);
      pmrem.dispose();

      this.renderer = renderer;
      this.envRT = envRT;
      this.rigs.set("crown", buildCrownRig(envRT.texture));
      this.rigs.set("island", buildIslandRig(envRT.texture));
      this.rigs.set("wheel", buildShipWheelRig(envRT.texture));
      this.rigs.set("clam", buildClamRig(envRT.texture));
      this.rigs.set("trophy", buildTrophyRig(envRT.texture));
      return true;
    } catch {
      this.failed = true;
      return false;
    }
  }

  register(kind: Asset3DKind, canvas: HTMLCanvasElement, customState = 0): TargetSlot | null {
    if (!this.ensureInit()) return null;
    const ctx2d = canvas.getContext("2d");
    if (!ctx2d) return null;
    const slot: TargetSlot = {
      kind,
      canvas,
      ctx2d,
      hovered: false,
      hoverAmt: 0,
      dragging: false,
      targetYaw: 0,
      targetPitch: 0,
      curYaw: 0,
      curPitch: 0,
      customState,
    };
    this.targets.push(slot);
    this.drawSlot(slot, 0.016);
    this.start();
    return slot;
  }

  unregister(slot: TargetSlot | null) {
    if (!slot) return;
    const i = this.targets.indexOf(slot);
    if (i >= 0) this.targets.splice(i, 1);
    if (this.targets.length === 0) {
      this.running = false;
      cancelAnimationFrame(this.rafId);
    }
  }

  private start() {
    if (this.running) return;
    this.running = true;
    this.lastNow = performance.now();
    const soft = detectSoftwareWebGL();
    const minMs = soft ? 90 : 0;

    const tick = (now: number) => {
      if (!this.running) return;
      if (!document.hidden && now - this.lastDraw >= minMs) {
        const dt = Math.min(0.05, Math.max(0.004, (now - this.lastNow) / 1000));
        this.lastNow = now;
        this.lastDraw = now;
        this.elapsed += dt;
        for (const s of this.targets) {
          const damp = 1 - Math.exp(-10 * dt);
          s.hoverAmt += ((s.hovered ? 1 : 0) - s.hoverAmt) * damp;
          if (!s.dragging) {
            const ret = 1 - Math.exp(-3.2 * dt);
            s.targetYaw *= 1 - ret;
            s.targetPitch *= 1 - ret;
          }
          const orbitDamp = 1 - Math.exp(-14 * dt);
          s.curYaw += (s.targetYaw - s.curYaw) * orbitDamp;
          s.curPitch += (s.targetPitch - s.curPitch) * orbitDamp;
          this.drawSlot(s, dt);
        }
      }
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  /** Sky-bonus rigs (3D balloons & dangling rewards) are only built the first time they are baked */
  private lazySkyRig(kind: Asset3DKind): AssetRig | undefined {
    if (!this.envRT || !kind.startsWith("sky")) return undefined;
    const rig = buildSkyRig(kind as SkyRigKind, this.envRT.texture);
    this.rigs.set(kind, rig);
    return rig;
  }

  bakeFrames(
    kind: Asset3DKind,
    frames: number,
    size: number,
    cycleSeconds: number,
    customState: number,
    stateForFrame?: (u: number) => number,
  ): HTMLCanvasElement[] | null {
    if (!this.ensureInit()) return null;
    const renderer = this.renderer;
    const rig = this.rigs.get(kind) ?? this.lazySkyRig(kind);
    if (!renderer || !rig) return null;

    const prevW = this.sizeVec.x;
    renderer.getSize(this.sizeVec);
    const savedW = Math.round(this.sizeVec.x);
    const savedH = Math.round(this.sizeVec.y);
    const savedAspect = rig.camera.aspect;

    const rw = Math.min(this.bufSize, size * 2);
    renderer.setSize(rw, rw, false);
    rig.camera.aspect = 1;
    rig.camera.updateProjectionMatrix();

    // Pre-warm one full cycle at a fine step so internal damped states (lid opening etc.) are settled
    const sub = 0.05;
    let t = 0;
    for (; t < cycleSeconds; t += sub) rig.update(t, 0, sub, 0, 0, customState);

    const out: HTMLCanvasElement[] = [];
    const frameDt = cycleSeconds / frames;
    const steps = Math.max(1, Math.round(frameDt / sub));
    for (let f = 0; f < frames; f++) {
      const st = stateForFrame ? stateForFrame(f / frames) : customState;
      for (let s = 0; s < steps; s++) {
        t += frameDt / steps;
        rig.update(t, 0, frameDt / steps, 0, 0, st);
      }
      renderer.clear(true, true, true);
      renderer.render(rig.scene, rig.camera);
      const cv = document.createElement("canvas");
      cv.width = size;
      cv.height = size;
      const c2 = cv.getContext("2d");
      if (!c2) return null;
      c2.imageSmoothingEnabled = true;
      c2.imageSmoothingQuality = "high";
      c2.drawImage(renderer.domElement, 0, 0, rw, rw, 0, 0, size, size);
      out.push(cv);
    }

    // Restore live slot state
    if (savedW > 0 && savedH > 0 && prevW !== undefined) renderer.setSize(savedW, savedH, false);
    rig.camera.aspect = savedAspect;
    rig.camera.updateProjectionMatrix();
    return out;
  }

  private drawSlot(slot: TargetSlot, dt: number) {
    const renderer = this.renderer;
    const rig = this.rigs.get(slot.kind);
    if (!renderer || !rig) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = Math.max(100, slot.canvas.clientWidth || 260);
    const ch = Math.max(100, slot.canvas.clientHeight || 260);
    const aspect = Math.max(0.6, Math.min(1.6, cw / ch));

    const dstW = Math.min(640, Math.round(cw * dpr));
    const dstH = Math.min(640, Math.round(ch * dpr));
    if (slot.canvas.width !== dstW || slot.canvas.height !== dstH) {
      slot.canvas.width = dstW;
      slot.canvas.height = dstH;
    }

    const rw = this.bufSize;
    const rh = Math.max(100, Math.round(rw / aspect));
    renderer.getSize(this.sizeVec);
    if (Math.round(this.sizeVec.x) !== rw || Math.round(this.sizeVec.y) !== rh) {
      renderer.setSize(rw, rh, false);
    }
    if (Math.abs(rig.camera.aspect - aspect) > 0.008) {
      rig.camera.aspect = aspect;
      rig.camera.updateProjectionMatrix();
    }

    rig.update(this.elapsed, slot.hoverAmt, dt, slot.curYaw, slot.curPitch, slot.customState);
    renderer.clear(true, true, true);
    renderer.render(rig.scene, rig.camera);

    slot.ctx2d.clearRect(0, 0, dstW, dstH);
    slot.ctx2d.imageSmoothingEnabled = true;
    slot.ctx2d.imageSmoothingQuality = "high";
    slot.ctx2d.drawImage(renderer.domElement, 0, 0, rw, rh, 0, 0, dstW, dstH);
  }

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.rafId);
    for (const r of this.rigs.values()) r.dispose();
    this.rigs.clear();
    this.envRT?.dispose();
    this.envRT = null;
    this.renderer?.dispose();
    this.renderer = null;
  }
}

const pool = new Asset3DShowcasePool();

/**
 * Bake an animation cycle of one asset into crisp transparent sprite frames (used by the in-game
 * canvas engine for the 3D Pearl Clam pickups). Pre-warms the rig's internal smoothing state first
 * so frame 0 already matches the steady auto open/close rhythm.
 */
export function bakeAsset3DFrames(
  kind: Asset3DKind,
  frames: number,
  size: number,
  cycleSeconds: number,
  customState = 0,
): HTMLCanvasElement[] | null {
  return pool.bakeFrames(kind, frames, size, cycleSeconds, customState);
}

let clamFramesCache: HTMLCanvasElement[] | null = null;
let clamBakeAttempts = 0;
let clamNextTry = 0;
export const CLAM_CYCLE_SECONDS = 5.6;

/** Open amount (0..1) along the 5.6 s showpiece loop: bloom open → silky seal → hold shut → bloom open */
export function clamOpenAtCycle(u: number): number {
  const cyc = ((u % 1) + 1) % 1;
  if (cyc < 0.44) return 0.94 + Math.sin(cyc * CLAM_CYCLE_SECONDS * 2.2) * 0.05;
  if (cyc < 0.6) return 1 - smooth01((cyc - 0.44) / 0.16);
  if (cyc < 0.82) return 0;
  return smooth01((cyc - 0.82) / 0.18);
}

/** Lazily baked 3D Pearl Clam sprite cycle (32 frames @ 128px) shared by all pearl pickups in the ocean */
export function getClamSpriteFrames(): HTMLCanvasElement[] | null {
  if (clamFramesCache) return clamFramesCache;
  const now = performance.now();
  if (clamBakeAttempts >= 6 || now < clamNextTry) return null;
  clamBakeAttempts++;
  clamNextTry = now + 1500;
  try {
    const frames = pool.bakeFrames("clam", 32, 128, CLAM_CYCLE_SECONDS, 0, (u) => 10 + clamOpenAtCycle(u));
    if (frames && frames.length) clamFramesCache = frames;
  } catch (e) {
    console.warn("[clam sprites] bake failed, will retry", e);
  }
  return clamFramesCache;
}

/* ---------------- 3D SKY BONUSES: glossy balloons & dangling rewards (baked sprite frames) ---------------- */
const skyCache = new Map<string, HTMLCanvasElement[]>();
const skyTries = new Map<string, { n: number; next: number }>();
export { SKY_ITEM_CYCLE };
export type { SkyItemKind };

/** Baked frames of a sky-bonus asset (balloon: 1 frame per palette 0..4, items: a seamless loop) or null while unavailable */
export function getSkySprites(kind: SkyRigKind, palette = 0): HTMLCanvasElement[] | null {
  const key = `${kind}:${palette}`;
  const hit = skyCache.get(key);
  if (hit) return hit;
  const now = performance.now();
  const tr = skyTries.get(key) ?? { n: 0, next: 0 };
  if (tr.n >= 4 || now < tr.next) return null;
  tr.n++;
  tr.next = now + 2000;
  skyTries.set(key, tr);
  try {
    const frames =
      kind === "skyBalloon"
        ? pool.bakeFrames(kind, 1, 128, 0.1, palette)
        : pool.bakeFrames(kind, SKY_ITEM_FRAMES[kind], 128, SKY_ITEM_CYCLE[kind], 0);
    if (frames && frames.length) skyCache.set(key, frames);
  } catch (e) {
    console.warn("[sky sprites] bake failed, will retry", e);
  }
  return skyCache.get(key) ?? null;
}

/** Bake every sky asset in small idle slices (one asset per idle callback) */
function prebakeSkySprites(): void {
  const jobs: Array<[SkyRigKind, number]> = [
    ["skyBalloon", 0],
    ["skyBalloon", 1],
    ["skyBalloon", 2],
    ["skyBalloon", 3],
    ["skyBalloon", 4],
    ["skyStopwatch", 0],
    ["skyCoin", 0],
    ["skyTurbo", 0],
    ["skyVortex", 0],
    ["skyShield", 0],
  ];
  const ric = (window as unknown as { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => void }).requestIdleCallback;
  const step = () => {
    const j = jobs.shift();
    if (!j) return;
    getSkySprites(j[0], j[1]);
    if (!jobs.length) return;
    if (ric) ric(step, { timeout: 1200 });
    else window.setTimeout(step, 120);
  };
  step();
}

/** Call from the menu while idle so gameplay never pays the bake cost */
export function prebakeClamSprites(): void {
  const run = () => {
    if (!clamFramesCache) getClamSpriteFrames();
    prebakeSkySprites();
  };
  if (typeof (window as unknown as { requestIdleCallback?: unknown }).requestIdleCallback === "function") {
    (window as unknown as { requestIdleCallback: (cb: () => void, o?: { timeout: number }) => void }).requestIdleCallback(run, {
      timeout: 1500,
    });
  } else {
    window.setTimeout(run, 400);
  }
}

interface Asset3DViewProps {
  kind: Asset3DKind;
  label: string;
  customState?: number;
  onTap?: () => void;
  titleHint?: string;
}

export function Asset3DView({ kind, label, customState = 0, onTap, titleHint }: Asset3DViewProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const slotRef = useRef<TargetSlot | null>(null);
  const dragRef = useRef<{ id: number; x: number; y: number; dist: number } | null>(null);
  const [dragging, setDragging] = useState(false);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const slot = pool.register(kind, cv, customState);
    slotRef.current = slot;
    return () => {
      pool.unregister(slot);
      slotRef.current = null;
    };
  }, [kind]);

  useEffect(() => {
    if (slotRef.current) slotRef.current.customState = customState;
  }, [customState]);

  return (
    <canvas
      ref={canvasRef}
      role="img"
      aria-label={label}
      title={titleHint || `${label} — seret untuk putar 3D`}
      onMouseEnter={() => {
        if (slotRef.current) slotRef.current.hovered = true;
      }}
      onMouseLeave={() => {
        if (slotRef.current) slotRef.current.hovered = false;
      }}
      onPointerDown={(e) => {
        dragRef.current = { id: e.pointerId, x: e.clientX, y: e.clientY, dist: 0 };
        setDragging(true);
        if (slotRef.current) slotRef.current.dragging = true;
        e.currentTarget.setPointerCapture?.(e.pointerId);
      }}
      onPointerMove={(e) => {
        const d = dragRef.current;
        const s = slotRef.current;
        if (!d || !s || d.id !== e.pointerId) return;
        const dx = e.clientX - d.x;
        const dy = e.clientY - d.y;
        d.dist += Math.hypot(dx, dy);
        d.x = e.clientX;
        d.y = e.clientY;
        s.targetYaw += dx * 0.013;
        s.targetPitch = Math.max(-0.72, Math.min(0.72, s.targetPitch + dy * 0.01));
      }}
      onPointerUp={(e) => {
        const d = dragRef.current;
        if (!d || d.id !== e.pointerId) return;
        const wasTap = d.dist < 6;
        dragRef.current = null;
        setDragging(false);
        if (slotRef.current) slotRef.current.dragging = false;
        e.currentTarget.releasePointerCapture?.(e.pointerId);
        if (wasTap && onTap) onTap();
      }}
      onPointerCancel={() => {
        dragRef.current = null;
        setDragging(false);
        if (slotRef.current) slotRef.current.dragging = false;
      }}
      className={`block w-full h-full touch-none select-none transition-transform duration-200 ease-out drop-shadow-[0_16px_26px_rgba(3,28,62,0.42)] ${
        dragging ? "cursor-grabbing scale-[1.03]" : "cursor-grab hover:scale-[1.04]"
      }`}
    />
  );
}
