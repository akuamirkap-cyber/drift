// Procedural audio: footsteps + wind ambience (no external files)
let ctx: AudioContext | null = null
let master: GainNode | null = null
let noiseBuf: AudioBuffer | null = null

function ensure() {
  if (ctx) return ctx
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  ctx = new AC()
  master = ctx.createGain()
  master.gain.value = 0.8
  master.connect(ctx.destination)
  // 2 seconds of white noise
  noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate)
  const d = noiseBuf.getChannelData(0)
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1
  startAmbience()
  return ctx
}

export function initAudio() {
  const c = ensure()
  if (c.state === 'suspended') void c.resume()
}

function startAmbience() {
  if (!ctx || !master || !noiseBuf) return
  // wind: looping noise -> lowpass with slow LFO
  const src = ctx.createBufferSource()
  src.buffer = noiseBuf
  src.loop = true
  const lp = ctx.createBiquadFilter()
  lp.type = 'lowpass'
  lp.frequency.value = 320
  lp.Q.value = 0.8
  const g = ctx.createGain()
  g.gain.value = 0.045
  const lfo = ctx.createOscillator()
  lfo.frequency.value = 0.07
  const lfoG = ctx.createGain()
  lfoG.gain.value = 180
  lfo.connect(lfoG)
  lfoG.connect(lp.frequency)
  const lfo2 = ctx.createOscillator()
  lfo2.frequency.value = 0.19
  const lfo2G = ctx.createGain()
  lfo2G.gain.value = 0.02
  lfo2.connect(lfo2G)
  lfo2G.connect(g.gain)
  src.connect(lp)
  lp.connect(g)
  g.connect(master)
  src.start()
  lfo.start()
  lfo2.start()
  // low room tone
  const hum = ctx.createOscillator()
  hum.type = 'sine'
  hum.frequency.value = 48
  const humG = ctx.createGain()
  humG.gain.value = 0.012
  hum.connect(humG)
  humG.connect(master)
  hum.start()
}

export function footstep(surface: 'wood' | 'concrete', strength = 1) {
  if (!ctx || !master || !noiseBuf) return
  const t = ctx.currentTime
  const src = ctx.createBufferSource()
  src.buffer = noiseBuf
  src.playbackRate.value = 0.8 + Math.random() * 0.5
  const bp = ctx.createBiquadFilter()
  bp.type = surface === 'wood' ? 'lowpass' : 'bandpass'
  bp.frequency.value = surface === 'wood' ? 420 + Math.random() * 200 : 1100 + Math.random() * 600
  bp.Q.value = surface === 'wood' ? 0.9 : 1.6
  const g = ctx.createGain()
  const peak = (surface === 'wood' ? 0.32 : 0.22) * strength
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(peak, t + 0.008)
  g.gain.exponentialRampToValueAtTime(0.0001, t + (surface === 'wood' ? 0.17 : 0.11))
  src.connect(bp)
  bp.connect(g)
  g.connect(master)
  src.start(t)
  src.stop(t + 0.25)
  // heel thud
  const osc = ctx.createOscillator()
  osc.frequency.setValueAtTime(surface === 'wood' ? 95 : 70, t)
  osc.frequency.exponentialRampToValueAtTime(40, t + 0.09)
  const og = ctx.createGain()
  og.gain.setValueAtTime(0.0001, t)
  og.gain.exponentialRampToValueAtTime(0.18 * strength, t + 0.006)
  og.gain.exponentialRampToValueAtTime(0.0001, t + 0.1)
  osc.connect(og)
  og.connect(master)
  osc.start(t)
  osc.stop(t + 0.12)
  // wood creak occasionally
  if (surface === 'wood' && Math.random() < 0.18) {
    const c = ctx.createOscillator()
    c.type = 'sawtooth'
    c.frequency.setValueAtTime(180 + Math.random() * 120, t + 0.02)
    c.frequency.linearRampToValueAtTime(120 + Math.random() * 80, t + 0.22)
    const cf = ctx.createBiquadFilter()
    cf.type = 'bandpass'
    cf.frequency.value = 600
    cf.Q.value = 4
    const cg = ctx.createGain()
    cg.gain.setValueAtTime(0.0001, t + 0.02)
    cg.gain.exponentialRampToValueAtTime(0.05, t + 0.06)
    cg.gain.exponentialRampToValueAtTime(0.0001, t + 0.26)
    c.connect(cf)
    cf.connect(cg)
    cg.connect(master)
    c.start(t + 0.02)
    c.stop(t + 0.3)
  }
}

export function clickSound() {
  if (!ctx || !master) return
  const t = ctx.currentTime
  const osc = ctx.createOscillator()
  osc.type = 'square'
  osc.frequency.value = 1800
  const g = ctx.createGain()
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(0.06, t + 0.003)
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.04)
  osc.connect(g)
  g.connect(master)
  osc.start(t)
  osc.stop(t + 0.05)
}

// ---------------------------------------------------------------------------
// Weapon sounds (procedural)
function noiseBurst(t: number, dur: number, type: BiquadFilterType, f0: number, f1: number, peak: number, q = 0.7) {
  if (!ctx || !master || !noiseBuf) return
  const src = ctx.createBufferSource()
  src.buffer = noiseBuf
  const f = ctx.createBiquadFilter()
  f.type = type
  f.Q.value = q
  f.frequency.setValueAtTime(f0, t)
  f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur)
  const g = ctx.createGain()
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(peak, t + 0.003)
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
  src.connect(f)
  f.connect(g)
  g.connect(master)
  src.start(t, Math.random() * 1.4, dur + 0.05)
}

export function gunshot(indoor: boolean) {
  const c = ensure()
  if (!master) return
  const t = c.currentTime
  // supersonic crack + muzzle blast
  noiseBurst(t, 0.09, 'highpass', 2500, 1200, 0.5, 0.5)
  noiseBurst(t, 0.32, 'lowpass', 7000, 300, 1.0, 0.6)
  // low thump
  const o = c.createOscillator()
  o.type = 'sine'
  o.frequency.setValueAtTime(160, t)
  o.frequency.exponentialRampToValueAtTime(38, t + 0.14)
  const g = c.createGain()
  g.gain.setValueAtTime(0.9, t)
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18)
  o.connect(g)
  g.connect(master)
  o.start(t)
  o.stop(t + 0.2)
  // reverb tail (indoor = tight slap, outdoor = long distant rumble)
  if (indoor) {
    noiseBurst(t + 0.045, 0.5, 'lowpass', 2200, 200, 0.22, 0.5)
    noiseBurst(t + 0.11, 0.6, 'lowpass', 1400, 150, 0.12, 0.5)
  } else {
    noiseBurst(t + 0.18, 1.2, 'lowpass', 900, 90, 0.16, 0.4)
  }
}

export function dryFire() {
  const c = ensure()
  noiseBurst(c.currentTime, 0.03, 'highpass', 3000, 2500, 0.25, 2)
}

export function reloadSound() {
  const c = ensure()
  const t = c.currentTime
  noiseBurst(t + 0.25, 0.06, 'bandpass', 1800, 900, 0.35, 3) // mag release
  noiseBurst(t + 0.35, 0.18, 'lowpass', 600, 200, 0.2, 1) // mag out
  noiseBurst(t + 1.15, 0.05, 'bandpass', 2400, 1500, 0.45, 4) // mag in
  noiseBurst(t + 1.22, 0.04, 'highpass', 3200, 2600, 0.3, 2)
  noiseBurst(t + 1.75, 0.05, 'bandpass', 2000, 1200, 0.4, 3) // charging handle back
  noiseBurst(t + 1.88, 0.05, 'bandpass', 2600, 1800, 0.45, 3) // forward
}

export function impactSound(dist: number) {
  if (!ctx || !master) return
  const v = Math.max(0.02, 0.18 / (1 + dist * 0.15))
  noiseBurst(ctx.currentTime + dist / 340, 0.08, 'bandpass', 1500 + Math.random() * 1500, 600, v, 1.5)
}

export function ding(dist: number) {
  if (!ctx || !master) return
  const t = ctx.currentTime + dist / 340
  for (const [f, v] of [[1850, 0.22], [2780, 0.1], [920, 0.08]] as [number, number][]) {
    const o = ctx.createOscillator()
    o.type = 'sine'
    o.frequency.value = f
    const g = ctx.createGain()
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(v, t + 0.004)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6)
    o.connect(g)
    g.connect(master)
    o.start(t)
    o.stop(t + 0.65)
  }
}

export function zombieGroan() {
  const c = ensure()
  if (!ctx || !master) return
  const t = c.currentTime
  const o = ctx.createOscillator()
  o.type = 'sawtooth'
  o.frequency.setValueAtTime(70 + Math.random() * 40, t)
  o.frequency.exponentialRampToValueAtTime(48 + Math.random() * 20, t + 0.8)
  const lp = ctx.createBiquadFilter()
  lp.type = 'lowpass'
  lp.frequency.value = 420
  const g = ctx.createGain()
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(0.05, t + 0.12)
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9)
  o.connect(lp)
  lp.connect(g)
  g.connect(master)
  o.start(t)
  o.stop(t + 0.95)
}

export function zombieBite() {
  const c = ensure()
  if (!ctx || !master) return
  const t = c.currentTime
  noiseBurst(t, 0.12, 'bandpass', 900, 220, 0.22, 1.4)
  noiseBurst(t + 0.07, 0.16, 'lowpass', 700, 140, 0.18, 0.8)
}

export function allyShot(dist: number) {
  if (!ctx || !master) return
  const t = ctx.currentTime
  const v = Math.max(0.03, 0.32 / (1 + dist * 0.09))
  noiseBurst(t, 0.12, 'highpass', 2200, 700, v, 0.6)
  noiseBurst(t, 0.2, 'lowpass', 3000, 240, v * 0.7, 0.5)
}

export function waveHorn() {
  const c = ensure()
  if (!ctx || !master) return
  const t = c.currentTime
  for (const f of [62, 93, 124]) {
    const o = ctx.createOscillator()
    o.type = 'sawtooth'
    o.frequency.setValueAtTime(f, t)
    o.frequency.linearRampToValueAtTime(f * 1.06, t + 1.4)
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = 600
    const g = ctx.createGain()
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(0.05, t + 0.35)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 2.2)
    o.connect(lp)
    lp.connect(g)
    g.connect(master)
    o.start(t)
    o.stop(t + 2.3)
  }
}
