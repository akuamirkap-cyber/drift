import { useGame } from '../state'

const KEYS: [string, string][] = [
  ['WASD', 'Bergerak'],
  ['MOUSE', 'Lihat / bidik'],
  ['KLIK KIRI', 'Tembak zombie'],
  ['KLIK KANAN', 'Aim (ADS)'],
  ['R', 'Reload'],
  ['G', 'Squad: follow / hold'],
  ['E', 'Revive prajurit yang down'],
  ['SHIFT', 'Sprint'],
  ['SPASI', 'Loncat'],
  ['C', 'Jongkok'],
  ['F', 'Senter taktis'],
  ['ESC', 'Pause'],
]

export function StartScreen({ progress, ready }: { progress: number; ready: boolean }) {
  const locked = useGame((s) => s.locked)
  const everStarted = useGame((s) => s.everStarted)
  if (locked) return null
  const pct = Math.round(progress * 100)
  return (
    <div className="pointer-events-none absolute inset-0 flex items-center overflow-y-auto bg-gradient-to-r from-black/92 via-black/70 to-black/20 font-mono text-white">
      <div className="mx-6 w-full max-w-2xl py-6 sm:ml-[5vw]">
        <div className="flex items-center gap-3 text-[10px] tracking-[0.4em] text-red-400/90 uppercase">
          <span className="h-px w-10 bg-red-400/80" />
          {everStarted ? 'Operasi dijeda' : 'Zombie siege · Site 14'}
        </div>
        <h1 className="mt-2 text-4xl leading-[0.92] font-black tracking-tight uppercase sm:text-5xl">
          Operation
          <br />
          <span className="text-red-500">Dead Zone</span>
          <span className="ml-3 align-middle text-[12px] font-bold tracking-[0.3em] text-white/45">SQUAD DLC</span>
        </h1>
        <p className="mt-4 max-w-lg text-[12px] leading-relaxed text-white/65">
          Kamu memimpin fire team 4 orang — <span className="text-cyan-300">GHOST-2, ALPHA, BRAVO, CHARLIE</span> — bertahan di kompleks
          industri yang sama (hall 40×24 m, rumah manajer bertingkat + teras atap, menara jaga). Zombie datang bergelombang dari
          seluruh perimeter. Squad menembak sendiri, tapi bisa <span className="text-amber-300">down</span> — dekatkan diri dan tahan E untuk
          revive. Bertahan selama mungkin, naik tower untuk posisi tinggi.
        </p>

        {!ready ? (
          <div className="mt-7 max-w-md">
            <div className="flex justify-between text-[10px] tracking-[0.3em] text-white/55 uppercase">
              <span>Memuat map, squad &amp; material</span>
              <span>{pct}%</span>
            </div>
            <div className="mt-2 h-[3px] w-full bg-white/10">
              <div className="h-full bg-red-500 transition-all duration-200" style={{ width: `${pct}%` }} />
            </div>
          </div>
        ) : (
          <div className="mt-6">
            <div className="inline-flex animate-pulse items-center gap-3 border border-red-400/60 bg-red-500/10 px-5 py-3 text-sm font-bold tracking-[0.28em] text-red-200 uppercase">
              ▶ {everStarted ? 'Klik untuk lanjut' : 'Klik layar untuk deploy'}
            </div>
            <div className="mt-5 grid max-w-2xl grid-cols-1 gap-x-6 gap-y-1.5 text-[11px] text-white/60 sm:grid-cols-2">
              {KEYS.map(([k, v]) => (
                <div key={k} className="flex items-center gap-2">
                  <span className="min-w-[82px] border border-white/20 bg-white/5 px-1.5 py-0.5 text-center text-[10px] font-bold text-white">{k}</span>
                  <span>{v}</span>
                </div>
              ))}
            </div>
            <div className="mt-5 text-[10px] tracking-[0.25em] text-white/35 uppercase">
              Tip: wave makin berat tiap ronde · headshot mematikan lebih cepat · tangga barat menuju teras atap (LVL 3)
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
