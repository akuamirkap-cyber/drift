import { useEffect, useState } from 'react'
import { useGame } from '../state'

const DIRS: [number, string][] = [
  [0, 'N'], [45, 'NE'], [90, 'E'], [135, 'SE'], [180, 'S'], [225, 'SW'], [270, 'W'], [315, 'NW'],
]

function Compass({ heading }: { heading: number }) {
  const ticks: { x: number; label?: string; major: boolean }[] = []
  for (let d = -90; d <= 90; d += 5) {
    const deg = (((heading + d) % 360) + 360) % 360
    const label = DIRS.find(([a]) => a === Math.round(deg / 5) * 5 % 360)?.[1]
    ticks.push({ x: d, label: deg % 45 === 0 ? label : undefined, major: deg % 15 === 0 })
  }
  return (
    <div className="absolute top-5 left-1/2 h-10 w-[420px] -translate-x-1/2 overflow-hidden" style={{ maskImage: 'linear-gradient(90deg, transparent, black 18%, black 82%, transparent)' }}>
      <div className="absolute inset-x-0 top-3 h-px bg-white/25" />
      {ticks.map((t, i) => (
        <div key={i} className="absolute top-0 flex flex-col items-center" style={{ left: `${50 + (t.x / 180) * 100}%`, transform: 'translateX(-50%)' }}>
          <div className={`w-px ${t.label ? 'h-3 bg-white' : t.major ? 'h-2 bg-white/60' : 'h-1 bg-white/30'}`} />
          {t.label && <div className={`mt-0.5 text-[11px] font-bold ${t.label === 'N' ? 'text-amber-300' : 'text-white/90'}`}>{t.label}</div>}
        </div>
      ))}
      <div className="absolute top-0 left-1/2 h-0 w-0 -translate-x-1/2 border-x-[5px] border-t-[6px] border-x-transparent border-t-amber-300" />
      <div className="absolute right-0 bottom-0 left-0 text-center text-[10px] text-white/70">{heading.toString().padStart(3, '0')}</div>
    </div>
  )
}

const S = 156
const H = 108
const sx = (x: number) => ((x + 60) / 96) * S
const sz = (z: number) => ((z + 28) / 68) * H
function parseBlips(raw: string): number[][] {
  if (!raw) return []
  const out: number[][] = []
  for (const item of raw.split('|')) {
    const parts = item.split(',').map(Number)
    if (parts.length >= 2 && Number.isFinite(parts[0]) && Number.isFinite(parts[1])) out.push(parts)
  }
  return out
}

function Minimap({ px, pz, heading, zBlips, sBlips }: { px: number; pz: number; heading: number; zBlips: string; sBlips: string }) {
  const zombies = parseBlips(zBlips)
  const squad = parseBlips(sBlips)
  return (
    <div className="absolute top-6 left-6 border border-white/20 bg-black/50 p-1.5 shadow-[0_0_18px_rgba(0,0,0,0.65)] backdrop-blur-[2px]">
      <svg width={S} height={H} className="block">
        <rect x={0} y={0} width={S} height={H} fill="rgba(52,58,52,0.62)" />
        <rect x={sx(-60)} y={sz(12.3)} width={sx(36) - sx(-60)} height={sz(40) - sz(12.3)} fill="rgba(30,32,30,0.65)" />
        <rect x={sx(-20)} y={sz(-12)} width={sx(20) - sx(-20)} height={sz(12) - sz(-12)} fill="rgba(150,146,134,0.8)" stroke="rgba(255,255,255,0.45)" strokeWidth={0.8} />
        <rect x={sx(-42)} y={sz(-11)} width={sx(-20.2) - sx(-42)} height={sz(3) - sz(-11)} fill="rgba(132,120,104,0.8)" stroke="rgba(255,255,255,0.45)" strokeWidth={0.8} />
        {zombies.map(([x, z], i) => (
          <circle key={`z${i}`} cx={sx(x)} cy={sz(z)} r={1.7} fill="#ef4444" />
        ))}
        {squad.map(([x, z, st], i) => (
          <circle key={`s${i}`} cx={sx(x)} cy={sz(z)} r={2.1} fill={st === 2 ? '#f59e0b' : '#67e8f9'} stroke="#04191b" strokeWidth={0.6} />
        ))}
        <g transform={`translate(${sx(px)} ${sz(pz)}) rotate(${heading})`}>
          <path d="M0,0 L-13,-24 A28,28 0 0 1 13,-24 Z" fill="rgba(252,211,77,0.16)" />
          <path d="M0,-7 L5,5 L0,2.5 L-5,5 Z" fill="#fcd34d" stroke="black" strokeWidth={0.6} />
        </g>
        <rect x={0.5} y={0.5} width={S - 1} height={H - 1} fill="none" stroke="rgba(255,255,255,0.3)" strokeDasharray="3 2" />
      </svg>
      <div className="mt-1 flex justify-between text-[9px] tracking-[0.18em] text-white/60">
        <span>SITE 14</span>
        <span className="text-red-400">● {zombies.length} HOSTILE</span>
      </div>
    </div>
  )
}

function WaveBanner() {
  const wave = useGame((s) => s.wave)
  const phase = useGame((s) => s.hordePhase)
  const timer = useGame((s) => s.waveTimer)
  const left = useGame((s) => s.zombiesLeft)
  return (
    <div className="absolute top-[68px] left-1/2 -translate-x-1/2 text-center font-mono uppercase drop-shadow-[0_0_6px_rgba(0,0,0,0.95)]">
      {phase === 'prep' && (
        <>
          <div className="text-[10px] tracking-[0.4em] text-amber-300">SQUAD UP · PREPARE</div>
          <div className="text-[22px] leading-tight font-black tracking-wider text-white">WAVE {wave + 1} IN {Math.max(0, timer)}s</div>
        </>
      )}
      {phase === 'active' && (
        <>
          <div className="text-[10px] tracking-[0.4em] text-red-400">ZOMBIE HORDE</div>
          <div className="text-[22px] leading-tight font-black tracking-wider text-white">WAVE {wave} · {left} LEFT</div>
        </>
      )}
      {phase === 'clear' && (
        <>
          <div className="text-[10px] tracking-[0.4em] text-emerald-300">AREA SECURED</div>
          <div className="text-[20px] leading-tight font-black tracking-wider text-white">WAVE {wave} CLEARED · NEXT IN {Math.max(0, timer)}s</div>
        </>
      )}
    </div>
  )
}

export function HUD() {
  const locked = useGame((s) => s.locked)
  const flashlight = useGame((s) => s.flashlight)
  const crouch = useGame((s) => s.crouch)
  const floor = useGame((s) => s.floor)
  const px = useGame((s) => s.px)
  const pz = useGame((s) => s.pz)
  const heading = useGame((s) => s.heading)
  const ammo = useGame((s) => s.ammo)
  const reserve = useGame((s) => s.reserve)
  const reloading = useGame((s) => s.reloading)
  const ads = useGame((s) => s.ads)
  const health = useGame((s) => s.health)
  const damageId = useGame((s) => s.damageId)
  const kills = useGame((s) => s.kills)
  const headshots = useGame((s) => s.headshots)
  const squad = useGame((s) => s.squad)
  const squadMode = useGame((s) => s.squadMode)
  const zombieBlips = useGame((s) => s.zombieBlips)
  const squadBlips = useGame((s) => s.squadBlips)
  const playerDown = useGame((s) => s.playerDown)
  const reviveTarget = useGame((s) => s.reviveTarget)
  const reviveProgress = useGame((s) => s.reviveProgress)
  const fps = useGame((s) => s.fps)
  const [hit, setHit] = useState(false)
  const [showHelp, setShowHelp] = useState(true)

  useEffect(() => {
    if (!damageId) return
    setHit(true)
    const t = setTimeout(() => setHit(false), 260)
    return () => clearTimeout(t)
  }, [damageId])

  useEffect(() => {
    if (!locked) return
    setShowHelp(true)
    const t = setTimeout(() => setShowHelp(false), 11000)
    return () => clearTimeout(t)
  }, [locked])

  const low = ammo <= 8
  const dead = playerDown
  return (
    <div className="pointer-events-none absolute inset-0 font-mono text-[11px] tracking-[0.15em] text-white/90 uppercase select-none">
      {/* damage vignette */}
      <div className={`absolute inset-0 transition-opacity duration-200 ${hit ? 'opacity-100' : 'opacity-0'}`} style={{ background: 'radial-gradient(ellipse at center, transparent 38%, rgba(150,10,10,0.55) 100%)' }} />
      {health < 35 && !dead && (
        <div className="absolute inset-0 animate-pulse" style={{ boxShadow: 'inset 0 0 140px 30px rgba(170,15,15,0.5)' }} />
      )}

      {/* crosshair */}
      <div id="xhair" className="absolute top-1/2 left-1/2" style={{ ['--gap' as string]: '10px', opacity: dead ? 0 : 1 }}>
        <div className="absolute h-[2px] w-[9px] -translate-y-1/2 bg-white shadow-[0_0_2px_black]" style={{ left: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[2px] w-[9px] -translate-y-1/2 bg-white shadow-[0_0_2px_black]" style={{ right: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[9px] w-[2px] -translate-x-1/2 bg-white shadow-[0_0_2px_black]" style={{ top: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[9px] w-[2px] -translate-x-1/2 bg-white shadow-[0_0_2px_black]" style={{ bottom: 'calc(var(--gap) * 1)' }} />
        <div className="absolute h-[2px] w-[2px] -translate-x-1/2 -translate-y-1/2 bg-white/80" />
      </div>
      <div id="hitmark" className="absolute top-1/2 left-1/2 h-0 w-0" style={{ opacity: 0, color: '#fff' }}>
        {[45, 135, 225, 315].map((a) => (
          <div key={a} className="absolute h-[2px] w-[10px] bg-current shadow-[0_0_3px_black]" style={{ transform: `rotate(${a}deg) translateX(9px)`, transformOrigin: '0 50%' }} />
        ))}
      </div>

      <Compass heading={heading} />
      <WaveBanner />
      <Minimap px={px} pz={pz} heading={heading} zBlips={zombieBlips} sBlips={squadBlips} />

      {/* squad roster */}
      <div className="absolute top-[178px] left-6 w-[212px]">
        <div className="mb-1 flex items-center justify-between border-b border-white/25 pb-1 text-[9px] tracking-[0.3em] text-white/60">
          <span>FIRE TEAM</span>
          <span className={squadMode === 'follow' ? 'text-cyan-300' : 'text-amber-300'}>{squadMode === 'follow' ? 'FOLLOW' : 'HOLD'} [G]</span>
        </div>
        {squad.map((m) => (
          <div key={m.name} className="mb-1 border-l-2 pl-2" style={{ borderColor: m.state === 'down' ? '#f59e0b' : m.hp > 55 ? '#22d3ee' : '#ef4444' }}>
            <div className="flex items-center justify-between text-[10px]">
              <span className={m.state === 'down' ? 'text-amber-300' : 'text-white/90'}>{m.name}</span>
              <span className={m.state === 'down' ? 'text-amber-300' : m.hp > 55 ? 'text-cyan-200' : 'text-red-300'}>
                {m.state === 'down' ? 'DOWN' : `${m.hp}`}
              </span>
            </div>
            <div className="mt-[2px] h-[3px] w-full bg-white/15">
              <div className="h-full" style={{ width: `${(m.hp / m.max) * 100}%`, background: m.state === 'down' ? '#f59e0b' : m.hp > 55 ? '#22d3ee' : '#ef4444' }} />
            </div>
          </div>
        ))}
      </div>

      {/* top right stats */}
      <div className="absolute top-6 right-7 text-right text-[10px] tracking-[0.25em] text-white/75 drop-shadow-[0_0_4px_black]">
        <div className="text-[9px] text-white/50">OPERATION DEAD ZONE</div>
        <div className="mt-1">KILLS <span className="text-[18px] font-black text-red-400">{kills}</span></div>
        <div className="text-white/55">HEADSHOTS <span className="text-white/90">{headshots}</span></div>
        <div className="mt-1 text-white/40">FPS {fps}</div>
      </div>

      {/* bottom-left: health */}
      <div className="absolute bottom-8 left-8 flex flex-col gap-1.5 drop-shadow-[0_0_4px_rgba(0,0,0,0.9)]">
        <div className="flex items-center gap-2">
          <div className="text-[13px] font-bold text-white">R. MENDEZ</div>
          <div className="text-white/50">LVL {floor}</div>
          {flashlight && <span className="text-amber-200">◉</span>}
          {crouch && <span className="text-white/60">▼</span>}
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-[16px] font-black ${health > 55 ? 'text-white' : health > 25 ? 'text-amber-300' : 'text-red-400'}`}>{health}</span>
          <div className="h-[8px] w-56 skew-x-[-20deg] bg-white/15">
            <div className={`h-full transition-[width] duration-200 ${health > 55 ? 'bg-emerald-300/90' : health > 25 ? 'bg-amber-400' : 'bg-red-500'}`} style={{ width: `${health}%` }} />
          </div>
          <span className="text-[9px] text-white/45">HP</span>
        </div>
        <div className="flex gap-2 text-[9px] text-white/45">
          <span>{ads ? 'ADS' : 'HIP'}</span>
          <span>·</span>
          <span>SUPPORT: {squad.filter((s) => s.state !== 'down').length}/4</span>
        </div>
      </div>

      {/* bottom-right: ammo */}
      <div className="absolute right-8 bottom-8 flex flex-col items-end drop-shadow-[0_0_6px_rgba(0,0,0,0.9)]">
        <div className="text-[10px] tracking-[0.3em] text-white/60">M4A1 · RED DOT · AUTO</div>
        <div className="mt-1 flex items-end gap-2">
          <span className={`text-[44px] leading-none font-black tracking-tight ${low ? 'text-red-400' : 'text-white'}`}>{ammo.toString().padStart(2, '0')}</span>
          <span className="mb-1 text-[18px] font-bold text-white/55">/ {reserve}</span>
        </div>
        <div className="mt-1 flex gap-[2px]">
          {Array.from({ length: 30 }).map((_, i) => (
            <span key={i} className={`h-3 w-[3px] ${i < ammo ? (low ? 'bg-red-400' : 'bg-white/90') : 'bg-white/15'}`} />
          ))}
        </div>
      </div>

      {/* revive interaction */}
      {locked && reviveTarget >= 0 && (
        <div className="absolute top-[60%] left-1/2 w-64 -translate-x-1/2 border border-amber-300/50 bg-black/65 px-3 py-2 text-center">
          <div className="text-[10px] tracking-[0.3em] text-amber-300">HOLD [E] · REVIVE</div>
          <div className="mt-1 text-[13px] font-bold text-white">{squad[reviveTarget]?.name ?? 'SQUADMATE'}</div>
          <div className="mt-1.5 h-[4px] w-full bg-white/15">
            <div className="h-full bg-amber-300" style={{ width: `${Math.round(reviveProgress * 100)}%` }} />
          </div>
        </div>
      )}

      {/* reload / low ammo */}
      {locked && (reloading || ammo === 0 || low) && (
        <div className="absolute top-[57%] left-1/2 -translate-x-1/2 text-center drop-shadow-[0_0_4px_rgba(0,0,0,1)]">
          {reloading ? <span className="text-[13px] font-bold text-white/90">RELOADING…</span> : ammo === 0 && reserve === 0 ? <span className="text-[13px] font-bold text-red-400">NO AMMO</span> : <span className="text-[12px] font-bold text-amber-300">[R] RELOAD</span>}
        </div>
      )}

      {/* KIA overlay */}
      {dead && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-red-950/45 backdrop-grayscale-[0.4]">
          <div className="text-[10px] tracking-[0.6em] text-red-300">OPERATOR DOWN</div>
          <div className="mt-2 text-5xl font-black tracking-[0.2em] text-red-400">K.I.A.</div>
          <div className="mt-3 text-[11px] tracking-[0.3em] text-white/70">SQUAD REDEPLOYING IN A MOMENT…</div>
        </div>
      )}

      {/* controls hint */}
      {locked && !dead && (
        <div className={`absolute bottom-[7.5rem] left-1/2 -translate-x-1/2 border border-white/15 bg-black/45 px-4 py-2 text-center text-[10px] text-white/75 transition-opacity duration-1000 ${showHelp ? 'opacity-100' : 'opacity-0'}`}>
          WASD gerak · KLIK KIRI tembak · KLIK KANAN aim · R reload · G squad hold/follow · E revive · SHIFT sprint · C jongkok · F senter
        </div>
      )}
    </div>
  )
}
