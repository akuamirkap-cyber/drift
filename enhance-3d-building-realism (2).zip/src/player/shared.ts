// Mutable per-frame data shared between the player controller and the weapon (no React re-renders)
export const fx = {
  kickPitch: 0,
  kickYaw: 0,
  ads: 0, // 0..1 aim-down-sights blend
  speed: 0,
  sprint: false,
  crouch: false,
  grounded: true,
  bob: 0,
  yawVel: 0,
  pitchVel: 0,
  flashlight: false,
  px: -22,
  py: 0,
  pz: 28,
  yaw: -0.35,
  fps: 60,
}