import * as THREE from 'three'
import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { floorHeightAt, brightSources, insideFootprint, ROOMS, F2, H_ROOF, type AABB } from '../world/layout'
import { store } from '../state'
import { footstep, initAudio, clickSound } from '../audio'
import { ALL_COLLIDERS } from '../world/colliders'
import { takeRespawn, HORDE } from '../world/hordeState'
import { fx as wfx } from './shared'

const EYE_STAND = 1.6
const EYE_CROUCH = 1.05
const H_STAND = 1.78
const H_CROUCH = 1.25
const RADIUS = 0.22 // slim capsule
const STEP = 0.42 // auto step height
const JUMP_V = 4.1
const GRAVITY = 12
const SENS = 0.0021

interface PState {
  pos: THREE.Vector3 // feet
  vel: THREE.Vector3
  vy: number
  grounded: boolean
  jumpAt: number
  camY: number
  yaw: number
  pitch: number
  tYaw: number
  tPitch: number
  prevYaw: number
  roll: number
  bob: number
  lastBobSin: number
  eye: number
  dip: number
  exposure: number
  crouch: boolean
  flashlight: boolean
  spotDir: THREE.Vector3
  hudTick: number
}

function segmentHitsBox(ax: number, az: number, bx: number, bz: number, b: AABB) {
  const dx = bx - ax
  const dz = bz - az
  let tmin = 0
  let tmax = 1
  if (Math.abs(dx) < 1e-6) {
    if (ax < b.minX || ax > b.maxX) return false
  } else {
    let t1 = (b.minX - ax) / dx
    let t2 = (b.maxX - ax) / dx
    if (t1 > t2) [t1, t2] = [t2, t1]
    tmin = Math.max(tmin, t1)
    tmax = Math.min(tmax, t2)
    if (tmin > tmax) return false
  }
  if (Math.abs(dz) < 1e-6) {
    if (az < b.minZ || az > b.maxZ) return false
  } else {
    let t1 = (b.minZ - az) / dz
    let t2 = (b.maxZ - az) / dz
    if (t1 > t2) [t1, t2] = [t2, t1]
    tmin = Math.max(tmin, t1)
    tmax = Math.min(tmax, t2)
    if (tmin > tmax) return false
  }
  return true
}

export function Player() {
  const { camera, gl } = useThree()
  const keys = useRef<Record<string, boolean>>({})
  const spot = useRef<THREE.SpotLight>(null)
  const spotTarget = useMemo(() => new THREE.Object3D(), [])
  const colliders = useMemo(() => ALL_COLLIDERS, [])
  const tallColliders = useMemo(() => colliders.filter((c) => c.maxY - c.minY > 3.5), [colliders])
  const sources = useMemo(() => brightSources(), [])
  const st = useRef<PState>({
    pos: new THREE.Vector3(-22, 0, 28),
    vel: new THREE.Vector3(),
    vy: 0,
    grounded: true,
    jumpAt: -1,
    camY: 0,
    yaw: -0.35,
    pitch: 0.06,
    tYaw: -0.35,
    tPitch: 0.06,
    prevYaw: -0.35,
    roll: 0,
    bob: 0,
    lastBobSin: 0,
    eye: EYE_STAND,
    dip: 0,
    exposure: 1.0,
    crouch: false,
    flashlight: false,
    spotDir: new THREE.Vector3(0, 0, -1),
    hudTick: 0,
  })

  useEffect(() => {
    const canvas = gl.domElement
    const onKeyDown = (e: KeyboardEvent) => {
      keys.current[e.code] = true
      if (e.code === 'KeyF' && !e.repeat) {
        st.current.flashlight = !st.current.flashlight
        wfx.flashlight = st.current.flashlight
        store.set({ flashlight: st.current.flashlight })
        clickSound()
      }
      if ((e.code === 'KeyC' || e.code === 'ControlLeft') && !e.repeat) {
        st.current.crouch = !st.current.crouch
        store.set({ crouch: st.current.crouch })
      }
      if (e.code === 'Space' && !e.repeat) st.current.jumpAt = performance.now()
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault()
    }
    const onKeyUp = (e: KeyboardEvent) => {
      keys.current[e.code] = false
    }
    const onMouse = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return
      const s = st.current
      const sens = SENS * (1 - wfx.ads * 0.45)
      s.tYaw -= e.movementX * sens
      s.tPitch -= e.movementY * sens
      s.tPitch = Math.max(-1.35, Math.min(1.35, s.tPitch))
    }
    const onClick = () => {
      initAudio()
      if (document.pointerLockElement !== canvas) {
        try {
          const p = canvas.requestPointerLock() as unknown
          if (p && typeof (p as Promise<void>).catch === 'function') (p as Promise<void>).catch(() => {})
        } catch {
          /* ignore */
        }
      }
    }
    const onLock = () => {
      const locked = document.pointerLockElement === canvas
      store.set({ locked, everStarted: true })
      if (!locked) keys.current = {}
    }
    const onBlur = () => {
      keys.current = {}
    }
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)
    document.addEventListener('mousemove', onMouse)
    canvas.addEventListener('click', onClick)
    document.addEventListener('pointerlockchange', onLock)
    window.addEventListener('blur', onBlur)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
      document.removeEventListener('mousemove', onMouse)
      canvas.removeEventListener('click', onClick)
      document.removeEventListener('pointerlockchange', onLock)
      window.removeEventListener('blur', onBlur)
    }
  }, [gl])

  const tmp = useMemo(
    () => ({
      fwd: new THREE.Vector3(),
      right: new THREE.Vector3(),
      wish: new THREE.Vector3(),
      camFwd: new THREE.Vector3(),
      toSrc: new THREE.Vector3(),
      euler: new THREE.Euler(0, 0, 0, 'YXZ'),
    }),
    [],
  )

  useFrame((state, rawDt) => {
    // debug / screenshot camera: window.__cam = [x, y, z, yaw, pitch]
    const dbg = (window as unknown as { __cam?: number[] | null }).__cam
    if (takeRespawn()) {
      const s = st.current
      s.pos.set(-22, 0, 28)
      s.vel.set(0, 0, 0)
      s.vy = 0
      s.grounded = true
      s.yaw = s.tYaw = -0.35
      s.pitch = s.tPitch = 0.06
      store.set({ health: 100, playerDown: false })
    }
    if (dbg) {
      camera.position.set(dbg[0], dbg[1], dbg[2])
      tmp.euler.set(dbg[4] ?? 0, dbg[3] ?? 0, 0)
      camera.quaternion.setFromEuler(tmp.euler)
      return
    }
    const dt = Math.min(0.05, rawDt)
    const s = st.current
    const k = keys.current
    const t = state.clock.elapsedTime
    const locked = document.pointerLockElement === gl.domElement && !HORDE.down
    const height = s.crouch ? H_CROUCH : H_STAND

    // ---------------- horizontal movement ----------------
    const sprint = !!(k.ShiftLeft || k.ShiftRight) && !s.crouch && wfx.ads < 0.5 && (k.KeyW || k.ArrowUp)
    // weapon recoil feeds into the look target
    if (wfx.kickPitch || wfx.kickYaw) {
      s.tPitch = Math.min(1.35, s.tPitch + wfx.kickPitch)
      s.tYaw += wfx.kickYaw
      wfx.kickPitch = 0
      wfx.kickYaw = 0
    }
    const fz = (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0)
    const fx = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0)
    tmp.fwd.set(-Math.sin(s.yaw), 0, -Math.cos(s.yaw))
    tmp.right.set(Math.cos(s.yaw), 0, -Math.sin(s.yaw))
    tmp.wish.set(0, 0, 0)
    if (locked) tmp.wish.addScaledVector(tmp.fwd, fz).addScaledVector(tmp.right, fx)
    const moving = tmp.wish.lengthSq() > 0
    const maxSpeed = s.crouch ? 1.4 : sprint ? 5.6 : wfx.ads > 0.5 ? 1.9 : 3.2
    if (moving) tmp.wish.normalize().multiplyScalar(maxSpeed)
    const accel = s.grounded ? (moving ? 9 : 12) : moving ? 2.5 : 0.6
    const a = 1 - Math.exp(-dt * accel)
    s.vel.x += (tmp.wish.x - s.vel.x) * a
    s.vel.z += (tmp.wish.z - s.vel.z) * a
    s.pos.x += s.vel.x * dt
    s.pos.z += s.vel.z * dt

    // ---------------- horizontal collision (circle vs AABB) ----------------
    const feet = s.pos.y
    for (let pass = 0; pass < 2; pass++) {
      for (const c of colliders) {
        if (c.maxY <= feet + STEP) continue // low enough to step onto
        if (c.minY >= feet + height) continue // above the head
        const cx = Math.max(c.minX, Math.min(c.maxX, s.pos.x))
        const cz = Math.max(c.minZ, Math.min(c.maxZ, s.pos.z))
        let dx = s.pos.x - cx
        let dz = s.pos.z - cz
        const d2 = dx * dx + dz * dz
        if (d2 >= RADIUS * RADIUS) continue
        if (d2 < 1e-8) {
          const px = Math.min(s.pos.x - c.minX, c.maxX - s.pos.x)
          const pz = Math.min(s.pos.z - c.minZ, c.maxZ - s.pos.z)
          if (px < pz) {
            dx = s.pos.x - c.minX < c.maxX - s.pos.x ? -1 : 1
            s.pos.x = (dx < 0 ? c.minX : c.maxX) + dx * RADIUS
          } else {
            dz = s.pos.z - c.minZ < c.maxZ - s.pos.z ? -1 : 1
            s.pos.z = (dz < 0 ? c.minZ : c.maxZ) + dz * RADIUS
          }
          continue
        }
        const d = Math.sqrt(d2)
        const push = RADIUS - d
        s.pos.x += (dx / d) * push
        s.pos.z += (dz / d) * push
      }
    }

    // ---------------- support height (platforms, ramps, tops of low objects) ----------------
    let support = floorHeightAt(s.pos.x, s.pos.z, s.pos.y)
    for (const c of colliders) {
      if (c.maxY > s.pos.y + STEP || c.maxY <= support) continue
      if (c.minY > s.pos.y + STEP) continue
      const cx = Math.max(c.minX, Math.min(c.maxX, s.pos.x))
      const cz = Math.max(c.minZ, Math.min(c.maxZ, s.pos.z))
      const dx = s.pos.x - cx
      const dz = s.pos.z - cz
      if (dx * dx + dz * dz < RADIUS * RADIUS) support = c.maxY
    }

    // ---------------- vertical motion / jumping ----------------
    const wantJump = s.jumpAt > 0 && performance.now() - s.jumpAt < 150
    if (wantJump && s.grounded && locked) {
      s.vy = JUMP_V
      s.grounded = false
      s.jumpAt = -1
    }
    if (s.grounded) {
      if (support >= s.pos.y - 0.35) {
        s.pos.y = support
      } else {
        s.grounded = false
        s.vy = 0
      }
    }
    if (!s.grounded) {
      s.vy -= GRAVITY * dt
      s.pos.y += s.vy * dt
      if (s.pos.y <= support) {
        const impact = -s.vy
        s.pos.y = support
        s.vy = 0
        s.grounded = true
        if (impact > 1.5) {
          s.dip = Math.min(0.09, impact * 0.012)
          const room = ROOMS.find((r) => s.pos.x >= r.xMin - 0.2 && s.pos.x <= r.xMax + 0.2 && s.pos.z >= r.zMin - 0.2 && s.pos.z <= r.zMax + 0.2 && Math.abs(r.y - s.pos.y) < 1.6)
          footstep(room ? room.floor : 'concrete', Math.min(1.3, 0.6 + impact * 0.12))
        }
      }
    }
    if (s.grounded) s.camY = s.camY + (s.pos.y - s.camY) * Math.min(1, dt * 18)
    else s.camY = s.pos.y

    // ---------------- head bob & steps ----------------
    const speedH = Math.hypot(s.vel.x, s.vel.z)
    const bobK = s.grounded ? Math.min(1.25, speedH / 2.3) : 0
    if (s.grounded && speedH > 0.25) {
      s.bob += dt * (sprint ? 10.5 : s.crouch ? 6.5 : 8.2) * Math.max(0.55, Math.min(1.2, speedH / maxSpeed))
    }
    const bobSin = Math.sin(s.bob)
    if (s.grounded && speedH > 0.4 && Math.sign(bobSin) !== Math.sign(s.lastBobSin) && s.lastBobSin !== 0) {
      const room = ROOMS.find((r) => s.pos.x >= r.xMin - 0.2 && s.pos.x <= r.xMax + 0.2 && s.pos.z >= r.zMin - 0.2 && s.pos.z <= r.zMax + 0.2 && Math.abs(r.y - s.pos.y) < 1.6)
      const surface = room ? room.floor : insideFootprint(s.pos.x, s.pos.z) ? 'wood' : 'concrete'
      footstep(surface, sprint ? 1.15 : s.crouch ? 0.5 : 0.85)
      s.dip = sprint ? 0.028 : 0.016
    }
    s.lastBobSin = bobSin
    s.dip *= Math.exp(-dt * 9)

    // ---------------- camera orientation smoothing (body-cam lag) ----------------
    const look = 1 - Math.exp(-dt * 15)
    s.yaw += (s.tYaw - s.yaw) * look
    s.pitch += (s.tPitch - s.pitch) * look
    const yawVel = (s.yaw - s.prevYaw) / Math.max(dt, 1e-4)
    s.prevYaw = s.yaw
    wfx.yawVel = Math.max(-6, Math.min(6, yawVel))
    wfx.pitchVel = Math.max(-6, Math.min(6, (s.tPitch - s.pitch) * 6))
    wfx.speed = speedH
    wfx.sprint = !!sprint
    wfx.crouch = s.crouch
    wfx.grounded = s.grounded
    wfx.bob = s.bob
    wfx.px = s.pos.x
    wfx.py = s.pos.y
    wfx.pz = s.pos.z
    wfx.yaw = s.yaw
    {
      const cam = camera as THREE.PerspectiveCamera
      const targetFov = 78 - 28 * wfx.ads + (sprint && speedH > 3 ? 5 : 0)
      const nf = cam.fov + (targetFov - cam.fov) * (1 - Math.exp(-dt * 12))
      if (Math.abs(nf - cam.fov) > 0.01) {
        cam.fov = nf
        cam.updateProjectionMatrix()
      }
    }
    const lateral = s.vel.dot(tmp.right)
    const targetRoll = Math.max(-0.09, Math.min(0.09, -lateral * 0.012 + bobSin * 0.012 * bobK - yawVel * 0.01))
    s.roll += (targetRoll - s.roll) * (1 - Math.exp(-dt * 6))

    const eyeTarget = s.crouch ? EYE_CROUCH : EYE_STAND
    s.eye += (eyeTarget - s.eye) * (1 - Math.exp(-dt * 8))

    const breathY = Math.sin(t * 1.3) * 0.006 + Math.sin(t * 0.37) * 0.004
    const breathP = Math.sin(t * 1.3 + 0.8) * 0.0025
    const bobY = Math.sin(s.bob * 2) * 0.026 * bobK - s.dip
    const bobX = bobSin * 0.018 * bobK
    const bobP = Math.sin(s.bob * 2 + 0.6) * 0.006 * bobK
    const airP = s.grounded ? 0 : Math.max(-0.05, Math.min(0.05, -s.vy * 0.008))

    camera.position.set(s.pos.x + tmp.right.x * bobX, s.camY + s.eye + bobY + breathY, s.pos.z + tmp.right.z * bobX)
    tmp.euler.set(s.pitch + bobP + breathP + airP, s.yaw, s.roll)
    camera.quaternion.setFromEuler(tmp.euler)

    // ---------------- flashlight ----------------
    const light = spot.current
    if (light) {
      light.visible = s.flashlight
      if (s.flashlight) {
        tmp.camFwd.set(0, 0, -1).applyQuaternion(camera.quaternion)
        s.spotDir.lerp(tmp.camFwd, 1 - Math.exp(-dt * 9)).normalize()
        light.position.copy(camera.position).addScaledVector(tmp.right, 0.14)
        light.position.y -= 0.16
        spotTarget.position.copy(light.position).addScaledVector(s.spotDir, 10)
        spotTarget.updateMatrixWorld()
      }
    }

    // ---------------- fake auto exposure ----------------
    tmp.camFwd.set(0, 0, -1).applyQuaternion(camera.quaternion)
    let incoming = 0
    const cx = camera.position.x
    const cy = camera.position.y
    const cz = camera.position.z
    const inside = insideFootprint(cx, cz)
    if (!inside) incoming += 6
    for (const src of sources) {
      tmp.toSrc.set(src.x - cx, src.y - cy, src.z - cz)
      const dist = tmp.toSrc.length()
      if (dist < 0.3) continue
      tmp.toSrc.divideScalar(dist)
      const cosA = tmp.toSrc.dot(tmp.camFwd)
      if (cosA < 0.3) continue
      if (src.nx !== 0 || src.nz !== 0) {
        const side = (cx - src.x) * src.nx + (cz - src.z) * src.nz
        if (side < 0) continue
      }
      const ex = src.x - tmp.toSrc.x * 0.4
      const ez = src.z - tmp.toSrc.z * 0.4
      const midY = (cy + src.y) / 2
      let blocked = false
      for (const b of tallColliders) {
        if (b.minY > midY || b.maxY < midY) continue
        if (segmentHitsBox(cx, cz, ex, ez, b)) {
          blocked = true
          break
        }
      }
      if (blocked) continue
      incoming += (src.power * (cosA - 0.3)) / (1 + dist * 0.3)
    }
    const targetExp = Math.max(0.66, Math.min(0.98, 1.05 / (0.86 + incoming * 0.1)))
    s.exposure += (targetExp - s.exposure) * (1 - Math.exp(-dt * (targetExp < s.exposure ? 3.2 : 1.6)))
    gl.toneMappingExposure = s.exposure

    // ---------------- HUD state (throttled) ----------------
    s.hudTick++
    if (s.hudTick % 8 === 0) {
      store.set({
        sprint: sprint && moving,
        floor: s.pos.y > H_ROOF - 0.8 ? 3 : s.pos.y > F2 - 0.6 ? 2 : 1,
        px: Math.round(s.pos.x * 10) / 10,
        pz: Math.round(s.pos.z * 10) / 10,
        heading: Math.round((((-s.yaw * 180) / Math.PI) % 360 + 360) % 360),
        exposure: Math.round(s.exposure * 100) / 100,
      })
    }
  })

  return (
    <group>
      <spotLight
        ref={spot}
        visible={false}
        intensity={30}
        angle={0.5}
        penumbra={0.55}
        distance={26}
        decay={1.7}
        color="#fff3dc"
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.02}
        shadow-camera-near={0.3}
        shadow-camera-far={26}
        target={spotTarget}
      />
      <primitive object={spotTarget} />
    </group>
  )
}
