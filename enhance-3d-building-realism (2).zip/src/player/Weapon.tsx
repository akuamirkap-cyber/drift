import * as THREE from 'three'
import { useEffect, useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { fx } from './shared'
import { store } from '../state'
import { gunshot, dryFire, reloadSound, impactSound, initAudio, ding } from '../audio'
import { damageZombieSlot } from '../world/hordeState'
import { insideFootprint } from '../world/layout'

const MAG = 30
const RPM = 720
const RELOAD_T = 2.25
const HIP: [number, number, number] = [0.135, -0.155, -0.47]
const ADS_POS: [number, number, number] = [0, -0.0855, -0.3]

// ---------------------------------------------------------------------------
function holeTexture() {
  const s = 128
  const c = document.createElement('canvas')
  c.width = c.height = s
  const ctx = c.getContext('2d')!
  const g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2)
  g.addColorStop(0, 'rgba(8,8,8,1)')
  g.addColorStop(0.16, 'rgba(15,14,13,1)')
  g.addColorStop(0.24, 'rgba(60,56,50,0.9)')
  g.addColorStop(0.5, 'rgba(70,66,60,0.35)')
  g.addColorStop(1, 'rgba(0,0,0,0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, s, s)
  ctx.strokeStyle = 'rgba(20,18,16,0.7)'
  ctx.lineWidth = 1.5
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * Math.PI * 2 + Math.random() * 0.5
    ctx.beginPath()
    ctx.moveTo(s / 2 + Math.cos(a) * 12, s / 2 + Math.sin(a) * 12)
    ctx.lineTo(s / 2 + Math.cos(a) * (26 + Math.random() * 26), s / 2 + Math.sin(a) * (26 + Math.random() * 26))
    ctx.stroke()
  }
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}
function flashTexture() {
  const s = 128
  const c = document.createElement('canvas')
  c.width = c.height = s
  const ctx = c.getContext('2d')!
  ctx.translate(s / 2, s / 2)
  for (let i = 0; i < 5; i++) {
    ctx.rotate((Math.PI * 2) / 5)
    const g = ctx.createLinearGradient(0, 0, 0, -s / 2)
    g.addColorStop(0, 'rgba(255,240,200,1)')
    g.addColorStop(0.4, 'rgba(255,170,60,0.8)')
    g.addColorStop(1, 'rgba(255,120,20,0)')
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.moveTo(-9, 0)
    ctx.lineTo(0, -s / 2)
    ctx.lineTo(9, 0)
    ctx.fill()
  }
  const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 30)
  g.addColorStop(0, 'rgba(255,255,240,1)')
  g.addColorStop(1, 'rgba(255,180,80,0)')
  ctx.fillStyle = g
  ctx.fillRect(-s / 2, -s / 2, s, s)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

// ---------------------------------------------------------------------------
function buildGun() {
  const gun = new THREE.Group()
  const metal = new THREE.MeshStandardMaterial({ color: '#3a3d41', roughness: 0.38, metalness: 0.7 })
  const poly = new THREE.MeshStandardMaterial({ color: '#1c1d1f', roughness: 0.75, metalness: 0.1 })
  const tan = new THREE.MeshStandardMaterial({ color: '#6f6250', roughness: 0.8, metalness: 0.05 })
  const glove = new THREE.MeshStandardMaterial({ color: '#34322d', roughness: 0.85 })
  const sleeve = new THREE.MeshStandardMaterial({ color: '#474c3a', roughness: 0.95 })
  const lens = new THREE.MeshStandardMaterial({ color: '#16241f', roughness: 0.05, metalness: 0.9, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false })
  const dotMat = new THREE.MeshBasicMaterial({ color: '#ff2a1a' })
  const B = (mat: THREE.Material, s: [number, number, number], p: [number, number, number], r: [number, number, number] = [0, 0, 0], parent: THREE.Object3D = gun) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(...s), mat)
    m.position.set(...p)
    m.rotation.set(...r)
    parent.add(m)
    return m
  }
  const C = (mat: THREE.Material, r: number, len: number, p: [number, number, number], seg = 16, parent: THREE.Object3D = gun, open = false) => {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, seg, 1, open), mat)
    m.rotation.x = Math.PI / 2
    m.position.set(...p)
    parent.add(m)
    return m
  }
  // receiver
  B(metal, [0.05, 0.055, 0.3], [0, 0.02, -0.05])
  B(metal, [0.044, 0.05, 0.19], [0, -0.03, 0.0])
  B(poly, [0.012, 0.03, 0.06], [0.026, 0.025, -0.02]) // ejection port cover
  B(metal, [0.03, 0.012, 0.05], [0, 0.052, 0.09]) // charging handle
  // top rail
  for (let i = 0; i < 12; i++) B(metal, [0.036, 0.008, 0.012], [0, 0.052, -0.17 + i * 0.022])
  // handguard (tan) with rails
  {
    const hg = new THREE.Mesh(new THREE.CylinderGeometry(0.033, 0.033, 0.33, 8), tan)
    hg.rotation.set(Math.PI / 2, 0, Math.PI / 8)
    hg.position.set(0, 0.018, -0.36)
    gun.add(hg)
    // M-LOK slots
    for (let i = 0; i < 5; i++) for (const sx of [-1, 1]) B(poly, [0.004, 0.012, 0.03], [sx * 0.031, 0.012, -0.25 - i * 0.05])
    B(metal, [0.04, 0.012, 0.01], [0, 0.018, -0.195])
  }
  for (let i = 0; i < 10; i++) B(metal, [0.036, 0.008, 0.012], [0, 0.052, -0.22 - i * 0.026])
  // barrel & muzzle device
  C(metal, 0.0105, 0.22, [0, 0.018, -0.63])
  C(metal, 0.016, 0.07, [0, 0.018, -0.765], 6)
  B(metal, [0.012, 0.04, 0.012], [0, 0.07, -0.49]) // front sight post
  // magazine (curved approximation)
  B(poly, [0.032, 0.11, 0.07], [0, -0.1, -0.075], [-0.12, 0, 0])
  B(poly, [0.032, 0.09, 0.066], [0, -0.19, -0.095], [-0.32, 0, 0])
  // grip / trigger guard
  B(poly, [0.034, 0.11, 0.045], [0, -0.09, 0.075], [0.35, 0, 0])
  B(metal, [0.01, 0.006, 0.07], [0, -0.065, 0.02])
  // stock
  C(metal, 0.015, 0.16, [0, 0.008, 0.19])
  B(poly, [0.046, 0.085, 0.17], [0, -0.008, 0.29])
  B(poly, [0.048, 0.1, 0.02], [0, -0.015, 0.38])
  // red dot sight (sight centre at y 0.0855, z -0.06)
  B(metal, [0.032, 0.022, 0.05], [0, 0.064, -0.05])
  const tube = C(metal, 0.022, 0.07, [0, 0.0855, -0.06], 24, gun, true)
  ;(tube.material as THREE.Material).side = THREE.DoubleSide
  const tubeMat = metal.clone()
  tubeMat.side = THREE.DoubleSide
  tube.material = tubeMat
  const l = new THREE.Mesh(new THREE.CircleGeometry(0.021, 24), lens)
  l.position.set(0, 0.0855, -0.08)
  gun.add(l)
  const dot = new THREE.Mesh(new THREE.SphereGeometry(0.0017, 8, 6), dotMat)
  dot.position.set(0, 0.0855, -0.1)
  gun.add(dot)
  // hands & arms
  B(glove, [0.075, 0.055, 0.11], [-0.012, -0.03, -0.39], [0, 0, 0.25]) // support hand
  B(glove, [0.022, 0.02, 0.09], [0.03, 0.035, -0.39], [0, 0, -0.3]) // thumb over the rail
  const limb = (mat: THREE.Material, a: [number, number, number], b: [number, number, number], r0: number, r1: number) => {
    const va = new THREE.Vector3(...a)
    const vb = new THREE.Vector3(...b)
    const d = vb.clone().sub(va)
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r0, r1, d.length(), 14), mat)
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize())
    m.position.copy(va).add(vb).multiplyScalar(0.5)
    gun.add(m)
    return m
  }
  limb(glove, [-0.015, -0.045, -0.37], [-0.06, -0.1, -0.3], 0.03, 0.034) // wrist
  limb(sleeve, [-0.06, -0.1, -0.3], [-0.24, -0.36, 0.02], 0.04, 0.052) // left forearm
  B(glove, [0.06, 0.075, 0.08], [0.008, -0.075, 0.07], [0.3, 0, 0]) // firing hand
  limb(glove, [0.01, -0.1, 0.09], [0.05, -0.15, 0.15], 0.03, 0.034)
  limb(sleeve, [0.05, -0.15, 0.15], [0.2, -0.38, 0.36], 0.042, 0.055) // right forearm
  // magazine group handle for reload anim
  return { gun, dot }
}

// ---------------------------------------------------------------------------
export function Weapon() {
  const { gl, camera, scene, size } = useThree()
  const firing = useRef(false)
  const aiming = useRef(false)

  const W = useMemo(() => {
    const wScene = new THREE.Scene()
    const wCam = new THREE.PerspectiveCamera(58, 1, 0.01, 10)
    const hemi = new THREE.HemisphereLight('#dfe7f0', '#4a443c', 1.4)
    const sun = new THREE.DirectionalLight('#fff1dc', 2.4)
    sun.position.set(0.6, 1, 0.4)
    const amb = new THREE.AmbientLight('#ffffff', 0.25)
    const flashL = new THREE.PointLight('#ffb35c', 0, 1.5, 2)
    flashL.position.set(0, 0.02, -0.8)
    const { gun, dot } = buildGun()
    const root = new THREE.Group()
    root.add(gun)
    gun.add(flashL)
    const flash = new THREE.Sprite(new THREE.SpriteMaterial({ map: flashTexture(), color: '#ffffff', blending: THREE.AdditiveBlending, depthWrite: false, transparent: true }))
    flash.position.set(0, 0.018, -0.86)
    flash.visible = false
    gun.add(flash)
    wScene.add(hemi, sun, amb, root)
    return { wScene, wCam, hemi, sun, amb, flashL, gun, dot, root, flash }
  }, [])

  // world effects: bullet holes, impact dust, muzzle light
  const worldFx = useMemo(() => {
    const N = 300
    const holeMat = new THREE.MeshStandardMaterial({ map: holeTexture(), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4, roughness: 1 })
    const holes = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.09, 0.09), holeMat, N)
    holes.count = 0
    holes.frustumCulled = false
    holes.userData.noHit = true
    const P = 480
    const pPos = new Float32Array(P * 3).fill(-1000)
    const pVel = new Float32Array(P * 3)
    const pLife = new Float32Array(P)
    const pg = new THREE.BufferGeometry()
    pg.setAttribute('position', new THREE.BufferAttribute(pPos, 3))
    const pts = new THREE.Points(pg, new THREE.PointsMaterial({ color: '#c9c0b0', size: 0.045, sizeAttenuation: true, transparent: true, opacity: 0.85, depthWrite: false }))
    pts.frustumCulled = false
    pts.userData.noHit = true
    const light = new THREE.PointLight('#ffb466', 0, 9, 2)
    const B = 260
    const bPos = new Float32Array(B * 3).fill(-1000)
    const bVel = new Float32Array(B * 3)
    const bLife = new Float32Array(B)
    const bg = new THREE.BufferGeometry()
    bg.setAttribute('position', new THREE.BufferAttribute(bPos, 3))
    const blood = new THREE.Points(bg, new THREE.PointsMaterial({ color: '#6e1111', size: 0.06, transparent: true, opacity: 0.9, depthWrite: false }))
    blood.frustumCulled = false
    blood.userData.noHit = true
    return { holes, N, idx: 0, pts, pPos, pVel, pLife, P, pIdx: 0, light, blood, bPos, bVel, bLife, B, bIdx: 0 }
  }, [])

  const st = useRef({ ammo: MAG, reserve: 210, last: 0, reloadT: -1, recoil: 0, recoilRot: 0, flashT: 0, hitT: 0, killT: 0, swayX: 0, swayY: 0, ads: 0, sprint: 0, shots: 0 })
  const tmp = useMemo(
    () => ({ ray: new THREE.Raycaster(), dir: new THREE.Vector3(), n: new THREE.Vector3(), m4: new THREE.Matrix4(), q: new THREE.Quaternion(), v: new THREE.Vector3(), z: new THREE.Vector3(0, 0, 1), right: new THREE.Vector3(), up: new THREE.Vector3() }),
    [],
  )

  useEffect(() => {
    const canvas = gl.domElement
    const down = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return
      initAudio()
      if (e.button === 0) firing.current = true
      if (e.button === 2) aiming.current = true
    }
    const up = (e: MouseEvent) => {
      if (e.button === 0) firing.current = false
      if (e.button === 2) aiming.current = false
    }
    const key = (e: KeyboardEvent) => {
      if (e.code === 'KeyR' && !e.repeat) startReload()
    }
    const ctx = (e: Event) => e.preventDefault()
    const lock = () => {
      if (document.pointerLockElement !== canvas) {
        firing.current = false
        aiming.current = false
      }
    }
    document.addEventListener('mousedown', down)
    document.addEventListener('mouseup', up)
    window.addEventListener('keydown', key)
    document.addEventListener('contextmenu', ctx)
    document.addEventListener('pointerlockchange', lock)
    return () => {
      document.removeEventListener('mousedown', down)
      document.removeEventListener('mouseup', up)
      window.removeEventListener('keydown', key)
      document.removeEventListener('contextmenu', ctx)
      document.removeEventListener('pointerlockchange', lock)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gl])

  function startReload() {
    const s = st.current
    if (s.reloadT >= 0 || s.ammo >= MAG || s.reserve <= 0) return
    s.reloadT = 0
    store.set({ reloading: true })
    reloadSound()
  }

  function spawnImpact(p: THREE.Vector3, n: THREE.Vector3) {
    const f = worldFx
    // decal
    tmp.q.setFromUnitVectors(tmp.z, n)
    const spin = new THREE.Quaternion().setFromAxisAngle(tmp.z, Math.random() * Math.PI * 2)
    tmp.q.multiply(spin)
    const sc = 0.7 + Math.random() * 0.6
    tmp.m4.compose(tmp.v.copy(p).addScaledVector(n, 0.003), tmp.q, new THREE.Vector3(sc, sc, sc))
    f.holes.setMatrixAt(f.idx % f.N, tmp.m4)
    f.idx++
    f.holes.count = Math.min(f.N, f.idx)
    f.holes.instanceMatrix.needsUpdate = true
    spawnDust(p, n, 14)
  }

  function spawnBlood(p: THREE.Vector3, n: THREE.Vector3) {
    const f = worldFx
    for (let k = 0; k < 16; k++) {
      const i = f.bIdx++ % f.B
      f.bPos[i * 3] = p.x
      f.bPos[i * 3 + 1] = p.y
      f.bPos[i * 3 + 2] = p.z
      const sp = 0.5 + Math.random() * 2.4
      f.bVel[i * 3] = n.x * sp + (Math.random() - 0.5) * 1.4
      f.bVel[i * 3 + 1] = n.y * sp + Math.random() * 1.6
      f.bVel[i * 3 + 2] = n.z * sp + (Math.random() - 0.5) * 1.4
      f.bLife[i] = 0.4 + Math.random() * 0.5
    }
  }

  function spawnDust(p: THREE.Vector3, n: THREE.Vector3, count: number) {
    const f = worldFx
    for (let k = 0; k < count; k++) {
      const i = f.pIdx++ % f.P
      f.pPos[i * 3] = p.x + n.x * 0.02
      f.pPos[i * 3 + 1] = p.y + n.y * 0.02
      f.pPos[i * 3 + 2] = p.z + n.z * 0.02
      const sp = 0.8 + Math.random() * 2.2
      f.pVel[i * 3] = n.x * sp + (Math.random() - 0.5) * 1.6
      f.pVel[i * 3 + 1] = n.y * sp + (Math.random() - 0.2) * 1.6
      f.pVel[i * 3 + 2] = n.z * sp + (Math.random() - 0.5) * 1.6
      f.pLife[i] = 0.35 + Math.random() * 0.5
    }
  }

  function fire(now: number) {
    const s = st.current
    s.last = now
    s.ammo--
    s.shots++
    store.set({ ammo: s.ammo })
    const ads = s.ads
    const indoor = insideFootprint(camera.position.x, camera.position.z)
    gunshot(indoor)
    // recoil
    const kick = (0.011 + Math.random() * 0.006) * (1 - ads * 0.45) * (fx.crouch ? 0.7 : 1)
    fx.kickPitch += kick
    fx.kickYaw += (Math.random() - 0.45) * 0.006 * (1 - ads * 0.4)
    s.recoil = Math.min(1.6, s.recoil + 1)
    s.recoilRot = Math.min(1.6, s.recoilRot + 1)
    s.flashT = 0.05
    // hitscan with spread
    const spread = (ads > 0.6 ? 0.002 : 0.022) + fx.speed * 0.006 + (fx.grounded ? 0 : 0.05)
    tmp.dir.set((Math.random() - 0.5) * spread, (Math.random() - 0.5) * spread, -1).normalize().applyQuaternion(camera.quaternion)
    tmp.ray.set(camera.position, tmp.dir)
    tmp.ray.far = 250
    const hits = tmp.ray.intersectObjects(scene.children, true)
    for (const h of hits) {
      const o = h.object as THREE.Mesh
      if (o.userData.noHit || !(o as THREE.Mesh).isMesh) continue
      const mat = o.material as THREE.Material | THREE.Material[]
      const m0 = Array.isArray(mat) ? mat[0] : mat
      if (!m0 || (m0 as THREE.ShaderMaterial).isShaderMaterial) continue
      if (m0.transparent && !m0.depthWrite) continue
      if (!h.face) continue
      tmp.n.copy(h.face.normal)
      const im = o as unknown as THREE.InstancedMesh
      if (im.isInstancedMesh && h.instanceId !== undefined) {
        im.getMatrixAt(h.instanceId, tmp.m4)
        tmp.n.transformDirection(tmp.m4)
      }
      tmp.n.transformDirection(o.matrixWorld)
      if (tmp.n.dot(tmp.dir) > 0) tmp.n.negate()
      const part = (o.userData as { zombiePart?: string }).zombiePart
      if (part && h.instanceId !== undefined) {
        const head = part === 'head'
        const killed = damageZombieSlot(h.instanceId, head ? 58 : 36, head)
        spawnBlood(h.point, tmp.n)
        st.current.hitT = 0.22
        if (killed) st.current.killT = 0.5
        ding(h.distance)
        store.set({ hits: store.get().hits + 1 })
      } else {
        spawnImpact(h.point, tmp.n)
        impactSound(h.distance)
      }
      break
    }
  }

  useFrame((state, rawDt) => {
    const dt = Math.min(0.05, rawDt)
    const s = st.current
    const now = state.clock.elapsedTime
    const locked = document.pointerLockElement === gl.domElement
    const reloading = s.reloadT >= 0

    // ---------------- reload ----------------
    if (reloading) {
      s.reloadT += dt
      if (s.reloadT >= RELOAD_T) {
        const need = MAG - s.ammo
        const take = Math.min(need, s.reserve)
        s.ammo += take
        s.reserve -= take
        s.reloadT = -1
        store.set({ ammo: s.ammo, reserve: s.reserve, reloading: false })
      }
    }

    // ---------------- ADS / sprint blends ----------------
    const wantAds = aiming.current && locked && !reloading && !fx.sprint
    s.ads += ((wantAds ? 1 : 0) - s.ads) * (1 - Math.exp(-dt * 14))
    fx.ads = s.ads
    store.set({ ads: s.ads > 0.5 })
    const sprintK = fx.sprint && fx.speed > 2.5 && !firing.current ? 1 : 0
    s.sprint += (sprintK - s.sprint) * (1 - Math.exp(-dt * 8))

    // ---------------- firing ----------------
    if (firing.current && locked && !reloading && s.sprint < 0.4) {
      if (now - s.last >= 60 / RPM) {
        if (s.ammo > 0) fire(now)
        else {
          s.last = now + 0.25
          dryFire()
          startReload()
        }
      }
    }

    // ---------------- viewmodel pose ----------------
    s.recoil *= Math.exp(-dt * 14)
    s.recoilRot *= Math.exp(-dt * 9)
    s.swayX += (-fx.yawVel * 0.012 - s.swayX) * (1 - Math.exp(-dt * 10))
    s.swayY += (fx.pitchVel * 0.012 - s.swayY) * (1 - Math.exp(-dt * 10))
    const a = s.ads
    const bobK = fx.grounded ? Math.min(1.3, fx.speed / 2.3) * (1 - a * 0.85) : 0
    const bx = Math.sin(fx.bob) * 0.012 * bobK
    const by = -Math.abs(Math.cos(fx.bob)) * 0.01 * bobK
    const breath = Math.sin(now * 1.4) * 0.0018 * (1 - a * 0.7)
    const g = W.gun
    const px = HIP[0] + (ADS_POS[0] - HIP[0]) * a
    const py = HIP[1] + (ADS_POS[1] - HIP[1]) * a
    const pz = HIP[2] + (ADS_POS[2] - HIP[2]) * a
    let rx = s.recoilRot * 0.05 * (1 - a * 0.6) + breath * 2
    let ry = 0
    let rz = 0
    let ox = 0
    let oy = 0
    // sprint pose
    rx += -0.35 * s.sprint
    ry += 0.75 * s.sprint
    rz += 0.25 * s.sprint
    ox += -0.06 * s.sprint
    oy += -0.06 * s.sprint
    // reload pose
    if (reloading) {
      const t = s.reloadT / RELOAD_T
      const e = Math.sin(Math.min(1, t * 1.15) * Math.PI)
      rz += 0.55 * e
      rx += 0.25 * e
      oy += -0.07 * e
      ox += -0.03 * e
    }
    g.position.set(px + bx + s.swayX * (1 - a * 0.8) + ox, py + by + breath + s.swayY * (1 - a * 0.8) + oy, pz + s.recoil * 0.035 * (1 - a * 0.4))
    g.rotation.set(rx + s.swayY * 2, ry + s.swayX * 2.5, rz + s.swayX * 1.5)
    W.dot.visible = a > 0.6

    // ---------------- muzzle flash ----------------
    s.flashT -= dt
    const flashOn = s.flashT > 0
    W.flash.visible = flashOn
    if (flashOn) {
      W.flash.material.rotation = Math.random() * Math.PI
      const sc = 0.13 + Math.random() * 0.08
      W.flash.scale.set(sc, sc, sc)
    }
    W.flashL.intensity = flashOn ? 3.5 : 0
    tmp.right.set(1, 0, 0).applyQuaternion(camera.quaternion)
    tmp.up.set(0, 1, 0).applyQuaternion(camera.quaternion)
    tmp.v.set(0, 0, -1).applyQuaternion(camera.quaternion)
    worldFx.light.position.copy(camera.position).addScaledVector(tmp.v, 0.9).addScaledVector(tmp.right, 0.15 * (1 - a)).addScaledVector(tmp.up, -0.1)
    worldFx.light.intensity = flashOn ? 14 : 0

    // ---------------- particles ----------------
    const f = worldFx
    for (let i = 0; i < f.P; i++) {
      if (f.pLife[i] <= 0) continue
      f.pLife[i] -= dt
      if (f.pLife[i] <= 0) {
        f.pPos[i * 3 + 1] = -1000
        continue
      }
      f.pVel[i * 3 + 1] -= 6 * dt
      const drag = Math.exp(-dt * 3)
      f.pVel[i * 3] *= drag
      f.pVel[i * 3 + 2] *= drag
      f.pPos[i * 3] += f.pVel[i * 3] * dt
      f.pPos[i * 3 + 1] += f.pVel[i * 3 + 1] * dt
      f.pPos[i * 3 + 2] += f.pVel[i * 3 + 2] * dt
    }
    ;(f.pts.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true
    for (let i = 0; i < f.B; i++) {
      if (f.bLife[i] <= 0) continue
      f.bLife[i] -= dt
      if (f.bLife[i] <= 0) { f.bPos[i * 3 + 1] = -1000; continue }
      f.bVel[i * 3 + 1] -= 9 * dt
      f.bPos[i * 3] += f.bVel[i * 3] * dt
      f.bPos[i * 3 + 1] += f.bVel[i * 3 + 1] * dt
      f.bPos[i * 3 + 2] += f.bVel[i * 3 + 2] * dt
    }
    ;(f.blood.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true

    // ---------------- hit marker ----------------
    s.hitT = Math.max(0, s.hitT - dt)
    const hm = document.getElementById('hitmark')
    if (hm) {
      hm.style.opacity = String(Math.min(1, s.hitT * 6))
      hm.style.color = s.killT > 0 ? '#ff5a4a' : '#ffffff'
    }
    s.killT = Math.max(0, s.killT - dt)

    // ---------------- crosshair (DOM, no React) ----------------
    const xh = document.getElementById('xhair')
    if (xh) {
      const spreadPx = 10 + fx.speed * 4 + s.recoil * 9 + (fx.grounded ? 0 : 14)
      xh.style.setProperty('--gap', `${spreadPx}px`)
      xh.style.opacity = String(Math.max(0, 1 - a * 1.6 - s.sprint))
    }

    // ---------------- lighting of the viewmodel ----------------
    const indoor = insideFootprint(camera.position.x, camera.position.z)
    const k = indoor ? 0.42 : 1.0
    W.hemi.intensity += (1.4 * k + (fx.flashlight ? 0.5 : 0) - W.hemi.intensity) * (1 - Math.exp(-dt * 4))
    W.sun.intensity += (2.4 * k * (indoor ? 0.4 : 1) - W.sun.intensity) * (1 - Math.exp(-dt * 4))

    // ---------------- render the viewmodel on top ----------------
    W.wCam.aspect = size.width / size.height
    W.wCam.fov = 58 - 14 * a
    W.wCam.updateProjectionMatrix()
    gl.autoClear = false
    gl.setRenderTarget(null)
    gl.clearDepth()
    gl.render(W.wScene, W.wCam)
  }, 2)

  return (
    <group>
      <primitive object={worldFx.holes} />
      <primitive object={worldFx.pts} />
      <primitive object={worldFx.blood} />
      <primitive object={worldFx.light} />
    </group>
  )
}
