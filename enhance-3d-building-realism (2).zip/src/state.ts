import { useSyncExternalStore } from 'react'

export interface SquadMember {
  name: string
  role: string
  hp: number
  max: number
  state: 'follow' | 'hold' | 'down'
  kills: number
}

export interface GameState {
  locked: boolean
  flashlight: boolean
  sprint: boolean
  crouch: boolean
  floor: number
  px: number
  pz: number
  heading: number
  exposure: number
  everStarted: boolean
  ammo: number
  reserve: number
  reloading: boolean
  ads: boolean
  hits: number
  // squad + horde
  health: number
  damageId: number
  kills: number
  headshots: number
  wave: number
  hordePhase: 'prep' | 'active' | 'clear' | 'killed'
  waveTimer: number
  zombiesAlive: number
  zombiesLeft: number
  squad: SquadMember[]
  squadMode: 'follow' | 'hold'
  playerDown: boolean
  reviveTarget: number
  reviveProgress: number
  fps: number
  showFps: boolean
  zombieBlips: string
  squadBlips: string
}

let state: GameState = {
  locked: false,
  flashlight: false,
  sprint: false,
  crouch: false,
  floor: 1,
  px: 0,
  pz: 0,
  heading: 0,
  exposure: 1,
  everStarted: false,
  ammo: 30,
  reserve: 240,
  reloading: false,
  ads: false,
  hits: 0,
  health: 100,
  damageId: 0,
  kills: 0,
  headshots: 0,
  wave: 0,
  hordePhase: 'prep',
  waveTimer: 12,
  zombiesAlive: 0,
  zombiesLeft: 0,
  squad: [
    { name: 'GHOST-2', role: 'SUPPORT', hp: 100, max: 100, state: 'follow', kills: 0 },
    { name: 'ALPHA', role: 'RIFLEMAN', hp: 100, max: 100, state: 'follow', kills: 0 },
    { name: 'BRAVO', role: 'BREACHER', hp: 100, max: 100, state: 'follow', kills: 0 },
    { name: 'CHARLIE', role: 'MARKSMAN', hp: 100, max: 100, state: 'follow', kills: 0 },
  ],
  squadMode: 'follow',
  playerDown: false,
  reviveTarget: -1,
  reviveProgress: 0,
  fps: 60,
  showFps: true,
  zombieBlips: '',
  squadBlips: '',
}

const listeners = new Set<() => void>()

export const store = {
  get: () => state,
  set: (partial: Partial<GameState>) => {
    let changed = false
    for (const k in partial) {
      if ((state as unknown as Record<string, unknown>)[k] !== (partial as Record<string, unknown>)[k]) {
        changed = true
        break
      }
    }
    if (!changed) return
    state = { ...state, ...partial }
    listeners.forEach((l) => l())
  },
  subscribe: (l: () => void) => {
    listeners.add(l)
    return () => {
      listeners.delete(l)
    }
  },
}

export function useGame<T>(selector: (s: GameState) => T): T {
  return useSyncExternalStore(store.subscribe, () => selector(state), () => selector(state))
}
