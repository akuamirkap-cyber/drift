import { useEffect, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { store } from '../state'
import { fx } from '../player/shared'

/** adaptive resolution + FPS telemetry: keeps the frame time stable instead of letting effects tank FPS */
export function PerformanceGovernor() {
  const { gl } = useThree()
  const acc = useRef({ t: 0, n: 0, dpr: Math.min(1.1, typeof window !== 'undefined' ? window.devicePixelRatio : 1), lastChange: 0 })
  useEffect(() => {
    gl.setPixelRatio(acc.current.dpr)
  }, [gl])
  useFrame((_, dt) => {
    const a = acc.current
    a.t += dt
    a.n++
    if (a.t > 1.25) {
      const fps = a.n / a.t
      fx.fps = fps
      store.set({ fps: Math.round(fps) })
      a.t = 0
      a.n = 0
      a.lastChange += 1.25
      const wantDown = a.dpr > 0.72 && a.lastChange > 2
      const wantUp = a.dpr < Math.min(1.1, window.devicePixelRatio || 1) && a.lastChange > 6
      if (fps < 52 && wantDown) {
        a.dpr = Math.max(0.72, a.dpr - 0.12)
        gl.setPixelRatio(a.dpr)
        a.lastChange = 0
      } else if (fps > 58 && wantUp) {
        a.dpr = Math.min(1.1, a.dpr + 0.05)
        gl.setPixelRatio(a.dpr)
        a.lastChange = 0
      }
    }
  }, 6)
  return null
}
