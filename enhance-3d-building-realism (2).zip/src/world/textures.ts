import * as THREE from 'three'

import wallPlasterUrl from '../assets/textures/wall_plaster.jpg'
import wallGreenUrl from '../assets/textures/wall_green.jpg'
import floorWoodUrl from '../assets/textures/floor_wood.jpg'
import floorConcreteUrl from '../assets/textures/floor_concrete.jpg'
import ceilingUrl from '../assets/textures/ceiling_stained.jpg'
import brickUrl from '../assets/textures/brick.jpg'
import rustUrl from '../assets/textures/metal_rust.jpg'
import graffitiBubbleUrl from '../assets/textures/graffiti_bubble.png'
import graffitiTagsUrl from '../assets/textures/graffiti_tags.png'

export interface TexPair {
  map: THREE.Texture
  normal: THREE.Texture
}

export interface WorldTextures {
  wallPale: TexPair
  wallPlaster: TexPair
  wallStripe: TexPair
  tile: TexPair
  concrete: TexPair
  concreteFloor: TexPair
  brickWhite: TexPair
  metal: TexPair
  corrugated: TexPair
  rust: TexPair
  wood: TexPair
  ceiling: TexPair
  ground: TexPair
  graffitiBubble: THREE.Texture
  graffitiTags: THREE.Texture
  stain: THREE.Texture
  streak: THREE.Texture
  particle: THREE.Texture
  noise: THREE.Texture
  lensDirt: THREE.Texture
}

type ImgSource = HTMLImageElement | HTMLCanvasElement

function loadImage(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.crossOrigin = 'anonymous'
    img.onload = () => resolve(img)
    img.onerror = () => resolve(null)
    img.src = url
  })
}

function canvasOf(w: number, h: number) {
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  return c
}

/** Draw source into a square canvas of given size */
function toCanvas(src: ImgSource, size: number) {
  const c = canvasOf(size, size)
  c.getContext('2d')!.drawImage(src, 0, 0, size, size)
  return c
}

/** Remove large scale brightness gradients so tiles don't show a visible repeating pattern */
function highPass(src: ImgSource, size: number, strength = 0.75): HTMLCanvasElement {
  const base = toCanvas(src, size)
  const ctx = base.getContext('2d')!
  const img = ctx.getImageData(0, 0, size, size)
  const d = img.data
  // low frequency version via downscale + blur + upscale
  const small = canvasOf(32, 32)
  const sctx = small.getContext('2d')!
  sctx.filter = 'blur(6px)'
  sctx.drawImage(base, 0, 0, 32, 32)
  sctx.filter = 'none'
  const big = canvasOf(size, size)
  const bctx = big.getContext('2d')!
  bctx.imageSmoothingEnabled = true
  bctx.drawImage(small, 0, 0, size, size)
  const low = bctx.getImageData(0, 0, size, size).data
  let mr = 0,
    mg = 0,
    mb = 0
  const n = size * size
  for (let i = 0; i < n; i++) {
    mr += low[i * 4]
    mg += low[i * 4 + 1]
    mb += low[i * 4 + 2]
  }
  mr /= n
  mg /= n
  mb /= n
  for (let i = 0; i < n; i++) {
    const o = i * 4
    d[o] = Math.max(0, Math.min(255, d[o] + (mr - low[o]) * strength))
    d[o + 1] = Math.max(0, Math.min(255, d[o + 1] + (mg - low[o + 1]) * strength))
    d[o + 2] = Math.max(0, Math.min(255, d[o + 2] + (mb - low[o + 2]) * strength))
  }
  ctx.putImageData(img, 0, 0)
  return base
}

/** Make an arbitrary image tileable by blending 4 half-offset copies with tent weights */
function makeSeamless(src: ImgSource, size: number): HTMLCanvasElement {
  const base = toCanvas(src, size)
  const sd = base.getContext('2d')!.getImageData(0, 0, size, size).data
  const out = canvasOf(size, size)
  const octx = out.getContext('2d')!
  const od = octx.createImageData(size, size)
  const o = od.data
  const half = size / 2
  const tent = (v: number) => {
    const t = 1 - Math.abs(v - half) / half // 1 at centre, 0 at edges
    return t * t * (3 - 2 * t)
  }
  for (let y = 0; y < size; y++) {
    const ty = tent(y)
    const y2 = (y + half) % size
    for (let x = 0; x < size; x++) {
      const tx = tent(x)
      const x2 = (x + half) % size
      const w00 = tx * ty
      const w10 = (1 - tx) * ty
      const w01 = tx * (1 - ty)
      const w11 = (1 - tx) * (1 - ty)
      const i00 = (y * size + x) * 4
      const i10 = (y * size + x2) * 4
      const i01 = (y2 * size + x) * 4
      const i11 = (y2 * size + x2) * 4
      const oi = i00
      for (let c = 0; c < 3; c++) {
        o[oi + c] = sd[i00 + c] * w00 + sd[i10 + c] * w10 + sd[i01 + c] * w01 + sd[i11 + c] * w11
      }
      o[oi + 3] = 255
    }
  }
  octx.putImageData(od, 0, 0)
  return out
}

/** Derive a tangent space normal map from the luminance of an image (sobel) */
function makeNormalMap(src: ImgSource, size: number, strength: number): HTMLCanvasElement {
  const c = toCanvas(src, size)
  const ctx = c.getContext('2d')!
  const d = ctx.getImageData(0, 0, size, size).data
  const h = new Float32Array(size * size)
  for (let i = 0; i < size * size; i++) {
    h[i] = (d[i * 4] * 0.299 + d[i * 4 + 1] * 0.587 + d[i * 4 + 2] * 0.114) / 255
  }
  // light blur to reduce jpeg noise
  const hb = new Float32Array(size * size)
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let s = 0
      for (let oy = -1; oy <= 1; oy++) {
        const yy = (y + oy + size) % size
        for (let ox = -1; ox <= 1; ox++) {
          const xx = (x + ox + size) % size
          s += h[yy * size + xx]
        }
      }
      hb[y * size + x] = s / 9
    }
  }
  const out = ctx.createImageData(size, size)
  const o = out.data
  const H = (x: number, y: number) => hb[((y + size) % size) * size + ((x + size) % size)]
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx =
        H(x + 1, y - 1) + 2 * H(x + 1, y) + H(x + 1, y + 1) - (H(x - 1, y - 1) + 2 * H(x - 1, y) + H(x - 1, y + 1))
      const dy =
        H(x - 1, y + 1) + 2 * H(x, y + 1) + H(x + 1, y + 1) - (H(x - 1, y - 1) + 2 * H(x, y - 1) + H(x + 1, y - 1))
      let nx = -dx * strength
      let ny = dy * strength
      let nz = 1
      const l = Math.sqrt(nx * nx + ny * ny + nz * nz)
      nx /= l
      ny /= l
      nz /= l
      const i = (y * size + x) * 4
      o[i] = (nx * 0.5 + 0.5) * 255
      o[i + 1] = (ny * 0.5 + 0.5) * 255
      o[i + 2] = (nz * 0.5 + 0.5) * 255
      o[i + 3] = 255
    }
  }
  ctx.putImageData(out, 0, 0)
  return c
}

/** Convert graffiti painted on white into an RGBA decal (white -> transparent) */
function whiteToAlpha(src: HTMLImageElement): HTMLCanvasElement {
  const w = src.naturalWidth
  const h = src.naturalHeight
  const c = canvasOf(w, h)
  const ctx = c.getContext('2d')!
  ctx.drawImage(src, 0, 0)
  const img = ctx.getImageData(0, 0, w, h)
  const d = img.data
  for (let i = 0; i < w * h; i++) {
    const o = i * 4
    const r = d[o],
      g = d[o + 1],
      b = d[o + 2]
    const mn = Math.min(r, g, b)
    let a = 1 - mn / 255
    a = Math.min(1, Math.max(0, (a - 0.06) / 0.94))
    if (a <= 0.001) {
      d[o + 3] = 0
      continue
    }
    // un-matte from white
    d[o] = Math.max(0, Math.min(255, (r - (1 - a) * 255) / a))
    d[o + 1] = Math.max(0, Math.min(255, (g - (1 - a) * 255) / a))
    d[o + 2] = Math.max(0, Math.min(255, (b - (1 - a) * 255) / a))
    d[o + 3] = a * 255
  }
  ctx.putImageData(img, 0, 0)
  return c
}

// ---------- procedural canvases ----------

function valueNoise(size: number, seed = 1) {
  // multi octave value noise in [0,1]
  const rnd = mulberry(seed)
  const octaves = [4, 8, 16, 32, 64]
  const grids = octaves.map((n) => {
    const g = new Float32Array(n * n)
    for (let i = 0; i < n * n; i++) g[i] = rnd()
    return { n, g }
  })
  const out = new Float32Array(size * size)
  const smooth = (t: number) => t * t * (3 - 2 * t)
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let v = 0
      let amp = 1
      let tot = 0
      for (const { n, g } of grids) {
        const fx = (x / size) * n
        const fy = (y / size) * n
        const x0 = Math.floor(fx),
          y0 = Math.floor(fy)
        const tx = smooth(fx - x0),
          ty = smooth(fy - y0)
        const x1 = (x0 + 1) % n,
          y1 = (y0 + 1) % n
        const a = g[y0 * n + x0],
          b = g[y0 * n + x1],
          c = g[y1 * n + x0],
          d = g[y1 * n + x1]
        const vv = (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty
        v += vv * amp
        tot += amp
        amp *= 0.55
      }
      out[y * size + x] = v / tot
    }
  }
  return out
}

function mulberry(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function makeGround(size = 512): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const d = img.data
  const n1 = valueNoise(size, 11)
  const n2 = valueNoise(size, 23)
  for (let i = 0; i < size * size; i++) {
    const a = n1[i]
    const b = n2[i]
    // dirt base, patches of dead grass, gravel
    let r = 98 + a * 60 - b * 20
    let g = 86 + a * 52 - b * 10
    let bl = 70 + a * 38 - b * 18
    if (b > 0.58) {
      const k = (b - 0.58) * 3
      r = r * (1 - k) + 110 * k
      g = g * (1 - k) + 105 * k
      bl = bl * (1 - k) + 60 * k
    }
    const grain = (mulberryHash(i) - 0.5) * 22
    d[i * 4] = r + grain
    d[i * 4 + 1] = g + grain
    d[i * 4 + 2] = bl + grain
    d[i * 4 + 3] = 255
  }
  ctx.putImageData(img, 0, 0)
  return c
}

function mulberryHash(i: number) {
  let t = (i + 0x6d2b79f5) | 0
  t = Math.imul(t ^ (t >>> 15), 1 | t)
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296
}

function makeNoiseTex(size = 256): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const n = valueNoise(size, 77)
  for (let i = 0; i < size * size; i++) {
    const v = n[i] * 255
    img.data[i * 4] = v
    img.data[i * 4 + 1] = v
    img.data[i * 4 + 2] = v
    img.data[i * 4 + 3] = 255
  }
  ctx.putImageData(img, 0, 0)
  return c
}

function makeStain(size = 256): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const n = valueNoise(size, 5)
  const d = img.data
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x
      const dx = (x / size - 0.5) * 2
      const dy = (y / size - 0.5) * 2
      const r = Math.sqrt(dx * dx + dy * dy)
      const edge = 0.55 + (n[i] - 0.5) * 0.6
      let a = 1 - Math.min(1, Math.max(0, (r - edge + 0.25) / 0.35))
      a *= 0.55 + n[i] * 0.6
      d[i * 4] = 255
      d[i * 4 + 1] = 255
      d[i * 4 + 2] = 255
      d[i * 4 + 3] = Math.max(0, Math.min(255, a * 255))
    }
  }
  ctx.putImageData(img, 0, 0)
  return c
}

function makeStreak(size = 256): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const n = valueNoise(size, 9)
  const d = img.data
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x
      const col = n[Math.floor(y / 40) * size + x] // streaky columns
      const v = y / size
      let a = Math.pow(col, 2.2) * (1 - v) * (0.3 + 0.7 * Math.min(1, v * 6))
      const side = 1 - Math.pow(Math.abs(x / size - 0.5) * 2, 3)
      a *= side
      d[i * 4] = 255
      d[i * 4 + 1] = 255
      d[i * 4 + 2] = 255
      d[i * 4 + 3] = Math.max(0, Math.min(255, a * 255))
    }
  }
  ctx.putImageData(img, 0, 0)
  return c
}

function makeParticle(size = 64): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2)
  g.addColorStop(0, 'rgba(255,255,255,1)')
  g.addColorStop(0.3, 'rgba(255,255,255,0.6)')
  g.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, size, size)
  return c
}

function makeLensDirt(size = 512): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  ctx.fillStyle = '#000'
  ctx.fillRect(0, 0, size, size)
  const rnd = mulberry(321)
  // soft specks
  for (let i = 0; i < 140; i++) {
    const x = rnd() * size
    const y = rnd() * size
    const r = 1.5 + rnd() * rnd() * 9
    const a = 0.12 + rnd() * 0.5
    const g = ctx.createRadialGradient(x, y, 0, x, y, r)
    g.addColorStop(0, `rgba(255,255,255,${a})`)
    g.addColorStop(0.5, `rgba(255,255,255,${a * 0.5})`)
    g.addColorStop(1, 'rgba(255,255,255,0)')
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.arc(x, y, r, 0, Math.PI * 2)
    ctx.fill()
  }
  // smudges
  ctx.filter = 'blur(10px)'
  for (let i = 0; i < 7; i++) {
    ctx.save()
    ctx.translate(rnd() * size, rnd() * size)
    ctx.rotate(rnd() * Math.PI)
    ctx.fillStyle = `rgba(255,255,255,${0.05 + rnd() * 0.09})`
    ctx.beginPath()
    ctx.ellipse(0, 0, 30 + rnd() * 70, 8 + rnd() * 20, 0, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }
  ctx.filter = 'none'
  // fine scratches
  ctx.strokeStyle = 'rgba(255,255,255,0.18)'
  ctx.lineWidth = 1
  for (let i = 0; i < 6; i++) {
    ctx.beginPath()
    const x = rnd() * size
    const y = rnd() * size
    ctx.moveTo(x, y)
    ctx.lineTo(x + (rnd() - 0.5) * 160, y + (rnd() - 0.5) * 160)
    ctx.stroke()
  }
  return c
}

/** Colour grading of a source image: crop, desaturate, levels. Used to turn dirty textures into pale clean ones */
interface ProcOpts {
  crop?: [number, number, number, number] // x0,y0,x1,y1 fractions
  desaturate?: number
  gain?: number
  lift?: number
  contrast?: number
  tint?: [number, number, number]
}
function processTexture(src: ImgSource, size: number, o: ProcOpts): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const sw = src instanceof HTMLImageElement ? src.naturalWidth : src.width
  const sh = src instanceof HTMLImageElement ? src.naturalHeight : src.height
  const cr = o.crop ?? [0, 0, 1, 1]
  ctx.drawImage(src, cr[0] * sw, cr[1] * sh, (cr[2] - cr[0]) * sw, (cr[3] - cr[1]) * sh, 0, 0, size, size)
  const img = ctx.getImageData(0, 0, size, size)
  const d = img.data
  const des = o.desaturate ?? 0
  const gain = o.gain ?? 1
  const lift = o.lift ?? 0
  const con = o.contrast ?? 1
  const tint = o.tint ?? [1, 1, 1]
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], g = d[i + 1], b = d[i + 2]
    const lum = 0.299 * r + 0.587 * g + 0.114 * b
    for (let k = 0; k < 3; k++) {
      let v = d[i + k]
      v = lum + (v - lum) * (1 - des)
      v = ((v / 255 - 0.5) * con + 0.5) * gain + lift
      v *= tint[k]
      d[i + k] = Math.max(0, Math.min(255, v * 255))
    }
  }
  ctx.putImageData(img, 0, 0)
  return c
}

function makeMetalPaint(size = 512): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const n1 = valueNoise(size, 101)
  const n2 = valueNoise(size, 202)
  const d = img.data
  for (let i = 0; i < size * size; i++) {
    let v = 150 + (n1[i] - 0.5) * 50 + (n2[i] - 0.5) * 20
    const grain = (mulberryHash(i * 7) - 0.5) * 18
    v += grain
    // rust / dirt patches where n2 is high
    const rustK = Math.max(0, n2[i] - 0.66) * 3
    d[i * 4] = v + rustK * 40
    d[i * 4 + 1] = v - rustK * 20
    d[i * 4 + 2] = v - rustK * 60
    d[i * 4 + 3] = 255
  }
  ctx.putImageData(img, 0, 0)
  // scratches
  ctx.strokeStyle = 'rgba(230,230,230,0.35)'
  ctx.lineWidth = 1
  const rnd = mulberry(77)
  for (let i = 0; i < 40; i++) {
    ctx.beginPath()
    const x = rnd() * size, y = rnd() * size
    ctx.moveTo(x, y)
    ctx.lineTo(x + (rnd() - 0.5) * 120, y + (rnd() - 0.5) * 30)
    ctx.stroke()
  }
  ctx.strokeStyle = 'rgba(40,40,40,0.3)'
  for (let i = 0; i < 25; i++) {
    ctx.beginPath()
    const x = rnd() * size, y = rnd() * size
    ctx.moveTo(x, y)
    ctx.lineTo(x + (rnd() - 0.5) * 90, y + (rnd() - 0.5) * 90)
    ctx.stroke()
  }
  return c
}

function makeCorrugated(size = 512): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const n1 = valueNoise(size, 303)
  const d = img.data
  const ribs = 10
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x
      const ph = ((x / size) * ribs) % 1
      // trapezoid rib profile
      const rib = Math.min(1, Math.max(0, Math.abs(ph - 0.5) * 2 - 0.1) / 0.5)
      let v = 120 + rib * 70 + (n1[i] - 0.5) * 30
      // streaks of grime running down
      const col = n1[Math.floor(y / 64) * size + x]
      v -= Math.max(0, col - 0.6) * 60 * (y / size)
      const grain = (mulberryHash(i * 3) - 0.5) * 12
      v += grain
      d[i * 4] = v
      d[i * 4 + 1] = v
      d[i * 4 + 2] = v
      d[i * 4 + 3] = 255
    }
  }
  ctx.putImageData(img, 0, 0)
  return c
}

function makeTiles(size = 512): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  const img = ctx.createImageData(size, size)
  const d = img.data
  const n = valueNoise(size, 404)
  const tiles = 5
  const ts = size / tiles
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x
      const tx = Math.floor(x / ts)
      const ty = Math.floor(y / ts)
      const fx = (x % ts) / ts
      const fy = (y % ts) / ts
      let r: number, g: number, b: number
      if (fx < 0.04 || fy < 0.04) {
        r = g = b = 120 + (n[i] - 0.5) * 30
      } else {
        const checker = (tx + ty) % 2 === 0
        const base = checker ? [216, 210, 198] : [170, 164, 154]
        const k = 0.92 + (n[i] - 0.5) * 0.22 + (mulberryHash(i * 5) - 0.5) * 0.06
        r = base[0] * k
        g = base[1] * k
        b = base[2] * k
        const e = Math.min(fx, fy, 1 - fx, 1 - fy)
        if (e < 0.08) {
          const kk = 0.86 + (e / 0.08) * 0.14
          r *= kk
          g *= kk
          b *= kk
        }
      }
      d[i * 4] = r
      d[i * 4 + 1] = g
      d[i * 4 + 2] = b
      d[i * 4 + 3] = 255
    }
  }
  ctx.putImageData(img, 0, 0)
  return c
}

/** faded striped wallpaper laid over the (processed) plaster so the paper is worn away where the plaster is damaged */
function makeWallpaper(base: HTMLCanvasElement, size = 1024): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  ctx.drawImage(base, 0, 0, size, size)
  const img = ctx.getImageData(0, 0, size, size)
  const d = img.data
  const n = valueNoise(size, 505)
  const stripes = 14
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x
      const ph = ((x / size) * stripes) % 1
      const band = ph < 0.5
      const pin = Math.abs(ph - 0.5) < 0.02 || ph < 0.02
      const motif = Math.sin((x / size) * stripes * Math.PI) * Math.sin((y / size) * 28 * Math.PI)
      const r = d[i * 4]
      const g = d[i * 4 + 1]
      const b = d[i * 4 + 2]
      const lum = (r * 0.299 + g * 0.587 + b * 0.114) / 255
      const intact = Math.min(1, Math.max(0, (lum - 0.45) / 0.3)) * (0.5 + 0.5 * n[i])
      let kr = 1
      let kg = 1
      let kb = 1
      if (band) {
        kr *= 0.955
        kg *= 0.935
        kb *= 0.9
      }
      if (pin) {
        kr *= 0.9
        kg *= 0.88
        kb *= 0.85
      }
      if (!band && motif > 0.75) {
        kr *= 0.93
        kg *= 0.9
        kb *= 0.86
      }
      d[i * 4] = r * (1 - intact + intact * kr)
      d[i * 4 + 1] = g * (1 - intact + intact * kg)
      d[i * 4 + 2] = b * (1 - intact + intact * kb)
    }
  }
  ctx.putImageData(img, 0, 0)
  return c
}

function fallbackTile(color: string, size = 256): HTMLCanvasElement {
  const c = canvasOf(size, size)
  const ctx = c.getContext('2d')!
  ctx.fillStyle = color
  ctx.fillRect(0, 0, size, size)
  const n = valueNoise(size, 3)
  const img = ctx.getImageData(0, 0, size, size)
  for (let i = 0; i < size * size; i++) {
    const k = 0.7 + n[i] * 0.6
    img.data[i * 4] *= k
    img.data[i * 4 + 1] *= k
    img.data[i * 4 + 2] *= k
  }
  ctx.putImageData(img, 0, 0)
  return c
}

// ---------- texture builders ----------

interface TileOpts {
  seamless?: boolean
  highpass?: number
  normalStrength?: number
  mirror?: boolean
  size?: number
  anisotropy?: number
  wrapT?: THREE.Wrapping
}

function tex(src: ImgSource, srgb: boolean, wrapS: THREE.Wrapping, wrapT: THREE.Wrapping, anisotropy: number) {
  const t = new THREE.CanvasTexture(src as HTMLCanvasElement)
  t.wrapS = wrapS
  t.wrapT = wrapT
  t.anisotropy = anisotropy
  if (srgb) t.colorSpace = THREE.SRGBColorSpace
  t.generateMipmaps = true
  t.minFilter = THREE.LinearMipmapLinearFilter
  t.needsUpdate = true
  return t
}

function buildPair(src: ImgSource, o: TileOpts, anisotropy: number): TexPair {
  const size = o.size ?? 1024
  let img: ImgSource = src
  if (o.highpass) img = highPass(img, size, o.highpass)
  if (o.seamless) img = makeSeamless(img, size)
  else if (img instanceof HTMLImageElement) img = toCanvas(img, size)
  const wrapS = o.mirror ? THREE.MirroredRepeatWrapping : THREE.RepeatWrapping
  const wrapT = o.wrapT ?? wrapS
  const normalCanvas = makeNormalMap(img, 512, o.normalStrength ?? 1.5)
  return {
    map: tex(img, true, wrapS, wrapT, anisotropy),
    normal: tex(normalCanvas, false, wrapS, wrapT, anisotropy),
  }
}

export async function loadWorldTextures(onProgress?: (p: number) => void): Promise<WorldTextures> {
  const urls = [
    wallPlasterUrl,
    wallGreenUrl,
    floorWoodUrl,
    floorConcreteUrl,
    ceilingUrl,
    brickUrl,
    rustUrl,
    graffitiBubbleUrl,
    graffitiTagsUrl,
  ]
  let done = 0
  const imgs = await Promise.all(
    urls.map(async (u) => {
      const img = await loadImage(u)
      done++
      onProgress?.((done / urls.length) * 0.5)
      return img
    }),
  )
  const [plasterI, greenI, woodI, concreteI, ceilingI, brickI, rustI, bubbleI, tagsI] = imgs
  const aniso = 8
  const step = (p: number) => onProgress?.(0.5 + p * 0.5)
  // yield to the browser between heavy steps so the loading screen can paint
  const next = () => new Promise((r) => setTimeout(r, 0))

  // pale peeling paint (main hall walls) – from the green peeling texture, desaturated & lifted
  const wallPale = buildPair(
    processTexture(greenI ?? fallbackTile('#c8ccc4'), 1024, { desaturate: 0.82, gain: 1.22, lift: 0.1, contrast: 0.8 }),
    { seamless: true, normalStrength: 1.5 },
    aniso,
  )
  step(0.1)
  await next()
  // off-white plaster (offices / stairwell) – clean upper part of the plaster texture
  const wallPlaster = buildPair(
    processTexture(plasterI ?? fallbackTile('#d8d2c4'), 1024, { crop: [0, 0, 1, 0.58], desaturate: 0.55, gain: 1.12, lift: 0.08, contrast: 0.85 }),
    { seamless: true, normalStrength: 1.3 },
    aniso,
  )
  const wallStripe = buildPair(
    makeWallpaper(processTexture(plasterI ?? fallbackTile('#d8d2c4'), 1024, { crop: [0, 0, 1, 0.58], desaturate: 0.6, gain: 1.1, lift: 0.1, contrast: 0.8 }), 1024),
    { seamless: true, normalStrength: 1.1 },
    aniso,
  )
  const tile = buildPair(makeTiles(512), { normalStrength: 1.8, size: 512 }, aniso)
  step(0.2)
  await next()
  const concrete = buildPair(
    processTexture(concreteI ?? fallbackTile('#b9b6ae'), 1024, { desaturate: 0.25, gain: 1.08, lift: 0.04, contrast: 0.9 }),
    { seamless: true, highpass: 0.6, normalStrength: 1.5 },
    aniso,
  )
  step(0.3)
  await next()
  const concreteFloor = buildPair(
    processTexture(concreteI ?? fallbackTile('#cfccc4'), 1024, { desaturate: 0.35, gain: 1.18, lift: 0.1, contrast: 0.85 }),
    { seamless: true, highpass: 0.6, normalStrength: 1.4 },
    aniso,
  )
  step(0.4)
  await next()
  const brickWhite = buildPair(
    processTexture(brickI ?? fallbackTile('#d6d0c8'), 1024, { desaturate: 0.78, gain: 1.3, lift: 0.14, contrast: 0.75 }),
    { mirror: true, normalStrength: 2.2 },
    aniso,
  )
  step(0.5)
  await next()
  const wood = buildPair(woodI ?? fallbackTile('#8a7a66'), { mirror: true, normalStrength: 1.3, highpass: 0.4 }, aniso)
  step(0.6)
  await next()
  const ceiling = buildPair(
    processTexture(ceilingI ?? fallbackTile('#d8d2c6'), 1024, { desaturate: 0.4, gain: 1.08, lift: 0.07, contrast: 0.88 }),
    { seamless: true, highpass: 0.5, normalStrength: 1.0 },
    aniso,
  )
  step(0.7)
  await next()
  const rust = buildPair(rustI ?? fallbackTile('#6e4a32'), { mirror: true, normalStrength: 1.6, size: 512 }, aniso)
  step(0.8)
  await next()
  const metal = buildPair(makeMetalPaint(512), { normalStrength: 1.2, size: 512 }, aniso)
  const corrugated = buildPair(makeCorrugated(512), { normalStrength: 3.5, size: 512 }, aniso)
  const ground = buildPair(makeGround(512), { normalStrength: 2.0, size: 512 }, aniso)
  step(0.9)
  await next()

  const graffitiBubble = tex(
    bubbleI ? whiteToAlpha(bubbleI) : canvasOf(4, 4),
    true,
    THREE.ClampToEdgeWrapping,
    THREE.ClampToEdgeWrapping,
    aniso,
  )
  const graffitiTags = tex(
    tagsI ? whiteToAlpha(tagsI) : canvasOf(4, 4),
    true,
    THREE.ClampToEdgeWrapping,
    THREE.ClampToEdgeWrapping,
    aniso,
  )
  const stain = tex(makeStain(), false, THREE.ClampToEdgeWrapping, THREE.ClampToEdgeWrapping, 4)
  const streak = tex(makeStreak(), false, THREE.ClampToEdgeWrapping, THREE.ClampToEdgeWrapping, 4)
  const particle = tex(makeParticle(), false, THREE.ClampToEdgeWrapping, THREE.ClampToEdgeWrapping, 1)
  const noise = tex(makeNoiseTex(), false, THREE.RepeatWrapping, THREE.RepeatWrapping, 1)
  const lensDirt = tex(makeLensDirt(), false, THREE.ClampToEdgeWrapping, THREE.ClampToEdgeWrapping, 1)
  lensDirt.generateMipmaps = false
  lensDirt.minFilter = THREE.LinearFilter
  step(1)

  return {
    wallPale,
    wallPlaster,
    wallStripe,
    tile,
    concrete,
    concreteFloor,
    brickWhite,
    metal,
    corrugated,
    rust,
    wood,
    ceiling,
    ground,
    graffitiBubble,
    graffitiTags,
    stain,
    streak,
    particle,
    noise,
    lensDirt,
  }
}
