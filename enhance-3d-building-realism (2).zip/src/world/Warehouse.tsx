import * as THREE from 'three'
import { useMemo } from 'react'
import {
  WALLS,
  HX,
  HZ,
  EAVE,
  RIDGE,
  SLOPE,
  roofY,
  ROOF_PANELS,
  PANEL_W,
  PANEL_D,
  MEZZ,
  MEZZ_Y,
  MEZZ_T,
  CATWALK,
  COLUMNS,
  MEZZ_POSTS,
  RAMPS,
  type WallDef,
  type Ramp,
} from './layout'
import { useMaterials, wallGeometry, floorGeometry, splitLidGroups } from './materials'

type V3 = [number, number, number]

// ---------------------------------------------------------------------------
function Wall({ w }: { w: WallDef }) {
  const m = useMaterials()
  const geo = useMemo(() => wallGeometry(w.u0, w.len, w.h, w.t, w.openings), [w])
  const mats = useMemo(() => {
    const neg = m.byKey(w.matNeg)
    const pos = m.byKey(w.matPos)
    return w.axis === 'x' ? [neg, m.reveal, pos] : [pos, m.reveal, neg]
  }, [m, w])
  const pos: V3 = w.axis === 'x' ? [w.x, w.y, w.z - w.t / 2] : [w.x + w.t / 2, w.y, w.z]
  const rotY = w.axis === 'x' ? 0 : -Math.PI / 2
  return <mesh geometry={geo} material={mats} position={pos} rotation={[0, rotY, 0]} castShadow receiveShadow />
}

function GableWalls() {
  const m = useMaterials()
  const geo = useMemo(() => {
    const s = new THREE.Shape()
    s.moveTo(-HZ - 0.2, EAVE - 0.01)
    s.lineTo(HZ + 0.2, EAVE - 0.01)
    s.lineTo(0, RIDGE + 0.02)
    s.closePath()
    const g = new THREE.ExtrudeGeometry(s, { depth: 0.4, bevelEnabled: false, steps: 1 })
    splitLidGroups(g)
    g.computeVertexNormals()
    return g
  }, [])
  return (
    <group>
      {/* local z -> world -x after the -90deg yaw; group 0 = lid at local z=0 */}
      <mesh geometry={geo} material={[m.brickWhite, m.reveal, m.wallPale]} position={[HX + 0.2, 0, 0]} rotation={[0, -Math.PI / 2, 0]} castShadow receiveShadow />
      <mesh geometry={geo} material={[m.wallPale, m.reveal, m.brickWhite]} position={[-HX + 0.2, 0, 0]} rotation={[0, -Math.PI / 2, 0]} castShadow receiveShadow />
    </group>
  )
}

// ---------------------------------------------------------------------------
function hash(n: number) {
  const x = Math.sin(n * 12.9898) * 43758.5453
  return x - Math.floor(x)
}

// ---------------------------------------------------------------------------
const unitBox = new THREE.BoxGeometry(1, 1, 1)

function memberMatrix(a: THREE.Vector3, b: THREE.Vector3, tx: number, ty: number, out: THREE.Matrix4) {
  const dir = b.clone().sub(a)
  const len = dir.length()
  dir.normalize()
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir)
  const mid = a.clone().add(b).multiplyScalar(0.5)
  out.compose(mid, q, new THREE.Vector3(tx, ty, len))
  return out
}

function makeInstanced(mats: THREE.Matrix4[], material: THREE.Material, castShadow = true) {
  const mesh = new THREE.InstancedMesh(unitBox, material, Math.max(1, mats.length))
  mats.forEach((mm, i) => mesh.setMatrixAt(i, mm))
  mesh.count = mats.length
  mesh.instanceMatrix.needsUpdate = true
  mesh.castShadow = castShadow
  mesh.receiveShadow = true
  mesh.frustumCulled = false
  return mesh
}

function RoofStructure() {
  const m = useMaterials()
  const meshes = useMemo(() => {
    const members: THREE.Matrix4[] = []
    const V = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z)
    const trussX = [-19.5, -12, -4, 4, 12, 19.5]
    const bottomY = 7.9
    for (const tx of trussX) {
      for (let k = 0; k < 8; k++) {
        const za = -HZ + k * 3
        const zb = za + 3
        // top chord
        members.push(memberMatrix(V(tx, roofY(za) - 0.2, za), V(tx, roofY(zb) - 0.2, zb), 0.12, 0.12, new THREE.Matrix4()))
        // bottom chord
        members.push(memberMatrix(V(tx, bottomY, za), V(tx, bottomY, zb), 0.12, 0.12, new THREE.Matrix4()))
        // vertical
        members.push(memberMatrix(V(tx, bottomY, za), V(tx, roofY(za) - 0.2, za), 0.08, 0.08, new THREE.Matrix4()))
        // diagonal (toward the ridge)
        if (za < 0) members.push(memberMatrix(V(tx, bottomY, za), V(tx, roofY(zb) - 0.2, zb), 0.07, 0.07, new THREE.Matrix4()))
        else members.push(memberMatrix(V(tx, bottomY, zb), V(tx, roofY(za) - 0.2, za), 0.07, 0.07, new THREE.Matrix4()))
      }
      members.push(memberMatrix(V(tx, bottomY, HZ), V(tx, roofY(HZ) - 0.2, HZ), 0.08, 0.08, new THREE.Matrix4()))
    }
    // purlins along x
    for (let j = 0; j <= 8; j++) {
      const z = -HZ + j * 3
      members.push(memberMatrix(V(-HX, roofY(z) - 0.09, z), V(HX, roofY(z) - 0.09, z), 0.12, 0.16, new THREE.Matrix4()))
    }
    // ridge beam + eave beams
    members.push(memberMatrix(V(-HX, RIDGE - 0.2, 0), V(HX, RIDGE - 0.2, 0), 0.2, 0.25, new THREE.Matrix4()))
    members.push(memberMatrix(V(-HX, bottomY, -HZ + 0.25), V(HX, bottomY, -HZ + 0.25), 0.2, 0.3, new THREE.Matrix4()))
    members.push(memberMatrix(V(-HX, bottomY, HZ - 0.25), V(HX, bottomY, HZ - 0.25), 0.2, 0.3, new THREE.Matrix4()))
    // horizontal bracing between bottom chords
    for (let k = 0; k < 8; k += 2) {
      const za = -HZ + k * 3 + 1.5
      for (let t = 0; t < trussX.length - 1; t++) {
        members.push(memberMatrix(V(trussX[t], bottomY, za), V(trussX[t + 1], bottomY, za), 0.06, 0.06, new THREE.Matrix4()))
      }
    }
    // crane rail beam across the hall
    members.push(memberMatrix(V(-HX + 0.3, 7.2, 1.5), V(HX - 0.3, 7.2, 1.5), 0.3, 0.4, new THREE.Matrix4()))

    // roof panels
    const panelOk: THREE.Matrix4[] = []
    const panelSky: THREE.Matrix4[] = []
    const frames: THREE.Matrix4[] = []
    const hanging: { pos: THREE.Vector3; rot: THREE.Euler; sky: boolean }[] = []
    const tilt = Math.atan(SLOPE)
    for (const p of ROOF_PANELS) {
      const cx = (p.x0 + p.x1) / 2
      const cz = (p.z0 + p.z1) / 2
      const rotX = cz < 0 ? -tilt : tilt
      const y = roofY(cz) + 0.03
      const mat = new THREE.Matrix4().compose(
        new THREE.Vector3(cx, y, cz),
        new THREE.Quaternion().setFromEuler(new THREE.Euler(rotX, 0, 0)),
        new THREE.Vector3(PANEL_W - 0.02, 0.04, PANEL_D / Math.cos(tilt) - 0.02),
      )
      if (p.state === 'ok') panelOk.push(mat)
      else if (p.state === 'skylight') panelSky.push(mat)
      if (p.state === 'skylight' || p.state === 'skylightMissing') {
        // frame around skylight panels
        frames.push(memberMatrix(new THREE.Vector3(p.x0, roofY(p.z0) + 0.02, p.z0), new THREE.Vector3(p.x0, roofY(p.z1) + 0.02, p.z1), 0.08, 0.1, new THREE.Matrix4()))
        frames.push(memberMatrix(new THREE.Vector3(p.x1, roofY(p.z0) + 0.02, p.z0), new THREE.Vector3(p.x1, roofY(p.z1) + 0.02, p.z1), 0.08, 0.1, new THREE.Matrix4()))
        frames.push(memberMatrix(new THREE.Vector3(p.x0, roofY(p.z0) + 0.02, p.z0), new THREE.Vector3(p.x1, roofY(p.z0) + 0.02, p.z0), 0.08, 0.1, new THREE.Matrix4()))
        frames.push(memberMatrix(new THREE.Vector3(p.x0, roofY(p.z1) + 0.02, p.z1), new THREE.Vector3(p.x1, roofY(p.z1) + 0.02, p.z1), 0.08, 0.1, new THREE.Matrix4()))
      }
      if (p.state === 'hanging') {
        const k = hash(p.i * 31 + p.j * 17)
        const fromNorth = k < 0.5
        const pivotZ = fromNorth ? p.z0 : p.z1
        const ang = (fromNorth ? 1 : -1) * (1.1 + k * 0.4)
        hanging.push({ pos: new THREE.Vector3(cx, roofY(pivotZ), pivotZ), rot: new THREE.Euler(ang, 0, (k - 0.5) * 0.3), sky: false })
      }
    }
    return {
      structure: makeInstanced(members, m.steel),
      panels: makeInstanced(panelOk, m.corrugated),
      sky: makeInstanced(panelSky, m.skylight, false),
      frames: makeInstanced(frames, m.steelDark),
      hanging,
    }
  }, [m])

  return (
    <group>
      <primitive object={meshes.structure} />
      <primitive object={meshes.panels} />
      <primitive object={meshes.sky} />
      <primitive object={meshes.frames} />
      {meshes.hanging.map((h, i) => (
        <group key={i} position={h.pos} rotation={h.rot}>
          <mesh position={[0, 0, PANEL_D / 2 - 0.1]} material={m.corrugated} castShadow receiveShadow>
            <boxGeometry args={[PANEL_W - 0.1, 0.04, PANEL_D - 0.2]} />
          </mesh>
          <mesh position={[PANEL_W * 0.3, -0.03, PANEL_D * 0.35]} rotation={[0, 0, 0.1]} material={m.steelDark} castShadow>
            <boxGeometry args={[0.08, 0.06, PANEL_D * 0.6]} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

// ---------------------------------------------------------------------------
function IBeamColumn({ x, z, h }: { x: number; z: number; h: number }) {
  const m = useMaterials()
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, h / 2, 0.21]} material={m.steel} castShadow receiveShadow>
        <boxGeometry args={[0.42, h, 0.04]} />
      </mesh>
      <mesh position={[0, h / 2, -0.21]} material={m.steel} castShadow receiveShadow>
        <boxGeometry args={[0.42, h, 0.04]} />
      </mesh>
      <mesh position={[0, h / 2, 0]} material={m.steel} castShadow receiveShadow>
        <boxGeometry args={[0.03, h, 0.4]} />
      </mesh>
      <mesh position={[0, 0.02, 0]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[0.6, 0.04, 0.6]} />
      </mesh>
      <mesh position={[0, 0.6, 0]} material={m.rust} receiveShadow>
        <boxGeometry args={[0.44, 1.2, 0.46]} />
      </mesh>
    </group>
  )
}

function Railing({ a, b, y, h = 1.1 }: { a: [number, number]; b: [number, number]; y: number; h?: number }) {
  const m = useMaterials()
  const dx = b[0] - a[0]
  const dz = b[1] - a[1]
  const L = Math.hypot(dx, dz)
  const rot = Math.atan2(-dz, dx)
  const n = Math.max(2, Math.ceil(L / 1.6) + 1)
  return (
    <group position={[(a[0] + b[0]) / 2, y, (a[1] + b[1]) / 2]} rotation={[0, rot, 0]}>
      <mesh position={[0, h, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[L, 0.05, 0.05]} />
      </mesh>
      <mesh position={[0, h * 0.55, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[L, 0.035, 0.035]} />
      </mesh>
      <mesh position={[0, 0.07, 0]} material={m.steelDark} castShadow>
        <boxGeometry args={[L, 0.14, 0.02]} />
      </mesh>
      {Array.from({ length: n }).map((_, i) => (
        <mesh key={i} position={[-L / 2 + (i / (n - 1)) * L, h / 2, 0]} material={m.steelDark} castShadow>
          <boxGeometry args={[0.05, h, 0.05]} />
        </mesh>
      ))}
    </group>
  )
}

function StairFlight({ r, kind, railWest, railEast }: { r: Ramp; kind: 'steel' | 'concrete'; railWest?: boolean; railEast?: boolean }) {
  const m = useMaterials()
  const width = r.xMax - r.xMin
  const xMid = (r.xMin + r.xMax) / 2
  const rise = r.h1 - r.h0
  const run = Math.abs(r.z1 - r.z0)
  const dirZ = Math.sign(r.z1 - r.z0)
  const n = Math.round(rise / 0.18)
  const td = run / n
  const rh = rise / n
  const L = Math.hypot(run, rise)
  const slopeRot = Math.atan2(-rise, dirZ * run)
  const zMid = (r.z0 + r.z1) / 2
  const yMid = (r.h0 + r.h1) / 2
  const steps = useMemo(() => {
    const arr: { y: number; z: number }[] = []
    for (let k = 0; k < n; k++) arr.push({ y: r.h0 + (k + 1) * rh, z: r.z0 + dirZ * (k + 0.5) * td })
    return arr
  }, [n, r, rh, td, dirZ])
  const treadMesh = useMemo(() => {
    const mats = steps.map((s) =>
      new THREE.Matrix4().compose(
        new THREE.Vector3(xMid, kind === 'steel' ? s.y - 0.025 : s.y - rh / 2, s.z),
        new THREE.Quaternion(),
        new THREE.Vector3(width, kind === 'steel' ? 0.05 : rh + 0.01, td + 0.03),
      ),
    )
    return makeInstanced(mats, kind === 'steel' ? m.steelDark : m.concrete)
  }, [steps, xMid, width, td, rh, kind, m])
  const posts = useMemo(() => steps.filter((_, i) => i % 3 === 0), [steps])
  const rails = [railWest ? r.xMin + 0.03 : null, railEast ? r.xMax - 0.03 : null].filter((v): v is number => v !== null)
  return (
    <group>
      <primitive object={treadMesh} />
      {kind === 'steel' ? (
        <>
          <mesh position={[r.xMin + 0.04, yMid - 0.12, zMid]} rotation={[slopeRot, 0, 0]} material={m.steelDark} castShadow receiveShadow>
            <boxGeometry args={[0.06, 0.3, L + 0.2]} />
          </mesh>
          <mesh position={[r.xMax - 0.04, yMid - 0.12, zMid]} rotation={[slopeRot, 0, 0]} material={m.steelDark} castShadow receiveShadow>
            <boxGeometry args={[0.06, 0.3, L + 0.2]} />
          </mesh>
        </>
      ) : (
        <mesh position={[xMid, yMid - rh - 0.1, zMid]} rotation={[slopeRot, 0, 0]} material={m.concrete} castShadow receiveShadow>
          <boxGeometry args={[width, 0.18, L]} />
        </mesh>
      )}
      {rails.map((rx) => (
        <group key={rx}>
          <mesh position={[rx, yMid + 1.0, zMid]} rotation={[slopeRot, 0, 0]} material={m.steelDark} castShadow>
            <boxGeometry args={[0.05, 0.05, L + 0.4]} />
          </mesh>
          <mesh position={[rx, yMid + 0.55, zMid]} rotation={[slopeRot, 0, 0]} material={m.steelDark} castShadow>
            <boxGeometry args={[0.035, 0.035, L + 0.4]} />
          </mesh>
          {posts.map((p, i) => (
            <mesh key={i} position={[rx, p.y + 0.5, p.z]} material={m.steelDark} castShadow>
              <boxGeometry args={[0.045, 1.0, 0.045]} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  )
}

function Mezzanine() {
  const m = useMaterials()
  const Y = MEZZ_Y
  const deckW = MEZZ.xMax - MEZZ.xMin
  const deckD = MEZZ.zMax - MEZZ.zMin
  const cwW = CATWALK.xMax - CATWALK.xMin
  const cwD = CATWALK.zMax - CATWALK.zMin
  return (
    <group>
      {/* decks */}
      <mesh position={[(MEZZ.xMin + MEZZ.xMax) / 2, Y - MEZZ_T / 2, (MEZZ.zMin + MEZZ.zMax) / 2]} material={m.deck} castShadow receiveShadow>
        <boxGeometry args={[deckW, MEZZ_T, deckD]} />
      </mesh>
      <mesh position={[(CATWALK.xMin + CATWALK.xMax) / 2, Y - MEZZ_T / 2, (CATWALK.zMin + CATWALK.zMax) / 2]} material={m.deck} castShadow receiveShadow>
        <boxGeometry args={[cwW, MEZZ_T, cwD]} />
      </mesh>
      {/* edge channels */}
      <mesh position={[0, Y - 0.17, MEZZ.zMax - 0.04]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[deckW, 0.34, 0.1]} />
      </mesh>
      <mesh position={[CATWALK.xMin + 0.04, Y - 0.17, (CATWALK.zMin + CATWALK.zMax) / 2]} material={m.steelDark} castShadow receiveShadow>
        <boxGeometry args={[0.1, 0.34, cwD]} />
      </mesh>
      {/* support posts */}
      {MEZZ_POSTS.map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <mesh position={[0, Y / 2, 0]} material={m.steel} castShadow receiveShadow>
            <boxGeometry args={[0.26, Y, 0.26]} />
          </mesh>
          <mesh position={[0, 0.02, 0]} material={m.steelDark} receiveShadow>
            <boxGeometry args={[0.5, 0.04, 0.5]} />
          </mesh>
        </group>
      ))}
      {/* beams under the deck front */}
      <mesh position={[0, Y - MEZZ_T - 0.15, MEZZ.zMax - 0.2]} material={m.steel} castShadow receiveShadow>
        <boxGeometry args={[deckW, 0.3, 0.2]} />
      </mesh>
      {/* railings */}
      <Railing a={[-18.4, MEZZ.zMax]} b={[CATWALK.xMin, MEZZ.zMax]} y={Y} />
      <Railing a={[CATWALK.xMin, MEZZ.zMax]} b={[CATWALK.xMin, CATWALK.zMax]} y={Y} />
      <Railing a={[16.6, 5.2]} b={[18.6, 5.2]} y={Y} />
      <Railing a={[16.6, 4.4]} b={[16.6, 5.2]} y={Y} />
      <Railing a={[17.1, 10.4]} b={[18.6, 10.4]} y={2} />
      <Railing a={[15.4, 10.4]} b={[15.4, 11.8]} y={2} />
      {/* landings */}
      <mesh position={[17.6, 2 - 0.1, 11.1]} material={m.concrete} castShadow receiveShadow>
        <boxGeometry args={[4.4, 0.2, 1.4]} />
      </mesh>
      <mesh position={[18.2, Y - 0.1, 4.8]} material={m.concrete} castShadow receiveShadow>
        <boxGeometry args={[3.2, 0.2, 0.8]} />
      </mesh>
      {/* stairs */}
      <StairFlight r={RAMPS[0]} kind="steel" railEast />
      <StairFlight r={RAMPS[1]} kind="concrete" railWest railEast />
      <StairFlight r={RAMPS[2]} kind="concrete" railWest />
    </group>
  )
}

// ---------------------------------------------------------------------------
export function Warehouse() {
  const m = useMaterials()
  const floor = useMemo(() => floorGeometry(HX * 2, HZ * 2, 0, 0), [])
  return (
    <group>
      {WALLS.map((w) => (
        <Wall key={w.id} w={w} />
      ))}
      <GableWalls />
      <mesh geometry={floor} material={m.concreteFloor} receiveShadow />
      <RoofStructure />
      {COLUMNS.map(([x, z], i) => (
        <IBeamColumn key={i} x={x} z={z} h={7.9} />
      ))}
      <Mezzanine />
    </group>
  )
}
