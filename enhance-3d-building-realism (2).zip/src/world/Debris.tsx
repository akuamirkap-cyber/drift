import * as THREE from 'three'
import { useMemo } from 'react'
import { useMaterials } from './materials'
import { ROOMS, WALLS, type Room } from './layout'

function mulberry(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

interface Inst {
  p: THREE.Vector3
  r: THREE.Euler
  s: THREE.Vector3
}

function makeInstanced(geo: THREE.BufferGeometry, mat: THREE.Material, list: Inst[], shadows = true) {
  const mesh = new THREE.InstancedMesh(geo, mat, Math.max(1, list.length))
  const m4 = new THREE.Matrix4()
  const q = new THREE.Quaternion()
  list.forEach((it, i) => {
    q.setFromEuler(it.r)
    m4.compose(it.p, q, it.s)
    mesh.setMatrixAt(i, m4)
  })
  mesh.count = list.length
  mesh.instanceMatrix.needsUpdate = true
  mesh.castShadow = shadows
  mesh.receiveShadow = true
  mesh.frustumCulled = false
  return mesh
}


function randIn(rnd: () => number, r: Room) {
  return new THREE.Vector3(r.xMin + rnd() * (r.xMax - r.xMin), r.y, r.zMin + rnd() * (r.zMax - r.zMin))
}

// keep debris off stairs / inside containers
function blocked(p: THREE.Vector3) {
  if (p.x > -19.7 && p.x < -18.3 && p.z > -7.2 && p.z < -0.8 && p.y < 1) return true
  if (p.y < 1 && p.z > -10.9 && p.z < -8.2 && ((p.x > -1.1 && p.x < 5.1) || (p.x > 6.9 && p.x < 13.1))) return true
  if (p.y < 1 && p.x > 15.3 && p.x < 16.7 && p.z > 5.1 && p.z < 10.5) return true
  if (p.y < 1 && p.x > 18.5 && p.z > 5.1 && p.z < 10.5) return true
  if (p.x > -27.95 && p.x < -26.5 && p.z > -4.7 && p.z < 1.4) return true
  return false
}

export function Debris() {
  const m = useMaterials()
  const meshes = useMemo(() => {
    const rnd = mulberry(9001)
    const rubble: Inst[] = []
    const papers: Inst[] = []
    const planks: Inst[] = []
    const bricks: Inst[] = []
    const bottles: Inst[] = []
    const glass: Inst[] = []
    const plaster: Inst[] = []

    const mounds: Inst[] = []
    const scraps: Inst[] = []
    const blocks: Inst[] = []
    for (const room of ROOMS) {
      const area = (room.xMax - room.xMin) * (room.zMax - room.zMin)
      const d = room.density
      const nRubble = Math.round(area * 0.9 * d)
      for (let i = 0; i < nRubble; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        if (rnd() < 0.45) {
          const toWall = rnd() < 0.5
          if (toWall) p.x = rnd() < 0.5 ? room.xMin + rnd() * 0.6 : room.xMax - rnd() * 0.6
          else p.z = rnd() < 0.5 ? room.zMin + rnd() * 0.6 : room.zMax - rnd() * 0.6
        }
        const s = 0.04 + rnd() * rnd() * 0.24
        p.y += s * 0.35
        rubble.push({ p, r: new THREE.Euler(rnd() * 0.5, rnd() * Math.PI, rnd() * 0.5), s: new THREE.Vector3(s * (0.7 + rnd()), s * 0.6, s * (0.7 + rnd())) })
      }
      const nMounds = Math.round(area * 0.07 * d)
      for (let i = 0; i < nMounds; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        const s = 0.35 + rnd() * 0.9
        mounds.push({ p, r: new THREE.Euler(0, rnd() * Math.PI, 0), s: new THREE.Vector3(s, s * (0.16 + rnd() * 0.12), s * (0.6 + rnd() * 0.6)) })
      }
      const nPlaster = Math.round(area * 0.5 * d)
      for (let i = 0; i < nPlaster; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        const s = 0.12 + rnd() * 0.35
        p.y += 0.012
        plaster.push({ p, r: new THREE.Euler(0, rnd() * Math.PI, 0), s: new THREE.Vector3(s, 0.025, s * (0.5 + rnd())) })
      }
      const nPapers = Math.round(area * 0.3 * d)
      for (let i = 0; i < nPapers; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        p.y += 0.004 + rnd() * 0.01
        papers.push({ p, r: new THREE.Euler(-Math.PI / 2 + (rnd() - 0.5) * 0.15, 0, rnd() * Math.PI), s: new THREE.Vector3(0.8 + rnd() * 0.5, 0.8 + rnd() * 0.5, 1) })
      }
      const nPlanks = Math.round(area * 0.06 * d)
      for (let i = 0; i < nPlanks; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        p.y += 0.03
        planks.push({ p, r: new THREE.Euler(0, rnd() * Math.PI, (rnd() - 0.5) * 0.1), s: new THREE.Vector3(0.7 + rnd() * 1.3, 0.04, 0.09 + rnd() * 0.08) })
      }
      const nBlocks = Math.round(area * 0.08 * d)
      for (let i = 0; i < nBlocks; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        const tipped = rnd() < 0.35
        p.y += tipped ? 0.195 : 0.095
        blocks.push({ p, r: tipped ? new THREE.Euler(0, rnd() * Math.PI, Math.PI / 2) : new THREE.Euler(0, rnd() * Math.PI, 0), s: new THREE.Vector3(1, 1, 1) })
      }
      const nBricks = Math.round(area * 0.05 * d)
      for (let i = 0; i < nBricks; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        p.y += 0.035
        bricks.push({ p, r: new THREE.Euler(0, rnd() * Math.PI, rnd() < 0.2 ? 0.4 : 0), s: new THREE.Vector3(1, 1, 1) })
      }
      const nScraps = Math.round(area * 0.08 * d)
      for (let i = 0; i < nScraps; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        p.y += 0.02
        const long = rnd() < 0.5
        scraps.push({ p, r: new THREE.Euler(long ? 0 : 0.05, rnd() * Math.PI, 0), s: long ? new THREE.Vector3(1.2 + rnd() * 1.6, 0.05, 0.05) : new THREE.Vector3(0.4 + rnd() * 0.5, 0.02, 0.3 + rnd() * 0.4) })
      }
      const nBottles = Math.round(area * 0.04 * d)
      for (let i = 0; i < nBottles; i++) {
        const p = randIn(rnd, room)
        if (blocked(p)) continue
        const lying = rnd() < 0.7
        p.y += lying ? 0.035 : 0.12
        bottles.push({ p, r: lying ? new THREE.Euler(Math.PI / 2, 0, rnd() * Math.PI) : new THREE.Euler(0, 0, 0), s: new THREE.Vector3(1, 1, 1) })
      }
    }

    // extra rubble under every missing roof panel is handled by the general spread; add a pile at the collapsed west wall
    for (let i = 0; i < 40; i++) {
      const p = new THREE.Vector3(-19.2 + rnd() * 1.6, rnd() * 0.3, 0.6 + rnd() * 3.6)
      const s = 0.06 + rnd() * rnd() * 0.3
      rubble.push({ p, r: new THREE.Euler(rnd(), rnd() * Math.PI, rnd()), s: new THREE.Vector3(s * (0.7 + rnd()), s * 0.7, s * (0.7 + rnd())) })
      if (i % 4 === 0) blocks.push({ p: new THREE.Vector3(p.x, 0.1 + rnd() * 0.25, p.z), r: new THREE.Euler(rnd() * 0.6, rnd() * Math.PI, rnd() * 0.6), s: new THREE.Vector3(1, 1, 1) })
    }

    // broken glass below windows (inside)
    for (const w of WALLS) {
      if (!w.exterior) continue
      for (const o of w.openings) {
        if (o.kind !== 'window') continue
        for (let i = 0; i < 12; i++) {
          const along = o.at + (rnd() - 0.5) * (o.w + 1.0)
          const inward = 0.3 + rnd() * 2.2
          let p: THREE.Vector3
          if (w.axis === 'x') p = new THREE.Vector3(w.x + along, w.y + 0.004, w.z + (w.z > 0 ? -inward : inward))
          else p = new THREE.Vector3(w.x + (w.x > 0 ? -inward : inward), w.y + 0.004, w.z + along)
          if (w.id === 'N' && p.x > -16.2 && p.x < -3.8) continue // offices have a ceiling
          glass.push({ p, r: new THREE.Euler(-Math.PI / 2, 0, rnd() * Math.PI), s: new THREE.Vector3(0.5 + rnd(), 0.5 + rnd(), 1) })
        }
      }
    }

    const rubbleGeo = new THREE.DodecahedronGeometry(0.5, 0)
    const boxGeo = new THREE.BoxGeometry(1, 1, 1)
    const paperGeo = new THREE.PlaneGeometry(0.21, 0.3)
    const brickGeo = new THREE.BoxGeometry(0.21, 0.065, 0.1)
    const blockGeo = new THREE.BoxGeometry(0.39, 0.19, 0.19)
    const bottleGeo = new THREE.CylinderGeometry(0.03, 0.035, 0.26, 10)
    const glassGeo = new THREE.PlaneGeometry(0.07, 0.05)
    const moundGeo = new THREE.SphereGeometry(1, 12, 8)
    const bottleMat = new THREE.MeshStandardMaterial({ color: '#2f4f2a', roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.85 })
    return [
      makeInstanced(rubbleGeo, m.rubble, rubble),
      makeInstanced(moundGeo, m.dust, mounds),
      makeInstanced(boxGeo, m.rubble, plaster, false),
      makeInstanced(paperGeo, m.paper, papers, false),
      makeInstanced(boxGeo, m.woodDark, planks),
      makeInstanced(blockGeo, m.cinder, blocks),
      makeInstanced(brickGeo, m.brickChunk, bricks),
      makeInstanced(boxGeo, m.rust, scraps),
      makeInstanced(bottleGeo, bottleMat, bottles),
      makeInstanced(glassGeo, m.glass, glass, false),
    ]
  }, [m])

  return (
    <group>
      {meshes.map((mesh, i) => (
        <primitive key={i} object={mesh} />
      ))}
    </group>
  )
}
