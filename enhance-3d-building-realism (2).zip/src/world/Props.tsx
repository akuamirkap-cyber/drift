import * as THREE from 'three'
import { useMemo } from 'react'
import { useMaterials } from './materials'
import { MEZZ_Y, boxCollider, type AABB } from './layout'

type V3 = [number, number, number]
const Y = MEZZ_Y

// ---------------------------------------------------------------------------
export const PROP_COLLIDERS: AABB[] = [
  boxCollider(-6, 5.5, 2.5, 1.0, 0, 0.95), // workbench
  boxCollider(-3, 5.2, 2.5, 1.0, 0, 0.95), // workbench
  boxCollider(-16.5, 6.5, 1.1, 1.1, 0, 1.3), // ibc
  boxCollider(-16.5, 7.7, 1.1, 1.1, 0, 1.3),
  boxCollider(-15.3, 6.5, 1.1, 1.1, 0, 1.3),
  boxCollider(10, -3.5, 1.1, 1.1, 0, 1.3),
  boxCollider(11.5, 10.3, 1.8, 1.6, 0, 0.95), // drums A
  boxCollider(-8.5, -4.5, 1.5, 1.0, 0, 0.95), // drums B
  boxCollider(16.5, -5, 1.5, 1.0, 0, 0.95), // drums C
  boxCollider(-1, -11, 1.6, 0.8, 0, 0.95), // drums D
  boxCollider(0, 7.5, 3.3, 0.25, 0, 1.0), // block wall 1
  boxCollider(-9.5, 1.0, 0.25, 2.5, 0, 1.0), // block wall 2
  boxCollider(7, 3.5, 1.6, 1.4, 0, 0.6), // block pile
  boxCollider(3.5, -2.0, 2.0, 0.7, 0, 0.9), // barrier
  boxCollider(5.8, -2.6, 2.0, 0.7, 0, 0.9),
  boxCollider(-1.5, -5.5, 0.7, 2.0, 0, 0.9),
  boxCollider(6, 9.5, 1.3, 1.1, 0, 1.4), // pallet stack
  boxCollider(-3, 10, 1.3, 1.1, 0, 1.3), // pallets + crates
  boxCollider(13, 1.2, 1.05, 1.05, 0, 1.0), // crates
  boxCollider(12.2, 2.4, 0.75, 0.75, 0, 0.7),
  boxCollider(-13, 3, 1.4, 1.2, 0, 1.0),
  boxCollider(10, -9.55, 6.1, 2.65, 0, 2.6), // blue container
  boxCollider(2, -9.55, 6.1, 2.65, 0, 2.6), // red container
  boxCollider(19.5, -5.5, 0.6, 0.9, 0, 2.0), // cabinet E
  boxCollider(-19.5, 11.0, 0.6, 1.8, 0, 2.0), // cabinets W
  boxCollider(-11, -2.5, 2.6, 1.8, 0, 1.6), // forklift
  boxCollider(10.5, 10.5, 1.7, 1.7, 0, 0.9), // spool
  boxCollider(8.8, 10.8, 1.3, 1.3, 0, 0.7),
  boxCollider(-17.5, 10.5, 1.4, 1.4, 0, 0.9), // tyres
  boxCollider(16, -11.4, 2.1, 0.6, 0, 2.0), // shelving under deck
  boxCollider(15, -8.6, 1.3, 1.1, 0, 0.5), // pallet
  boxCollider(4, 6.6, 0.9, 0.6, 0, 1.1), // cable cabinet by column
  // offices
  boxCollider(-14, -10.5, 1.7, 0.85, 0, 0.8),
  boxCollider(-12.5, -11.4, 0.5, 0.65, 0, 1.4),
  boxCollider(-10, -10.5, 1.7, 0.85, 0, 0.8),
  boxCollider(-6, -11.4, 2.1, 0.6, 0, 2.0),
  // mezzanine
  boxCollider(-10, -10, 1.1, 1.1, Y, Y + 1.0),
  boxCollider(-9, -9, 0.75, 0.75, Y, Y + 0.7),
  boxCollider(6, -10.5, 1.5, 0.8, Y, Y + 0.95),
  boxCollider(14, -10.5, 1.7, 0.85, Y, Y + 0.8),
  boxCollider(15.3, -11.4, 0.5, 0.65, Y, Y + 1.4),
  boxCollider(-15, -10.5, 1.7, 1.1, Y, Y + 1.0),
  boxCollider(17.3, -10.5, 1.1, 1.1, Y, Y + 1.3),
]

// ---------------------------------------------------------------------------
export function B({ p, s, r, m, shadow = true }: { p: V3; s: V3; r?: V3; m: THREE.Material; shadow?: boolean }) {
  return (
    <mesh position={p} rotation={r ?? [0, 0, 0]} material={m} castShadow={shadow} receiveShadow>
      <boxGeometry args={s} />
    </mesh>
  )
}
export function Cyl({ p, r, h, m, rot, seg = 20 }: { p: V3; r: number; h: number; m: THREE.Material; rot?: V3; seg?: number }) {
  return (
    <mesh position={p} rotation={rot ?? [0, 0, 0]} material={m} castShadow receiveShadow>
      <cylinderGeometry args={[r, r, h, seg]} />
    </mesh>
  )
}

export function Workbench({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  const top = useMemo(() => new THREE.MeshStandardMaterial({ color: '#9fb0a0', roughness: 0.85 }), [])
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.88, 0]} s={[2.4, 0.08, 0.9]} m={top} />
      <B p={[0, 0.7, 0]} s={[2.3, 0.28, 0.8]} m={m.steelDark} />
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => <B key={`${sx}${sz}`} p={[sx * 1.1, 0.42, sz * 0.38]} s={[0.07, 0.84, 0.07]} m={m.steelDark} />),
      )}
      <B p={[0.4, 0.95, 0.1]} s={[0.4, 0.06, 0.3]} m={m.paper} />
      <Cyl p={[-0.7, 1.0, -0.2]} r={0.08} h={0.16} m={m.rust} seg={12} />
      <B p={[-0.2, 0.94, -0.25]} s={[0.25, 0.04, 0.15]} m={m.metalDark} />
    </group>
  )
}

export function IBC({ p, dirty = false }: { p: V3; dirty?: boolean }) {
  const m = useMaterials()
  return (
    <group position={p}>
      <B p={[0, 0.66, 0]} s={[0.96, 0.96, 0.96]} m={dirty ? m.paintCream : m.plasticWhite} />
      <B p={[0, 0.08, 0]} s={[1.06, 0.16, 1.06]} m={m.steelDark} />
      {[-0.52, 0.52].map((x) =>
        [-0.52, 0.52].map((z) => <B key={`${x}${z}`} p={[x, 0.66, z]} s={[0.04, 1.2, 0.04]} m={m.metal} />),
      )}
      {[0.4, 0.75, 1.1].map((y) => (
        <group key={y}>
          <B p={[0, y, 0.52]} s={[1.06, 0.03, 0.03]} m={m.metal} />
          <B p={[0, y, -0.52]} s={[1.06, 0.03, 0.03]} m={m.metal} />
          <B p={[0.52, y, 0]} s={[0.03, 0.03, 1.06]} m={m.metal} />
          <B p={[-0.52, y, 0]} s={[0.03, 0.03, 1.06]} m={m.metal} />
        </group>
      ))}
      <Cyl p={[0, 1.2, 0]} r={0.08} h={0.08} m={m.black} seg={12} />
    </group>
  )
}

export function Drum({ p, m: mat, tipped = false, rot = 0 }: { p: V3; m?: THREE.Material; tipped?: boolean; rot?: number }) {
  const m = useMaterials()
  return (
    <group position={tipped ? [p[0], p[1] + 0.3, p[2]] : p} rotation={tipped ? [Math.PI / 2, 0, rot] : [0, rot, 0]}>
      <Cyl p={[0, tipped ? 0 : 0.44, 0]} r={0.3} h={0.88} m={mat ?? m.rust} seg={24} />
      {[-0.17, 0.17].map((y) => (
        <mesh key={y} position={[0, (tipped ? 0 : 0.44) + y, 0]} material={m.metalDark}>
          <torusGeometry args={[0.305, 0.012, 6, 28]} />
        </mesh>
      ))}
    </group>
  )
}

export function Crate({ p, s, rot = 0 }: { p: V3; s: V3; rot?: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, s[1] / 2, 0]} s={s} m={m.woodDark} />
      <B p={[0, s[1] / 2, s[2] / 2 + 0.005]} s={[s[0] * 0.92, 0.05, 0.01]} m={m.wood} />
      <B p={[0, s[1] - 0.05, s[2] / 2 + 0.005]} s={[s[0] * 0.92, 0.05, 0.01]} m={m.wood} />
      <B p={[-s[0] / 2 - 0.005, s[1] / 2, 0]} s={[0.01, 0.05, s[2] * 0.92]} m={m.wood} />
    </group>
  )
}

export function Pallet({ p, rot = 0 }: { p: V3; rot?: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      {Array.from({ length: 5 }).map((_, i) => (
        <B key={i} p={[-0.5 + i * 0.25, 0.12, 0]} s={[0.1, 0.02, 1.0]} m={m.wood} />
      ))}
      {[-0.45, 0, 0.45].map((z) => (
        <B key={z} p={[0, 0.06, z]} s={[1.2, 0.1, 0.1]} m={m.woodDark} />
      ))}
    </group>
  )
}

export function CinderWall({ p, rot, len, courses = 5 }: { p: V3; rot: number; len: number; courses?: number }) {
  const m = useMaterials()
  const n = Math.floor(len / 0.4)
  const blocks: React.ReactNode[] = []
  for (let c = 0; c < courses; c++) {
    const offset = c % 2 ? 0.2 : 0
    const count = c === courses - 1 ? Math.max(1, n - 2) : n
    for (let i = 0; i < count; i++) {
      blocks.push(<B key={`${c}-${i}`} p={[-len / 2 + 0.2 + i * 0.4 + offset, 0.1 + c * 0.2, 0]} s={[0.39, 0.19, 0.19]} m={m.cinder} />)
    }
  }
  return (
    <group position={p} rotation={[0, rot, 0]}>
      {blocks}
    </group>
  )
}

export function Barrier({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.15, 0]} s={[2.0, 0.3, 0.6]} m={m.concrete} />
      <B p={[0, 0.55, 0]} s={[2.0, 0.5, 0.36]} m={m.concrete} />
      <B p={[0, 0.82, 0]} s={[2.0, 0.08, 0.2]} m={m.concrete} />
    </group>
  )
}

function Container({ p, rot, mat, open = false }: { p: V3; rot: number; mat: THREE.Material; open?: boolean }) {
  const m = useMaterials()
  const L = 6.06
  const H = 2.59
  const D = 2.44
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, H / 2 + 0.1, 0]} s={[L, H - 0.2, D]} m={mat} />
      {/* corner posts & rails */}
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => <B key={`${sx}${sz}`} p={[sx * (L / 2 - 0.08), H / 2, sz * (D / 2 - 0.02)]} s={[0.16, H, 0.2]} m={m.steelDark} />),
      )}
      <B p={[0, 0.08, 0]} s={[L, 0.16, D + 0.02]} m={m.steelDark} />
      <B p={[0, H - 0.05, 0]} s={[L, 0.1, D + 0.02]} m={m.steelDark} />
      {/* doors at +x end */}
      {open ? (
        <group position={[L / 2, 0, -D / 2]} rotation={[0, -2.2, 0]}>
          <B p={[0.03, H / 2, D / 4]} s={[0.06, H - 0.1, D / 2 - 0.05]} m={mat} />
        </group>
      ) : (
        <B p={[L / 2 + 0.03, H / 2, -D / 4]} s={[0.06, H - 0.1, D / 2 - 0.05]} m={mat} />
      )}
      <B p={[L / 2 + 0.03, H / 2, D / 4]} s={[0.06, H - 0.1, D / 2 - 0.05]} m={mat} />
      {[-0.4, 0.4].map((z) => (
        <B key={z} p={[L / 2 + 0.08, H / 2, z + D / 4]} s={[0.04, H - 0.4, 0.05]} m={m.steelDark} />
      ))}
    </group>
  )
}

export function Cable({ pts, r = 0.02, mat }: { pts: V3[]; r?: number; mat?: THREE.Material }) {
  const m = useMaterials()
  const geo = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p)))
    return new THREE.TubeGeometry(curve, Math.max(10, pts.length * 6), r, 7, false)
  }, [pts, r])
  return <mesh geometry={geo} material={mat ?? m.cable} castShadow receiveShadow />
}

export function Cabinet({ p, rot, w = 0.8, h = 2.0, open = false }: { p: V3; rot: number; w?: number; h?: number; open?: boolean }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, h / 2, 0]} s={[w, h, 0.5]} m={m.steel} />
      {open ? (
        <group position={[-w / 2, 0, 0.25]} rotation={[0, 1.6, 0]}>
          <B p={[w / 2, h / 2, 0]} s={[w - 0.02, h - 0.06, 0.03]} m={m.steel} />
        </group>
      ) : (
        <B p={[0, h / 2, 0.26]} s={[w - 0.04, h - 0.06, 0.02]} m={m.steelLight} />
      )}
      <B p={[0, h * 0.6, 0.0]} s={[w - 0.1, h * 0.5, 0.42]} m={m.black} />
      <B p={[w * 0.1, h * 0.55, 0.05]} s={[0.15, 0.3, 0.1]} m={m.rust} />
    </group>
  )
}

export function Shelving({ p, rot = 0 }: { p: V3; rot?: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => <B key={`${sx}${sz}`} p={[sx * 0.98, 1.0, sz * 0.25]} s={[0.04, 2.0, 0.04]} m={m.steelDark} />),
      )}
      {[0.3, 0.85, 1.4, 1.95].map((y) => (
        <B key={y} p={[0, y, 0]} s={[2.0, 0.03, 0.55]} m={m.steelDark} />
      ))}
      <B p={[-0.5, 0.5, 0]} s={[0.5, 0.36, 0.4]} m={m.paper} />
      <B p={[0.4, 1.07, 0.05]} s={[0.6, 0.4, 0.35]} m={m.woodDark} />
      <B p={[-0.3, 1.58, 0]} s={[0.35, 0.3, 0.3]} m={m.plasticBlue} />
      <Cyl p={[0.7, 0.5, 0]} r={0.14} h={0.38} m={m.rust} seg={14} />
    </group>
  )
}

export function Desk({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.74, 0]} s={[1.6, 0.04, 0.8]} m={m.woodDark} />
      <B p={[-0.55, 0.36, 0]} s={[0.45, 0.72, 0.75]} m={m.steel} />
      <B p={[0.72, 0.36, 0]} s={[0.05, 0.72, 0.75]} m={m.steel} />
      <B p={[0.2, 0.78, -0.1]} s={[0.35, 0.04, 0.3]} m={m.paper} />
      <B p={[-0.3, 0.9, 0.1]} s={[0.4, 0.3, 0.35]} m={m.paintCream} />
    </group>
  )
}

export function Chair({ p, rot, fallen = false }: { p: V3; rot: number; fallen?: boolean }) {
  const m = useMaterials()
  return (
    <group position={fallen ? [p[0], p[1] + 0.21, p[2]] : p} rotation={fallen ? [Math.PI / 2, rot, 0] : [0, rot, 0]}>
      <B p={[0, 0.45, 0]} s={[0.42, 0.04, 0.42]} m={m.fabricDark} />
      <B p={[0, 0.72, -0.19]} s={[0.42, 0.5, 0.04]} m={m.fabricDark} />
      <B p={[0, 0.22, 0]} s={[0.05, 0.44, 0.05]} m={m.metalDark} />
      <B p={[0, 0.02, 0]} s={[0.5, 0.04, 0.5]} m={m.metalDark} />
    </group>
  )
}

function Forklift({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  const body = useMemo(() => new THREE.MeshStandardMaterial({ color: '#8a7a3a', roughness: 0.8, metalness: 0.3 }), [])
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0.2, 0.6, 0]} s={[1.8, 0.7, 1.1]} m={body} />
      <B p={[0.6, 1.3, 0]} s={[0.9, 0.7, 1.0]} m={m.steelDark} />
      <B p={[-0.1, 1.6, 0]} s={[0.08, 1.6, 1.0]} m={m.steelDark} />
      <B p={[-0.95, 1.2, 0]} s={[0.12, 2.4, 0.9]} m={m.rust} />
      <B p={[-1.5, 0.08, -0.3]} s={[1.1, 0.05, 0.12]} m={m.steelDark} />
      <B p={[-1.5, 0.08, 0.3]} s={[1.1, 0.05, 0.12]} m={m.steelDark} />
      {[-0.6, 0.7].map((x) =>
        [-0.6, 0.6].map((z) => (
          <mesh key={`${x}${z}`} position={[x, 0.3, z]} rotation={[Math.PI / 2, 0, 0]} material={m.black} castShadow>
            <torusGeometry args={[0.22, 0.1, 8, 18]} />
          </mesh>
        )),
      )}
    </group>
  )
}

export function Tyres({ p }: { p: V3 }) {
  const m = useMaterials()
  return (
    <group position={p}>
      {[0, 1, 2, 3, 4].map((i) => (
        <mesh key={i} position={[(i % 2) * 0.05, 0.1 + i * 0.2, 0]} rotation={[Math.PI / 2, 0, i * 0.4]} material={m.black} castShadow receiveShadow>
          <torusGeometry args={[0.3, 0.1, 10, 24]} />
        </mesh>
      ))}
      <mesh position={[0.8, 0.1, 0.5]} rotation={[Math.PI / 2, 0, 0.3]} material={m.black} castShadow receiveShadow>
        <torusGeometry args={[0.3, 0.1, 10, 24]} />
      </mesh>
      <mesh position={[0.5, 0.3, -0.6]} rotation={[0.2, 0.5, 0.1]} material={m.black} castShadow receiveShadow>
        <torusGeometry args={[0.3, 0.1, 10, 24]} />
      </mesh>
    </group>
  )
}

export function Spool({ p, r, h }: { p: V3; r: number; h: number }) {
  const m = useMaterials()
  return (
    <group position={p}>
      <Cyl p={[0, 0.04, 0]} r={r} h={0.08} m={m.wood} seg={24} />
      <Cyl p={[0, h - 0.04, 0]} r={r} h={0.08} m={m.wood} seg={24} />
      <Cyl p={[0, h / 2, 0]} r={r * 0.55} h={h} m={m.woodDark} seg={20} />
    </group>
  )
}

export function Mattress({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.11, 0]} s={[1.0, 0.22, 1.95]} m={m.mattress} />
      <B p={[0.1, 0.3, 0.2]} s={[0.7, 0.18, 1.4]} m={m.fabricDark} />
    </group>
  )
}

export function Mound({ p, s, rot = 0 }: { p: V3; s: V3; rot?: number }) {
  const m = useMaterials()
  return (
    <mesh position={p} rotation={[0, rot, 0]} scale={s} material={m.dust} receiveShadow castShadow>
      <sphereGeometry args={[1, 16, 10]} />
    </mesh>
  )
}

function HoistBlock({ x, z, beamY, drop }: { x: number; z: number; beamY: number; drop: number }) {
  const m = useMaterials()
  return (
    <group position={[x, beamY, z]}>
      <B p={[0, -0.45, 0]} s={[0.9, 0.5, 0.7]} m={m.steelDark} />
      <Cyl p={[0, -0.7 - drop / 2, 0]} r={0.02} h={drop} m={m.metalDark} seg={6} />
      <B p={[0, -0.7 - drop - 0.2, 0]} s={[0.3, 0.4, 0.2]} m={m.rust} />
      <mesh position={[0, -0.7 - drop - 0.55, 0]} rotation={[0, 0, 0]} material={m.metalDark} castShadow>
        <torusGeometry args={[0.14, 0.035, 8, 18, Math.PI * 1.5]} />
      </mesh>
    </group>
  )
}


// ---------------------------------------------------------------------------
// annex furniture
export function Lockers({ p, rot, n }: { p: V3; rot: number; n: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      {Array.from({ length: n }).map((_, i) => {
        const x = -((n - 1) * 0.62) / 2 + i * 0.62
        const open = i % 3 === 1
        return (
          <group key={i} position={[x, 0, 0]}>
            <B p={[0, 0.95, 0]} s={[0.6, 1.9, 0.5]} m={i % 4 === 2 ? m.rust : m.steel} />
            <group position={[-0.29, 0, 0.25]} rotation={[0, open ? 1.3 : 0, 0]}>
              <B p={[0.29, 0.95, 0.012]} s={[0.56, 1.84, 0.02]} m={i % 4 === 2 ? m.rust : m.steelLight} />
            </group>
          </group>
        )
      })}
    </group>
  )
}

export function Bench({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.44, 0]} s={[1.8, 0.05, 0.35]} m={m.woodDark} />
      <B p={[-0.75, 0.21, 0]} s={[0.06, 0.42, 0.3]} m={m.steelDark} />
      <B p={[0.75, 0.21, 0]} s={[0.06, 0.42, 0.3]} m={m.steelDark} />
    </group>
  )
}

export function Table({ p, rot, w = 1.2, d = 0.8, h = 0.76 }: { p: V3; rot: number; w?: number; d?: number; h?: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, h - 0.02, 0]} s={[w, 0.04, d]} m={m.woodDark} />
      {[-1, 1].map((sx) =>
        [-1, 1].map((sz) => <B key={`${sx}${sz}`} p={[sx * (w / 2 - 0.05), (h - 0.04) / 2, sz * (d / 2 - 0.05)]} s={[0.05, h - 0.04, 0.05]} m={m.steelDark} />),
      )}
    </group>
  )
}

export function Sofa({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.22, 0]} s={[1.9, 0.44, 0.85]} m={m.fabric} />
      <B p={[0, 0.6, -0.33]} s={[1.9, 0.5, 0.2]} m={m.fabric} />
      <B p={[-0.85, 0.5, 0]} s={[0.2, 0.3, 0.85]} m={m.fabric} />
      <B p={[0.85, 0.5, 0]} s={[0.2, 0.3, 0.85]} m={m.fabric} />
      <B p={[-0.4, 0.48, 0.05]} s={[0.8, 0.12, 0.7]} m={m.fabricDark} />
    </group>
  )
}

export function Toilet({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.2, 0]} s={[0.36, 0.4, 0.5]} m={m.paintWhite} />
      <Cyl p={[0, 0.42, 0.05]} r={0.2} h={0.06} m={m.paintWhite} seg={18} />
      <B p={[0, 0.6, -0.28]} s={[0.4, 0.5, 0.18]} m={m.paintWhite} />
    </group>
  )
}


export function BedFrame({ p, rot, mattress = true }: { p: V3; rot: number; mattress?: boolean }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      {[-0.45, 0.45].map((z) => (
        <B key={z} p={[0, 0.35, z]} s={[1.95, 0.03, 0.03]} m={m.metalDark} />
      ))}
      {Array.from({ length: 9 }).map((_, i) => (
        <B key={i} p={[-0.9 + i * 0.225, 0.35, 0]} s={[0.02, 0.02, 0.9]} m={m.metalDark} />
      ))}
      {[-0.95, 0.95].map((x) =>
        [-0.45, 0.45].map((z) => <B key={`${x}${z}`} p={[x, 0.3, z]} s={[0.03, 0.6, 0.03]} m={m.metalDark} />),
      )}
      <B p={[-0.95, 0.7, 0]} s={[0.03, 0.03, 0.93]} m={m.metalDark} />
      {mattress && <B p={[0, 0.46, 0]} s={[1.9, 0.18, 0.88]} m={m.mattress} />}
    </group>
  )
}


export function Extinguisher({ p, rot }: { p: V3; rot: number }) {
  const red = useMemo(() => new THREE.MeshStandardMaterial({ color: '#8f1f1a', roughness: 0.5, metalness: 0.3 }), [])
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <Cyl p={[0, 0.3, 0.1]} r={0.08} h={0.55} m={red} seg={14} />
      <Cyl p={[0, 0.62, 0.1]} r={0.03} h={0.12} m={m.metalDark} seg={8} />
      <B p={[0, 0.35, 0.01]} s={[0.2, 0.3, 0.02]} m={m.steelDark} />
    </group>
  )
}

export function Monitor({ p, rot }: { p: V3; rot: number }) {
  const m = useMaterials()
  return (
    <group position={p} rotation={[0, rot, 0]}>
      <B p={[0, 0.25, 0]} s={[0.46, 0.38, 0.4]} m={m.paintCream} />
      <B p={[0, 0.25, 0.2]} s={[0.36, 0.28, 0.01]} m={m.black} />
    </group>
  )
}

// ---------------------------------------------------------------------------
export function Props() {
  const m = useMaterials()
  const whiteboard = useMemo(() => new THREE.MeshStandardMaterial({ color: '#f4f4f0', roughness: 0.4 }), [])
  return (
    <group>
      {/* ================= MAIN HALL ================= */}
      <Workbench p={[-6, 0, 5.5]} rot={0.08} />
      <Workbench p={[-3, 0, 5.2]} rot={-0.06} />
      <IBC p={[-16.5, 0, 6.5]} />
      <IBC p={[-16.5, 0, 7.7]} dirty />
      <IBC p={[-15.3, 0, 6.5]} />
      <IBC p={[10, 0, -3.5]} dirty />
      {/* drums */}
      <Drum p={[11.2, 0, 10.1]} />
      <Drum p={[11.9, 0, 10.7]} m={m.plasticBlue} />
      <Drum p={[11.1, 0, 10.9]} m={m.steelLight} tipped rot={0.6} />
      <Drum p={[12.1, 0, 9.9]} />
      <Drum p={[-8.8, 0, -4.4]} m={m.steelLight} />
      <Drum p={[-8.1, 0, -4.7]} />
      <Drum p={[-8.5, 0, -3.8]} m={m.plasticBlue} tipped rot={-0.4} />
      <Drum p={[16.2, 0, -5.2]} />
      <Drum p={[16.9, 0, -4.8]} m={m.rust} />
      <Drum p={[16.4, 0, -5.9]} m={m.steelLight} tipped rot={1.2} />
      <Drum p={[-1.4, 0, -11.1]} m={m.plasticBlue} />
      <Drum p={[-0.6, 0, -11.0]} />
      <Drum p={[-1.0, 0, -10.3]} m={m.steelLight} />
      {/* cinder block cover */}
      <CinderWall p={[0, 0, 7.5]} rot={0} len={3.2} />
      <CinderWall p={[-9.5, 0, 1.0]} rot={Math.PI / 2} len={2.4} courses={4} />
      <Mound p={[7, 0.05, 3.5]} s={[0.9, 0.35, 0.8]} />
      {/* jersey barriers */}
      <Barrier p={[3.5, 0, -2.0]} rot={0.1} />
      <Barrier p={[5.8, 0, -2.6]} rot={-0.2} />
      <Barrier p={[-1.5, 0, -5.5]} rot={1.35} />
      {/* pallets & crates */}
      <group position={[6, 0, 9.5]}>
        {Array.from({ length: 9 }).map((_, i) => (
          <Pallet key={i} p={[(i % 3) * 0.02, i * 0.15, (i % 2) * 0.03]} rot={(i % 2) * 0.05} />
        ))}
      </group>
      <group position={[-3, 0, 10]}>
        <Pallet p={[0, 0, 0]} />
        <Pallet p={[0, 0.15, 0]} rot={0.04} />
        <Crate p={[0, 0.3, 0]} s={[0.9, 0.7, 0.8]} rot={0.1} />
      </group>
      <Crate p={[13, 0, 1.2]} s={[1.0, 1.0, 1.0]} rot={0.2} />
      <Crate p={[12.2, 0, 2.4]} s={[0.7, 0.7, 0.7]} rot={-0.5} />
      <Crate p={[-13, 0, 3]} s={[1.2, 1.0, 0.9]} rot={0.4} />
      {/* containers under the mezzanine */}
      <Container p={[10, 0, -9.55]} rot={0} mat={m.corrugatedBlue} open />
      <Container p={[2, 0, -9.55]} rot={0} mat={m.corrugatedRed} />
      {/* cable bundles down column (4,4) into a cabinet – like the reference */}
      <Cable pts={[[3.72, 7.9, 4.05], [3.72, 5.5, 4.0], [3.7, 3.2, 4.1], [3.74, 2.0, 4.6], [3.76, 1.6, 5.6], [3.8, 1.2, 6.3]]} r={0.045} />
      <Cable pts={[[3.65, 7.9, 3.85], [3.6, 5.4, 3.82], [3.62, 3.1, 3.95], [3.68, 1.9, 4.5], [3.7, 1.55, 5.5], [3.72, 1.15, 6.25]]} r={0.04} mat={m.steelDark} />
      <Cable pts={[[3.78, 7.9, 4.22], [3.8, 5.6, 4.2], [3.82, 3.3, 4.25], [3.9, 2.1, 4.7], [3.95, 1.7, 5.7], [3.98, 1.25, 6.35]]} r={0.035} mat={m.rust} />
      <Cable pts={[[3.6, 7.9, 4.3], [3.55, 5.0, 4.3], [3.55, 3.0, 4.35], [3.6, 2.2, 4.8], [3.62, 1.8, 5.8], [3.65, 1.3, 6.4]]} r={0.03} />
      <Cabinet p={[4, 0, 6.6]} rot={0} w={0.9} h={1.1} />
      {/* east wall cabinet with cables */}
      <Cabinet p={[19.5, 0, -5.5]} rot={-Math.PI / 2} open />
      <Cable pts={[[19.6, 7.8, -6.2], [19.6, 5.0, -6.1], [19.55, 2.5, -5.9], [19.5, 2.05, -5.7]]} r={0.04} />
      <Cable pts={[[19.65, 7.8, -6.5], [19.62, 5.2, -6.4], [19.6, 2.6, -6.1], [19.5, 2.05, -5.9]]} r={0.03} mat={m.steelDark} />
      <Cabinet p={[-19.5, 0, 10.6]} rot={Math.PI / 2} />
      <Cabinet p={[-19.5, 0, 11.4]} rot={Math.PI / 2} open />
      {/* pipes along the north wall under the deck */}
      <Cyl p={[8, 3.3, -11.6]} r={0.08} h={23} m={m.steelLight} rot={[0, 0, Math.PI / 2]} seg={12} />
      <Cyl p={[8, 3.05, -11.6]} r={0.05} h={23} m={m.rust} rot={[0, 0, Math.PI / 2]} seg={10} />
      <Cyl p={[18.5, 1.65, -11.6]} r={0.08} h={3.3} m={m.steelLight} seg={12} />
      <Cyl p={[19.3, 4.5, -11.6]} r={0.07} h={9} m={m.rust} seg={10} />
      {/* crane hoist & hanging chains */}
      <HoistBlock x={-2} z={1.5} beamY={7.0} drop={2.6} />
      <Cable pts={[[-10, 7.85, -2], [-10.02, 6.5, -2.0], [-10.05, 5.3, -2.05]]} r={0.015} mat={m.metalDark} />
      <Cable pts={[[8, 7.85, 6], [8.02, 7.0, 6.0], [8.03, 6.1, 6.02]]} r={0.015} mat={m.metalDark} />
      <Cable pts={[[-14, 7.85, 2], [-13.9, 6.9, 2.1], [-14.1, 5.9, 2.3], [-13.8, 5.2, 2.5]]} r={0.012} />
      <Forklift p={[-11, 0, -2.5]} rot={0.7} />
      <Spool p={[10.5, 0, 10.5]} r={0.8} h={0.9} />
      <Spool p={[8.8, 0, 10.8]} r={0.6} h={0.7} />
      <Tyres p={[-17.5, 0, 10.5]} />
      {/* rubble spilling through the broken wall from the house */}
      <Mound p={[-19.2, 0.0, -9.6]} s={[0.8, 0.4, 0.7]} rot={0.3} />
      <B p={[-19.0, 0.1, -10.3]} s={[0.39, 0.19, 0.19]} r={[0, 0.5, 0]} m={m.cinder} />
      <B p={[-18.7, 0.1, -9.1]} s={[0.39, 0.19, 0.19]} r={[0.3, 1.2, 0]} m={m.cinder} />
      {/* under deck east */}
      <Shelving p={[16, 0, -11.4]} />
      <Pallet p={[15, 0, -8.6]} rot={0.2} />
      <Cable pts={[[13.3, 3.7, -9.4], [13.2, 3.0, -9.3], [13.4, 2.2, -9.2], [13.1, 1.6, -9.3]]} r={0.012} />

      {/* ================= OFFICES ================= */}
      <Desk p={[-14, 0, -10.5]} rot={0} />
      <Chair p={[-14, 0, -9.6]} rot={Math.PI} />
      <Cabinet p={[-12.5, 0, -11.4]} rot={0} w={0.5} h={1.4} />
      <mesh position={[-14, 1.6, -11.78]} material={whiteboard} receiveShadow>
        <planeGeometry args={[1.8, 1.0]} />
      </mesh>
      <Desk p={[-10, 0, -10.5]} rot={0.1} />
      <Chair p={[-9.3, 0, -9.5]} rot={2.2} fallen />
      <mesh position={[-10, 1.6, -11.78]} material={whiteboard} receiveShadow>
        <planeGeometry args={[1.6, 1.0]} />
      </mesh>
      <Shelving p={[-6, 0, -11.4]} />
      <Mattress p={[-5, 0, -8.5]} rot={1.4} />

      {/* ================= MEZZANINE ================= */}
      <Crate p={[-10, Y, -10]} s={[1.0, 1.0, 1.0]} rot={0.2} />
      <Crate p={[-9, Y, -9]} s={[0.7, 0.7, 0.7]} rot={-0.4} />
      <Drum p={[5.7, Y, -10.6]} />
      <Drum p={[6.4, Y, -10.3]} m={m.plasticBlue} />
      <Desk p={[14, Y, -10.5]} rot={0} />
      <Chair p={[14.2, Y, -9.6]} rot={Math.PI + 0.3} />
      <Cabinet p={[15.3, Y, -11.4]} rot={0} w={0.5} h={1.4} open />
      <Mattress p={[-3, Y, -10.5]} rot={0.1} />
      <B p={[-15, Y + 0.5, -10.5]} s={[1.6, 1.0, 1.0]} m={m.steel} />
      <B p={[-15, Y + 1.05, -10.5]} s={[1.0, 0.1, 0.6]} m={m.steelDark} />
      <IBC p={[17.3, Y, -10.5]} dirty />
      <Cable pts={[[-6, 7.85, -9.5], [-6.05, 6.8, -9.4], [-5.95, 5.9, -9.5]]} r={0.012} />

      {/* ================= STAIRWELL ================= */}
      <B p={[14.7, 0.1, 10.8]} s={[0.39, 0.19, 0.19]} r={[0, 0.3, 0]} m={m.cinder} />
      <B p={[14.6, 0.3, 10.6]} s={[0.39, 0.19, 0.19]} r={[0, 0.9, 0]} m={m.cinder} />
      <Cyl p={[14.6, 0.15, 5.0]} r={0.14} h={0.3} m={m.rust} seg={12} />
      <Cyl p={[17.5, 1.2, 11.0]} r={0.03} h={2.4} m={m.rust} rot={[0.2, 0, 0.9]} seg={8} />
    </group>
  )
}
