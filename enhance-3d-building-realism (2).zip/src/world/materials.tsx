import * as THREE from 'three'
import { createContext, useContext, useMemo, type ReactNode } from 'react'
import type { WorldTextures } from './textures'
import type { MatKey } from './layout'

export interface Materials {
  tex: WorldTextures
  wallPale: THREE.MeshStandardMaterial
  wallPlaster: THREE.MeshStandardMaterial
  wallStripe: THREE.MeshStandardMaterial
  bath: THREE.MeshStandardMaterial
  tileFloor: THREE.MeshStandardMaterial
  concrete: THREE.MeshStandardMaterial
  concreteFloor: THREE.MeshStandardMaterial
  deck: THREE.MeshStandardMaterial
  brickWhite: THREE.MeshStandardMaterial
  reveal: THREE.MeshStandardMaterial
  steel: THREE.MeshStandardMaterial
  steelDark: THREE.MeshStandardMaterial
  steelLight: THREE.MeshStandardMaterial
  rust: THREE.MeshStandardMaterial
  corrugated: THREE.MeshStandardMaterial
  corrugatedBlue: THREE.MeshStandardMaterial
  corrugatedRed: THREE.MeshStandardMaterial
  shutter: THREE.MeshStandardMaterial
  skylight: THREE.MeshStandardMaterial
  wood: THREE.MeshStandardMaterial
  woodDark: THREE.MeshStandardMaterial
  ceiling: THREE.MeshStandardMaterial
  paintWhite: THREE.MeshStandardMaterial
  paintCream: THREE.MeshStandardMaterial
  metal: THREE.MeshStandardMaterial
  metalDark: THREE.MeshStandardMaterial
  fabric: THREE.MeshStandardMaterial
  fabricDark: THREE.MeshStandardMaterial
  mattress: THREE.MeshStandardMaterial
  glass: THREE.MeshPhysicalMaterial
  paper: THREE.MeshStandardMaterial
  rubble: THREE.MeshStandardMaterial
  dust: THREE.MeshStandardMaterial
  cinder: THREE.MeshStandardMaterial
  brickChunk: THREE.MeshStandardMaterial
  ground: THREE.MeshStandardMaterial
  black: THREE.MeshStandardMaterial
  cable: THREE.MeshStandardMaterial
  plasticBlue: THREE.MeshStandardMaterial
  plasticWhite: THREE.MeshStandardMaterial
  byKey: (k: MatKey) => THREE.MeshStandardMaterial
}

const MaterialsCtx = createContext<Materials | null>(null)

export function useMaterials() {
  const m = useContext(MaterialsCtx)
  if (!m) throw new Error('Materials context missing')
  return m
}

function std(
  opts: THREE.MeshStandardMaterialParameters & { pair?: { map: THREE.Texture; normal: THREE.Texture }; bump?: number },
) {
  const { pair, bump = 1, ...rest } = opts
  const m = new THREE.MeshStandardMaterial({
    roughness: 0.95,
    metalness: 0,
    ...rest,
  })
  if (pair) {
    m.map = pair.map
    m.normalMap = pair.normal
    m.normalScale = new THREE.Vector2(bump, bump)
  }
  return m
}

export function createMaterials(tex: WorldTextures): Materials {
  const tile = (p: { map: THREE.Texture; normal: THREE.Texture }, size: number, rotation = 0) => {
    const map = p.map.clone()
    map.repeat.set(1 / size, 1 / size)
    map.rotation = rotation
    map.center.set(0.5, 0.5)
    map.needsUpdate = true
    const normal = p.normal.clone()
    normal.repeat.set(1 / size, 1 / size)
    normal.rotation = rotation
    normal.center.set(0.5, 0.5)
    normal.needsUpdate = true
    return { map, normal }
  }

  const wallPale = std({ pair: tile(tex.wallPale, 3.2), color: '#9d9c96', roughness: 0.92, bump: 0.24 })
  const wallPlaster = std({ pair: tile(tex.wallPlaster, 3.0), color: '#c9c5bb', roughness: 0.9, bump: 0.35 })
  const wallStripe = std({ pair: tile(tex.wallStripe, 3.0), color: '#dad3c4', roughness: 0.9, bump: 0.42 })
  const bath = std({ pair: tile(tex.wallPlaster, 2.5), color: '#cad8d8', roughness: 0.6, bump: 0.7 })
  const tileFloor = std({ pair: tile(tex.tile, 1.0), color: '#dcd8d0', roughness: 0.55, bump: 0.9 })
  const concrete = std({ pair: tile(tex.concrete, 2.6), color: '#c3c0b9', roughness: 0.96, bump: 0.55 })
  const concreteFloor = std({ pair: tile(tex.concreteFloor, 3.0), color: '#d6d2ca', roughness: 0.82, bump: 0.8 })
  concreteFloor.envMapIntensity = 0.55
  const deck = std({ pair: tile(tex.concreteFloor, 2.2), color: '#a8a49c', roughness: 0.78, bump: 0.5 })
  deck.envMapIntensity = 0.6
  const brickWhite = std({ pair: tile(tex.brickWhite, 2.6), color: '#d3cabd', roughness: 0.95, bump: 0.85 })
  const reveal = std({ pair: tile(tex.concrete, 1.6), color: '#cfccc5', roughness: 0.98 })
  const steel = std({ pair: tile(tex.metal, 1.6), color: '#8f959d', roughness: 0.38, metalness: 0.82, bump: 0.6 })
  steel.envMapIntensity = 1.45
  const steelDark = std({ pair: tile(tex.metal, 1.2), color: '#4b4f55', roughness: 0.46, metalness: 0.72, bump: 0.5 })
  steelDark.envMapIntensity = 1.25
  const steelLight = std({ pair: tile(tex.metal, 1.6), color: '#b8bcc2', roughness: 0.5, metalness: 0.5, bump: 0.6 })
  const rust = std({ pair: tile(tex.rust, 1.0), color: '#bda894', roughness: 0.78, metalness: 0.32, bump: 1.0 })
  rust.envMapIntensity = 0.75
  const corrugated = std({ pair: tile(tex.corrugated, 1.0), color: '#c2c5c6', roughness: 0.6, metalness: 0.45, bump: 1.6, side: THREE.DoubleSide })
  const corrugatedBlue = std({ pair: tile(tex.corrugated, 1.2), color: '#2d5ea6', roughness: 0.6, metalness: 0.4, bump: 1.4 })
  const corrugatedRed = std({ pair: tile(tex.corrugated, 1.2), color: '#93402f', roughness: 0.7, metalness: 0.35, bump: 1.4 })
  const shutter = std({ pair: tile(tex.corrugated, 1.0, Math.PI / 2), color: '#9ea2a6', roughness: 0.6, metalness: 0.45, bump: 1.6 })
  const skylight = std({
    color: '#ffffff',
    emissive: new THREE.Color('#ffffff'),
    emissiveIntensity: 0.3,
    roughness: 0.35,
    transparent: true,
    opacity: 0.5,
    side: THREE.DoubleSide,
    depthWrite: false,
  })
  const woodPair = tile(tex.wood, 2.0, Math.PI / 2)
  const wood = new THREE.MeshPhysicalMaterial({
    map: woodPair.map,
    normalMap: woodPair.normal,
    normalScale: new THREE.Vector2(0.8, 0.8),
    color: '#c3b8a5',
    roughness: 0.48,
    clearcoat: 0.25,
    clearcoatRoughness: 0.35,
    envMapIntensity: 0.85,
  })
  const woodDark = std({ pair: tile(tex.wood, 1.2), color: '#7a6a58', roughness: 0.72, bump: 0.8 })
  const ceiling = std({ pair: tile(tex.ceiling, 2.6), color: '#e4e0d7', roughness: 0.95, bump: 0.8 })
  const paintWhite = std({ pair: tile(tex.ceiling, 1.2), color: '#eeebe4', roughness: 0.55, bump: 0.5 })
  const paintCream = std({ pair: tile(tex.ceiling, 1.0), color: '#e9e0cc', roughness: 0.6, bump: 0.5 })
  const metal = std({ color: '#a2a4a1', roughness: 0.32, metalness: 0.9 })
  metal.envMapIntensity = 1.6
  const metalDark = std({ color: '#2f3134', roughness: 0.6, metalness: 0.7 })
  const fabric = std({ pair: tile(tex.ceiling, 1.0), color: '#7d7466', roughness: 1, bump: 0.3 })
  const fabricDark = std({ color: '#3b3934', roughness: 1 })
  const mattress = std({ pair: tile(tex.ceiling, 1.4), color: '#d2cbbc', roughness: 1, bump: 0.5 })
  const glass = new THREE.MeshPhysicalMaterial({
    color: '#dfe9ea',
    roughness: 0.06,
    metalness: 0,
    transparent: true,
    opacity: 0.2,
    reflectivity: 1,
    clearcoat: 1,
    clearcoatRoughness: 0.03,
    ior: 1.5,
    envMapIntensity: 2.6,
    side: THREE.DoubleSide,
    depthWrite: false,
  })
  const paper = std({ color: '#ebe6d8', roughness: 0.9, side: THREE.DoubleSide })
  const rubble = std({ pair: tile(tex.concrete, 0.6), color: '#e2ded6', roughness: 1 })
  const dust = std({ pair: tile(tex.concreteFloor, 1.2), color: '#ebe7df', roughness: 1 })
  const cinder = std({ pair: tile(tex.concrete, 0.5), color: '#a9a8a3', roughness: 1 })
  const brickChunk = std({ pair: tile(tex.brickWhite, 0.5), color: '#b59a88', roughness: 1 })
  const ground = std({ pair: tile(tex.ground, 4), color: '#b3a893', roughness: 1, bump: 0.8 })
  const black = std({ color: '#111111', roughness: 0.9 })
  const cable = std({ color: '#26272a', roughness: 0.65, metalness: 0.1 })
  const plasticBlue = std({ color: '#1f4e9c', roughness: 0.6 })
  const plasticWhite = std({ color: '#e4e2da', roughness: 0.7 })

  const byKey = (k: MatKey) => {
    switch (k) {
      case 'wallPale':
        return wallPale
      case 'wallPlaster':
        return wallPlaster
      case 'wallStripe':
        return wallStripe
      case 'bath':
        return bath
      case 'concrete':
        return concrete
      case 'brickWhite':
        return brickWhite
    }
  }

  return {
    tex,
    wallPale,
    wallPlaster,
    wallStripe,
    bath,
    tileFloor,
    concrete,
    concreteFloor,
    deck,
    brickWhite,
    reveal,
    steel,
    steelDark,
    steelLight,
    rust,
    corrugated,
    corrugatedBlue,
    corrugatedRed,
    shutter,
    skylight,
    wood,
    woodDark,
    ceiling,
    paintWhite,
    paintCream,
    metal,
    metalDark,
    fabric,
    fabricDark,
    mattress,
    glass,
    paper,
    rubble,
    dust,
    cinder,
    brickChunk,
    ground,
    black,
    cable,
    plasticBlue,
    plasticWhite,
    byKey,
  }
}

export function MaterialsProvider({ textures, children }: { textures: WorldTextures; children: ReactNode }) {
  const mats = useMemo(() => createMaterials(textures), [textures])
  return <MaterialsCtx.Provider value={mats}>{children}</MaterialsCtx.Provider>
}

// ---------------------------------------------------------------------------
// Geometry helpers

/** Wall with rectangular openings. Returns extrude geometry with 3 groups: 0 = z0 lid, 1 = sides, 2 = z=depth lid */
export function wallGeometry(
  u0: number,
  len: number,
  h: number,
  t: number,
  openings: { at: number; w: number; b: number; t: number }[],
) {
  // openings reaching the floor are cut as notches in the outline (holes must not touch the contour)
  const notches = openings.filter((o) => o.b <= 0.001).sort((a, b) => a.at - b.at)
  const holes = openings.filter((o) => o.b > 0.001)
  const shape = new THREE.Shape()
  shape.moveTo(u0, 0)
  for (const o of notches) {
    const x0 = Math.max(u0 + 0.02, o.at - o.w / 2)
    const x1 = Math.min(u0 + len - 0.02, o.at + o.w / 2)
    const y1 = Math.min(h - 0.02, o.t)
    shape.lineTo(x0, 0)
    shape.lineTo(x0, y1)
    shape.lineTo(x1, y1)
    shape.lineTo(x1, 0)
  }
  shape.lineTo(u0 + len, 0)
  shape.lineTo(u0 + len, h)
  shape.lineTo(u0, h)
  shape.closePath()
  for (const o of holes) {
    const hole = new THREE.Path()
    const x0 = Math.max(u0 + 0.02, o.at - o.w / 2)
    const x1 = Math.min(u0 + len - 0.02, o.at + o.w / 2)
    const y0 = Math.max(0, o.b)
    const y1 = Math.min(h - 0.02, o.t)
    hole.moveTo(x0, y0)
    hole.lineTo(x0, y1)
    hole.lineTo(x1, y1)
    hole.lineTo(x1, y0)
    hole.closePath()
    shape.holes.push(hole)
  }
  const geo = new THREE.ExtrudeGeometry(shape, { depth: t, bevelEnabled: false, steps: 1 })
  splitLidGroups(geo)
  geo.computeVertexNormals()
  return geo
}

/** ExtrudeGeometry puts both lids in group 0. Split into 0 (z=0 lid), 2 (z=depth lid), 1 = sides. */
export function splitLidGroups(geo: THREE.ExtrudeGeometry) {
  const groups = geo.groups.map((g) => ({ ...g }))
  if (groups.length < 2) return
  const lid = groups[0]
  const sides = groups[1]
  const half = lid.count / 2
  geo.clearGroups()
  geo.addGroup(lid.start, half, 0)
  geo.addGroup(lid.start + half, half, 2)
  geo.addGroup(sides.start, sides.count, 1)
}

/** Horizontal plane with world-space UVs (1 uv unit == 1 metre) */
export function floorGeometry(w: number, d: number, cx: number, cz: number) {
  const g = new THREE.PlaneGeometry(w, d)
  const uv = g.attributes.uv as THREE.BufferAttribute
  const pos = g.attributes.position as THREE.BufferAttribute
  for (let i = 0; i < uv.count; i++) {
    // plane lies in XY before rotation; after rotateX(-90) local y -> -z
    uv.setXY(i, pos.getX(i) + cx, -pos.getY(i) + cz)
  }
  uv.needsUpdate = true
  g.rotateX(-Math.PI / 2)
  return g
}

/** Vertical plane facing +z with world-space-ish UVs */
export function panelGeometry(w: number, h: number, u0 = 0, v0 = 0) {
  const g = new THREE.PlaneGeometry(w, h)
  const uv = g.attributes.uv as THREE.BufferAttribute
  const pos = g.attributes.position as THREE.BufferAttribute
  for (let i = 0; i < uv.count; i++) uv.setXY(i, pos.getX(i) + u0 + w / 2, pos.getY(i) + v0 + h / 2)
  uv.needsUpdate = true
  return g
}

/** Shape of the footprint with holes, laid flat. kind: 'floor' faces up, 'ceiling' faces down */
export function slabGeometry(
  xMin: number,
  xMax: number,
  zMin: number,
  zMax: number,
  holes: [number, number][][],
  depth: number,
) {
  // shape in (x, -z) so that rotateX(-90) maps to world (x, y, z)
  const shape = new THREE.Shape()
  shape.moveTo(xMin, -zMin)
  shape.lineTo(xMax, -zMin)
  shape.lineTo(xMax, -zMax)
  shape.lineTo(xMin, -zMax)
  shape.closePath()
  for (const poly of holes) {
    const p = new THREE.Path()
    poly.forEach(([x, z], i) => (i === 0 ? p.moveTo(x, -z) : p.lineTo(x, -z)))
    p.closePath()
    shape.holes.push(p)
  }
  const geo = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false, steps: 1 })
  splitLidGroups(geo)
  // fix uvs of lids to be world-space (x, z): shape coordinates are (x, -z) which is fine for tiling
  geo.rotateX(-Math.PI / 2)
  geo.computeVertexNormals()
  return geo
}

export function rectPoly(xMin: number, xMax: number, zMin: number, zMax: number): [number, number][] {
  return [
    [xMin, zMin],
    [xMax, zMin],
    [xMax, zMax],
    [xMin, zMax],
  ]
}
