import * as THREE from 'three'
import { useEffect, useMemo, useRef } from 'react'
import { Environment, Lightformer } from '@react-three/drei'
import { useFrame, useThree } from '@react-three/fiber'
import { WALLS, SUN_DIR, SUN_POS, ROOF_PANELS, roofY, MEZZ, MEZZ_Y, H_ROOF_HOLES, H_CEIL2, F2 } from './layout'
import { RectAreaLightUniformsLib } from 'three/examples/jsm/lights/RectAreaLightUniformsLib.js'
import { useMaterials } from './materials'

// ---------------------------------------------------------------------------
// Sunlit openings -> polygons (world space, on inner wall face) + floor level
interface ShaftDef {
  pts: THREE.Vector3[] // polygon of the opening (ordered)
  floorY: number
  strength: number
  normal?: THREE.Vector3 // inward facing normal
  w?: number
  h?: number
}

function sunlitOpenings(): ShaftDef[] {
  const out: ShaftDef[] = []
  for (const w of WALLS) {
    if (!w.exterior) continue
    for (const o of w.openings) {
      if (!o.sunlit) continue
      if (o.kind === 'rollup' && o.rollup === 'closed') continue
      const y0 = w.y + o.b
      const y1 = w.y + (o.kind === 'rollup' && o.rollup === 'half' ? 2.0 : o.t)
      const floorY = w.y
      if (w.axis === 'x') {
        const zi = w.z - w.t / 2
        const x0 = w.x + o.at - o.w / 2
        const x1 = w.x + o.at + o.w / 2
        const inN = new THREE.Vector3(0, 0, w.z > 0 ? -1 : 1)
        out.push({
          pts: [new THREE.Vector3(x0, y0, zi), new THREE.Vector3(x1, y0, zi), new THREE.Vector3(x1, y1, zi), new THREE.Vector3(x0, y1, zi)],
          floorY,
          strength: o.kind === 'window' ? 1 : 0.8,
          normal: inN,
          w: o.w,
          h: y1 - y0,
        })
      } else {
        const xi = w.x - w.t / 2
        const z0 = w.z + o.at - o.w / 2
        const z1 = w.z + o.at + o.w / 2
        out.push({
          pts: [new THREE.Vector3(xi, y0, z0), new THREE.Vector3(xi, y0, z1), new THREE.Vector3(xi, y1, z1), new THREE.Vector3(xi, y1, z0)],
          floorY,
          strength: 1,
          normal: new THREE.Vector3(w.x > 0 ? -1 : 1, 0, 0),
          w: o.w,
          h: y1 - y0,
        })
      }
    }
  }
  // holes in the roof
  for (const p of ROOF_PANELS) {
    if (p.state !== 'missing' && p.state !== 'hanging' && p.state !== 'skylightMissing') continue
    const pts = [
      new THREE.Vector3(p.x0 + 0.05, roofY(p.z0) - 0.02, p.z0 + 0.05),
      new THREE.Vector3(p.x1 - 0.05, roofY(p.z0) - 0.02, p.z0 + 0.05),
      new THREE.Vector3(p.x1 - 0.05, roofY(p.z1) - 0.02, p.z1 - 0.05),
      new THREE.Vector3(p.x0 + 0.05, roofY(p.z1) - 0.02, p.z1 - 0.05),
    ]
    // does the patch land on the mezzanine deck?
    const c = new THREE.Vector3((p.x0 + p.x1) / 2, roofY((p.z0 + p.z1) / 2), (p.z0 + p.z1) / 2)
    const onDeck = c.clone().addScaledVector(sunDir, (c.y - MEZZ_Y) / -sunDir.y)
    const floorY = onDeck.z > MEZZ.zMin && onDeck.z < MEZZ.zMax ? MEZZ_Y : 0
    out.push({ pts, floorY, strength: p.state === 'hanging' ? 0.6 : 1.1 })
  }
  // collapsed roof + broken skylight of the house (upper floor rooms)
  for (const h of H_ROOF_HOLES) {
    out.push({ pts: h.poly.map(([x, z]: [number, number]) => new THREE.Vector3(x, H_CEIL2, z)), floorY: F2, strength: 1.2 })
  }
  return out
}

const sunDir = new THREE.Vector3(SUN_DIR.x, SUN_DIR.y, SUN_DIR.z)

function projectToFloor(p: THREE.Vector3, floorY: number) {
  const s = (p.y - floorY) / -sunDir.y
  return p.clone().addScaledVector(sunDir, s)
}

// ---------------------------------------------------------------------------
const shaftVert = /* glsl */ `
  attribute float fade;
  attribute float side;
  varying float vFade;
  varying float vSide;
  varying vec3 vWorld;
  void main() {
    vFade = fade;
    vSide = side;
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vWorld = wp.xyz;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`
const shaftFrag = /* glsl */ `
  uniform vec3 color;
  uniform float intensity;
  uniform float time;
  uniform sampler2D noiseTex;
  uniform vec3 camPos;
  varying float vFade;
  varying float vSide;
  varying vec3 vWorld;
  void main() {
    vec2 nuv = vec2(vWorld.x * 0.6 + vWorld.z * 0.4, vWorld.y * 0.5 - vWorld.z * 0.3) * 0.35 + vec2(time * 0.010, -time * 0.016);
    float n = texture2D(noiseTex, nuv).r;
    float n2 = texture2D(noiseTex, nuv * 2.7 + vec2(-time * 0.012, time * 0.009)).r;
    float dust = 0.45 + 1.4 * n * n2;
    float edge = smoothstep(0.0, 0.18, vSide) * smoothstep(1.0, 0.82, vSide);
    vec3 fdx = dFdx(vWorld);
    vec3 fdy = dFdy(vWorld);
    vec3 nrm = normalize(cross(fdx, fdy));
    vec3 v = normalize(camPos - vWorld);
    float facing = pow(abs(dot(nrm, v)), 0.6);
    float a = intensity * (1.0 - vFade * 0.7) * dust * (0.35 + 0.65 * edge) * (0.25 + 0.75 * facing);
    gl_FragColor = vec4(color * a, 1.0);
  }
`

function buildShaftGeometry(def: ShaftDef) {
  const near = def.pts
  const far = near.map((p) => projectToFloor(p, def.floorY))
  const n = near.length
  const positions: number[] = []
  const fades: number[] = []
  const sides: number[] = []
  const push = (p: THREE.Vector3, f: number, s: number) => {
    positions.push(p.x, p.y, p.z)
    fades.push(f)
    sides.push(s)
  }
  // side faces
  for (let i = 0; i < n; i++) {
    const a = near[i],
      b = near[(i + 1) % n]
    const c = far[(i + 1) % n],
      d = far[i]
    push(a, 0, 0)
    push(b, 0, 1)
    push(c, 1, 1)
    push(a, 0, 0)
    push(c, 1, 1)
    push(d, 1, 0)
  }
  // two cross planes through the centre for a volumetric core
  const cNear = new THREE.Vector3()
  near.forEach((p) => cNear.add(p))
  cNear.multiplyScalar(1 / n)
  const cFar = projectToFloor(cNear, def.floorY)
  const pairs: [number, number][] = n === 4 ? [[0, 2], [1, 3]] : [[0, Math.floor(n / 2)], [Math.floor(n / 4), Math.floor((3 * n) / 4)]]
  for (const [i, j] of pairs) {
    const a = near[i].clone().lerp(cNear, 0.15)
    const b = near[j].clone().lerp(cNear, 0.15)
    const c = far[j].clone().lerp(cFar, 0.15)
    const d = far[i].clone().lerp(cFar, 0.15)
    push(a, 0, 0)
    push(b, 0, 1)
    push(c, 1, 1)
    push(a, 0, 0)
    push(c, 1, 1)
    push(d, 1, 0)
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
  g.setAttribute('fade', new THREE.Float32BufferAttribute(fades, 1))
  g.setAttribute('side', new THREE.Float32BufferAttribute(sides, 1))
  g.computeBoundingSphere()
  return { geometry: g, near, far }
}

function LightShafts({ defs }: { defs: ShaftDef[] }) {
  const m = useMaterials()
  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: shaftVert,
        fragmentShader: shaftFrag,
        uniforms: {
          color: { value: new THREE.Color(1.0, 0.9, 0.72) },
          intensity: { value: 0.010 },
          time: { value: 0 },
          noiseTex: { value: m.tex.noise },
          camPos: { value: new THREE.Vector3() },
        },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        fog: false,
      }),
    [m.tex.noise],
  )
  const geos = useMemo(() => defs.map((d) => buildShaftGeometry(d)), [defs])
  useFrame((state) => {
    material.uniforms.time.value = state.clock.elapsedTime
    material.uniforms.camPos.value.copy(state.camera.position)
  })
  return (
    <group>
      {geos.map((g, i) => (
        <mesh key={i} geometry={g.geometry} material={material} renderOrder={5} />
      ))}
    </group>
  )
}

// ---------------------------------------------------------------------------
const dustVert = /* glsl */ `
  attribute float seed;
  attribute float psize;
  uniform float time;
  uniform float scale;
  varying float vAlpha;
  void main() {
    vec3 p = position;
    p.x += sin(time * 0.31 + seed * 6.2831) * 0.14;
    p.y += sin(time * 0.21 + seed * 12.57) * 0.10;
    p.z += cos(time * 0.27 + seed * 9.42) * 0.14;
    vec4 mv = modelViewMatrix * vec4(p, 1.0);
    float dist = -mv.z;
    gl_PointSize = clamp(psize * scale / dist, 1.0, 14.0);
    float tw = 0.55 + 0.45 * sin(time * 1.7 + seed * 40.0);
    vAlpha = tw * smoothstep(0.15, 0.9, dist) * (1.0 - smoothstep(9.0, 16.0, dist));
    gl_Position = projectionMatrix * mv;
  }
`
const dustFrag = /* glsl */ `
  uniform sampler2D map;
  uniform vec3 color;
  uniform float intensity;
  varying float vAlpha;
  void main() {
    float a = texture2D(map, gl_PointCoord).a * vAlpha * intensity;
    gl_FragColor = vec4(color * a, a);
  }
`

function Dust({ defs }: { defs: ShaftDef[] }) {
  const m = useMaterials()
  const { size, camera } = useThree()
  const { geometry, material } = useMemo(() => {
    const rnd = mulberry(1234)
    const positions: number[] = []
    const seeds: number[] = []
    const sizes: number[] = []
    // dust concentrated in the light shafts
    const areas = defs.map((d) => {
      const w = d.pts[0].distanceTo(d.pts[1])
      const h = d.pts[1].distanceTo(d.pts[2])
      return w * h * d.strength
    })
    const total = areas.reduce((a, b) => a + b, 0)
    const N_SHAFT = 1700
    defs.forEach((d, i) => {
      const count = Math.round((areas[i] / total) * N_SHAFT)
      const n = d.pts.length
      for (let k = 0; k < count; k++) {
        // random point in the polygon (fan sampling from centre)
        const c = new THREE.Vector3()
        d.pts.forEach((p) => c.add(p))
        c.multiplyScalar(1 / n)
        const i0 = Math.floor(rnd() * n)
        const a = d.pts[i0],
          b = d.pts[(i0 + 1) % n]
        let u = rnd(),
          v = rnd()
        if (u + v > 1) {
          u = 1 - u
          v = 1 - v
        }
        const p = c.clone().addScaledVector(a.clone().sub(c), u).addScaledVector(b.clone().sub(c), v)
        const sMax = (p.y - d.floorY) / -sunDir.y
        const s = (0.03 + rnd() * 0.97) * sMax
        p.addScaledVector(sunDir, s)
        // slight spread outside the beam
        p.x += (rnd() - 0.5) * 0.25
        p.z += (rnd() - 0.5) * 0.25
        positions.push(p.x, p.y, p.z)
        seeds.push(rnd())
        sizes.push(0.012 + rnd() * 0.03)
      }
    })
    // sparse ambient dust everywhere inside
    for (let k = 0; k < 850; k++) {
      positions.push(-41 + rnd() * 61, 0.2 + rnd() * 8.5, (rnd() - 0.5) * 23)
      seeds.push(rnd())
      sizes.push(0.008 + rnd() * 0.016)
    }
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3))
    g.setAttribute('seed', new THREE.Float32BufferAttribute(seeds, 1))
    g.setAttribute('psize', new THREE.Float32BufferAttribute(sizes, 1))
    g.computeBoundingSphere()
    const mat = new THREE.ShaderMaterial({
      vertexShader: dustVert,
      fragmentShader: dustFrag,
      uniforms: {
        time: { value: 0 },
        scale: { value: 600 },
        map: { value: m.tex.particle },
        color: { value: new THREE.Color(1.0, 0.93, 0.8) },
        intensity: { value: 0.5 },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
    })
    return { geometry: g, material: mat }
  }, [defs, m.tex.particle])

  useFrame((state) => {
    material.uniforms.time.value = state.clock.elapsedTime
    const cam = camera as THREE.PerspectiveCamera
    material.uniforms.scale.value = (size.height * 0.5) / Math.tan((cam.fov * Math.PI) / 360)
  })
  return <points geometry={geometry} material={material} renderOrder={6} frustumCulled={false} />
}

function mulberry(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// ---------------------------------------------------------------------------
const skyVert = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vDir = wp.xyz - cameraPosition;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`
const skyFrag = /* glsl */ `
  uniform vec3 sunDir;
  varying vec3 vDir;
  void main() {
    vec3 d = normalize(vDir);
    float h = max(d.y, 0.0);
    vec3 zenith = vec3(0.24, 0.40, 0.70) * 1.0;
    vec3 horizon = vec3(0.76, 0.81, 0.85) * 1.22;
    vec3 col = mix(horizon, zenith, pow(h, 0.5));
    float s = max(dot(d, sunDir), 0.0);
    col += vec3(1.0, 0.93, 0.82) * (pow(s, 900.0) * 30.0 + pow(s, 12.0) * 0.6 + pow(s, 2.5) * 0.18);
    // haze/ground below horizon
    vec3 ground = vec3(0.56, 0.58, 0.58) * 1.0;
    col = mix(col, ground, clamp(-d.y * 10.0, 0.0, 1.0));
    gl_FragColor = vec4(col, 1.0);
  }
`

function SkyDome() {
  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: skyVert,
        fragmentShader: skyFrag,
        uniforms: { sunDir: { value: new THREE.Vector3(-SUN_DIR.x, -SUN_DIR.y, -SUN_DIR.z) } },
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
      }),
    [],
  )
  return (
    <mesh material={material} frustumCulled={false} renderOrder={-10}>
      <sphereGeometry args={[520, 32, 16]} />
    </mesh>
  )
}

// ---------------------------------------------------------------------------
function Sun() {
  const ref = useRef<THREE.DirectionalLight>(null)
  const frames = useRef(0)
  const { gl } = useThree()
  const target = useMemo(() => {
    const o = new THREE.Object3D()
    o.position.set(-12, 0, 6)
    o.updateMatrixWorld()
    return o
  }, [])
  useEffect(() => {
    gl.shadowMap.autoUpdate = true
    gl.shadowMap.needsUpdate = true
  }, [gl])
  useFrame(() => {
    const l = ref.current
    if (!l) return
    // static sun: render its shadow map only during the first frames
    frames.current++
    if (frames.current < 45) {
      l.shadow.needsUpdate = true
      l.shadow.autoUpdate = true
    } else if (frames.current === 45) {
      l.shadow.autoUpdate = false
    }
  })
  return (
    <group>
      <directionalLight
        ref={ref}
        position={[SUN_POS.x - 12, SUN_POS.y, SUN_POS.z + 6]}
        intensity={3.4}
        color="#fff2e0"
        castShadow
        target={target}
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0002}
        shadow-normalBias={0.04}
        shadow-camera-left={-58}
        shadow-camera-right={58}
        shadow-camera-top={58}
        shadow-camera-bottom={-58}
        shadow-camera-near={10}
        shadow-camera-far={170}
      />
      <primitive object={target} />
    </group>
  )
}

function BounceLights({ defs }: { defs: ShaftDef[] }) {
  const lights = useMemo(() => {
    const all = defs
      .map((d) => {
        const c = new THREE.Vector3()
        d.pts.forEach((p) => c.add(p))
        c.multiplyScalar(1 / d.pts.length)
        const w = d.pts[0].distanceTo(d.pts[1])
        const h = d.pts[1].distanceTo(d.pts[2])
        const patch = projectToFloor(c, d.floorY)
        return { pos: patch.add(new THREE.Vector3(0, 1.4, 0)), area: w * h * d.strength }
      })
      .sort((a, b) => b.area - a.area)
    // greedy spatial spread
    const chosen: typeof all = []
    for (const l of all) {
      if (chosen.length >= 9) break
      if (chosen.every((c) => c.pos.distanceTo(l.pos) > 5)) chosen.push(l)
    }
    return chosen
  }, [defs])
  return (
    <>
      {lights.map((l, i) => (
        <pointLight key={i} position={l.pos} intensity={1.0 + Math.min(1.9, l.area * 0.16)} distance={9} decay={2} color="#ffe2c4" />
      ))}
    </>
  )
}

// ---------------------------------------------------------------------------
// Baked environment probe: a one-off PMREM render of the sky/ground/sun used as reflection probe
// for metals, glass and wet floors (cheap stand-in for ray-traced reflections).
function BakedEnvironment() {
  const { scene } = useThree()
  useEffect(() => {
    // keep the probe for specular reflections but stop it flooding the interiors like ambient light
    scene.environmentIntensity = 0.5
  }, [scene])
  return (
    <Environment resolution={128} frames={1} background={false}>
      <color attach="background" args={['#8fb0cf']} />
      <Lightformer intensity={1.7} color="#c9dcf4" position={[0, 24, 0]} rotation-x={Math.PI / 2} scale={[120, 120, 1]} />
      <Lightformer intensity={5.5} color="#fff0d2" position={[-34, 16, 42]} scale={[18, 12, 1]} />
      <Lightformer intensity={1.2} color="#dce8f5" position={[40, 10, 18]} scale={[14, 9, 1]} />
      <Lightformer intensity={0.5} color="#6f6555" position={[0, -12, 0]} rotation-x={-Math.PI / 2} scale={[120, 120, 1]} />
    </Environment>
  )
}

// Soft sky/sun portals in the main openings. RectAreaLights give the soft directional
// window light (and specular highlights on wet floors / metal) that point lights cannot.
const AREA_LIGHTS = (() => {
  const tmp = sunlitOpenings()
  const items: { pos: THREE.Vector3; q: THREE.Quaternion; w: number; h: number; sun: boolean; power: number }[] = []
  const zAxis = new THREE.Vector3(0, 0, 1)
  for (const d of tmp) {
    if (!d.normal || !d.w || !d.h || !d.pts.length) continue
    if (d.pts[0].y > 30) continue
    const c = new THREE.Vector3()
    d.pts.forEach((p) => c.add(p))
    c.multiplyScalar(1 / d.pts.length)
    if (c.y < 0.4) continue
    const q = new THREE.Quaternion().setFromUnitVectors(zAxis, d.normal)
    items.push({ pos: c.clone().addScaledVector(d.normal, 0.18), q, w: Math.min(6, d.w), h: Math.min(5, d.h), sun: d.strength > 1.02, power: d.w * d.h * d.strength })
  }
  return items.sort((a, b) => b.power - a.power).slice(0, 7)
})()
let rectInit = false
function WindowAreaLights({ defs }: { defs: ShaftDef[] }) {
  const ready = useMemo(() => {
    if (!rectInit) {
      RectAreaLightUniformsLib.init()
      rectInit = true
    }
    return true
  }, [])
  void defs
  if (!ready) return null
  return (
    <group>
      {AREA_LIGHTS.map((a, i) => (
        <rectAreaLight
          key={i}
          position={a.pos}
          quaternion={a.q}
          width={a.w}
          height={a.h}
          intensity={a.sun ? 1.25 : 0.6}
          color={a.sun ? '#fff1d8' : '#cfdff2'}
        />
      ))}
    </group>
  )
}

// Light-probe style fills: precomputed soft bounce for rooms with no direct sun so no interior
// reads as a black hole. Values are baked once (cheap) instead of traced per frame.
const PROBES: { p: [number, number, number]; i: number; c: string; d: number }[] = [
  { p: [-22.6, 2.3, -4.0], i: 2.0, c: '#c9d7e6', d: 6.5 },
  { p: [-23.4, 5.5, -4.3], i: 2.1, c: '#d3e0ee', d: 6.5 },
  { p: [-34.0, 2.3, -7.2], i: 2.2, c: '#c6d4e2', d: 7.5 },
  { p: [-23.4, 2.4, -8.4], i: 2.1, c: '#c9d6e4', d: 7 },
  { p: [-34.0, 5.7, -7.2], i: 1.9, c: '#d0ddeb', d: 7 },
  { p: [-23.4, 5.7, -8.6], i: 2.0, c: '#d0ddeb', d: 7 },
  { p: [2.0, 2.6, -9.4], i: 1.6, c: '#c3d1de', d: 6.5 },
  { p: [7.0, 5.6, -9.2], i: 2.2, c: '#ffe6c2', d: 8.5 },
]
function RoomProbes() {
  return (
    <group>
      {PROBES.map((l, i) => (
        <pointLight key={i} position={l.p} intensity={l.i * 0.85} color={l.c} distance={l.d} decay={2} />
      ))}
    </group>
  )
}

export function Lighting() {
  const defs = useMemo(() => sunlitOpenings(), [])
  return (
    <group>
      <SkyDome />
      <Sun />
      <hemisphereLight args={['#a9c4e2', '#6d6455', 0.66]} />
      <ambientLight intensity={0.11} color="#d8e2ee" />
      <BakedEnvironment />
      <WindowAreaLights defs={defs} />
      <RoomProbes />
      <BounceLights defs={defs} />
      <LightShafts defs={defs} />
      <Dust defs={defs} />
    </group>
  )
}
