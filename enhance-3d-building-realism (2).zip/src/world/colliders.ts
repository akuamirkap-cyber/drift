import { wallColliders, type AABB } from './layout'
import { PROP_COLLIDERS } from './Props'
import { HOUSE_COLLIDERS } from './HouseProps'
import { ARCH_COLLIDERS } from './Architecture'
import { EXT_COLLIDERS } from './Exterior'

/** one shared immutable collider set for the player, squad AI and zombies */
export const ALL_COLLIDERS: AABB[] = [...wallColliders(), ...PROP_COLLIDERS, ...HOUSE_COLLIDERS, ...ARCH_COLLIDERS, ...EXT_COLLIDERS]
