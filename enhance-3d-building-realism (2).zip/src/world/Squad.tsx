import * as THREE from 'three'
import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { ALL_COLLIDERS } from './colliders'
import {
  HORDE,
  SOLDIERS,
  ZOMBIES,
  damageZombie,
  reviveSoldier,
  supportAt,
  syncHud,
} from './hordeState'
import { fx } from '../player/shared'
import { allyShot } from '../audio'
import { store } from '../state'

const SLOTS = [
  { side: -2.15, back: 2.2 },
  { side: 2.5, back: 0.7 },
  { side: -2.7, back: 0.3 },
  { side: 1.9, back: 3.0 },
]
const PALETTE = [
  { uniform: '#5c6647', vest: '#3b4332', helmet: '#4a5238', accent: '#7ce6ea' },
  { uniform: '#6b6a58', vest: '#43423a', helmet: '#55543f', accent: '#f0c46a' },
  { uniform: '#59605a', vest: '#393e3b', helmet: '#474d47', accent: '#e08a5a' },
  { uniform: '#66604d', vest: '#403c33', helmet: '#4f4a3b', accent: '#9fb8f0' },
]

const tmp = {
  q: new THREE.Quaternion(),
  m4: new THREE.Matrix4(),
  v: new THREE.Vector3(),
  s: new THREE.Vector3(),
}

function nametag(name: string, accent: string) {
  const c = document.createElement('canvas')
  c.width = 512
  c.height = 128
  const ctx = c.getContext('2d')!
  ctx.fillStyle = 'rgba(6,12,14,0.66)'
  ctx.fillRect(4, 20, 504, 80)
  ctx.strokeStyle = accent
  ctx.lineWidth = 4
  ctx.strokeRect(4, 20, 504, 80)
  ctx.fillStyle = '#e8fbfb'
  ctx.font = 'bold 44px monospace'
  ctx.fillText(name, 22, 74)
  ctx.fillStyle = accent
  ctx.font = '22px monospace'
  ctx.fillText('SQUAD · FRIENDLY', 22, 96)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

function buildSoldier(p: (typeof PALETTE)[number]) {
  const mats = {
    uniform: new THREE.MeshStandardMaterial({ color: p.uniform, roughness: 0.92 }),
    vest: new THREE.MeshStandardMaterial({ color: p.vest, roughness: 0.82 }),
    helmet: new THREE.MeshStandardMaterial({ color: p.helmet, roughness: 0.7 }),
    glove: new THREE.MeshStandardMaterial({ color: '#2a2824', roughness: 0.9 }),
    boot: new THREE.MeshStandardMaterial({ color: '#23231f', roughness: 0.95 }),
    gun: new THREE.MeshStandardMaterial({ color: '#2a2d30', roughness: 0.4, metalness: 0.7 }),
    accent: new THREE.MeshStandardMaterial({ color: p.accent, emissive: new THREE.Color(p.accent), emissiveIntensity: 0.9, roughness: 0.4 }),
  }
  const root = new THREE.Group()
  const body = new THREE.Group()
  root.add(body)
  const box = (mat: THREE.Material, s: [number, number, number], pos: [number, number, number], parent: THREE.Object3D = body) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(...s), mat)
    m.position.set(...pos)
    parent.add(m)
    return m
  }
  box(mats.uniform, [0.4, 0.26, 0.24], [0, 0.98, 0]) // hips
  box(mats.uniform, [0.44, 0.5, 0.26], [0, 1.28, 0]) // chest
  box(mats.vest, [0.48, 0.4, 0.31], [0, 1.3, 0])
  box(mats.vest, [0.3, 0.14, 0.06], [0, 1.34, 0.19])
  box(mats.accent, [0.05, 0.05, 0.02], [-0.14, 1.44, 0.16])
  box(mats.vest, [0.38, 0.4, 0.16], [0, 1.28, -0.21]) // pack
  box(mats.gun, [0.025, 0.2, 0.025], [0.16, 1.55, -0.27]) // antenna
  const head = new THREE.Group()
  head.position.set(0, 1.64, 0)
  body.add(head)
  box(mats.glove, [0.2, 0.2, 0.2], [0, 0, 0], head)
  const helm = box(mats.helmet, [0.24, 0.13, 0.25], [0, 0.11, 0], head)
  box(mats.helmet, [0.2, 0.05, 0.12], [0, 0.06, 0.11], head)
  box(mats.accent, [0.12, 0.03, 0.02], [0, 0.1, 0.13], head)
  helm.castShadow = false
  // arms
  const armL = new THREE.Group()
  armL.position.set(-0.3, 1.45, 0)
  body.add(armL)
  box(mats.uniform, [0.13, 0.3, 0.14], [0, -0.15, 0], armL)
  box(mats.uniform, [0.12, 0.28, 0.13], [0, -0.37, 0.12], armL)
  box(mats.glove, [0.1, 0.1, 0.1], [0, -0.48, 0.2], armL)
  const armR = new THREE.Group()
  armR.position.set(0.3, 1.45, 0)
  body.add(armR)
  box(mats.uniform, [0.13, 0.3, 0.14], [0, -0.16, -0.02], armR)
  box(mats.uniform, [0.12, 0.26, 0.13], [0, -0.37, 0.06], armR)
  box(mats.glove, [0.1, 0.1, 0.1], [0, -0.46, 0.14], armR)
  // legs
  const legL = new THREE.Group()
  legL.position.set(-0.12, 0.92, 0)
  body.add(legL)
  box(mats.uniform, [0.17, 0.46, 0.19], [0, -0.23, 0], legL)
  box(mats.boot, [0.16, 0.14, 0.27], [0, -0.85, 0.04], legL)
  const legR = new THREE.Group()
  legR.position.set(0.12, 0.92, 0)
  body.add(legR)
  box(mats.uniform, [0.17, 0.46, 0.19], [0, -0.23, 0], legR)
  box(mats.boot, [0.16, 0.14, 0.27], [0, -0.85, 0.04], legR)
  // rifle held ready
  const rifle = new THREE.Group()
  rifle.position.set(0.03, 1.16, 0.22)
  rifle.rotation.set(0.06, 0.1, 0.22)
  body.add(rifle)
  box(mats.gun, [0.055, 0.06, 0.6], [0, 0, 0], rifle)
  box(mats.gun, [0.045, 0.05, 0.24], [0, 0, -0.42], rifle)
  box(mats.gun, [0.05, 0.09, 0.15], [0, -0.06, 0.12], rifle)
  box(mats.gun, [0.045, 0.16, 0.07], [0, -0.12, 0.05], rifle)
  box(mats.gun, [0.04, 0.06, 0.12], [0, 0.025, -0.08], rifle)
  // muzzle flash sprite
  const flashMat = new THREE.SpriteMaterial({ color: '#ffd08a', blending: THREE.AdditiveBlending, depthWrite: false, transparent: true })
  const flash = new THREE.Sprite(flashMat)
  flash.scale.set(0.35, 0.35, 1)
  flash.position.set(0, 0.02, -0.62)
  flash.visible = false
  rifle.add(flash)
  root.traverse((o) => {
    const mesh = o as THREE.Mesh
    if (mesh.isMesh) {
      mesh.castShadow = false
      mesh.receiveShadow = true
    }
  })
  return { root, body, head, armL, armR, legL, legR, flash }
}

export function Squad() {
  const built = useMemo(() => SOLDIERS.map((_, i) => buildSoldier(PALETTE[i % PALETTE.length])), [])
  const tags = useMemo(() => SOLDIERS.map((s, i) => nametag(s.name, PALETTE[i % PALETTE.length].accent)), [])
  const tagSprites = useMemo(
    () =>
      tags.map((t) => {
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthWrite: false, depthTest: false }))
        sp.scale.set(0.95, 0.24, 1)
        sp.position.set(0, 2.12, 0)
        return sp
      }),
    [tags],
  )
  useEffect(() => {
    built.forEach((b, i) => b.root.add(tagSprites[i]))
    SOLDIERS.forEach((s) => {
      if (Math.hypot(s.pos.x - fx.px, s.pos.z - fx.pz) > 14) {
        s.pos.set(fx.px + (i2(s.slot) - 1) * 1.6, fx.py, fx.pz + 2.2)
      }
    })
  }, [built, tagSprites])

  const state = useRef({ held: false, revive: 0, reviveIdx: -1, shotCd: 0 })
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.code === 'KeyE') state.current.held = true
      if (e.code === 'KeyG' && !e.repeat) {
        HORDE.squadMode = HORDE.squadMode === 'follow' ? 'hold' : 'follow'
        for (const s of SOLDIERS) if (s.state !== 'down') s.state = HORDE.squadMode
        store.set({ squadMode: HORDE.squadMode })
        syncHud(true)
      }
    }
    const up = (e: KeyboardEvent) => {
      if (e.code === 'KeyE') state.current.held = false
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
    }
  }, [])

  // blob shadows for the squad
  const shadows = useMemo(() => {
    const im = new THREE.InstancedMesh(
      new THREE.CircleGeometry(0.46, 14).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.3, depthWrite: false }),
      4,
    )
    im.instanceMatrix.setUsage(THREE.DynamicDrawUsage)
    im.frustumCulled = false
    return im
  }, [])

  useFrame((_, rawDt) => {
    const dt = Math.min(0.05, rawDt)
    const st = state.current
    const pYaw = fx.yaw
    const fwdX = -Math.sin(pYaw)
    const fwdZ = -Math.cos(pYaw)
    const rightX = Math.cos(pYaw)
    const rightZ = -Math.sin(pYaw)

    // revive logic
    let nearestDown = -1
    let nearestD = 2.4
    for (const s of SOLDIERS) {
      if (s.state !== 'down') continue
      const d = Math.hypot(s.pos.x - fx.px, s.pos.z - fx.pz)
      if (d < nearestD) {
        nearestD = d
        nearestDown = s.id
      }
    }
    if (st.held && nearestDown >= 0) {
      if (st.reviveIdx !== nearestDown) {
        st.reviveIdx = nearestDown
        st.revive = 0
      }
      st.revive += dt / 2.3
      HORDE.reviveTarget = nearestDown
      HORDE.reviveProgress = Math.min(1, st.revive)
      if (st.revive >= 1) {
        const s = SOLDIERS.find((q) => q.id === nearestDown)
        if (s) reviveSoldier(s)
        st.revive = 0
        st.reviveIdx = -1
        HORDE.reviveTarget = -1
        HORDE.reviveProgress = 0
      }
    } else {
      st.revive = 0
      st.reviveIdx = -1
      HORDE.reviveTarget = -1
      HORDE.reviveProgress = 0
    }

    SOLDIERS.forEach((s, i) => {
      const rig = built[i]
      const slot = SLOTS[s.slot]
      // pick a target
      let best = -1
      let bestD = 32
      if (s.state !== 'down') {
        for (let k = 0; k < ZOMBIES.length; k++) {
          const z = ZOMBIES[k]
          if (z.state === 'dead') continue
          const d = Math.hypot(z.pos.x - s.pos.x, z.pos.z - s.pos.z)
          if (d < bestD) {
            bestD = d
            best = k
          }
        }
      }
      s.target = best
      const tz = best >= 0 ? ZOMBIES[best] : null

      // movement / formation
      let wantX = 0
      let wantZ = 0
      if (s.state === 'down') {
        wantX = 0
        wantZ = 0
      } else if (s.state === 'follow') {
        const back = slot.back
        const tx = fx.px + rightX * slot.side + fwdX * -back
        const tz2 = fx.pz + rightZ * slot.side + fwdZ * -back
        const dx = tx - s.pos.x
        const dz = tz2 - s.pos.z
        const d = Math.hypot(dx, dz)
        if (d > 0.55) {
          wantX = dx / d
          wantZ = dz / d
        }
      }
      // engage: sidestep to keep some spacing while shooting
      if (tz && bestD < 7 && s.state !== 'down' && Math.hypot(wantX, wantZ) < 0.1) {
        wantX = -fwdX * 0.25
        wantZ = -fwdZ * 0.25
      }
      const speed = bestD < 9 ? 2.1 : 4.2
      const step = speed * dt * (Math.abs(wantX) + Math.abs(wantZ) > 0 ? 1 : 0)
      const bx = s.pos.x
      const bz = s.pos.z
      s.pos.x += wantX * step
      s.pos.z += wantZ * step
      for (const c of ALL_COLLIDERS) {
        if (c.maxY <= s.pos.y + 0.4) continue
        if (c.minY >= s.pos.y + 1.7) continue
        const cx = Math.max(c.minX, Math.min(c.maxX, s.pos.x))
        const cz = Math.max(c.minZ, Math.min(c.maxZ, s.pos.z))
        const ddx = s.pos.x - cx
        const ddz = s.pos.z - cz
        const d2 = ddx * ddx + ddz * ddz
        if (d2 >= 0.34 * 0.34 || d2 < 1e-8) continue
        const d = Math.sqrt(d2)
        const push = 0.34 - d
        s.pos.x += (ddx / d) * push
        s.pos.z += (ddz / d) * push
      }
      const sup = supportAt(s.pos.x, s.pos.z, s.pos.y)
      if (sup > s.pos.y + 0.5) {
        s.pos.x = bx
        s.pos.z = bz
      } else {
        s.pos.y += (sup - s.pos.y) * Math.min(1, dt * 12)
      }

      // facing / aiming
      let faceYaw = s.yaw
      const moving = Math.hypot(wantX, wantZ) > 0.05
      if (tz && s.state !== 'down') {
        faceYaw = Math.atan2(tz.pos.x - s.pos.x, tz.pos.z - s.pos.z)
      } else if (moving) faceYaw = Math.atan2(wantX, wantZ)
      else if (s.state !== 'down') faceYaw = Math.atan2(fx.px - s.pos.x, fx.pz - s.pos.z)
      const diff = ((faceYaw - s.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI
      s.yaw += diff * Math.min(1, dt * 7)

      // fire
      s.fireCd -= dt
      s.muzzle = Math.max(0, s.muzzle - dt)
      if (tz && s.state !== 'down' && s.fireCd <= 0 && bestD < 28) {
        s.fireCd = 0.95 + Math.random() * 0.7 + (s.role === 'MARKSMAN' ? 0.55 : 0)
        s.mag--
        if (s.mag <= 0) {
          s.mag = 30
          s.fireCd += 1.6
        }
        s.muzzle = 0.05
        allyShot(Math.hypot(s.pos.x - fx.px, s.pos.z - fx.pz))
        const dmg = s.role === 'MARKSMAN' ? 34 : 21
        const head = Math.random() < (s.role === 'MARKSMAN' ? 0.35 : 0.14)
        const killed = damageZombie(best, dmg, head)
        if (killed) s.kills++
      }

      // animate
      s.phase += dt * (moving ? 7.5 : 1.4)
      const amp = moving ? 1 : 0
      const sw = Math.sin(s.phase) * 0.55 * amp
      rig.legL.rotation.x = sw
      rig.legR.rotation.x = -sw
      rig.armL.rotation.x = -sw * 0.25 - (tz ? 0.15 : 0)
      rig.armR.rotation.x = sw * 0.25 - (tz ? 0.15 : 0)
      rig.body.position.y = Math.abs(Math.sin(s.phase * 2)) * 0.02 * amp
      rig.body.rotation.z = Math.sin(s.phase) * 0.015 * amp
      rig.head.rotation.y = tz ? Math.max(-0.3, Math.min(0.3, diff)) : Math.sin(performance.now() * 0.0006 + i) * 0.2
      rig.flash.visible = s.muzzle > 0
      if (rig.flash.visible) {
        const fs = 0.25 + Math.random() * 0.18
        rig.flash.scale.set(fs, fs, 1)
        rig.flash.material.rotation = Math.random() * 3
      }
      if (s.state === 'down') {
        rig.root.rotation.z += ((Math.PI / 2) * 0.94 - rig.root.rotation.z) * Math.min(1, dt * 5)
        rig.body.position.y += (-0.55 - rig.body.position.y) * Math.min(1, dt * 5)
      } else {
        rig.root.rotation.z += (0 - rig.root.rotation.z) * Math.min(1, dt * 6)
        rig.body.position.y += (0 - rig.body.position.y) * Math.min(1, dt * 8)
      }
      rig.root.position.set(s.pos.x, s.pos.y, s.pos.z)
      rig.root.rotation.y = s.yaw
      tagSprites[i].visible = Math.hypot(s.pos.x - fx.px, s.pos.z - fx.pz) < 18 && s.state !== 'down'

      tmp.m4.compose(tmp.v.set(s.pos.x, s.pos.y + 0.012, s.pos.z), tmp.q, tmp.s.set(1, 1, 1))
      shadows.setMatrixAt(i, tmp.m4)
    })
    shadows.instanceMatrix.needsUpdate = true
  }, 0)

  return (
    <group>
      {built.map((b, i) => (
        <primitive key={i} object={b.root} />
      ))}
      <primitive object={shadows} />
    </group>
  )
}

function i2(n: number) {
  return n % 3
}
