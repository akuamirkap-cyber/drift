import * as THREE from 'three'
import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { ALL_COLLIDERS } from './colliders'
import {
  HORDE,
  MAX_ALIVE,
  ZOMBIES,
  SOLDIERS,
  updateHorde,
  nearestLivingTarget,
  damagePlayer,
  damageSoldier,
  supportAt,
} from './hordeState'
import { zombieGroan, zombieBite } from '../audio'

const R = 0.32
const ZERO = new THREE.Vector3(0.0001, 0.0001, 0.0001)

const VARIANTS = [
  { shirt: '#4a4a3f', pants: '#353730', skin: '#7d8a6c' },
  { shirt: '#3b4348', pants: '#2f3236', skin: '#8a927d' },
  { shirt: '#5a4034', pants: '#3a322c', skin: '#77826a' },
  { shirt: '#6e2b2b', pants: '#33251f', skin: '#6f7c61' },
]

export function Zombies() {
  const start = useRef(performance.now())
  // park every instance off-screen until the first zombie spawns (prevents a stack at the world origin)
  useEffect(() => {
    const away = new THREE.Matrix4().compose(new THREE.Vector3(0, -500, 0), new THREE.Quaternion(), new THREE.Vector3(0.0001, 0.0001, 0.0001))
    for (const key of ['torso', 'head', 'armL', 'armR', 'legL', 'legR'] as const) {
      const m = meshesRef.current?.[key]
      if (m) for (let i = 0; i < MAX_ALIVE; i++) m.setMatrixAt(i, away)
    }
  }, [])
  const meshes = useMemo(() => {
    const mk = (geo: THREE.BufferGeometry, mat: THREE.Material) => {
      const m = new THREE.InstancedMesh(geo, mat, MAX_ALIVE)
      m.instanceMatrix.setUsage(THREE.DynamicDrawUsage)
      m.frustumCulled = false
      m.castShadow = false
      m.receiveShadow = false
      m.userData.zombiePart = 'body'
      return m
    }
    const shirtMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.92, metalness: 0 })
    shirtMat.vertexColors = true
    const skinMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.86, metalness: 0.02 })
    skinMat.vertexColors = true
    const pantsMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.95 })
    pantsMat.vertexColors = true
    const torso = mk(new THREE.BoxGeometry(0.47, 0.62, 0.28), shirtMat)
    torso.userData.zombiePart = 'body'
    const head = mk(new THREE.BoxGeometry(0.26, 0.3, 0.27), skinMat)
    head.userData.zombiePart = 'head'
    const armGeo = new THREE.BoxGeometry(0.135, 0.64, 0.15).translate(0, -0.32, 0)
    const armL = mk(armGeo, skinMat)
    armL.userData.zombiePart = 'arm'
    const armR = mk(armGeo, skinMat)
    armR.userData.zombiePart = 'arm'
    const legGeo = new THREE.BoxGeometry(0.18, 0.86, 0.21).translate(0, -0.43, 0)
    const legL = mk(legGeo, pantsMat)
    legL.userData.zombiePart = 'leg'
    const legR = mk(legGeo, pantsMat)
    legR.userData.zombiePart = 'leg'
    const shadow = new THREE.InstancedMesh(
      new THREE.CircleGeometry(0.52, 14).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.32, depthWrite: false }),
      MAX_ALIVE,
    )
    shadow.instanceMatrix.setUsage(THREE.DynamicDrawUsage)
    shadow.frustumCulled = false
    return { torso, head, armL, armR, legL, legR, shadow }
  }, [])

  const meshesRef = useRef<Record<string, THREE.InstancedMesh> | null>(null)
  meshesRef.current = meshes as unknown as Record<string, THREE.InstancedMesh>
  const tmp = useMemo(
    () => ({
      m4: new THREE.Matrix4(),
      qRoot: new THREE.Quaternion(),
      qPart: new THREE.Quaternion(),
      eRoot: new THREE.Euler(0, 0, 0, 'YXZ'),
      ePart: new THREE.Euler(0, 0, 0, 'XYZ'),
      off: new THREE.Vector3(),
      pos: new THREE.Vector3(),
      col: new THREE.Color(),

      qOut: new THREE.Quaternion(),
      scale: new THREE.Vector3(),
      shadowQ: new THREE.Quaternion(),
      shadowP: new THREE.Vector3(),
    }),
    [],
  )

  useFrame((_, rawDt) => {
    const dt = Math.min(0.05, rawDt)
    const now = (performance.now() - start.current) / 1000
    updateHorde(dt, now)
    const active = typeof document !== 'undefined' && document.pointerLockElement !== null
    const { m4, qRoot, qPart, eRoot, ePart, off, pos, col } = tmp
    const M = meshes

    for (const z of ZOMBIES) {
      const dead = z.state === 'dead'
      if (dead) z.deathT += dt
      z.hitT = Math.max(0, z.hitT - dt)
      z.lunge = Math.max(0, z.lunge - dt * 4)

      if (!dead && active) {
        const target = nearestLivingTarget(z.pos.x, z.pos.z)
        let dx = 0
        let dz = 0
        let dist = 99
        if (target) {
          dx = target.x - z.pos.x
          dz = target.z - z.pos.z
          dist = Math.hypot(dx, dz)
        }
        // separation so the horde does not stack into one blob
        let sx = 0
        let sz = 0
        for (const o of ZOMBIES) {
          if (o === z || o.state === 'dead') continue
          const ox = z.pos.x - o.pos.x
          const oz = z.pos.z - o.pos.z
          const d2 = ox * ox + oz * oz
          if (d2 > 0.0001 && d2 < 1.7) {
            const d = Math.sqrt(d2)
            sx += (ox / d) * (1.3 - d)
            sz += (oz / d) * (1.3 - d)
          }
        }
        let wishX = 0
        let wishZ = 0
        const attacking = dist < 1.25
        if (target && !attacking) {
          wishX = dx / dist + sx * 0.55
          wishZ = dz / dist + sz * 0.55
          const wl = Math.hypot(wishX, wishZ) || 1
          wishX /= wl
          wishZ /= wl
        }
        const speed = attacking ? 0 : z.speed * (z.variant === 3 ? 1.05 : 1)
        const step = speed * dt
        const bx = z.pos.x
        const bz = z.pos.z
        z.pos.x += wishX * step
        z.pos.z += wishZ * step
        // static collision
        const feet = z.pos.y
        for (let pass = 0; pass < 2; pass++) {
          for (const c of ALL_COLLIDERS) {
            if (c.maxY <= feet + 0.35) continue
            if (c.minY >= feet + 1.8) continue
            const cx = Math.max(c.minX, Math.min(c.maxX, z.pos.x))
            const cz = Math.max(c.minZ, Math.min(c.maxZ, z.pos.z))
            const ddx = z.pos.x - cx
            const ddz = z.pos.z - cz
            const d2 = ddx * ddx + ddz * ddz
            if (d2 >= R * R) continue
            if (d2 < 1e-8) {
              const pdx = Math.min(z.pos.x - c.minX, c.maxX - z.pos.x)
              const pdz = Math.min(z.pos.z - c.minZ, c.maxZ - z.pos.z)
              if (pdx < pdz) z.pos.x += pdx + R
              else z.pos.z += pdz + R
              continue
            }
            const d = Math.sqrt(d2)
            const push = R - d
            z.pos.x += (ddx / d) * push
            z.pos.z += (ddz / d) * push
          }
        }
        // vertical: follow ground, refuse tall steps (keeps the horde on the correct level)
        const sup = supportAt(z.pos.x, z.pos.z, z.pos.y)
        if (sup > z.pos.y + 0.45) {
          z.pos.x = bx
          z.pos.z = bz
          z.stuck += dt
        } else {
          z.pos.y += (sup - z.pos.y) * Math.min(1, dt * 12)
          z.stuck = Math.max(0, z.stuck - dt)
        }
        if (z.stuck > 0.55 && target) {
          // slide along the obstacle
          z.pos.x += -dz / (dist || 1) * step * 1.2
          z.pos.z += dx / (dist || 1) * step * 1.2
          if (z.stuck > 2.4) z.stuck = 0
        }
        const face = target ? Math.atan2(dx, dz) : z.yaw
        const diff = ((face - z.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI
        z.yaw += diff * Math.min(1, dt * 6)
        z.phase += dt * (attacking ? 5 : speed * 3.4)
        // attack
        z.attackCd -= dt
        if (target && dist < 1.35 && z.attackCd <= 0) {
          z.attackCd = 1.15 - Math.min(0.35, HORDE.wave * 0.02)
          z.lunge = 1
          const dmg = 8 + HORDE.wave * 0.7 + (z.variant === 3 ? 5 : 0)
          if (target.kind === 'player') {
            damagePlayer(dmg, z.pos)
            zombieBite()
          } else {
            const s = SOLDIERS.find((q) => q.id === target.idx)
            if (s) {
              damageSoldier(s, dmg)
              zombieBite()
            }
          }
          if (Math.random() < 0.25) zombieGroan()
        }
      }

      // ---------------- build the instance matrices ----------------
      const fall = dead ? Math.min(1, z.deathT / 0.55) * 1.42 : 0
      const sink = dead ? Math.min(0.14, Math.max(0, z.deathT - 0.3) * 0.3) : 0
      const hittilt = z.hitT > 0 ? Math.sin(z.hitT * 60) * 0.12 : 0
      const lean = yawLean(z)
      eRoot.set(fall, z.yaw, hittilt, 'YXZ')
      qRoot.setFromEuler(eRoot)
      pos.set(z.pos.x, z.pos.y - sink, z.pos.z)
      const sc = z.scale
      const S = tmp.scale.set(sc, sc, sc)
      const bob = dead ? 0 : Math.sin(z.phase * 2) * 0.025
      const swing = dead ? 0 : Math.sin(z.phase) * 0.62
      const armBase = dead ? 0.25 : -1.05 + Math.sin(z.phase) * 0.16 - z.lunge * 0.5
      const bodyLean = dead ? 0 : lean
      const hidden = dead && z.deathT > 8

      const write = (mesh: THREE.InstancedMesh, ox: number, oy: number, oz: number, rotX = 0, rotY = 0, rotZ = 0) => {
        if (hidden) {
          tmp.shadowP.set(0, -500, 0)
          m4.compose(tmp.shadowP, qRoot, ZERO)
        } else {
          ePart.set(rotX, rotY, rotZ, 'XYZ')
          qPart.setFromEuler(ePart)
          const q = tmp.qOut.copy(qRoot).multiply(qPart)
          off.set(ox, oy + bob, oz).applyQuaternion(qRoot).add(pos)
          m4.compose(off, q, S)
        }
        mesh.setMatrixAt(z.slot, m4)
      }
      write(M.torso, 0, 1.16, 0, bodyLean, dead ? 0.28 : 0.16 * Math.sin(z.sway + z.phase * 0.3))
      write(M.head, 0, 1.64, 0.04, dead ? 0.4 : 0.12 + Math.sin(z.phase * 0.7 + z.sway) * 0.1, 0, dead ? 0.5 : Math.sin(z.phase * 0.5) * 0.14)
      write(M.armL, -0.31, 1.44, 0, armBase)
      write(M.armR, 0.31, 1.44, 0, dead ? 0.5 : armBase + Math.sin(z.phase + 1.6) * 0.18)
      write(M.legL, -0.13, 0.88, 0, closedSwing(swing))
      write(M.legR, 0.13, 0.88, 0, closedSwing(-swing))
      // blob shadow
      if (hidden) tmp.shadowP.set(0, -500, 0)
      else tmp.shadowP.set(z.pos.x, z.pos.y + 0.012, z.pos.z)
      tmp.m4.compose(tmp.shadowP, tmp.shadowQ, tmp.scale.set(dead ? 1.25 * sc : sc, 1, sc))
      M.shadow.setMatrixAt(z.slot, tmp.m4)

      // clothing tint (only when variant colour changes)
      const color = VARIANTS[z.variant]
      col.set(color.shirt)
      M.torso.setColorAt(z.slot, col)
      col.set(color.skin)
      M.head.setColorAt(z.slot, col)
      M.armL.setColorAt(z.slot, col)
      M.armR.setColorAt(z.slot, col)
      col.set(color.pants)
      M.legL.setColorAt(z.slot, col)
      M.legR.setColorAt(z.slot, col)
    }
    for (const key of ['torso', 'head', 'armL', 'armR', 'legL', 'legR', 'shadow'] as const) {
      const m = M[key]
      m.instanceMatrix.needsUpdate = true
      if (m.instanceColor) m.instanceColor.needsUpdate = true
    }
  }, -1)

  return (
    <group>
      <primitive object={meshes.torso} />
      <primitive object={meshes.head} />
      <primitive object={meshes.armL} />
      <primitive object={meshes.armR} />
      <primitive object={meshes.legL} />
      <primitive object={meshes.legR} />
      <primitive object={meshes.shadow} />
    </group>
  )
}

function closedSwing(v: number) {
  return Math.max(-0.75, Math.min(0.75, v * 0.8))
}
function yawLean(z: { variant: number; phase: number }) {
  return Math.sin(z.phase * 0.9) * 0.055 + (z.variant === 3 ? 0.16 : 0)
}
