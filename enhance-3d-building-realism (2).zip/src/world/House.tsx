import * as THREE from 'three'
import { useMemo } from 'react'
import { WALLS, HOUSE, H_CEIL1, H_CEIL2, F2, H_STAIR, H_STAIR_Z_TOP, H_STAIR_HOLE, H_ROOF_HOLES } from './layout'
import { useMaterials, floorGeometry, slabGeometry, rectPoly } from './materials'
import { HouseDoorFrame } from './Openings'

type V3 = [number, number, number]

// ---------------------------------------------------------------------------
/** skirting boards + cornices on every house wall face (instanced) */
function Trim() {
  const m = useMaterials()
  const mesh = useMemo(() => {
    const mats: THREE.Matrix4[] = []
    const q = new THREE.Quaternion()
    const qz = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, Math.PI / 2, 0))
    const add = (cx: number, cy: number, cz: number, sx: number, sy: number, sz: number, rot: boolean) =>
      mats.push(new THREE.Matrix4().compose(new THREE.Vector3(cx, cy, cz), rot ? qz : q, new THREE.Vector3(sx, sy, sz)))
    for (const w of WALLS) {
      if (!w.trim) continue
      const faces = w.trim === 'both' ? [-1, 1] : w.trim === 'neg' ? [-1] : [1]
      const gaps = w.openings.filter((o) => o.b <= 0.1 && (o.kind === 'door' || o.kind === 'hole')).sort((a, b) => a.at - b.at)
      const segs: [number, number][] = []
      let cur = w.u0
      for (const g of gaps) {
        segs.push([cur, g.at - g.w / 2 - 0.1])
        cur = g.at + g.w / 2 + 0.1
      }
      segs.push([cur, w.u0 + w.len])
      const ceilY = w.y < 1 ? H_CEIL1 : H_CEIL2
      for (const f of faces) {
        const off = f * (w.t / 2 + 0.014)
        for (const [s0, s1] of segs) {
          if (s1 - s0 < 0.05) continue
          const uc = (s0 + s1) / 2
          const L = s1 - s0
          if (w.axis === 'x') add(w.x + uc, w.y + 0.07, w.z + off, L, 0.14, 0.026, false)
          else add(w.x + off, w.y + 0.07, w.z + uc, L, 0.14, 0.026, true)
        }
        const offc = f * (w.t / 2 + 0.03)
        const uc = w.u0 + w.len / 2
        if (w.axis === 'x') add(w.x + uc, ceilY - 0.04, w.z + offc, w.len, 0.08, 0.06, false)
        else add(w.x + offc, ceilY - 0.04, w.z + uc, w.len, 0.08, 0.06, true)
      }
    }
    const im = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), m.paintWhite, Math.max(1, mats.length))
    mats.forEach((mm, i) => im.setMatrixAt(i, mm))
    im.count = mats.length
    im.instanceMatrix.needsUpdate = true
    im.castShadow = true
    im.receiveShadow = true
    im.frustumCulled = false
    return im
  }, [m])
  return <primitive object={mesh} />
}

// ---------------------------------------------------------------------------
function Floors() {
  const m = useMaterials()
  const W = HOUSE.xMax - HOUSE.xMin
  const D = HOUSE.zMax - HOUSE.zMin
  const cx = (HOUSE.xMin + HOUSE.xMax) / 2
  const cz = (HOUSE.zMin + HOUSE.zMax) / 2
  const geos = useMemo(
    () => ({
      wood: floorGeometry(W, D, cx, cz),
      kitchen: floorGeometry(5.3, 7.5, -34.05, -7.25),
      pantry: floorGeometry(5.3, 3.5, -39.35, -5.25),
      laundry: floorGeometry(5.3, 4, -39.35, -9),
      backWing: floorGeometry(6.4, 8.5, -23.4, -6.75),
      bath: floorGeometry(6.4, 3.5, -23.4, -4.25),
      slab: slabGeometry(HOUSE.xMin + 0.15, -19.85, HOUSE.zMin + 0.15, HOUSE.zMax - 0.15, [rectPoly(H_STAIR_HOLE.xMin, H_STAIR_HOLE.xMax, H_STAIR_HOLE.zMin, H_STAIR_HOLE.zMax)], F2 - H_CEIL1),
      roof: slabGeometry(HOUSE.xMin - 0.3, -19.9, HOUSE.zMin - 0.3, HOUSE.zMax + 0.3, H_ROOF_HOLES.map((h) => h.poly), 0.3),
    }),
    [W, D, cx, cz],
  )
  return (
    <group>
      <mesh geometry={geos.wood} material={m.wood} position={[cx, 0.002, cz]} receiveShadow />
      <mesh geometry={geos.kitchen} material={m.tileFloor} position={[-34.05, 0.006, -7.25]} receiveShadow />
      <mesh geometry={geos.pantry} material={m.tileFloor} position={[-39.35, 0.006, -5.25]} receiveShadow />
      <mesh geometry={geos.laundry} material={m.tileFloor} position={[-39.35, 0.006, -9]} receiveShadow />
      <mesh geometry={geos.backWing} material={m.tileFloor} position={[-23.4, 0.006, -6.75]} receiveShadow />
      {/* first floor slab: ceiling below, floorboards on top */}
      <mesh geometry={geos.slab} material={[m.ceiling, m.reveal, m.wood]} position={[0, H_CEIL1, 0]} castShadow receiveShadow />
      <mesh geometry={geos.bath} material={m.tileFloor} position={[-23.4, F2 + 0.006, -4.25]} receiveShadow />
      {/* roof slab with collapsed areas */}
      <mesh geometry={geos.roof} material={[m.ceiling, m.reveal, m.deck]} position={[0, H_CEIL2, 0]} castShadow receiveShadow />
      {/* parapet */}
      <mesh position={[cx - 0.1, H_CEIL2 + 0.5, HOUSE.zMin - 0.2]} material={m.brickWhite} castShadow receiveShadow>
        <boxGeometry args={[W + 0.6, 0.4, 0.25]} />
      </mesh>
      <mesh position={[cx - 0.1, H_CEIL2 + 0.5, HOUSE.zMax + 0.2]} material={m.brickWhite} castShadow receiveShadow>
        <boxGeometry args={[W + 0.6, 0.4, 0.25]} />
      </mesh>
      {/* west parapet split by the roof-access opening */}
      <mesh position={[HOUSE.xMin - 0.2, H_CEIL2 + 0.5, (HOUSE.zMin - 0.3 + -7.9) / 2]} material={m.brickWhite} castShadow receiveShadow>
        <boxGeometry args={[0.25, 0.4, -7.9 - (HOUSE.zMin - 0.3)]} />
      </mesh>
      <mesh position={[HOUSE.xMin - 0.2, H_CEIL2 + 0.5, (-6.7 + HOUSE.zMax + 0.3) / 2]} material={m.brickWhite} castShadow receiveShadow>
        <boxGeometry args={[0.25, 0.4, HOUSE.zMax + 0.3 - -6.7]} />
      </mesh>
    </group>
  )
}

// ---------------------------------------------------------------------------
function NewelPost({ x, y, z }: { x: number; y: number; z: number }) {
  const m = useMaterials()
  return (
    <group position={[x, y, z]}>
      <mesh position={[0, 0.55, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[0.13, 1.1, 0.13]} />
      </mesh>
      <mesh position={[0, 1.12, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[0.17, 0.05, 0.17]} />
      </mesh>
      <mesh position={[0, 1.2, 0]} castShadow receiveShadow material={m.paintWhite}>
        <sphereGeometry args={[0.07, 16, 12]} />
      </mesh>
    </group>
  )
}

function Stairs() {
  const m = useMaterials()
  const S = H_STAIR
  const rh = S.rise / S.steps
  const td = S.run / S.steps
  const xMid = (S.xMin + S.xMax) / 2
  const width = S.xMax - S.xMin
  const L = Math.hypot(S.run, S.rise)
  const slope = Math.atan2(S.rise, S.run)
  const zMid = (S.zBottom + H_STAIR_Z_TOP) / 2

  const steps = useMemo(() => {
    const arr: { tread: V3; riser: V3 }[] = []
    for (let i = 0; i < S.steps; i++) {
      arr.push({
        tread: [xMid, (i + 1) * rh - 0.02, S.zBottom - (i + 0.5) * td],
        riser: [xMid, (i + 0.5) * rh, S.zBottom - i * td + 0.005],
      })
    }
    return arr
  }, [S, rh, td, xMid])

  const balusterMesh = useMemo(() => {
    const list: { p: V3; h: number }[] = []
    for (let i = 0; i < S.steps; i++) {
      list.push({ p: [S.xMin + 0.02, (i + 1) * rh + 0.45, S.zBottom - (i + 0.5) * td], h: 0.9 })
    }
    const n1 = Math.round((H_STAIR_HOLE.zMax - H_STAIR_HOLE.zMin) / 0.16)
    for (let i = 1; i < n1; i++) list.push({ p: [H_STAIR_HOLE.xMin + 0.02, F2 + 0.47, H_STAIR_HOLE.zMin + (i / n1) * (H_STAIR_HOLE.zMax - H_STAIR_HOLE.zMin)], h: 0.94 })
    const n2 = Math.round((H_STAIR_HOLE.xMax - H_STAIR_HOLE.xMin) / 0.16)
    for (let i = 1; i < n2; i++) list.push({ p: [H_STAIR_HOLE.xMin + (i / n2) * (H_STAIR_HOLE.xMax - H_STAIR_HOLE.xMin), F2 + 0.47, H_STAIR_HOLE.zMax - 0.02], h: 0.94 })
    const geo = new THREE.BoxGeometry(0.035, 1, 0.035)
    const mesh = new THREE.InstancedMesh(geo, m.paintWhite, list.length)
    const mat = new THREE.Matrix4()
    const q = new THREE.Quaternion()
    list.forEach((b, i) => {
      mat.compose(new THREE.Vector3(...b.p), q, new THREE.Vector3(1, b.h, 1))
      mesh.setMatrixAt(i, mat)
    })
    mesh.instanceMatrix.needsUpdate = true
    mesh.castShadow = true
    mesh.receiveShadow = true
    return mesh
  }, [S, rh, td, m.paintWhite])

  const panelGeo = useMemo(() => {
    const zStart = S.zBottom - (0.26 * S.run) / S.rise
    const s = new THREE.Shape()
    s.moveTo(zStart, 0)
    s.lineTo(H_STAIR_Z_TOP, 0)
    s.lineTo(H_STAIR_Z_TOP, S.rise - 0.26)
    s.closePath()
    return new THREE.ShapeGeometry(s)
  }, [S])

  return (
    <group>
      {steps.map((s, i) => (
        <group key={i}>
          <mesh position={s.tread} castShadow receiveShadow material={m.woodDark}>
            <boxGeometry args={[width, 0.04, td + 0.03]} />
          </mesh>
          <mesh position={s.riser} castShadow receiveShadow material={m.paintCream}>
            <boxGeometry args={[width, rh, 0.025]} />
          </mesh>
        </group>
      ))}
      <mesh position={[S.xMin + 0.02, S.rise / 2 - 0.08, zMid]} rotation={[slope, 0, 0]} castShadow receiveShadow material={m.paintCream}>
        <boxGeometry args={[0.05, 0.3, L + 0.1]} />
      </mesh>
      <mesh position={[xMid, S.rise / 2 - 0.2, zMid]} rotation={[slope, 0, 0]} receiveShadow material={m.paintCream}>
        <boxGeometry args={[width, 0.03, L]} />
      </mesh>
      <mesh position={[S.xMin + 0.02, S.rise / 2 + 0.92, zMid]} rotation={[slope, 0, 0]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[0.07, 0.07, L + 0.15]} />
      </mesh>
      <mesh position={[H_STAIR_HOLE.xMin + 0.02, F2 + 0.96, (H_STAIR_HOLE.zMin + H_STAIR_HOLE.zMax) / 2]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[0.07, 0.07, H_STAIR_HOLE.zMax - H_STAIR_HOLE.zMin]} />
      </mesh>
      <mesh position={[(H_STAIR_HOLE.xMin + H_STAIR_HOLE.xMax) / 2, F2 + 0.96, H_STAIR_HOLE.zMax - 0.02]} castShadow receiveShadow material={m.paintWhite}>
        <boxGeometry args={[H_STAIR_HOLE.xMax - H_STAIR_HOLE.xMin, 0.07, 0.07]} />
      </mesh>
      <NewelPost x={S.xMin + 0.02} y={0} z={S.zBottom + 0.08} />
      <NewelPost x={S.xMin + 0.02} y={F2} z={H_STAIR_Z_TOP - 0.06} />
      <NewelPost x={H_STAIR_HOLE.xMin + 0.02} y={F2} z={H_STAIR_HOLE.zMax - 0.02} />
      <primitive object={balusterMesh} />
      {/* spandrel panel + closet door at the top end */}
      <mesh geometry={panelGeo} position={[S.xMin - 0.01, 0, 0]} rotation={[0, -Math.PI / 2, 0]} receiveShadow material={m.paintCream} />
      <group position={[xMid, 0, H_STAIR_Z_TOP + 0.1]}>
        <HouseDoorFrame o={{ at: 0, w: 0.8, b: 0, t: 1.95, kind: 'door', leaf: 'closed' }} t={0.1} leafMat={m.paintCream} />
        <mesh position={[0, (1.95 + H_CEIL1) / 2 + 0.05, 0]} receiveShadow material={m.wallStripe}>
          <boxGeometry args={[width, H_CEIL1 - 1.95 - 0.1, 0.1]} />
        </mesh>
      </group>
    </group>
  )
}

// ---------------------------------------------------------------------------
function CollapsedRoof() {
  const m = useMaterials()
  const { x, z } = H_ROOF_HOLES[0]
  const y = H_CEIL2
  const wire = useMemo(() => {
    const mk = (pts: V3[]) => new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p))), 12, 0.009, 6, false)
    return [
      mk([[x + 0.2, y + 0.1, z - 0.6], [x + 0.25, y - 0.5, z - 0.5], [x + 0.1, y - 1.3, z - 0.55], [x + 0.3, y - 1.9, z - 0.4]]),
      mk([[x - 0.6, y + 0.1, z + 0.2], [x - 0.55, y - 0.6, z + 0.3], [x - 0.7, y - 1.1, z + 0.25]]),
    ]
  }, [x, y, z])
  return (
    <group>
      <mesh position={[x - 1.1, y + 0.14, z - 0.4]} material={m.woodDark} castShadow receiveShadow>
        <boxGeometry args={[0.08, 0.2, 2.4]} />
      </mesh>
      <mesh position={[x + 0.4, y + 0.14, z + 0.3]} rotation={[0, 0.05, 0]} material={m.woodDark} castShadow receiveShadow>
        <boxGeometry args={[0.08, 0.2, 1.8]} />
      </mesh>
      <mesh position={[x + 1.0, y + 0.14, z]} material={m.woodDark} castShadow receiveShadow>
        <boxGeometry args={[0.08, 0.2, 2.6]} />
      </mesh>
      <mesh position={[x - 0.3, y - 0.5, z + 0.9]} rotation={[0.9, 0.2, 0]} material={m.woodDark} castShadow receiveShadow>
        <boxGeometry args={[0.08, 0.16, 1.3]} />
      </mesh>
      <mesh position={[x + 0.9, y - 0.6, z - 0.9]} rotation={[-1.1, 0.3, 0.2]} material={m.ceiling} castShadow receiveShadow>
        <boxGeometry args={[0.12, 0.03, 1.1]} />
      </mesh>
      <mesh position={[x - 1.2, y - 0.3, z - 0.2]} rotation={[0.4, 0, -0.7]} material={m.ceiling} castShadow receiveShadow>
        <boxGeometry args={[0.4, 0.02, 0.8]} />
      </mesh>
      {wire.map((g, i) => (
        <mesh key={i} geometry={g} material={m.black} castShadow />
      ))}
      {/* broken skylight frame over the bathroom */}
      <mesh position={[H_ROOF_HOLES[1].x, y + 0.2, H_ROOF_HOLES[1].z]} material={m.steelDark} castShadow>
        <boxGeometry args={[1.3, 0.06, 0.06]} />
      </mesh>
      <mesh position={[H_ROOF_HOLES[1].x + 0.3, y - 0.3, H_ROOF_HOLES[1].z + 0.2]} rotation={[0.8, 0.3, 0]} material={m.glass}>
        <planeGeometry args={[0.6, 0.5]} />
      </mesh>
    </group>
  )
}

// ---------------------------------------------------------------------------
export function House() {
  return (
    <group>
      <Floors />
      <Trim />
      <Stairs />
      <CollapsedRoof />
    </group>
  )
}
