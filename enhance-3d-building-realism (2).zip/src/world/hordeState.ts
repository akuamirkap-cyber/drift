import * as THREE from 'three'
import { store } from '../state'
import { fx } from '../player/shared'
import { floorHeightAt } from './layout'
import { waveHorn } from '../audio'

export type ZombieState = 'walk' | 'attack' | 'dead'
export type SquadState = 'follow' | 'hold' | 'down'
export type HordePhase = 'prep' | 'active' | 'clear' | 'killed'

export interface Zombie {
  id: number
  slot: number
  pos: THREE.Vector3
  yaw: number
  hp: number
  maxHp: number
  speed: number
  state: ZombieState
  attackCd: number
  deathT: number
  phase: number
  variant: number
  hitT: number
  lunge: number
  stuck: number
  sway: number
  scale: number
}

export interface Soldier {
  id: number
  name: string
  role: string
  pos: THREE.Vector3
  yaw: number
  hp: number
  maxHp: number
  state: SquadState
  fireCd: number
  mag: number
  muzzle: number
  aimAt: number
  reviveT: number
  kills: number
  downT: number
  phase: number
  slot: number
  target: number
}

const SPAWNS: [number, number][] = [
  [-7, 36.4],
  [-22, 36.2],
  [14, 36.4],
  [33, 30],
  [33, -26],
  [-56, 30],
  [-56, 8],
  [-56, -22],
  [-30, -24],
  [26, -26],
  [33, 8],
  [-40, 35],
  [-2, 35.6],
  [20, 33.5],
]
const SQUAD_DEF: { name: string; role: string; slot: number; ox: number; oz: number }[] = [
  { name: 'GHOST-2', role: 'SUPPORT', slot: 0, ox: -1.9, oz: 2.5 },
  { name: 'ALPHA', role: 'RIFLEMAN', slot: 1, ox: 2.4, oz: 0.6 },
  { name: 'BRAVO', role: 'BREACHER', slot: 2, ox: -2.5, oz: 0.2 },
  { name: 'CHARLIE', role: 'MARKSMAN', slot: 3, ox: 1.8, oz: 2.7 },
]

export const ZOMBIES: Zombie[] = []
export const SOLDIERS: Soldier[] = []
export const MAX_ALIVE = 26
export const SPAWN_POINTS = SPAWNS

export const HORDE = {
  started: false,
  wave: 0,
  phase: 'prep' as HordePhase,
  timer: 14,
  toSpawn: 0,
  spawnCd: 0,
  alive: 0,
  kills: 0,
  headshots: 0,
  playerHp: 100,
  maxHp: 100,
  lastDamage: -999,
  down: false,
  downT: 0,
  respawnPending: false,
  spawnCursor: 0,
  squadMode: 'follow' as 'follow' | 'hold',
  reviveTarget: -1,
  reviveProgress: 0,
  held: false,
  eliteWave: 0,
}

export function initHorde() {
  ZOMBIES.length = 0
  SOLDIERS.length = 0
  const px = fx.px
  const pz = fx.pz
  SQUAD_DEF.forEach((d, i) => {
    const sx = px + Math.cos(fx.yaw) * d.ox - Math.sin(fx.yaw) * d.oz
    const sz = pz - Math.sin(fx.yaw) * d.ox - Math.cos(fx.yaw) * d.oz
    SOLDIERS.push({
      id: i,
      name: d.name,
      role: d.role,
      pos: new THREE.Vector3(sx, 0, sz),
      yaw: fx.yaw,
      hp: 100,
      maxHp: 100,
      state: 'follow',
      fireCd: 0.6 + i * 0.25,
      mag: 30,
      muzzle: 0,
      aimAt: -1,
      reviveT: 0,
      kills: 0,
      downT: 0,
      phase: 0,
      slot: d.slot,
      target: -1,
    })
  })
  HORDE.down = false
  HORDE.downT = 0
  HORDE.respawnPending = false
  HORDE.reviveTarget = -1
  HORDE.reviveProgress = 0
  Object.assign(HORDE, {
    started: false,
    wave: 0,
    phase: 'prep',
    timer: 14,
    toSpawn: 0,
    spawnCd: 0,
    alive: 0,
    kills: 0,
    headshots: 0,
    playerHp: 100,
    lastDamage: -999,
    down: false,
    downT: 0,
    respawnPending: false,
    spawnCursor: 0,
    squadMode: 'follow',
    reviveTarget: -1,
    reviveProgress: 0,
    eliteWave: 0,
  })
}

export function wavePlan(wave: number) {
  const count = Math.min(44, 7 + Math.floor(wave * 3.4))
  const hp = Math.min(320, 95 + wave * 17)
  const speed = Math.min(2.75, 1.16 + wave * 0.075)
  return { count, hp, speed }
}

function spawnOne() {
  const plan = wavePlan(HORDE.wave)
  let slot = -1
  for (let i = 0; i < MAX_ALIVE; i++) if (!ZOMBIES.some((z) => z.slot === i && z.state !== 'dead')) { slot = i; break }
  if (slot < 0) return false
  // pick a spawn point away from the player
  let best = 0
  let bestD = -1
  for (let k = 0; k < 4; k++) {
    const cand = (HORDE.spawnCursor + k) % SPAWNS.length
    const [x, z] = SPAWNS[cand]
    const d = Math.hypot(x - fx.px, z - fx.pz)
    if (d > bestD) {
      bestD = d
      best = cand
    }
  }
  HORDE.spawnCursor = (best + 1) % SPAWNS.length
  const [sx, sz] = SPAWNS[best]
  const elite = HORDE.wave >= 4 && Math.random() < 0.12
  const body = {
    id: Math.random(),
    slot,
    pos: new THREE.Vector3(sx + (Math.random() - 0.5) * 1.6, 0, sz + (Math.random() - 0.5) * 1.6),
    yaw: Math.random() * 6.28,
    hp: plan.hp * (elite ? 1.8 : 1),
    maxHp: plan.hp * (elite ? 1.8 : 1),
    speed: plan.speed * (elite ? 0.82 : 0.92 + Math.random() * 0.2),
    state: 'walk' as const,
    attackCd: 0.4 + Math.random() * 0.5,
    deathT: 0,
    phase: Math.random() * 6.28,
    variant: elite ? 3 : Math.floor(Math.random() * 3),
    hitT: 0,
    lunge: 0,
    stuck: 0,
    sway: Math.random() * 6.28,
    scale: elite ? 1.14 : 0.94 + Math.random() * 0.12,
  }
  // recycle a fully faded corpse so the array/index length stays bounded
  const existing = ZOMBIES.find((z) => z.slot === slot)
  if (existing) {
    if (existing.state === 'dead' && existing.deathT > 5) Object.assign(existing, body)
    else return false
  } else if (ZOMBIES.length >= MAX_ALIVE) return false
  else ZOMBIES.push(body as Zombie)
  return true
}

export function nearestLivingTarget(x: number, z: number): { kind: 'player' | 'soldier'; idx: number; x: number; y: number; z: number; d: number } | null {
  let best: { kind: 'player' | 'soldier'; idx: number; x: number; y: number; z: number; d: number } | null = null
  if (!HORDE.down) {
    const d = Math.hypot(fx.px - x, fx.pz - z)
    best = { kind: 'player', idx: -1, x: fx.px, y: fx.py, z: fx.pz, d }
  }
  for (const s of SOLDIERS) {
    if (s.state === 'down') continue
    const d = Math.hypot(s.pos.x - x, s.pos.z - z)
    if (!best || d < best.d - 0.8) best = { kind: 'soldier', idx: s.id, x: s.pos.x, y: s.pos.y, z: s.pos.z, d }
  }
  return best
}

export function damageZombie(index: number, dmg: number, headshot: boolean): boolean {
  const z = ZOMBIES[index]
  if (!z || z.state === 'dead') return false
  z.hp -= dmg * (headshot ? 2.3 : 1)
  z.hitT = 0.14
  if (z.hp <= 0) {
    z.state = 'dead'
    z.deathT = 0
    z.hp = 0
    HORDE.kills++
    if (headshot) HORDE.headshots++
    return true
  }
  return false
}

export function zombieBySlot(slot: number): Zombie | undefined {
  for (const z of ZOMBIES) if (z.slot === slot) return z
  return undefined
}

/** used by the weapon raycaster: instanced meshes carry the slot id */
export function damageZombieSlot(slot: number, dmg: number, headshot: boolean): boolean {
  let idx = -1
  for (let i = 0; i < ZOMBIES.length; i++) if (ZOMBIES[i].slot === slot) { idx = i; break }
  if (idx < 0) return false
  const res = damageZombie(idx, dmg, headshot)
  syncHud()
  return res
}

export function damageSoldier(s: Soldier, dmg: number) {
  if (s.state === 'down') return
  s.hp -= dmg
  if (s.hp <= 0) {
    s.hp = 0
    s.state = 'down'
    s.downT = 0
    s.reviveT = 0
  }
}

export function reviveSoldier(s: Soldier) {
  if (s.state !== 'down') return
  s.hp = 60
  s.state = HORDE.squadMode === 'follow' ? 'follow' : 'hold'
  s.reviveT = 0
}

export function damagePlayer(dmg: number, _from: THREE.Vector3) {
  if (HORDE.down || HORDE.phase === 'killed') return
  HORDE.playerHp = Math.max(0, HORDE.playerHp - dmg)
  HORDE.lastDamage = performance.now() / 1000
  if (HORDE.playerHp <= 0) {
    HORDE.playerHp = 0
    HORDE.down = true
    HORDE.downT = 0
  }
  store.set({ health: Math.ceil(HORDE.playerHp), damageId: store.get().damageId + 1 })
}

export function takeRespawn(): boolean {
  if (!HORDE.respawnPending) return false
  HORDE.respawnPending = false
  HORDE.playerHp = HORDE.maxHp
  HORDE.down = false
  HORDE.downT = 0
  HORDE.lastDamage = performance.now() / 1000
  for (const s of SOLDIERS) if (s.state === 'down') reviveSoldier(s)
  store.set({ health: HORDE.maxHp, playerDown: false })
  return true
}

let hudCache = ''
export function syncHud(force = false) {
  const squad = SOLDIERS.map((s) => ({ name: s.name, role: s.role, hp: Math.round(s.hp), max: s.maxHp, state: s.state, kills: s.kills }))
  const zb = ZOMBIES.filter((z) => z.state !== 'dead' && z.deathT === 0).slice(0, 40).map((z) => `${z.pos.x.toFixed(1)},${z.pos.z.toFixed(1)}`).join('|')
  const sb = SOLDIERS.map((s) => `${s.pos.x.toFixed(1)},${s.pos.z.toFixed(1)},${s.state}`).join('|')
  const key = `${zb}|${sb}|${Math.ceil(HORDE.playerHp)}|${HORDE.wave}|${HORDE.phase}|${Math.ceil(HORDE.timer)}|${HORDE.alive}|${HORDE.kills}|${HORDE.squadMode}|${HORDE.down}|${squad.map((x) => `${x.hp}${x.state}${x.kills}`).join(',')}|${HORDE.reviveTarget}|${Math.round(HORDE.reviveProgress * 10)}`
  if (!force && key === hudCache) return
  hudCache = key
  store.set({
    health: Math.ceil(HORDE.playerHp),
    squad,
    wave: HORDE.wave,
    hordePhase: HORDE.phase,
    waveTimer: Math.ceil(HORDE.timer),
    zombiesAlive: HORDE.alive,
    zombiesLeft: HORDE.toSpawn + HORDE.alive,
    kills: HORDE.kills,
    headshots: HORDE.headshots,
    squadMode: HORDE.squadMode,
    playerDown: HORDE.down,
    reviveTarget: HORDE.reviveTarget,
    reviveProgress: HORDE.reviveProgress,
    zombieBlips: zb,
    squadBlips: sb,
  })
}

/** wave director + player regen; called once per frame from the horde renderer */
export function updateHorde(dt: number, now: number) {
  HORDE.alive = ZOMBIES.reduce((n, z) => n + (z.state !== 'dead' ? 1 : 0), 0)
  const locked = typeof document !== 'undefined' && document.pointerLockElement !== null
  if (!HORDE.started && locked) {
    HORDE.started = true
    HORDE.timer = 12
  }
  if (!HORDE.started) return

  if (HORDE.down) {
    HORDE.downT += dt
    if (HORDE.downT > 4.5) HORDE.respawnPending = true
  } else if (now - HORDE.lastDamage > 6.5 && HORDE.playerHp < HORDE.maxHp) {
    HORDE.playerHp = Math.min(HORDE.maxHp, HORDE.playerHp + dt * 9)
  }

  if (HORDE.phase === 'prep') {
    HORDE.timer -= dt
    if (HORDE.timer <= 0) {
      HORDE.wave++
      const plan = wavePlan(HORDE.wave)
      HORDE.toSpawn = plan.count
      HORDE.phase = 'active'
      HORDE.spawnCd = 0
      HORDE.eliteWave = Math.floor(HORDE.wave / 4)
      waveHorn()
    }
  } else if (HORDE.phase === 'active') {
    if (HORDE.toSpawn > 0) {
      HORDE.spawnCd -= dt
      if (HORDE.spawnCd <= 0 && HORDE.alive < MAX_ALIVE) {
        if (spawnOne()) HORDE.toSpawn--
        HORDE.spawnCd = Math.max(0.35, 1.15 - HORDE.wave * 0.05)
      }
    } else if (HORDE.alive === 0) {
      HORDE.phase = 'clear'
      HORDE.timer = 9
    }
  } else if (HORDE.phase === 'clear') {
    HORDE.timer -= dt
    if (HORDE.timer <= 0) {
      HORDE.phase = 'prep'
      HORDE.timer = 8
    }
  }
  // regen soldiers slowly out of combat
  for (const s of SOLDIERS) {
    if (s.state === 'down') {
      s.downT += dt
      continue
    }
    if (s.hp < s.maxHp && now - HORDE.lastDamage > 7) s.hp = Math.min(s.maxHp, s.hp + dt * 3.5)
  }
  syncHud()
}

/** exposed for the squad AI: line of sight against the static colliders */
export function losClear(ax: number, az: number, bx: number, bz: number, colliders: { minX: number; maxX: number; minZ: number; maxZ: number; maxY: number }[], eyeY = 1.4) {
  if (eyeY < 1.2) return true
  const dx = bx - ax
  const dz = bz - az
  const n = Math.min(10, Math.max(3, Math.round(Math.hypot(dx, dz) / 2.4)))
  for (let i = 1; i < n; i++) {
    const t = i / n
    const x = ax + dx * t
    const z = az + dz * t
    for (const c of colliders) {
      if (c.maxY < 0.9) continue
      if (x > c.minX - 0.15 && x < c.maxX + 0.15 && z > c.minZ - 0.15 && z < c.maxZ + 0.15) return false
    }
  }
  return true
}

export function supportAt(x: number, z: number, y: number) {
  return floorHeightAt(x, z, y)
}

// build the initial squad immediately so the renderer has valid state on first frame
initHorde()
