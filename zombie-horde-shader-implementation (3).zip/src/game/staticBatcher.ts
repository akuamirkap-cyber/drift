import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { BreakableGlassPane } from './compoundBuilder';

/**
 * =====================================================================================
 *  STATIC MESH BATCHER  —  the #1 FPS fix
 * =====================================================================================
 *  The original world was ~2 700 separate meshes (≈3 900 draw calls per frame once the
 *  shadow pass is counted). Draw-call overhead on the CPU, not the GPU, was the bottleneck.
 *
 *  This pass bakes every STATIC opaque mesh into big merged chunks, grouped by
 *  (material × shadow flags × 40 m grid cell), so frustum culling still works.
 *
 *  The ORIGINAL meshes are kept (moved under a hidden group) so every raycast in the game
 *  — bullets, bot line-of-sight, autofocus, sun-occlusion — still hits exact geometry,
 *  and all interactive things (doors, glass, targets, props with userData) are untouched.
 *  Visuals are pixel-identical; only the number of draw calls changes.
 * =====================================================================================
 */

const CELL = 40;
const MAX_SOURCE_VERTS = 7000; // big meshes (terrain…) gain nothing from merging

export interface BatchStats {
  sourceMeshes: number;
  mergedMeshes: number;
}

function harvest(value: unknown, out: Set<THREE.Object3D>, depth = 0) {
  if (!value || depth > 3) return;
  if (value instanceof THREE.Object3D) {
    value.traverse((o) => out.add(o));
    return;
  }
  if (Array.isArray(value)) {
    for (const v of value) harvest(v, out, depth + 1);
    return;
  }
  if (typeof value === 'object') {
    for (const v of Object.values(value as Record<string, unknown>)) {
      if (v instanceof THREE.Object3D || Array.isArray(v) || (typeof v === 'object' && v !== null && depth < 2)) {
        harvest(v, out, depth + 1);
      }
    }
  }
}

function isBatchableMaterial(m: THREE.Material): boolean {
  const mm = m as THREE.Material & {
    isMeshStandardMaterial?: boolean;
    isMeshLambertMaterial?: boolean;
    isMeshPhongMaterial?: boolean;
    isMeshBasicMaterial?: boolean;
  };
  if (m.visible === false) return false;
  return Boolean(mm.isMeshStandardMaterial || mm.isMeshLambertMaterial || mm.isMeshPhongMaterial || mm.isMeshBasicMaterial);
}

function sliceGeometry(g: THREE.BufferGeometry, start: number, count: number): THREE.BufferGeometry {
  const out = new THREE.BufferGeometry();
  for (const name of Object.keys(g.attributes)) {
    const a = g.attributes[name] as THREE.BufferAttribute;
    const arr = (a.array as Float32Array).slice(start * a.itemSize, (start + count) * a.itemSize);
    out.setAttribute(name, new THREE.BufferAttribute(arr, a.itemSize, a.normalized));
  }
  return out;
}

interface Entry {
  geo: THREE.BufferGeometry;
  mat: THREE.Material;
  cast: boolean;
  recv: boolean;
  cx: number;
  cz: number;
  sig: string;
}

/**
 * @param scene         scene that owns the world
 * @param dynamicRoots  anything that moves / changes at runtime (doors, glass panes, targets…)
 */
export function batchStaticMeshes(scene: THREE.Scene, dynamicRoots: unknown[]): BatchStats {
  scene.updateMatrixWorld(true);

  const dynamic = new Set<THREE.Object3D>();
  for (const r of dynamicRoots) harvest(r, dynamic);

  const entries: Entry[] = [];
  const sources: THREE.Mesh[] = [];

  scene.traverse((o) => {
    const mesh = o as THREE.Mesh & { isInstancedMesh?: boolean; isSkinnedMesh?: boolean };
    if (!mesh.isMesh || mesh.isInstancedMesh || mesh.isSkinnedMesh) return;
    if (dynamic.has(mesh) || !mesh.visible || mesh.renderOrder !== 0) return;
    if (Object.keys(mesh.userData).length > 0) return;
    if (mesh.layers.mask !== 1) return;

    // every ancestor must be visible & plain (no userData such as door / target ids)
    for (let p = mesh.parent; p && p !== scene; p = p.parent) {
      if (!p.visible || dynamic.has(p) || Object.keys(p.userData).length > 0) return;
    }

    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    if (mats.length === 0 || !mats.every(isBatchableMaterial)) return;
    const g0 = mesh.geometry;
    if (!g0.attributes.position || g0.morphAttributes.position) return;
    const vcount = g0.index ? g0.index.count : g0.attributes.position.count;
    if (vcount > MAX_SOURCE_VERTS) return;
    if (mesh.matrixWorld.determinant() <= 0) return;
    if (Array.isArray(mesh.material) && g0.groups.length === 0) return;

    const g = g0.index ? g0.toNonIndexed() : g0.clone();
    if (!g.attributes.normal) g.computeVertexNormals();
    g.applyMatrix4(mesh.matrixWorld);
    g.computeBoundingBox();
    const c = g.boundingBox!.getCenter(new THREE.Vector3());
    const cx = Math.floor(c.x / CELL);
    const cz = Math.floor(c.z / CELL);

    const pushEntry = (geo: THREE.BufferGeometry, mat: THREE.Material) => {
      // keep only attributes shared by the merge group signature
      const names = Object.keys(geo.attributes).sort();
      const sig = names.map((n) => `${n}:${(geo.attributes[n] as THREE.BufferAttribute).itemSize}`).join(',');
      entries.push({ geo, mat, cast: mesh.castShadow, recv: mesh.receiveShadow, cx, cz, sig });
    };

    if (Array.isArray(mesh.material)) {
      for (const grp of g.groups) {
        const mat = mesh.material[grp.materialIndex ?? 0];
        if (!mat || grp.count <= 0) continue;
        pushEntry(sliceGeometry(g, grp.start, grp.count), mat);
      }
    } else {
      g.clearGroups();
      pushEntry(g, mesh.material);
    }
    sources.push(mesh);
  });

  // group → merge
  const groups = new Map<string, Entry[]>();
  for (const e of entries) {
    const key = `${e.mat.uuid}|${e.sig}|${e.cast ? 1 : 0}${e.recv ? 1 : 0}|${e.cx},${e.cz}`;
    let arr = groups.get(key);
    if (!arr) {
      arr = [];
      groups.set(key, arr);
    }
    arr.push(e);
  }

  const batchRoot = new THREE.Group();
  batchRoot.name = 'static-batches';
  let merged = 0;
  for (const arr of groups.values()) {
    const geo = arr.length === 1 ? arr[0].geo : mergeGeometries(arr.map((a) => a.geo), false);
    if (!geo) continue;
    geo.computeBoundingBox();
    const center = geo.boundingBox!.getCenter(new THREE.Vector3());
    geo.translate(-center.x, -center.y, -center.z);
    geo.computeBoundingSphere();
    const mesh = new THREE.Mesh(geo, arr[0].mat);
    mesh.position.copy(center);
    mesh.castShadow = arr[0].cast;
    mesh.receiveShadow = arr[0].recv;
    mesh.matrixAutoUpdate = false;
    mesh.updateMatrix();
    mesh.updateMatrixWorld(true);
    mesh.userData.isFx = true; // never a gameplay raycast target — the hidden originals are
    mesh.raycast = () => {};
    batchRoot.add(mesh);
    merged++;
  }
  scene.add(batchRoot);

  // originals stay for raycasts only: hidden group is skipped by every render pass
  const hidden = new THREE.Group();
  hidden.name = 'static-originals-raycast-only';
  hidden.visible = false;
  hidden.matrixAutoUpdate = false;
  scene.add(hidden);
  for (const m of sources) {
    hidden.attach(m);
    m.matrixAutoUpdate = false;
  }
  hidden.updateMatrixWorld(true);

  return { sourceMeshes: sources.length, mergedMeshes: merged };
}


/**
 * Double-sided transparent materials are drawn in TWO passes by three.js (back faces, then front faces).
 * For flat, non-depth-writing things (window glass, decals) a single pass is visually identical → half the draw calls.
 */
export function optimizeTransparentMaterials(root: THREE.Object3D): number {
  const done = new Set<THREE.Material>();
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const m of mats) {
      if (done.has(m)) continue;
      if (m.transparent && m.side === THREE.DoubleSide && (m.depthWrite === false || mesh.geometry.type === 'PlaneGeometry')) {
        m.forceSinglePass = true;
        done.add(m);
      }
    }
  });
  return done.size;
}

/**
 * Local-space batching for ANIMATED hierarchies (bots, doors, targets).
 * Inside every node, its direct rigid child meshes are baked into one mesh per material, expressed in that
 * node's local space — so the merged mesh follows the node's animation for free.
 * Originals stay (hidden) as exact raycast / hit-box proxies, so userData (botId, doorId, targetId…) keeps working.
 */
export function batchGroupsLocal(root: THREE.Object3D, exclude: THREE.Object3D[] = []): number {
  const skip = new Set<THREE.Object3D>();
  for (const e of exclude) e.traverse((o) => skip.add(o));
  const nodes: THREE.Object3D[] = [];
  root.traverse((o) => {
    if (o.children.length >= 2) nodes.push(o);
  });

  let created = 0;
  for (const node of nodes) {
    const entries: Entry[] = [];
    const used: THREE.Mesh[] = [];
    for (const child of node.children) {
      const mesh = child as THREE.Mesh & { isInstancedMesh?: boolean; isSkinnedMesh?: boolean };
      if (!mesh.isMesh || mesh.isInstancedMesh || mesh.isSkinnedMesh || skip.has(mesh)) continue;
      if (!mesh.visible || mesh.renderOrder !== 0 || mesh.layers.mask !== 1) continue;
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      if (mats.length === 0 || !mats.every((m) => isBatchableMaterial(m) && !m.transparent)) continue;
      const g0 = mesh.geometry;
      if (!g0.attributes.position || g0.morphAttributes.position) continue;
      if (Array.isArray(mesh.material) && g0.groups.length === 0) continue;
      mesh.updateMatrix();
      if (mesh.matrix.determinant() <= 0) continue;

      const g = g0.index ? g0.toNonIndexed() : g0.clone();
      if (!g.attributes.normal) g.computeVertexNormals();
      g.applyMatrix4(mesh.matrix);

      const push = (geo: THREE.BufferGeometry, mat: THREE.Material) => {
        const names = Object.keys(geo.attributes).sort();
        const sig = names.map((n) => `${n}:${(geo.attributes[n] as THREE.BufferAttribute).itemSize}`).join(',');
        entries.push({ geo, mat, cast: mesh.castShadow, recv: mesh.receiveShadow, cx: 0, cz: 0, sig });
      };
      if (Array.isArray(mesh.material)) {
        for (const grp of g.groups) {
          const mat = mesh.material[grp.materialIndex ?? 0];
          if (mat && grp.count > 0) push(sliceGeometry(g, grp.start, grp.count), mat);
        }
      } else {
        g.clearGroups();
        push(g, mesh.material);
      }
      used.push(mesh);
    }
    if (used.length < 2) continue;

    const groups = new Map<string, Entry[]>();
    for (const e of entries) {
      const key = `${e.mat.uuid}|${e.sig}|${e.cast ? 1 : 0}${e.recv ? 1 : 0}`;
      const arr = groups.get(key);
      if (arr) arr.push(e);
      else groups.set(key, [e]);
    }
    for (const arr of groups.values()) {
      const geo = arr.length === 1 ? arr[0].geo : mergeGeometries(arr.map((a) => a.geo), false);
      if (!geo) continue;
      geo.computeBoundingSphere();
      const merged = new THREE.Mesh(geo, arr[0].mat);
      merged.castShadow = arr[0].cast;
      merged.receiveShadow = arr[0].recv;
      merged.userData.isFx = true;
      merged.raycast = () => {};
      node.add(merged);
      created++;
    }
    for (const m of used) {
      m.visible = false; // hidden raycast proxy, still a child so it follows the animation
      m.matrixAutoUpdate = false; // rigid inside its parent → local matrix never changes (saves per-frame compose)
    }
  }
  return created;
}


/**
 * INTACT window panes are drawn as a few merged chunks. A pane that gets cracked / shattered is released:
 * its triangles collapse to a point in the chunk and the original pane mesh (which carries the crack
 * texture, hit-box userData and shatter logic) takes over. resetAll() restores everything.
 */
export class GlassBatch {
  private entries = new Map<
    string,
    { geo: THREE.BufferGeometry; start: number; saved: Float32Array; hidden: boolean; pane: BreakableGlassPane }
  >();

  constructor(scene: THREE.Scene, panes: BreakableGlassPane[], excludeRoots: THREE.Object3D[] = []) {
    scene.updateMatrixWorld(true);
    const movers = new Set<THREE.Object3D>(excludeRoots);
    const underMover = (o: THREE.Object3D) => {
      for (let p: THREE.Object3D | null = o; p; p = p.parent) if (movers.has(p)) return true;
      return false;
    };
    const groups = new Map<string, { pane: BreakableGlassPane; geo: THREE.BufferGeometry }[]>();
    for (const pane of panes) {
      const mat = pane.mesh.material as THREE.Material;
      if (Array.isArray(pane.mesh.material) || !pane.mesh.visible) continue;
      if (underMover(pane.mesh)) continue; // glass inside a swinging door: keep it parented so it moves with the door
      const g = pane.mesh.geometry.index ? pane.mesh.geometry.toNonIndexed() : pane.mesh.geometry.clone();
      g.applyMatrix4(pane.mesh.matrixWorld);
      for (const n of Object.keys(g.attributes)) if (n !== 'position' && n !== 'normal' && n !== 'uv') g.deleteAttribute(n);
      g.computeBoundingBox();
      const c = g.boundingBox!.getCenter(new THREE.Vector3());
      const key = `${mat.uuid}|${Math.floor(c.x / CELL)},${Math.floor(c.z / CELL)}`;
      const arr = groups.get(key);
      if (arr) arr.push({ pane, geo: g });
      else groups.set(key, [{ pane, geo: g }]);
    }

    const root = new THREE.Group();
    root.name = 'glass-batches';
    for (const arr of groups.values()) {
      const merged = mergeGeometries(arr.map((a) => a.geo), false);
      if (!merged) continue;
      merged.computeBoundingBox();
      const center = merged.boundingBox!.getCenter(new THREE.Vector3());
      merged.translate(-center.x, -center.y, -center.z);
      merged.computeBoundingSphere();
      const pos = merged.attributes.position as THREE.BufferAttribute;
      let offset = 0;
      for (const { pane, geo } of arr) {
        const vc = geo.attributes.position.count;
        this.entries.set(pane.id, {
          geo: merged,
          start: offset,
          saved: (pos.array as Float32Array).slice(offset * 3, (offset + vc) * 3),
          hidden: false,
          pane,
        });
        offset += vc;
      }
      const mesh = new THREE.Mesh(merged, arr[0].pane.mesh.material as THREE.Material);
      mesh.position.copy(center);
      mesh.receiveShadow = arr[0].pane.mesh.receiveShadow;
      mesh.matrixAutoUpdate = false;
      mesh.updateMatrix();
      mesh.userData.isFx = true;
      mesh.raycast = () => {};
      root.add(mesh);
      for (const { pane } of arr) pane.mesh.visible = false; // hidden raycast proxy
    }
    scene.add(root);
  }

  /** call BEFORE a pane is cracked or shattered */
  public release(pane: BreakableGlassPane) {
    const e = this.entries.get(pane.id);
    if (!e || e.hidden) return;
    const pos = e.geo.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    const n = e.saved.length / 3;
    const x = e.saved[0];
    const y = e.saved[1];
    const z = e.saved[2];
    for (let i = 0; i < n; i++) {
      arr[(e.start + i) * 3] = x;
      arr[(e.start + i) * 3 + 1] = y;
      arr[(e.start + i) * 3 + 2] = z;
    }
    pos.needsUpdate = true;
    e.hidden = true;
    pane.mesh.visible = true;
  }

  /** all panes back to intact + batched (after the engine reset them) */
  public resetAll() {
    for (const e of this.entries.values()) {
      if (e.hidden) {
        const pos = e.geo.attributes.position as THREE.BufferAttribute;
        (pos.array as Float32Array).set(e.saved, e.start * 3);
        pos.needsUpdate = true;
        e.hidden = false;
      }
      e.pane.mesh.visible = false;
    }
  }
}
