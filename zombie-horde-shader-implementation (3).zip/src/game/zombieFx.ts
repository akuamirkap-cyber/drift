import * as THREE from 'three';
import { createStylizedHeadGeometry } from '../skins/common';
import {
  createHairStyleGeometry,
  createZombieForearmClawGeometry,
  createZombieShinFootGeometry,
  getZombieEyeTexture,
  getZombieFaceTexture,
  HAIR_COLORS,
  HAIR_STYLE_COUNT,
  HEAD_VARIANTS,
} from '../skins/zombieCrowd';
import type { ZombieShootResult } from '../skins/zombieCrowd';
import type { BoxCollider3D } from './compoundBuilder';

/**
 * =====================================================================================
 *  ZOMBIE IMPACT FX  +  DEAD-ISLAND STYLE BLOOD
 * =====================================================================================
 *  Pack effects (kept):   shock ring · flesh gibs · flying skull · torn-off clawed limbs
 *  Dead Island blood:
 *    • stretched wet droplets (GPU instanced) that fly in cones, blow back at the shooter and exit behind the target
 *    • every droplet that lands leaves a splat: on the GROUND (streaked along its flight) and on WALLS (with drips)
 *    • drifting red mist puffs
 *    • ARTERIAL SPRAY: a decapitated body pumps blood from the neck with a heartbeat rhythm
 *    • blood TRAIL from bodies that fly / slide, then a spreading POOL under every corpse
 *    • returns a "lens" strength so the HUD can splatter the camera lens when it happens up close
 *  Everything is pooled / instanced — no per-shot allocations, zero GC hitches.
 * =====================================================================================
 */

const MAX_DROPS = 1500;
const MAX_SPOTS = 1800;
const MAX_POOLS = 72;
const MAX_PUFFS = 160;

interface Particle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  age: number;
  life: number;
  gravity: number;
  baseScale: number;
  ring: boolean;
}
interface Gib {
  obj: THREE.Object3D;
  vel: THREE.Vector3;
  spin: THREE.Vector3;
  age: number;
  life: number;
}
interface Bleeder {
  key: number;
  t: number;
  life: number;
  kind: 'neck' | 'trail';
  acc: number;
  decalAcc: number;
  get: (pos: THREE.Vector3, vel: THREE.Vector3) => boolean;
}

const _dir = new THREE.Vector3();
const _side = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _p = new THREE.Vector3();
const _v = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _q2 = new THREE.Quaternion();
const _qAlign = new THREE.Quaternion();
const _n = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _s = new THREE.Vector3();
const _Z = new THREE.Vector3(0, 0, 1);
const rnd = (a: number, b: number) => a + Math.random() * (b - a);

function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** white-on-transparent splat: ragged core, tapered streaks with round tips, flung satellite droplets */
function makeSplatTexture(kind: 'spot' | 'pool' | 'soft'): THREE.CanvasTexture {
  const S = 256;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d')!;
  const r = mulberry(kind === 'spot' ? 71 : kind === 'pool' ? 131 : 3);
  g.clearRect(0, 0, S, S);
  const cx = S / 2;
  if (kind === 'soft') {
    const grd = g.createRadialGradient(cx, cx, 0, cx, cx, cx);
    grd.addColorStop(0, 'rgba(255,255,255,0.95)');
    grd.addColorStop(0.45, 'rgba(255,255,255,0.45)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.fillRect(0, 0, S, S);
  } else if (kind === 'pool') {
    // irregular rounded blob with a soft rim
    for (let k = 0; k < 9; k++) {
      const ox = cx + (r() - 0.5) * 60;
      const oy = cx + (r() - 0.5) * 60;
      const rad = 54 + r() * 36;
      const grd = g.createRadialGradient(ox, oy, rad * 0.35, ox, oy, rad);
      grd.addColorStop(0, 'rgba(255,255,255,1)');
      grd.addColorStop(0.82, 'rgba(255,255,255,0.97)');
      grd.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = grd;
      g.beginPath();
      g.arc(ox, oy, rad, 0, Math.PI * 2);
      g.fill();
    }
  } else {
    g.fillStyle = '#fff';
    // ragged core
    g.beginPath();
    const lobes = 26;
    for (let i = 0; i <= lobes; i++) {
      const a = (i / lobes) * Math.PI * 2;
      const rr = 40 + r() * 26;
      const x = cx + Math.cos(a) * rr;
      const y = cx + Math.sin(a) * rr;
      if (i === 0) g.moveTo(x, y);
      else g.lineTo(x, y);
    }
    g.closePath();
    g.fill();
    // tapered streaks with round tips
    for (let i = 0; i < 24; i++) {
      const a = r() * Math.PI * 2;
      const len = 62 + r() * 62;
      const w = 3 + r() * 8;
      const ex = cx + Math.cos(a) * len;
      const ey = cx + Math.sin(a) * len;
      const px = -Math.sin(a) * w;
      const py = Math.cos(a) * w;
      g.beginPath();
      g.moveTo(cx + px, cx + py);
      g.lineTo(ex, ey);
      g.lineTo(cx - px, cx - py);
      g.closePath();
      g.fill();
      g.beginPath();
      g.arc(ex, ey, 2 + r() * 5.5, 0, Math.PI * 2);
      g.fill();
    }
    // flung droplets
    for (let i = 0; i < 22; i++) {
      const a = r() * Math.PI * 2;
      const d = 78 + r() * 48;
      g.beginPath();
      g.arc(cx + Math.cos(a) * d, cx + Math.sin(a) * d, 1.5 + r() * 5, 0, Math.PI * 2);
      g.fill();
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}

export class ZombieFx {
  private group = new THREE.Group();

  // ------------------------------------------------------------ pack effects
  private shardGeom = new THREE.OctahedronGeometry(1, 0);
  private ringGeom = new THREE.RingGeometry(0.42, 0.95, 10);
  private sparkMat = new THREE.MeshBasicMaterial({ color: 0xffd35c });
  private bloodMat = new THREE.MeshBasicMaterial({ color: 0x8a0f12 });
  private ringBloodMat = new THREE.MeshBasicMaterial({ color: 0xb3141a, side: THREE.DoubleSide });
  private ringSparkMat = new THREE.MeshBasicMaterial({ color: 0xffd35c, side: THREE.DoubleSide });
  private fleshMats = [0x8fb3a6, 0x6f9188, 0xb9cec6].map((c) => new THREE.MeshBasicMaterial({ color: c }));
  private shardPool: THREE.Mesh[] = [];
  private ringPool: THREE.Mesh[] = [];
  private particles: Particle[] = [];
  private gibs: Gib[] = [];
  private headGeoms = HEAD_VARIANTS.map((v) => createStylizedHeadGeometry(v));
  private hairGeoms: (THREE.BufferGeometry | null)[] = [];
  private headPool: { head: THREE.Mesh; hair: THREE.Mesh }[] = [];
  private nextHead = 0;
  private armGeom = createZombieForearmClawGeometry();
  private legGeom = createZombieShinFootGeometry();
  private limbMats = [0x8fb3a6, 0x7ea8a0, 0x9aa894].map((c) => new THREE.MeshBasicMaterial({ color: c }));
  private shoeMats = [0x8fb3a6, 0x4a5568, 0x3a322d].map((c) => new THREE.MeshBasicMaterial({ color: c }));

  // ------------------------------------------------------------ Dead-Island blood
  private dropMesh: THREE.InstancedMesh;
  private nd = 0;
  private dpx = new Float32Array(MAX_DROPS);
  private dpy = new Float32Array(MAX_DROPS);
  private dpz = new Float32Array(MAX_DROPS);
  private dvx = new Float32Array(MAX_DROPS);
  private dvy = new Float32Array(MAX_DROPS);
  private dvz = new Float32Array(MAX_DROPS);
  private dsz = new Float32Array(MAX_DROPS);
  private dage = new Float32Array(MAX_DROPS);
  private dlife = new Float32Array(MAX_DROPS);
  private dlvl = new Float32Array(MAX_DROPS);
  private dshade = new Float32Array(MAX_DROPS);

  private spotMesh: THREE.InstancedMesh;
  private spotN = 0;
  private spotHead = 0;
  private spotBudget = 0;
  private spotDirty = false;

  private poolMesh: THREE.InstancedMesh;
  private poolHead = 0;
  private poolN = 0;
  private growing: { idx: number; age: number; target: number; x: number; y: number; z: number; rot: number; sx: number }[] = [];

  private puffMesh: THREE.InstancedMesh;
  private puffs: { x: number; y: number; z: number; vx: number; vy: number; vz: number; age: number; life: number; size: number; shade: number }[] = [];

  private bleeders: Bleeder[] = [];
  private wallCells = new Map<number, BoxCollider3D[]>();

  constructor(
    scene: THREE.Scene,
    private ground: (x: number, z: number, y: number) => number,
    colliders: BoxCollider3D[] = []
  ) {
    this.group.name = 'zombie-fx';
    scene.add(this.group);
    for (let s = 0; s < HAIR_STYLE_COUNT; s++) this.hairGeoms.push(createHairStyleGeometry(s));
    for (let i = 0; i < 6; i++) {
      const head = new THREE.Mesh(
        this.headGeoms[0],
        new THREE.MeshStandardMaterial({
          map: getZombieFaceTexture(),
          color: 0xffffff,
          roughness: 0.84,
          flatShading: true,
          emissive: 0xffffff,
          emissiveIntensity: 1.0,
          emissiveMap: getZombieEyeTexture(),
        })
      );
      head.visible = false;
      head.userData.isFx = true;
      head.raycast = () => {};
      const hair = new THREE.Mesh(this.hairGeoms[0]!, new THREE.MeshStandardMaterial({ color: 0x2a211c, roughness: 0.9, flatShading: true }));
      hair.visible = false;
      hair.userData.isFx = true;
      hair.raycast = () => {};
      head.add(hair);
      this.headPool.push({ head, hair });
    }

    // wet droplets: low-poly teardrops stretched along their velocity
    this.dropMesh = new THREE.InstancedMesh(
      new THREE.OctahedronGeometry(1, 0),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.22, metalness: 0.05, emissive: 0x1c0000, emissiveIntensity: 0.6 }),
      MAX_DROPS
    );
    this.initInstanced(this.dropMesh, true);

    const splat = makeSplatTexture('spot');
    const poolTex = makeSplatTexture('pool');
    const soft = makeSplatTexture('soft');
    const flat = new THREE.PlaneGeometry(1, 1);
    const decalMat = (map: THREE.Texture) =>
      new THREE.MeshStandardMaterial({
        map,
        color: 0xffffff,
        transparent: true,
        depthWrite: false,
        roughness: 0.32,
        metalness: 0.0,
        emissive: 0x160000,
        emissiveIntensity: 0.5,
        polygonOffset: true,
        polygonOffsetFactor: -4,
        polygonOffsetUnits: -4,
      });
    this.spotMesh = new THREE.InstancedMesh(flat, decalMat(splat), MAX_SPOTS);
    this.initInstanced(this.spotMesh, false);
    this.poolMesh = new THREE.InstancedMesh(flat, decalMat(poolTex), MAX_POOLS);
    this.initInstanced(this.poolMesh, false);
    this.poolMesh.renderOrder = 1;
    this.spotMesh.renderOrder = 2;
    this.puffMesh = new THREE.InstancedMesh(
      flat,
      new THREE.MeshBasicMaterial({ map: soft, color: 0xffffff, transparent: true, depthWrite: false, opacity: 0.5 }),
      MAX_PUFFS
    );
    this.initInstanced(this.puffMesh, false);
    this.puffMesh.renderOrder = 3;

    // spatial index of wall boxes (6 m cells) so a droplet only tests the walls near it
    for (const c of colliders) {
      if (c.maxY - c.minY < 0.4) continue;
      const x0 = Math.floor(c.minX / 6);
      const x1 = Math.floor(c.maxX / 6);
      const z0 = Math.floor(c.minZ / 6);
      const z1 = Math.floor(c.maxZ / 6);
      if ((x1 - x0 + 1) * (z1 - z0 + 1) > 80) continue; // giant boundary boxes
      for (let x = x0; x <= x1; x++) {
        for (let z = z0; z <= z1; z++) {
          const k = (x + 1024) * 2048 + (z + 1024);
          let a = this.wallCells.get(k);
          if (!a) {
            a = [];
            this.wallCells.set(k, a);
          }
          a.push(c);
        }
      }
    }
  }

  private initInstanced(m: THREE.InstancedMesh, color: boolean) {
    m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    m.frustumCulled = false;
    m.castShadow = false;
    m.receiveShadow = false;
    m.userData.isFx = true;
    m.raycast = () => {};
    m.count = 0;
    const zero = new THREE.Matrix4().makeScale(0, 0, 0);
    const cap = m.instanceMatrix.count;
    const col = new THREE.Color(0xffffff);
    for (let i = 0; i < cap; i++) {
      m.setMatrixAt(i, zero);
      m.setColorAt(i, col);
    }
    void color;
    this.group.add(m);
  }

  // ====================================================================== palette
  /** deep arterial reds, a few brighter fresh spurts */
  private setBlood(arr: THREE.InstancedBufferAttribute | null, i: number, shade: number) {
    if (!arr) return;
    const a = arr.array as Float32Array;
    // shade 0 = fresh bright, 1 = old & dark
    a[i * 3] = 0.36 - 0.24 * shade;
    a[i * 3 + 1] = 0.008 + 0.006 * (1 - shade);
    a[i * 3 + 2] = 0.014 + 0.008 * (1 - shade);
  }

  // ====================================================================== droplets
  private spawnDrop(x: number, y: number, z: number, vx: number, vy: number, vz: number, size: number, life: number, lvl: number) {
    if (this.nd >= MAX_DROPS) return;
    const i = this.nd++;
    this.dpx[i] = x;
    this.dpy[i] = y;
    this.dpz[i] = z;
    this.dvx[i] = vx;
    this.dvy[i] = vy;
    this.dvz[i] = vz;
    this.dsz[i] = size;
    this.dage[i] = 0;
    this.dlife[i] = life;
    this.dlvl[i] = lvl;
    this.dshade[i] = Math.random() * 0.45;
  }

  private removeDrop(i: number) {
    const l = --this.nd;
    if (i !== l) {
      this.dpx[i] = this.dpx[l];
      this.dpy[i] = this.dpy[l];
      this.dpz[i] = this.dpz[l];
      this.dvx[i] = this.dvx[l];
      this.dvy[i] = this.dvy[l];
      this.dvz[i] = this.dvz[l];
      this.dsz[i] = this.dsz[l];
      this.dage[i] = this.dage[l];
      this.dlife[i] = this.dlife[l];
      this.dlvl[i] = this.dlvl[l];
      this.dshade[i] = this.dshade[l];
    }
  }

  private writeSpot(x: number, y: number, z: number, nx: number, ny: number, nz: number, sx: number, sy: number, shade: number, alignDir?: THREE.Vector3) {
    if (this.spotBudget <= 0) return;
    this.spotBudget--;
    const idx = this.spotHead;
    this.spotHead = (this.spotHead + 1) % MAX_SPOTS;
    if (this.spotN < MAX_SPOTS) this.spotN++;
    _n.set(nx, ny, nz);
    _qAlign.setFromUnitVectors(_Z, _n);
    if (alignDir) {
      // rotate about the normal so the splat's long axis lies along alignDir (projected on the surface)
      _v.set(0, 1, 0).applyQuaternion(_qAlign);
      _s.copy(alignDir).addScaledVector(_n, -alignDir.dot(_n));
      if (_s.lengthSq() > 1e-6) {
        _s.normalize();
        const ang = Math.atan2(_v.clone().cross(_s).dot(_n), _v.dot(_s));
        _q2.setFromAxisAngle(_n, ang);
        _q.copy(_q2).multiply(_qAlign);
      } else _q.copy(_qAlign);
    } else {
      _q2.setFromAxisAngle(_n, Math.random() * Math.PI * 2);
      _q.copy(_q2).multiply(_qAlign);
    }
    _p.set(x + nx * 0.004 * (idx % 7), y + ny * 0.004 * (idx % 7), z + nz * 0.004 * (idx % 7));
    _s.set(sx, sy, 1);
    _m.compose(_p, _q, _s);
    this.spotMesh.setMatrixAt(idx, _m);
    this.setBlood(this.spotMesh.instanceColor, idx, shade);
    this.spotDirty = true;
  }

  private groundSplat(x: number, y: number, z: number, i: number) {
    const sp = Math.hypot(this.dvx[i], this.dvz[i]);
    const size = (0.1 + this.dsz[i] * 7) * rnd(0.75, 1.45);
    const stretch = 1 + Math.min(2.6, sp * 0.24);
    _dir.set(this.dvx[i], 0, this.dvz[i]);
    this.writeSpot(x, y, z, 0, 1, 0, size, size * stretch, this.dshade[i], _dir.lengthSq() > 1e-4 ? _dir : undefined);
  }

  private wallSplat(c: BoxCollider3D, ppx: number, ppy: number, ppz: number, nx: number, ny: number, nz: number, i: number): boolean {
    let ox = 0;
    let oy = 0;
    let oz = 0;
    let hx = nx;
    let hy = ny;
    let hz = nz;
    if (ppx <= c.minX) {
      ox = -1;
      hx = c.minX;
    } else if (ppx >= c.maxX) {
      ox = 1;
      hx = c.maxX;
    } else if (ppz <= c.minZ) {
      oz = -1;
      hz = c.minZ;
    } else if (ppz >= c.maxZ) {
      oz = 1;
      hz = c.maxZ;
    } else if (ppy >= c.maxY) {
      oy = 1;
      hy = c.maxY;
    } else return false;
    const size = (0.12 + this.dsz[i] * 7.5) * rnd(0.75, 1.35);
    this.writeSpot(hx + ox * 0.006, hy + oy * 0.006, hz + oz * 0.006, ox, oy, oz, size, size * rnd(1, 1.5), this.dshade[i]);
    if (oy === 0 && this.dsz[i] > 0.016 && Math.random() < 0.7) {
      // drip running down the wall
      _dir.set(0, -1, 0);
      const len = size * rnd(1.6, 3.4);
      this.writeSpot(hx + ox * 0.006, hy - len * 0.55, hz + oz * 0.006, ox, oy, oz, size * 0.2, len, this.dshade[i] + 0.1, _dir);
    }
    return true;
  }

  // ====================================================================== wound
  /** one bullet wound: cone sprays forward (exit wound), blow-back toward the shooter, side spatter, mist */
  private wound(p: THREE.Vector3, dir: THREE.Vector3, lethal: boolean, head: boolean) {
    const lvl = this.ground(p.x, p.z, p.y);
    const power = (lethal ? 1 : 0.5) * (head ? 1.4 : 1);
    const n = Math.round((lethal ? 64 : 28) * (head ? 1.5 : 1));
    for (let i = 0; i < n; i++) {
      const r = Math.random();
      // 0..0.42 exit spray · 0.42..0.8 blow-back · rest spatter
      if (r < 0.42) _v.copy(dir);
      else if (r < 0.8) _v.copy(dir).multiplyScalar(-1);
      else _v.set(rnd(-1, 1), rnd(-0.2, 1), rnd(-1, 1));
      _v.x += rnd(-0.55, 0.55);
      _v.y += rnd(-0.3, 0.55);
      _v.z += rnd(-0.55, 0.55);
      _v.normalize();
      const speed = (r < 0.42 ? 5.2 : 3.2) * (0.35 + Math.random() * 1.35) * (0.7 + power * 0.45);
      const size = 0.012 + Math.pow(Math.random(), 2.0) * 0.046;
      this.spawnDrop(p.x + _v.x * 0.05, p.y + _v.y * 0.05, p.z + _v.z * 0.05, _v.x * speed, _v.y * speed + 0.6, _v.z * speed, size, 1.8, lvl);
    }
    // fine mist: tiny, fast, short-lived
    for (let i = 0; i < n * 0.7; i++) {
      _v.set(rnd(-1, 1), rnd(-0.2, 1), rnd(-1, 1)).normalize().addScaledVector(dir, 0.6).normalize();
      const speed = rnd(2.5, 8);
      this.spawnDrop(p.x, p.y, p.z, _v.x * speed, _v.y * speed, _v.z * speed, rnd(0.004, 0.008), 0.9, lvl);
    }
    // drifting red mist
    const puffs = lethal ? 6 : 3;
    for (let i = 0; i < puffs; i++) this.addPuff(p.x, p.y, p.z, dir.x * rnd(0.4, 1.8) + rnd(-0.4, 0.4), rnd(0.1, 0.9), dir.z * rnd(0.4, 1.8) + rnd(-0.4, 0.4), rnd(0.4, 0.75) * (head ? 1.35 : 1), rnd(0.55, 0.95));
  }

  private addPuff(x: number, y: number, z: number, vx: number, vy: number, vz: number, size: number, life: number) {
    if (this.puffs.length >= MAX_PUFFS) return;
    this.puffs.push({ x, y, z, vx, vy, vz, age: 0, life, size, shade: Math.random() * 0.3 });
  }

  /** wound on a character that is NOT a zombie (team-match bots) */
  public bloodHit(p: THREE.Vector3, dir: THREE.Vector3, lethal: boolean, head: boolean) {
    _dir.copy(dir).normalize();
    this.wound(p, _dir, lethal, head);
  }

  /** returns lens strength 0..1 for the HUD (blood on the camera when it happens close to you) */
  public lensPower(p: THREE.Vector3, camera: THREE.Vector3, lethal: boolean): number {
    const d = camera.distanceTo(p);
    if (d > 8) return 0;
    return Math.min(1, (lethal ? 1 : 0.5) * (1 - d / 8) * 1.2);
  }

  // ====================================================================== bleeding bodies
  /** `get` fills the emission point (+ velocity) and returns false once the body is gone */
  public bleed(key: number, kind: 'neck' | 'trail', seconds: number, get: (pos: THREE.Vector3, vel: THREE.Vector3) => boolean) {
    for (let i = this.bleeders.length - 1; i >= 0; i--) if (this.bleeders[i].key === key && this.bleeders[i].kind === kind) this.bleeders.splice(i, 1);
    if (this.bleeders.length > 80) this.bleeders.shift();
    this.bleeders.push({ key, t: 0, life: seconds, kind, acc: 0, decalAcc: 0, get });
  }

  /** a pool that keeps spreading for a few seconds */
  public pool(x: number, y: number, z: number, size = 1) {
    const idx = this.poolHead;
    this.poolHead = (this.poolHead + 1) % MAX_POOLS;
    if (this.poolN < MAX_POOLS) this.poolN++;
    this.growing = this.growing.filter((g) => g.idx !== idx);
    this.growing.push({ idx, age: 0, target: rnd(0.95, 1.5) * size, x, y: y + 0.01 + (idx % 5) * 0.0015, z, rot: Math.random() * Math.PI * 2, sx: rnd(0.9, 1.2) });
    this.setBlood(this.poolMesh.instanceColor, idx, 0.35 + Math.random() * 0.2);
    if (this.poolMesh.instanceColor) this.poolMesh.instanceColor.needsUpdate = true;
  }

  // ====================================================================== pack effects
  private shard(mat: THREE.Material): THREE.Mesh {
    let m = this.shardPool.pop();
    if (!m) {
      m = new THREE.Mesh(this.shardGeom, mat);
      m.userData.isFx = true;
      m.raycast = () => {};
    }
    m.material = mat;
    m.visible = true;
    this.group.add(m);
    return m;
  }

  private burst(pos: THREE.Vector3, dir: THREE.Vector3, fatal: boolean, camera: THREE.Vector3) {
    const count = fatal ? 12 : 6;
    for (let i = 0; i < count; i++) {
      const mesh = this.shard(i % 4 === 0 ? this.sparkMat : this.bloodMat);
      mesh.position.copy(pos);
      const scale = (fatal ? 0.04 : 0.026) * (0.75 + Math.random() * 0.7);
      mesh.scale.setScalar(scale);
      mesh.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
      const speed = (fatal ? 2.8 : 1.7) * (0.6 + Math.random() * 0.9);
      const theta = Math.random() * Math.PI * 2;
      const phi = (Math.random() - 0.3) * Math.PI;
      const vel = new THREE.Vector3(Math.cos(theta) * Math.cos(phi) * speed, Math.abs(Math.sin(phi)) * speed + (fatal ? 1.1 : 0.55), Math.sin(theta) * Math.cos(phi) * speed).addScaledVector(dir, -0.9 - Math.random() * 1.2);
      this.particles.push({ mesh, vel, age: 0, life: fatal ? 0.48 : 0.3, gravity: 7.5, baseScale: scale, ring: false });
    }
    let ring = this.ringPool.pop();
    const mat = fatal ? this.ringSparkMat : this.ringBloodMat;
    if (!ring) {
      ring = new THREE.Mesh(this.ringGeom, mat);
      ring.userData.isFx = true;
      ring.raycast = () => {};
    }
    ring.material = mat;
    ring.visible = true;
    ring.position.copy(pos).addScaledVector(dir, -0.05);
    ring.lookAt(camera);
    const rs = fatal ? 0.2 : 0.12;
    ring.scale.setScalar(rs);
    this.group.add(ring);
    this.particles.push({ mesh: ring, vel: new THREE.Vector3(), age: 0, life: fatal ? 0.2 : 0.13, gravity: 0, baseScale: rs * 2.2, ring: true });
  }

  /** the full dramatic response for one bullet that connected with a zombie; returns the lens strength */
  public spawnHit(res: ZombieShootResult, dir: THREE.Vector3, camera: THREE.Vector3): number {
    if (!res.hit) return 0;
    const p = res.worldPoint;
    _dir.copy(dir).normalize();
    this.burst(p, _dir, res.isVital, camera);
    this.wound(p, _dir, res.isVital, res.isHeadshot);

    // chunky flesh & blood gibs
    const gibCount = res.isHeadshot ? 22 : res.isVital ? 14 : 8;
    _side.crossVectors(_dir, _up);
    if (_side.lengthSq() < 1e-4) _side.set(1, 0, 0);
    _side.normalize();
    for (let i = 0; i < gibCount; i++) {
      const isBlood = i % 3 !== 0;
      const mat = isBlood ? this.bloodMat : this.fleshMats[i % this.fleshMats.length];
      const mesh = this.shard(mat);
      mesh.position.copy(p);
      const scale = (res.isHeadshot ? 0.08 : 0.055) * (0.55 + Math.random() * 1.15);
      mesh.scale.setScalar(scale);
      mesh.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
      const theta = Math.random() * Math.PI * 2;
      const speed = 2.4 + Math.random() * 3.6;
      const along = (Math.random() < 0.55 ? 1 : -0.6) * (1.2 + Math.random() * 2.4);
      const vel = new THREE.Vector3().addScaledVector(_dir, along).addScaledVector(_side, Math.cos(theta) * speed * 0.7).addScaledVector(_up, 1.4 + Math.random() * 3.4 + Math.sin(theta) * speed * 0.3);
      this.particles.push({ mesh, vel, age: 0, life: 1.0 + Math.random() * 0.7, gravity: 12.5, baseScale: scale, ring: false });
    }

    // HEADSHOT — the skull spins away, hair and all
    if (res.isHeadshot && res.isVital) {
      const slot = this.headPool[this.nextHead % this.headPool.length];
      this.nextHead++;
      const head = slot.head;
      head.geometry = this.headGeoms[res.headVariant] ?? this.headGeoms[0];
      (head.material as THREE.MeshStandardMaterial).color.setHex(res.skinColor);
      if (res.hairStyle >= 0 && this.hairGeoms[res.hairStyle]) {
        slot.hair.geometry = this.hairGeoms[res.hairStyle]!;
        slot.hair.visible = true;
        (slot.hair.material as THREE.MeshStandardMaterial).color.setHex(HAIR_COLORS[res.hairStyle % HAIR_COLORS.length]);
      } else slot.hair.visible = false;
      head.visible = true;
      head.scale.setScalar(1);
      head.position.copy(p);
      head.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
      this.group.add(head);
      const prev = this.gibs.findIndex((g) => g.obj === head);
      if (prev >= 0) this.gibs.splice(prev, 1);
      this.gibs.push({
        obj: head,
        vel: new THREE.Vector3().addScaledVector(_dir, 2.4 + Math.random() * 3.6).addScaledVector(_side, (Math.random() - 0.5) * 4.5).addScaledVector(_up, 3.4 + Math.random() * 2.6),
        spin: new THREE.Vector3(-9 - Math.random() * 7, (Math.random() - 0.5) * 9, (Math.random() - 0.5) * 8),
        age: 0,
        life: 3.4,
      });
      // the skull leaves a blood comet behind it
      this.bleed(900000 + this.nextHead, 'trail', 1.4, (pos, vel) => {
        const g = this.gibs.find((q) => q.obj === head);
        if (!g) return false;
        pos.copy(head.position);
        vel.copy(g.vel);
        return true;
      });
    }

    // TORN-OFF LIMB
    if ((res.zone === 'arm' && res.lostArm > 0) || (res.zone === 'leg' && res.lostLeg > 0)) {
      const isArm = res.zone === 'arm';
      const mats = isArm ? this.limbMats : this.shoeMats;
      const limb = new THREE.Mesh(isArm ? this.armGeom : this.legGeom, mats[(isArm ? res.lostArm : res.lostLeg) % mats.length]);
      limb.userData.isFx = true;
      limb.raycast = () => {};
      limb.position.copy(p);
      limb.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
      this.group.add(limb);
      const gib: Gib = {
        obj: limb,
        vel: new THREE.Vector3().addScaledVector(_dir, 1.6 + Math.random() * 3.4).addScaledVector(_side, (Math.random() - 0.5) * 5.5).addScaledVector(_up, 2.8 + Math.random() * 2.6),
        spin: new THREE.Vector3(-7 - Math.random() * 8, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 9),
        age: 0,
        life: 3.0,
      };
      this.gibs.push(gib);
      this.bleed(800000 + (this.nextSplatKey++ % 9999), 'trail', 1.2, (pos, vel) => {
        if (gib.age >= gib.life) return false;
        pos.copy(limb.position);
        vel.copy(gib.vel);
        return true;
      });
      this.wound(p, _dir, true, false); // stump gushes
    }
    return this.lensPower(p, camera, res.isVital);
  }
  private nextSplatKey = 0;

  // ====================================================================== frame update
  public update(dt: number, camera: THREE.Camera) {
    this.spotBudget = 70;
    this.updatePack(dt);
    this.updateBleeders(dt);
    this.updateDrops(dt);
    this.updatePools(dt);
    this.updatePuffs(dt, camera);
    if (this.spotDirty) {
      this.spotMesh.count = this.spotN;
      this.spotMesh.instanceMatrix.needsUpdate = true;
      if (this.spotMesh.instanceColor) this.spotMesh.instanceColor.needsUpdate = true;
      this.spotDirty = false;
    }
  }

  private updateBleeders(dt: number) {
    for (let i = this.bleeders.length - 1; i >= 0; i--) {
      const b = this.bleeders[i];
      b.t += dt;
      if (b.t >= b.life || !b.get(_p, _s)) {
        this.bleeders.splice(i, 1);
        continue;
      }
      const f = 1 - b.t / b.life;
      const lvl = this.ground(_p.x, _p.z, _p.y);
      if (b.kind === 'neck') {
        // arterial spray: heart-beat pulses (≈2.2 Hz) that weaken as the body bleeds out
        const pulse = Math.pow(Math.max(0, Math.sin(b.t * 13.8)), 1.6);
        const strength = Math.pow(f, 1.1) * (0.3 + 0.7 * pulse);
        b.acc += dt * 240 * strength;
        while (b.acc >= 1) {
          b.acc -= 1;
          const up = rnd(3.2, 6.8) * (0.6 + strength);
          this.spawnDrop(_p.x, _p.y, _p.z, rnd(-1.4, 1.4) + _s.x * 0.4, up, rnd(-1.4, 1.4) + _s.z * 0.4, rnd(0.011, 0.03), 1.6, lvl);
        }
        if (pulse > 0.85 && Math.random() < dt * 14) this.addPuff(_p.x, _p.y + 0.1, _p.z, rnd(-0.3, 0.3), rnd(0.5, 1.1), rnd(-0.3, 0.3), rnd(0.2, 0.34), 0.5);
      } else {
        const sp = _s.length();
        b.acc += dt * (28 + sp * 7) * f;
        while (b.acc >= 1) {
          b.acc -= 1;
          this.spawnDrop(_p.x + rnd(-0.08, 0.08), _p.y + rnd(-0.05, 0.1), _p.z + rnd(-0.08, 0.08), _s.x * 0.18 + rnd(-0.9, 0.9), rnd(0.2, 1.3), _s.z * 0.18 + rnd(-0.9, 0.9), rnd(0.008, 0.02), 1.3, lvl);
        }
        // smear on the ground while a body is sliding
        if (sp > 1.4 && _p.y - lvl < 0.7) {
          b.decalAcc += dt * 14;
          if (b.decalAcc >= 1) {
            b.decalAcc = 0;
            _dir.set(_s.x, 0, _s.z);
            const sz = rnd(0.12, 0.26);
            this.writeSpot(_p.x, lvl + 0.012, _p.z, 0, 1, 0, sz, sz * (1.4 + Math.min(1.8, sp * 0.2)), 0.2 + Math.random() * 0.3, _dir.lengthSq() > 1e-4 ? _dir : undefined);
          }
        }
      }
    }
  }

  private updateDrops(dt: number) {
    if (this.nd === 0 && this.dropMesh.count === 0) return; // nothing to upload
    const arr = this.dropMesh.instanceMatrix.array as Float32Array;
    const col = this.dropMesh.instanceColor ? (this.dropMesh.instanceColor.array as Float32Array) : null;
    for (let i = 0; i < this.nd; ) {
      this.dage[i] += dt;
      if (this.dage[i] > this.dlife[i]) {
        this.removeDrop(i);
        continue;
      }
      const ppx = this.dpx[i];
      const ppy = this.dpy[i];
      const ppz = this.dpz[i];
      this.dvy[i] -= 9.8 * dt;
      const drag = 1 - 0.55 * dt;
      this.dvx[i] *= drag;
      this.dvz[i] *= drag;
      const nx = ppx + this.dvx[i] * dt;
      const ny = ppy + this.dvy[i] * dt;
      const nz = ppz + this.dvz[i] * dt;
      const gy = this.ground(nx, nz, this.dlvl[i] + 0.5) + 0.012;
      if (ny <= gy) {
        this.groundSplat(nx, gy, nz, i);
        this.removeDrop(i);
        continue;
      }
      let hit = false;
      const cell = this.wallCells.get((Math.floor(nx / 6) + 1024) * 2048 + (Math.floor(nz / 6) + 1024));
      if (cell && ny < 14) {
        for (const c of cell) {
          if (c.disabled || ny < c.minY - 0.02 || ny > c.maxY + 0.02) continue;
          if (nx > c.minX && nx < c.maxX && nz > c.minZ && nz < c.maxZ) {
            if (this.wallSplat(c, ppx, ppy, ppz, nx, ny, nz, i)) {
              hit = true;
              break;
            }
          }
        }
      }
      if (hit) {
        this.removeDrop(i);
        continue;
      }
      this.dpx[i] = nx;
      this.dpy[i] = ny;
      this.dpz[i] = nz;
      // write the instance: Y axis along the velocity (stretched), X/Z perpendicular
      const vx = this.dvx[i];
      const vy = this.dvy[i];
      const vz = this.dvz[i];
      const sp = Math.sqrt(vx * vx + vy * vy + vz * vz) || 1e-4;
      const yx = vx / sp;
      const yy = vy / sp;
      const yz = vz / sp;
      // X = normalize(Y × up) (fallback when vertical)
      let xx = yz;
      let xy = 0;
      let xz = -yx;
      const xl = Math.hypot(xx, xz);
      if (xl < 1e-3) {
        xx = 1;
        xz = 0;
      } else {
        xx /= xl;
        xz /= xl;
      }
      // Z = X × Y
      const zx = xy * yz - xz * yy;
      const zy = xz * yx - xx * yz;
      const zz = xx * yy - xy * yx;
      const sz = this.dsz[i];
      const sy = sz * Math.min(7, 1 + sp * 0.4);
      const o = i * 16;
      arr[o] = xx * sz;
      arr[o + 1] = xy * sz;
      arr[o + 2] = xz * sz;
      arr[o + 3] = 0;
      arr[o + 4] = yx * sy;
      arr[o + 5] = yy * sy;
      arr[o + 6] = yz * sy;
      arr[o + 7] = 0;
      arr[o + 8] = zx * sz;
      arr[o + 9] = zy * sz;
      arr[o + 10] = zz * sz;
      arr[o + 11] = 0;
      arr[o + 12] = nx;
      arr[o + 13] = ny;
      arr[o + 14] = nz;
      arr[o + 15] = 1;
      if (col) {
        const sh = this.dshade[i];
        col[i * 3] = 0.42 - 0.26 * sh;
        col[i * 3 + 1] = 0.012;
        col[i * 3 + 2] = 0.02;
      }
      i++;
    }
    this.dropMesh.count = this.nd;
    this.dropMesh.instanceMatrix.needsUpdate = true;
    if (this.dropMesh.instanceColor) this.dropMesh.instanceColor.needsUpdate = true;
  }

  private updatePools(dt: number) {
    if (this.growing.length === 0) return;
    for (let k = this.growing.length - 1; k >= 0; k--) {
      const g = this.growing[k];
      g.age += dt;
      const u = Math.min(1, g.age / 4.5);
      const ease = 1 - Math.pow(1 - u, 3);
      const sz = g.target * (0.12 + 0.88 * ease);
      _n.set(0, 1, 0);
      _qAlign.setFromUnitVectors(_Z, _n);
      _q2.setFromAxisAngle(_n, g.rot);
      _q.copy(_q2).multiply(_qAlign);
      _p.set(g.x, g.y, g.z);
      _s.set(sz * g.sx, sz, 1);
      _m.compose(_p, _q, _s);
      this.poolMesh.setMatrixAt(g.idx, _m);
      if (u >= 1) this.growing.splice(k, 1);
    }
    this.poolMesh.count = this.poolN;
    this.poolMesh.instanceMatrix.needsUpdate = true;
  }

  private updatePuffs(dt: number, camera: THREE.Camera) {
    if (this.puffs.length === 0 && this.puffMesh.count === 0) return;
    const arr = this.puffMesh.instanceMatrix.array as Float32Array;
    const col = this.puffMesh.instanceColor ? (this.puffMesh.instanceColor.array as Float32Array) : null;
    camera.getWorldQuaternion(_q);
    let n = 0;
    for (let i = this.puffs.length - 1; i >= 0; i--) {
      const f = this.puffs[i];
      f.age += dt;
      if (f.age >= f.life) {
        this.puffs.splice(i, 1);
        continue;
      }
    }
    for (const f of this.puffs) {
      f.vy -= 0.4 * dt;
      f.vx *= 1 - 1.6 * dt;
      f.vz *= 1 - 1.6 * dt;
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      f.z += f.vz * dt;
      const u = f.age / f.life;
      const sz = f.size * (0.5 + u * 1.5) * (u > 0.65 ? 1 - (u - 0.65) / 0.35 : 1);
      _p.set(f.x, f.y, f.z);
      _s.set(Math.max(0.001, sz), Math.max(0.001, sz), 1);
      _m.compose(_p, _q, _s);
      _m.toArray(arr, n * 16);
      if (col) {
        col[n * 3] = 0.34 - 0.16 * f.shade;
        col[n * 3 + 1] = 0.01;
        col[n * 3 + 2] = 0.018;
      }
      n++;
    }
    this.puffMesh.count = n;
    this.puffMesh.instanceMatrix.needsUpdate = true;
    if (this.puffMesh.instanceColor) this.puffMesh.instanceColor.needsUpdate = true;
  }

  private updatePack(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.age += dt;
      if (p.age >= p.life) {
        this.group.remove(p.mesh);
        (p.ring ? this.ringPool : this.shardPool).push(p.mesh);
        this.particles.splice(i, 1);
        continue;
      }
      const frac = p.age / p.life;
      p.vel.y -= p.gravity * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      if (!p.ring) {
        const gy = this.ground(p.mesh.position.x, p.mesh.position.z, p.mesh.position.y) + 0.02;
        if (p.mesh.position.y < gy) {
          p.mesh.position.y = gy;
          p.vel.y *= -0.35;
        }
        p.mesh.rotation.x += dt * 9;
        p.mesh.rotation.y += dt * 7;
        p.mesh.scale.setScalar(Math.max(0.001, p.baseScale * (1 - frac)));
      } else {
        p.mesh.scale.setScalar(Math.max(0.001, p.baseScale * (0.4 + frac * 1.1) * (1 - frac)));
      }
    }
    for (let i = this.gibs.length - 1; i >= 0; i--) {
      const g = this.gibs[i];
      g.age += dt;
      if (g.age >= g.life) {
        this.group.remove(g.obj);
        g.obj.visible = false;
        this.gibs.splice(i, 1);
        continue;
      }
      g.vel.y -= 12.5 * dt;
      g.obj.position.addScaledVector(g.vel, dt);
      const gy = this.ground(g.obj.position.x, g.obj.position.z, g.obj.position.y) + 0.13;
      if (g.obj.position.y < gy) {
        g.obj.position.y = gy;
        g.vel.y *= -0.34;
        g.vel.x *= 0.72;
        g.vel.z *= 0.72;
        g.spin.multiplyScalar(0.6);
      }
      g.obj.rotation.x += g.spin.x * dt;
      g.obj.rotation.y += g.spin.y * dt;
      g.obj.rotation.z += g.spin.z * dt;
      const gt = g.age / g.life;
      if (gt > 0.82) g.obj.scale.setScalar(Math.max(0.001, 1 - (gt - 0.82) / 0.18));
    }
  }

  /** wipe every effect (new match / new horde) */
  public reset() {
    this.nd = 0;
    this.puffs.length = 0;
    this.bleeders.length = 0;
    this.growing.length = 0;
    const zero = new THREE.Matrix4().makeScale(0, 0, 0);
    for (let i = 0; i < MAX_SPOTS; i++) this.spotMesh.setMatrixAt(i, zero);
    for (let i = 0; i < MAX_POOLS; i++) this.poolMesh.setMatrixAt(i, zero);
    this.spotN = this.spotHead = 0;
    this.poolN = this.poolHead = 0;
    this.spotMesh.count = 0;
    this.poolMesh.count = 0;
    this.spotMesh.instanceMatrix.needsUpdate = true;
    this.poolMesh.instanceMatrix.needsUpdate = true;
    for (const p of this.particles) this.group.remove(p.mesh);
    this.particles.length = 0;
    for (const g of this.gibs) this.group.remove(g.obj);
    this.gibs.length = 0;
  }

  /** compile every effect material up-front (first blood must not hitch) */
  public warmUp(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera) {
    for (const h of this.headPool) {
      h.head.visible = true;
      h.hair.visible = true;
      h.head.position.set(0, -500, 0);
      this.group.add(h.head);
    }
    for (const m of [this.dropMesh, this.spotMesh, this.poolMesh, this.puffMesh]) m.count = 1;
    renderer.compile(scene, camera);
    for (const h of this.headPool) {
      h.head.visible = false;
      h.hair.visible = false;
      this.group.remove(h.head);
    }
    for (const m of [this.dropMesh, this.spotMesh, this.poolMesh, this.puffMesh]) m.count = 0;
  }

  public dispose() {
    this.group.parent?.remove(this.group);
  }
}
