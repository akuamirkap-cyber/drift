import * as THREE from 'three';
import type { BoxCollider3D } from './compoundBuilder';
import { soundEngine } from './audio';
import { ZombieCrowd } from '../skins/zombieCrowd';
import type { ZombieShootResult } from '../skins/zombieCrowd';
import type { ZombieFx } from './zombieFx';

export type ZombieKind = 'walker' | 'runner' | 'brute';
export type ZombieState = 'run' | 'hop' | 'climb' | 'vault' | 'down' | 'dead';
export type HordePhase = 'idle' | 'intermission' | 'combat' | 'gameover';

interface Column {
  col: BoxCollider3D;
  /** anchor on the wall face (the pyramid is built outward from here) */
  x: number;
  z: number;
  baseY: number;
  topY: number;
  faceYaw: number;
  /** unit tangent along the wall, unit normal pointing away from the wall */
  tx: number;
  tz: number;
  nx: number;
  nz: number;
  members: Zombie[];
  /** seconds since the last zombie joined this pyramid */
  idle: number;
  /** conveyor offset (in ranks): once nobody new joins, the whole pyramid rises and spills over the wall */
  lift: number;
}

/** pyramid cross-section: wide at the base, narrow at the top (WWZ-style living ladder) */
const TIER_CAPS = [5, 4, 4, 3, 3, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1];
const TIER_H = 0.82;
function slotOf(rank: number): { tier: number; j: number; cap: number } {
  let r = rank;
  for (let t = 0; t < TIER_CAPS.length; t++) {
    if (r < TIER_CAPS[t]) return { tier: t, j: r, cap: TIER_CAPS[t] };
    r -= TIER_CAPS[t];
  }
  return { tier: TIER_CAPS.length - 1, j: 0, cap: 1 };
}
function pyramidCap(tiers: number): number {
  let n = 0;
  for (let t = 0; t < Math.min(tiers, TIER_CAPS.length); t++) n += TIER_CAPS[t];
  return n;
}

interface Zombie {
  id: number;
  slot: number;
  kind: ZombieKind;
  state: ZombieState;
  x: number;
  y: number;
  z: number;
  vy: number;
  yaw: number;
  scale: number;
  hp: number;
  maxHp: number;
  speed: number;
  radius: number;
  damage: number;
  reach: number;

  phase: number;
  animRate: number;
  attackCd: number;
  stagger: number;
  hopT: number;
  hopY: number;
  jamTime: number;
  blockedTime: number;
  blockCol: BoxCollider3D | null;
  ignoreCol: BoxCollider3D | null;
  vaultT: number;
  column: Column | null;
  jx: number;
  jz: number;
  armAsym: number;
  headTilt: number;
  leanBase: number;
  seed: number;

  beh: 0 | 1 | 2 | 3; // 0 lunger · 1 sprinter · 2 flailer · 3 leaper (the showcase's behaviours)
  vx: number;
  vz: number;
  deadT: number;
  attacking: boolean;
  mass: number;
  pressure: number;
  stumbleCd: number;
  slideT: number;
  slideX: number;
  slideZ: number;
  slideDir: number;
  poolDone: boolean;
}

export interface ZombieHit {
  zombieId: number;
  hitbox: 'head' | 'body';
  zone: 'head' | 'torso' | 'arm' | 'leg';
  side: 1 | 2;
  agent: number;
  dist: number;
  point: THREE.Vector3;
}

export interface HordeHud {
  active: boolean;
  phase: HordePhase;
  wave: number;
  alive: number;
  remaining: number;
  waveTotal: number;
  kills: number;
  headshots: number;
  intermissionLeft: number;
  tallestPile: number;
  climbing: number;
  nearby: number;
  bestWave: number;
  bannerId: number;
  bannerText: string;
}

export interface HordeArena {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface HordeUpdateContext {
  dt: number;
  playerPos: THREE.Vector3; // camera position
  playerFootY: number;
  playerAlive: boolean;
  onBite: (damage: number, from: THREE.Vector3, brute: boolean) => void;
}

const MAX_SLOTS = 440;

const _p = new THREE.Vector3();
const MAX_CLIMB_HEIGHT = 9.5;


function rnd(a: number, b: number) {
  return a + Math.random() * (b - a);
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export class ZombieHordeManager {
  private scene: THREE.Scene;
  private colliders: BoxCollider3D[];
  private getGround: (x: number, z: number, footY: number) => number;

  public active = false;
  public phase: HordePhase = 'idle';
  public wave = 0;
  public kills = 0;
  public headshots = 0;
  public bestWave = 0;

  public readonly crowd: ZombieCrowd;
  private zombies: Zombie[] = [];
  private slots: (Zombie | null)[] = new Array(MAX_SLOTS).fill(null);
  private columns: Column[] = [];
  private nextId = 1;

  private arena: HordeArena = { minX: -60, maxX: 60, minZ: -60, maxZ: 60 };
  private waveTotal = 0;
  private spawnQueue = 0;
  private surgeTimer = 0;
  private waveDirs: number[] = [];
  private intermissionLeft = 0;
  private groanTimer = 1;
  private biteGlobalCd = 0;
  private time = 0;
  private tallestPile = 0;
  private climbingCount = 0;
  private nearbyCount = 0;
  /** zombies of the current surge still waiting to be created (max 4 per frame → no spawn hitches) */
  private pendingSpawn: { ax: number; az: number; left: number; spread: number }[] = [];
  /** gore hooks supplied by the engine */
  public fx: { pool?: (x: number, y: number, z: number, size: number) => void } = {};
  private bannerId = 0;
  private bannerText = '';

  private hash = new Map<number, Zombie[]>();
  private hashPool: Zombie[][] = [];

  constructor(
    scene: THREE.Scene,
    colliders: BoxCollider3D[],
    getGround: (x: number, z: number, footY: number) => number
  ) {
    this.scene = scene;
    this.colliders = colliders;
    this.getGround = getGround;
    // every zombie look, run cycle, hit reaction and ragdoll comes from the zombie pack (ZombieCrowd)
    this.crowd = new ZombieCrowd(MAX_SLOTS);
    this.crowd.ground = (x, z, y) => this.groundAt(x, z, y);
    this.crowd.walls = colliders;
    this.crowd.onBump = (idx) => {
      const z = this.slots[idx];
      if (z && z.state !== 'dead' && z.state !== 'down') this.beginDown(z);
    };
    this.crowd.group.visible = false;
    scene.add(this.crowd.group);
  }

  // =============================================================================
  //  PUBLIC API
  // =============================================================================
  public start(arena: HordeArena) {
    this.clearAll();
    this.arena = arena;
    this.active = true;
    this.crowd.group.visible = true;
    this.kills = 0;
    this.headshots = 0;
    this.wave = 0;
    this.biteGlobalCd = 0;
    this.beginIntermission(3.2, true);
  }

  public stop() {
    this.clearAll();
    this.active = false;
    this.phase = 'idle';
    this.crowd.group.visible = false;
  }

  /** compile the zombie shader programs up-front so the first wave does not hitch */
  public prewarm(renderer: THREE.WebGLRenderer, camera: THREE.Camera) {
    const prev = this.crowd.group.visible;
    this.crowd.group.visible = true;
    renderer.compile(this.scene, camera);
    this.crowd.group.visible = prev;
  }

  public setArena(arena: HordeArena) {
    this.arena = arena;
  }

  public dispose() {
    this.clearAll();
    this.scene.remove(this.crowd.group);
    this.crowd.dispose();
  }

  public gameOver() {
    if (this.phase === 'gameover') return;
    this.phase = 'gameover';
    this.bestWave = Math.max(this.bestWave, this.wave);
    this.say('GAME OVER — KERUMUNAN MENGALAHKANMU');
  }

  public getAliveCount() {
    let n = 0;
    for (const z of this.zombies) if (z.state !== 'dead') n++;
    return n;
  }

  public getHud(): HordeHud {
    const alive = this.getAliveCount();
    return {
      active: this.active,
      phase: this.phase,
      wave: this.wave,
      alive,
      remaining: alive + this.spawnQueue,
      waveTotal: this.waveTotal,
      kills: this.kills,
      headshots: this.headshots,
      intermissionLeft: Math.ceil(this.intermissionLeft),
      tallestPile: this.tallestPile,
      climbing: this.climbingCount,
      nearby: this.nearbyCount,
      bestWave: Math.max(this.bestWave, this.wave),
      bannerId: this.bannerId,
      bannerText: this.bannerText,
    };
  }

  /** Ray vs the RENDERED triangles of every standing zombie (zone = head / torso / arm / leg). */
  public raycast(origin: THREE.Vector3, dir: THREE.Vector3, maxDist: number): ZombieHit | null {
    const h = this.crowd.raycast(origin, dir, maxDist);
    if (!h) return null;
    const z = this.slots[h.index];
    if (!z || z.state === 'dead') return null;
    return {
      zombieId: z.id,
      hitbox: h.zone === 'head' ? 'head' : 'body',
      zone: h.zone,
      side: h.side,
      agent: h.index,
      dist: h.dist,
      point: h.point,
    };
  }

  /** Damage + the pack's hit reaction (flash, bullet hole, dismemberment, stagger or ragdoll). */
  public applyDamage(
    hit: ZombieHit,
    damage: number,
    dir: THREE.Vector3
  ): { killed: boolean; pos: THREE.Vector3; isBrute: boolean; result: ZombieShootResult } | null {
    const z = this.slots[hit.agent];
    if (!z || z.id !== hit.zombieId || z.state === 'dead') return null;
    const brute = z.kind === 'brute';
    const head = hit.zone === 'head';
    z.hp -= head ? Math.max(damage, brute ? damage * 1.8 : 140) : damage;
    const lethal = z.hp <= 0;
    z.stagger = lethal ? 0 : brute ? 0.1 : 0.28;
    const result = this.crowd.applyHit(z.slot, hit.zone, hit.side, hit.point, dir, lethal, brute ? 0.8 : 1);
    if (!lethal && hit.zone === 'leg') z.speed *= 0.62; // a shot-off leg slows it down
    const pos = new THREE.Vector3(z.x, z.y + z.hopY + 1.0 * z.scale, z.z);
    if (lethal) this.killZombie(z, head);
    return { killed: lethal, pos, isBrute: brute, result };
  }

  /** Explosion: lethal near the centre, staggering further out. Returns kill count. */
  public applyExplosion(center: THREE.Vector3, radius: number): number {
    let kills = 0;
    for (const z of this.zombies) {
      if (z.state === 'dead') continue;
      const d = Math.hypot(z.x - center.x, z.z - center.z, (z.y + 0.9 - center.y) * 0.6);
      if (d > radius) continue;
      const fall = 1 - d / radius;
      z.hp -= 40 + 520 * fall * fall;
      if (z.hp <= 0) {
        this.crowd.blast(z.slot, center.x, center.y, center.z, fall * 1.6);
        this.killZombie(z, false);
        kills++;
      } else {
        z.stagger = 0.9;
      }
    }
    return kills;
  }

  // =============================================================================
  //  UPDATE
  // =============================================================================
  public update(ctx: HordeUpdateContext) {
    if (!this.active) return;
    const dt = Math.min(ctx.dt, 0.05);
    this.time += dt;
    this.biteGlobalCd = Math.max(0, this.biteGlobalCd - dt);

    // ------------- wave director -------------
    if (this.phase === 'intermission') {
      this.intermissionLeft -= dt;
      if (this.intermissionLeft <= 0) this.beginWave(this.wave + 1, ctx.playerPos);
    } else if (this.phase === 'combat') {
      this.runSpawner(dt, ctx.playerPos);
      this.drainPending(ctx.playerPos);
      if (this.spawnQueue <= 0 && this.pendingSpawn.length === 0 && this.getAliveCount() === 0) {
        this.say(`WAVE ${this.wave} SELESAI`);
        this.bestWave = Math.max(this.bestWave, this.wave);
        this.beginIntermission(7, false);
      }
    }

    // ------------- spatial hash -------------
    this.rebuildHash();

    // ------------- zombie sim -------------
    this.climbingCount = 0;
    this.nearbyCount = 0;
    const px = ctx.playerPos.x;
    const pz = ctx.playerPos.z;

    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      if (z.state === 'down') {
        if (this.crowd.bodyPos(z.slot, _p)) {
          z.x = _p.x;
          z.z = _p.z;
          z.y = this.groundAt(z.x, z.z, z.y);
        } else {
          z.state = 'run'; // back on its feet
          z.jamTime = -1.4;
          z.stagger = 0.15;
        }
        z.vx = z.vz = 0;
        continue;
      }
      if (z.state === 'dead') {
        z.deadT += dt;
        if (!z.poolDone && this.crowd.isFrozenBody(z.slot) && this.crowd.bodyPos(z.slot, _p)) {
          z.poolDone = true;
          this.fx.pool?.(_p.x, this.groundAt(_p.x, _p.z, _p.y), _p.z, z.kind === 'brute' ? 1.5 : 1.0);
        }
        this.crowd.setFade(z.slot, Math.min(1, Math.max(0, (z.deadT - 8.1) / 1.1)));
        if (z.deadT > 9.3) this.releaseZombie(z, i);
        continue;
      }
      const ox = z.x;
      const oz = z.z;
      this.simulateZombie(z, ctx, px, pz, dt);
      z.vx = (z.x - ox) / Math.max(dt, 1e-4);
      z.vz = (z.z - oz) / Math.max(dt, 1e-4);
      if (z.state === 'climb') this.climbingCount++;
    }

    // ------------- hard zombie ↔ zombie collision + jostling -------------
    this.resolveOverlaps(dt);

    // ------------- climbing columns upkeep -------------
    this.tallestPile = 0;
    for (let c = this.columns.length - 1; c >= 0; c--) {
      const col = this.columns[c];
      col.members = col.members.filter((m) => m.state === 'climb' && m.column === col);
      col.idle += dt;
      if (col.idle > 2.4) col.lift += dt * 1.1; // living-ladder conveyor: the pyramid keeps rising & spilling over the wall
      if (col.members.length === 0) {
        this.columns.splice(c, 1);
        continue;
      }
      let topY = col.baseY;
      for (const m of col.members) if (m.y > topY) topY = m.y;
      this.tallestPile = Math.max(this.tallestPile, topY - col.baseY + 1.7);
    }

    // ------------- ambience: groans -------------
    this.groanTimer -= dt;
    if (this.groanTimer <= 0) {
      const live = this.zombies.filter((z) => z.state !== 'dead');
      if (live.length > 0) {
        const z = pick(live);
        const d = Math.hypot(z.x - px, z.z - pz);
        soundEngine.playZombieGroan(d, z.kind === 'brute');
      }
      this.groanTimer = rnd(0.25, 0.9) * (this.zombies.length > 80 ? 0.6 : 1.0);
    }

    this.writeInstances(dt);
  }

  // -----------------------------------------------------------------------------
  private rebuildHash() {
    for (const arr of this.hash.values()) {
      arr.length = 0;
      this.hashPool.push(arr);
    }
    this.hash.clear();
    for (const z of this.zombies) {
      if (z.state === 'dead') continue;
      const key = this.cellKey(z.x, z.z);
      let arr = this.hash.get(key);
      if (!arr) {
        arr = this.hashPool.pop() ?? [];
        this.hash.set(key, arr);
      }
      arr.push(z);
    }
  }

  private cellKey(x: number, z: number) {
    return (Math.floor(x / 1.6) + 2048) * 4096 + (Math.floor(z / 1.6) + 2048);
  }

  private groundAt(x: number, z: number, y: number): number {
    let g = this.getGround(x, z, Math.max(0, y));
    for (const c of this.colliders) {
      if (c.disabled) continue;
      if (c.maxY - c.minY > 40) continue;
      if (x > c.minX && x < c.maxX && z > c.minZ && z < c.maxZ) {
        if (c.maxY <= y + 0.7 && c.maxY > g) g = c.maxY;
      }
    }
    const bt = this.crowd.bodyTop(x, z);
    if (bt > g && bt <= y + 0.7) g = bt; // step up onto corpses
    return g;
  }

  private insideSolid(x: number, z: number, y: number, margin: number): boolean {
    for (const c of this.colliders) {
      if (c.disabled) continue;
      if (y + 1.7 <= c.minY || y + 0.3 >= c.maxY) continue;
      if (x > c.minX - margin && x < c.maxX + margin && z > c.minZ - margin && z < c.maxZ + margin) return true;
    }
    return false;
  }

  private simulateZombie(z: Zombie, ctx: HordeUpdateContext, px: number, pz: number, dt: number) {
    const s = z.scale;
    z.stagger = Math.max(0, z.stagger - dt);
    z.attackCd = Math.max(0, z.attackCd - dt);
    z.stumbleCd = Math.max(0, z.stumbleCd - dt);
    z.slideT = Math.max(0, z.slideT - dt);
    z.attacking = false;

    let dx = px - z.x;
    let dz = pz - z.z;
    const dist = Math.hypot(dx, dz) || 0.0001;
    dx /= dist;
    dz /= dist;
    if (dist < 14) this.nearbyCount++;
    const staggerSlow = z.stagger > 0 ? 0.25 : 1.0;
    const pulse = 1 + 0.16 * Math.sin(this.time * 1.7 + z.seed * 6.28);

    // ---------------------------------------------------------- CLIMB: the living pyramid
    if (z.state === 'climb' && z.column) {
      const col = z.column;
      const idx = col.members.indexOf(z);
      const rank = Math.max(0, idx) + Math.floor(col.lift);
      const sl = slotOf(rank);
      const lateral = (sl.j - (sl.cap - 1) / 2) * 0.66 + z.jx * 0.25;
      const out = Math.max(0.3, 0.6 - 0.035 * sl.tier);
      const tx = col.x + col.tx * lateral + col.nx * out;
      const tz = col.z + col.tz * lateral + col.nz * out;
      const targetY = Math.min(col.topY + 0.3, col.baseY + sl.tier * TIER_H);
      const ex = tx - z.x;
      const ez = tz - z.z;
      const ed = Math.hypot(ex, ez);
      const mv = Math.min(ed, z.speed * 0.9 * dt);
      if (ed > 0.02) {
        z.x += (ex / ed) * mv;
        z.z += (ez / ed) * mv;
      }
      const rise = ed < 0.6 ? 2.4 : 0;
      if (z.y < targetY) z.y = Math.min(targetY, z.y + rise * dt);
      else z.y = Math.max(targetY, z.y - 4 * dt);
      z.yaw = this.lerpAngle(z.yaw, col.faceYaw, Math.min(1, dt * 8));
      z.phase += dt * 6.5;
      if (z.y >= col.topY - 0.55 && ed < 0.8) {
        z.state = 'vault';
        z.ignoreCol = col.col;
        z.vaultT = 0;
        z.vy = 0;
        z.column = null;
        z.blockedTime = 0;
      }
      return;
    }

    // ---------------------------------------------------------- VAULT over the wall top
    if (z.state === 'vault') {
      z.vaultT += dt;
      const col = z.ignoreCol;
      const topY = col ? col.maxY : z.y;
      z.y = Math.min(topY, z.y + 4.2 * dt);
      const sp = z.speed * 0.9 * staggerSlow;
      this.moveWithCollision(z, z.x + dx * sp * dt, z.z + dz * sp * dt);
      z.yaw = this.lerpAngle(z.yaw, Math.atan2(dx, dz), Math.min(1, dt * 7));
      z.phase += dt * 8;
      if (z.vaultT > 0.95) {
        z.state = 'run';
        z.ignoreCol = null;
        z.vy = 0;
      }
      return;
    }

    // ---------------------------------------------------------- HOP over the crowd
    if (z.state === 'hop') {
      z.hopT += dt;
      const T = 1.15;
      const u = Math.min(1, z.hopT / T);
      z.hopY = Math.pow(Math.sin(Math.PI * u), 0.65) * 1.05 * s;
      const sp = z.speed * 0.95 * staggerSlow;
      this.moveWithCollision(z, z.x + dx * sp * dt, z.z + dz * sp * dt);
      z.yaw = this.lerpAngle(z.yaw, Math.atan2(dx, dz), Math.min(1, dt * 9));
      z.phase += dt * 9;
      if (u >= 1) {
        z.state = 'run';
        z.hopY = 0;
        z.jamTime = -1.4;
      }
      return;
    }

    // ---------------------------------------------------------- RUN / ATTACK
    let dirx: number;
    let dirz: number;
    let ahead = 0;
    if (z.slideT > 0) {
      // the pyramid here is full: slide along the wall looking for another spot
      dirx = z.slideX * z.slideDir;
      dirz = z.slideZ * z.slideDir;
    } else {
      const wob = Math.sin(this.time * 0.9 + z.seed * 40) * 0.22;
      dirx = dx + -dz * wob;
      dirz = dz + dx * wob;
      // soft steering away from neighbours (the hard constraint is resolveOverlaps)
      let sepx = 0;
      let sepz = 0;
      const cx = Math.floor(z.x / 1.6);
      const cz = Math.floor(z.z / 1.6);
      for (let ox = -1; ox <= 1; ox++) {
        for (let oz = -1; oz <= 1; oz++) {
          const arr = this.hash.get((cx + ox + 2048) * 4096 + (cz + oz + 2048));
          if (!arr) continue;
          for (const o of arr) {
            if (o === z || o.state === 'climb' || o.state === 'down') continue;
            if (Math.abs(o.y + o.hopY - z.y - z.hopY) > 0.7) continue;
            const sx = z.x - o.x;
            const sz = z.z - o.z;
            const d2 = sx * sx + sz * sz;
            const rr = (z.radius + o.radius) * 1.3;
            if (d2 < rr * rr && d2 > 1e-6) {
              const d = Math.sqrt(d2);
              const w = (rr - d) / rr;
              sepx += (sx / d) * w;
              sepz += (sz / d) * w;
              if (-(sx * dx + sz * dz) > 0.5 * d) ahead++; // somebody is standing in my way
            }
          }
        }
      }
      dirx += sepx * 1.3;
      dirz += sepz * 1.3;
    }
    const dl = Math.hypot(dirx, dirz) || 1;
    dirx /= dl;
    dirz /= dl;

    const inReach = dist < z.reach && Math.abs(ctx.playerFootY + 0.9 - (z.y + 0.9 * s)) < 2.1;
    let moveSpeed = z.speed * pulse * staggerSlow * (z.slideT > 0 ? 0.8 : 1);
    if (ahead >= 2) moveSpeed *= 0.45;
    else if (ahead === 1) moveSpeed *= 0.8;
    if (inReach && ctx.playerAlive) {
      moveSpeed = 0;
      z.attacking = true;
      if (z.attackCd <= 0 && this.biteGlobalCd <= 0) {
        z.attackCd = rnd(0.8, 1.15);
        this.biteGlobalCd = 0.16;
        ctx.onBite(z.damage, _p.set(z.x, z.y + 1.2 * s, z.z), z.kind === 'brute');
      }
    }

    const nx = z.x + dirx * moveSpeed * dt;
    const nz = z.z + dirz * moveSpeed * dt;
    const before = Math.hypot(px - z.x, pz - z.z);
    this.moveWithCollision(z, nx, nz);
    const after = Math.hypot(px - z.x, pz - z.z);

    z.yaw = this.lerpAngle(z.yaw, z.slideT > 0 ? Math.atan2(dirx, dirz) : Math.atan2(dx, dz), Math.min(1, dt * 7));
    z.phase += dt * moveSpeed * z.animRate / s + dt * (z.attacking ? 4 : 0.8);

    // jammed in the crowd → leap over it; blocked by a wall → climb it
    const progress = moveSpeed > 0.01 ? (before - after) / (moveSpeed * dt + 1e-5) : 1;
    if (!inReach && z.slideT <= 0 && progress < 0.28 && dist < 18 && dist > z.reach * 1.2 && !z.blockCol) {
      z.jamTime += dt;
    } else {
      z.jamTime = Math.min(0, z.jamTime) < 0 ? Math.min(0, z.jamTime + dt) : Math.max(0, z.jamTime - dt * 2);
    }
    if (z.jamTime > 0.7 && z.stagger <= 0) {
      z.state = 'hop';
      z.hopT = 0;
      z.jamTime = 0;
    }
    if (z.blockCol) {
      z.blockedTime += dt;
      if (z.blockedTime > 0.28) this.tryStartClimb(z, z.blockCol);
    } else {
      z.blockedTime = Math.max(0, z.blockedTime - dt * 2);
    }

    // gravity / ground follow
    const g = this.groundAt(z.x, z.z, z.y);
    if (z.y > g + 0.02) {
      z.vy -= 22 * dt;
      z.y = Math.max(g, z.y + z.vy * dt);
    } else {
      z.y = g;
      z.vy = 0;
    }
  }

  private moveWithCollision(z: Zombie, nx: number, nz: number) {
    const r = z.radius;
    const low = z.y + 0.3;
    const high = z.y + 1.7 * z.scale;
    let blockedX = false;
    let blockedZ = false;
    let hitCol: BoxCollider3D | null = null;
    for (const c of this.colliders) {
      if (c.disabled || c === z.ignoreCol) continue;
      if (high <= c.minY || low >= c.maxY) continue;
      if (nx > c.minX - r && nx < c.maxX + r && z.z > c.minZ - r && z.z < c.maxZ + r) {
        blockedX = true;
        hitCol = c;
      }
      if (z.x > c.minX - r && z.x < c.maxX + r && nz > c.minZ - r && nz < c.maxZ + r) {
        blockedZ = true;
        hitCol = c;
      }
    }
    if (!blockedX) z.x = nx;
    if (!blockedZ) z.z = nz;
    z.blockCol = blockedX || blockedZ ? hitCol : null;

    // arena bounds
    const a = this.arena;
    z.x = THREE.MathUtils.clamp(z.x, a.minX, a.maxX);
    z.z = THREE.MathUtils.clamp(z.z, a.minZ, a.maxZ);
  }

  private tryStartClimb(z: Zombie, c: BoxCollider3D) {
    const topH = c.maxY - z.y;
    if (topH <= 0.2) return;
    if (topH <= 1.25) {
      z.state = 'vault'; // low obstacle: quick vault
      z.ignoreCol = c;
      z.vaultT = 0.35;
      z.blockedTime = 0;
      return;
    }
    if (topH > MAX_CLIMB_HEIGHT) {
      z.blockedTime = 0;
      this.startSlide(z, c);
      return;
    }
    // join an existing pyramid on this wall (or notice that every nearby one is full)
    let best: Column | null = null;
    let bestD = 3.6;
    let fullNear = false;
    for (const col of this.columns) {
      if (col.col !== c) continue;
      const d = Math.hypot(col.x - z.x, col.z - z.z);
      if (d > 3.6) continue;
      const tiers = Math.ceil((col.topY - col.baseY - 0.5) / TIER_H) + 1;
      if (col.members.length >= pyramidCap(tiers)) {
        fullNear = true;
        continue;
      }
      if (d < bestD) {
        bestD = d;
        best = col;
      }
    }
    if (!best) {
      if (fullNear) {
        z.blockedTime = 0;
        this.startSlide(z, c);
        return;
      }
      // new pyramid: anchor on the wall face, axis-aligned normal
      const qx = THREE.MathUtils.clamp(z.x, c.minX, c.maxX);
      const qz = THREE.MathUtils.clamp(z.z, c.minZ, c.maxZ);
      let fx = qx - z.x;
      let fz = qz - z.z;
      if (Math.abs(fx) + Math.abs(fz) < 0.01) {
        fx = (c.minX + c.maxX) * 0.5 - z.x;
        fz = (c.minZ + c.maxZ) * 0.5 - z.z;
      }
      let nfx = 0;
      let nfz = 0;
      if (Math.abs(fx) > Math.abs(fz)) nfx = Math.sign(fx) || 1;
      else nfz = Math.sign(fz) || 1;
      const ax = nfx > 0 ? c.minX : nfx < 0 ? c.maxX : THREE.MathUtils.clamp(z.x, c.minX + 0.4, c.maxX - 0.4);
      const az = nfz > 0 ? c.minZ : nfz < 0 ? c.maxZ : THREE.MathUtils.clamp(z.z, c.minZ + 0.4, c.maxZ - 0.4);
      best = {
        col: c,
        x: ax,
        z: az,
        baseY: z.y,
        topY: c.maxY,
        faceYaw: Math.atan2(nfx, nfz),
        tx: nfz,
        tz: -nfx,
        nx: -nfx,
        nz: -nfz,
        members: [],
        idle: 0,
        lift: 0,
      };
      this.columns.push(best);
    }
    z.state = 'climb';
    z.column = best;
    z.jx = rnd(-0.5, 0.5);
    z.jz = rnd(-0.5, 0.5);
    z.blockedTime = 0;
    best.members.push(z);
    best.idle = 0;
  }

  private startSlide(z: Zombie, c: BoxCollider3D) {
    const alongX = c.maxX - c.minX > c.maxZ - c.minZ;
    z.slideX = alongX ? 1 : 0;
    z.slideZ = alongX ? 0 : 1;
    z.slideDir = Math.random() < 0.5 ? -1 : 1;
    z.slideT = rnd(1.0, 2.2);
  }

  private clampOut(z: Zombie) {
    const r = z.radius;
    const low = z.y + 0.3;
    const high = z.y + 1.7 * z.scale;
    for (const c of this.colliders) {
      if (c.disabled || c === z.ignoreCol) continue;
      if (high <= c.minY || low >= c.maxY) continue;
      if (z.x > c.minX - r && z.x < c.maxX + r && z.z > c.minZ - r && z.z < c.maxZ + r) {
        const a = z.x - (c.minX - r);
        const b = c.maxX + r - z.x;
        const d = z.z - (c.minZ - r);
        const e = c.maxZ + r - z.z;
        const m = Math.min(a, b, d, e);
        if (m === a) z.x -= a;
        else if (m === b) z.x += b;
        else if (m === d) z.z -= d;
        else z.z += e;
      }
    }
    const ar = this.arena;
    z.x = THREE.MathUtils.clamp(z.x, ar.minX, ar.maxX);
    z.z = THREE.MathUtils.clamp(z.z, ar.minZ, ar.maxZ);
  }

  private beginDown(z: Zombie) {
    if (z.column) {
      z.column.members = z.column.members.filter((m) => m !== z);
      z.column = null;
    }
    z.state = 'down';
    z.hopY = 0;
    z.vy = 0;
    z.attacking = false;
    z.jamTime = 0;
    z.blockedTime = 0;
    z.ignoreCol = null;
  }

  /**
   * HARD zombie ↔ zombie collision (position-based, 2 iterations): bodies can never overlap, so a packed
   * horde piles up, shoves and leaps over itself like in World War Z. Heavy crowd pressure occasionally
   * trips a sprinter into a short ragdoll tumble.
   */
  private resolveOverlaps(dt: number) {
    this.rebuildHash();
    let downs = 0;
    for (const z of this.zombies) {
      z.pressure = 0;
      if (z.state === 'down') downs++;
    }
    for (let iter = 0; iter < 4; iter++) {
      let any = false;
      for (const z of this.zombies) {
        if (z.state === 'dead' || z.state === 'down' || z.state === 'climb') continue;
        const cx = Math.floor(z.x / 1.6);
        const cz = Math.floor(z.z / 1.6);
        for (let ox = -1; ox <= 1; ox++) {
          for (let oz = -1; oz <= 1; oz++) {
            const arr = this.hash.get((cx + ox + 2048) * 4096 + (cz + oz + 2048));
            if (!arr) continue;
            for (const o of arr) {
              if (o.slot <= z.slot) continue; // each pair once
              if (o.state === 'dead' || o.state === 'down' || o.state === 'climb') continue;
              if (Math.abs(o.y + o.hopY - z.y - z.hopY) > 0.75) continue; // one is leaping over the other
              const dx = z.x - o.x;
              const dz = z.z - o.z;
              const d2 = dx * dx + dz * dz;
              const rr = (z.radius + o.radius) * 1.12;
              if (d2 >= rr * rr) continue;
              any = true;
              const d = Math.sqrt(d2);
              let nx: number;
              let nz: number;
              if (d < 1e-4) {
                const a = (z.slot * 2.399) % 6.283;
                nx = Math.cos(a);
                nz = Math.sin(a);
              } else {
                nx = dx / d;
                nz = dz / d;
              }
              const pen = rr - d;
              const wz = o.mass / (z.mass + o.mass);
              const wo = z.mass / (z.mass + o.mass);
              const k = iter < 3 ? 0.8 : 1.0;
              z.x += nx * pen * wz * k;
              z.z += nz * pen * wz * k;
              o.x -= nx * pen * wo * k;
              o.z -= nz * pen * wo * k;
              if (iter === 0) {
                z.pressure += pen;
                o.pressure += pen;
              }
            }
          }
        }
      }
      if (!any) break;
    }
    // walls win over the crowd: push everybody back out of solid geometry once
    for (const z of this.zombies) {
      if (z.state === 'dead' || z.state === 'down' || z.state === 'climb') continue;
      this.clampOut(z);
    }
    // jostling: packed + sprinting → trip
    for (const z of this.zombies) {
      if (downs >= 18) break;
      if (z.state !== 'run' || z.stumbleCd > 0 || z.pressure < 0.16) continue;
      const sp = Math.hypot(z.vx, z.vz);
      if (sp < 2.8 || Math.random() > dt * 0.5) continue;
      if (this.crowd.knockdown(z.slot, z.vx / sp, z.vz / sp, 0.5 + Math.random() * 0.35, rnd(1.2, 2.0))) {
        this.beginDown(z);
        z.stumbleCd = rnd(5, 11);
        downs++;
      }
    }
  }

  private lerpAngle(a: number, b: number, t: number) {
    let d = b - a;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return a + d * t;
  }

  // =============================================================================
  //  WAVES / SPAWNING
  // =============================================================================
  private say(text: string) {
    this.bannerId++;
    this.bannerText = text;
  }

  private beginIntermission(seconds: number, first: boolean) {
    this.phase = 'intermission';
    this.intermissionLeft = seconds;
    if (first) this.say('BERSIAPLAH — KERUMUNAN DATANG');
  }

  private beginWave(n: number, playerPos: THREE.Vector3) {
    this.wave = n;
    this.phase = 'combat';
    this.waveTotal = 400 + (n - 1) * 60;
    this.spawnQueue = this.waveTotal;
    this.surgeTimer = 2.2;
    const dirCount = 4;
    this.waveDirs = [];
    const base = Math.random() * Math.PI * 2;
    for (let i = 0; i < dirCount; i++) this.waveDirs.push(base + (i / dirCount) * Math.PI * 2 + rnd(-0.35, 0.35));
    // THE SWARM ARRIVES ALL AT ONCE: up to 400 infected pour in from every side
    this.queueBurst(Math.min(this.maxConcurrent(), this.spawnQueue), playerPos);
    this.say(`INFECTED — ${this.waveTotal} ZOMBIE`);
    soundEngine.playHordeHorn(true);
  }

  private maxConcurrent() {
    return 400;
  }

  private findAnchor(angle: number, playerPos: THREE.Vector3): { x: number; z: number } | null {
    const a = this.arena;
    for (let attempt = 0; attempt < 30; attempt++) {
      const ang = angle + rnd(-0.35, 0.35) + attempt * 0.15;
      const R = rnd(42, 62) - attempt * 0.9;
      const ax = playerPos.x + Math.sin(ang) * R;
      const az = playerPos.z + Math.cos(ang) * R;
      if (ax < a.minX + 4 || ax > a.maxX - 4 || az < a.minZ + 4 || az > a.maxZ - 4) continue;
      if (this.insideSolid(ax, az, this.getGround(ax, az, 0), 1.2)) continue;
      return { x: ax, z: az };
    }
    for (let attempt = 0; attempt < 40; attempt++) {
      const ax = rnd(a.minX + 4, a.maxX - 4);
      const az = rnd(a.minZ + 4, a.maxZ - 4);
      if (Math.hypot(ax - playerPos.x, az - playerPos.z) < 24) continue;
      if (this.insideSolid(ax, az, this.getGround(ax, az, 0), 1.2)) continue;
      return { x: ax, z: az };
    }
    return null;
  }

  private queueBurst(count: number, playerPos: THREE.Vector3) {
    const dirs = this.waveDirs.length ? this.waveDirs : [Math.random() * 6.28];
    let left = count;
    for (let k = 0; k < dirs.length && left > 0; k++) {
      const n = k === dirs.length - 1 ? left : Math.min(left, Math.ceil(count / dirs.length));
      const anchor = this.findAnchor(dirs[k], playerPos);
      if (!anchor) continue;
      this.pendingSpawn.push({ ax: anchor.x, az: anchor.z, left: n, spread: 9 });
      left -= n;
    }
    this.spawnQueue -= count - left; // whatever could not be placed stays queued
  }

  /** refills the horde as slots free up (waves above 400 trickle in from the edges) */
  private runSpawner(dt: number, playerPos: THREE.Vector3) {
    if (this.spawnQueue <= 0) return;
    this.surgeTimer -= dt;
    if (this.surgeTimer > 0) return;
    const room = this.maxConcurrent() - this.getAliveCount();
    if (room < 12) {
      this.surgeTimer = 0.5;
      return;
    }
    const size = Math.min(this.spawnQueue, room, Math.floor(rnd(14, 28)));
    const anchor = this.findAnchor(pick(this.waveDirs), playerPos);
    if (anchor) {
      this.pendingSpawn.push({ ax: anchor.x, az: anchor.z, left: size, spread: 6 });
      this.spawnQueue -= size;
    }
    this.surgeTimer = rnd(1.4, 2.6);
  }

  private chooseKind(): ZombieKind {
    const w = this.wave;
    const r = Math.random();
    const bruteP = Math.min(0.08, 0.025 + w * 0.012);
    if (r < bruteP) return 'brute';
    const runnerP = Math.min(0.6, 0.32 + w * 0.04);
    return Math.random() < runnerP ? 'runner' : 'walker';
  }

  /** creates up to 30 zombies per frame from the queued clusters (a 400-strong burst lands in ~14 frames) */
  private drainPending(playerPos: THREE.Vector3) {
    let budget = 30;
    while (budget > 0 && this.pendingSpawn.length > 0) {
      const pend = this.pendingSpawn[0];
      const n = Math.min(budget, pend.left);
      const a = this.arena;
      for (let i = 0; i < n; i++) {
        for (let attempt = 0; attempt < 6; attempt++) {
          const px = pend.ax + rnd(-pend.spread, pend.spread);
          const pz = pend.az + rnd(-pend.spread, pend.spread);
          if (px < a.minX || px > a.maxX || pz < a.minZ || pz > a.maxZ) continue;
          const gy = this.getGround(px, pz, 0);
          if (this.insideSolid(px, pz, gy, 0.5)) continue;
          this.spawnZombie(px, gy, pz, this.chooseKind(), playerPos);
          break;
        }
      }
      pend.left -= n;
      budget -= n;
      if (pend.left <= 0) this.pendingSpawn.shift();
    }
  }

  private allocSlot(): number {
    for (let i = 0; i < MAX_SLOTS; i++) {
      if (!this.slots[i]) return i;
    }
    // evict the oldest corpse
    let oldest: Zombie | null = null;
    let idx = -1;
    for (let i = 0; i < this.zombies.length; i++) {
      const z = this.zombies[i];
      if (z.state === 'dead' && (!oldest || z.deadT > oldest.deadT)) {
        oldest = z;
        idx = i;
      }
    }
    if (oldest) {
      const slot = oldest.slot;
      this.releaseZombie(oldest, idx);
      return slot;
    }
    return -1;
  }

  private spawnZombie(x: number, y: number, zPos: number, kind: ZombieKind, playerPos: THREE.Vector3) {
    const slot = this.allocSlot();
    if (slot < 0) return;
    const w = this.wave;
    let scale = rnd(0.95, 1.08);
    let hp = 55;
    let speed = rnd(3.0, 3.9);
    let damage = 5;
    let radius = 0.34;
    let animRate = 2.6;
    let lean = 0.3;
    if (kind === 'runner') {
      hp = 38;
      speed = rnd(5.0, 6.3) + Math.min(1.0, w * 0.08);
      damage = 4;
      animRate = 2.0;
      lean = 0.46;
      scale = rnd(0.92, 1.04);
    } else if (kind === 'brute') {
      hp = 420 + w * 20;
      speed = rnd(3.0, 3.6);
      damage = 16;
      scale = rnd(1.32, 1.46);
      radius = 0.5;
      animRate = 2.8;
      lean = 0.22;
    } else {
      hp = 55 + w * 2;
    }
    const z: Zombie = {
      id: this.nextId++,
      slot,
      kind,
      state: 'run',
      x,
      y,
      z: zPos,
      vy: 0,
      yaw: Math.atan2(playerPos.x - x, playerPos.z - zPos),
      scale,
      hp,
      maxHp: hp,
      speed,
      radius: radius * scale,
      damage,
      reach: 1.15 + 0.55 * scale,
      phase: Math.random() * 6.28,
      animRate,
      attackCd: rnd(0.2, 0.9),
      stagger: 0,
      hopT: 0,
      hopY: 0,
      jamTime: -0.5,
      blockedTime: 0,
      blockCol: null,
      ignoreCol: null,
      vaultT: 0,
      column: null,
      jx: 0,
      jz: 0,
      armAsym: Math.random(),
      headTilt: rnd(-0.35, 0.35),
      leanBase: lean,
      seed: Math.random(),
      beh: 0,
      vx: 0,
      vz: 0,
      deadT: 0,
      attacking: false,
      mass: scale * scale * scale * (kind === 'brute' ? 2.6 : 1),
      pressure: 0,
      stumbleCd: rnd(2, 6),
      slideT: 0,
      slideX: 0,
      slideZ: 0,
      slideDir: 1,
      poolDone: false,
    };
    this.slots[slot] = z;
    this.zombies.push(z);

    // the pack's behaviours: runners sprint / flail / leap, walkers lunge or flail, brutes lunge
    z.beh = kind === 'runner' ? (Math.random() < 0.45 ? 3 : Math.random() < 0.6 ? 1 : 2) : kind === 'brute' ? 0 : Math.random() < 0.55 ? 0 : 2;
    this.crowd.activate(slot, { scale, behavior: z.beh, x, y, z: zPos, yaw: z.yaw });
  }


  /** a freshly killed zombie keeps bleeding: neck gusher if the head is gone, otherwise a trail while it tumbles */
  public startBleeding(hit: ZombieHit, fx: ZombieFx, headless: boolean) {
    const z = this.slots[hit.agent];
    if (!z || z.id !== hit.zombieId) return;
    const id = z.id;
    const slot = z.slot;
    const get = (kind: 'neck' | 'body') => (pos: THREE.Vector3, vel: THREE.Vector3) => {
      const q = this.slots[slot];
      if (!q || q.id !== id) return false;
      if (kind === 'neck') {
        if (!this.crowd.neckWorld(slot, pos)) return false;
      } else if (!this.crowd.bodyPos(slot, pos)) return false;
      this.crowd.bodyVel(slot, vel);
      return true;
    };
    if (headless) fx.bleed(id * 3, 'neck', 2.6, get('neck'));
    fx.bleed(id * 3 + 1, 'trail', 1.8, get('body'));
  }

  private killZombie(z: Zombie, headshot: boolean) {
    z.state = 'dead';
    z.deadT = 0;
    z.hopY = 0;
    z.attacking = false;
    if (z.column) {
      z.column.members = z.column.members.filter((m) => m !== z);
      z.column = null;
    }
    this.kills++;
    if (headshot) this.headshots++;
  }

  private releaseZombie(z: Zombie, listIdx: number) {
    if (z.column) z.column.members = z.column.members.filter((m) => m !== z);
    this.slots[z.slot] = null;
    this.crowd.deactivate(z.slot);
    if (listIdx >= 0) this.zombies.splice(listIdx, 1);
    else {
      const k = this.zombies.indexOf(z);
      if (k >= 0) this.zombies.splice(k, 1);
    }
  }

  private clearAll() {
    for (const z of [...this.zombies]) this.releaseZombie(z, -1);
    this.zombies.length = 0;
    this.columns.length = 0;
    this.slots.fill(null);
    this.spawnQueue = 0;
    this.pendingSpawn.length = 0;
    this.waveTotal = 0;
    this.tallestPile = 0;
  }

  /** hand every living zombie's position / state to the pack's pose engine, then let it animate */
  private writeInstances(dt: number) {
    for (const z of this.zombies) {
      if (z.state === 'dead' || z.state === 'down') continue;
      const vs = Math.hypot(z.vx, z.vz);
      let mode = vs > 2.2 ? 2 : vs > 0.4 ? 1 : 0;
      let leap = 0;
      if (z.state === 'climb') mode = 4;
      else if (z.state === 'hop') {
        mode = 2;
        leap = Math.sin(Math.PI * Math.min(1, z.hopT / 1.15));
      } else if (z.state === 'vault') {
        mode = 2;
        leap = 1;
      } else if (z.attacking) mode = 3;
      else if (z.vy < -5) {
        mode = 2; // leaping off a roof / ledge
        leap = 0.9;
      }
      this.crowd.setDrive(z.slot, z.x, z.y + z.hopY, z.z, z.yaw, mode, mode === 2 ? Math.max(vs, 3.2) : vs, leap);
    }
    // level of detail with hysteresis: a 400-strong horde renders without outlines / shadows
    const n = this.zombies.length;
    if (n > 210) this.crowd.setLod(false, false);
    else if (n > 130) this.crowd.setLod(false, true);
    else if (n < 100) this.crowd.setLod(true, true);
    this.crowd.updateDriven(dt, this.time);
  }
}
