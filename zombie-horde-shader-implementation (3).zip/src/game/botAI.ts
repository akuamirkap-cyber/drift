import * as THREE from 'three';
import { BoxCollider3D, CompoundContext, NavNode } from './compoundBuilder';
import { soundEngine } from './audio';
import { batchGroupsLocal } from './staticBatcher';

export type BotState = 'patrol' | 'investigate' | 'engage' | 'take_cover' | 'flank' | 'dead';

export interface BotShotEvent {
  muzzlePos: THREE.Vector3;
  targetPos: THREE.Vector3;
  hitPlayer: boolean;
  damage: number;
  distance: number;
}

interface BotLegRig {
  hip: THREE.Group;
  knee: THREE.Group;
}

interface SmartBot {
  id: string;
  role: 'flanker' | 'marksman' | 'breacher';
  group: THREE.Group;
  bodyPivot: THREE.Group;
  upperBodyPivot: THREE.Group;
  headGroup: THREE.Group;
  armGroup: THREE.Group;
  leftLeg: BotLegRig;
  rightLeg: BotLegRig;
  opticGlow: THREE.Mesh;
  muzzleSocket: THREE.Object3D;
  muzzleFlash: THREE.Mesh;
  hitMeshes: THREE.Object3D[];

  pos: THREE.Vector3;
  vel: THREE.Vector3;
  yaw: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  state: BotState;

  // Navigation & Human-Like Tactics
  path: number[];
  pathIdx: number;
  targetNodeId: number;
  lastKnownPlayerPos: THREE.Vector3 | null;
  hasLos: boolean;
  losCheckTimer: number;
  stateTimer: number;
  reactionTimer: number;
  burstRemaining: number;
  fireCooldown: number;
  ammo: number;
  strafeDir: number;
  strafeTimer: number;

  // Player-Parity Stance States: Sprint, Ngeker (ADS), & Crouch!
  wantSprint: boolean;
  wantAds: boolean;
  wantCrouch: boolean;
  combatCrouchTimer: number;
  sprintBlend: number;
  adsBlend: number;
  crouchBlend: number;

  // Visual Animation State
  walkPhase: number;
  lastStepIdx: number;
  staggerTimer: number;
  muzzleFlashTimer: number;
  recoilKick: number;
  deathAngle: number;
  deathVel: number;
  deathRoll: number;
}

// Smooth Stylized 3D Character Materials (100% Reference Clay/Satin Aesthetic: warm peach skin, brown swept hair, jackets & long navy pants!)
const BMAT = {
  // Warm smooth peach stylized skin with soft subsurface glow matching reference character!
  skinPeach: new THREE.MeshStandardMaterial({
    color: 0xf4d2bd,
    emissive: 0x2c140a,
    emissiveIntensity: 0.16,
    roughness: 0.56,
    metalness: 0.02,
  }),
  // Iconic sculpted swept-back smooth brown hair (warm chestnut brown matching reference!)
  hairBrown: new THREE.MeshStandardMaterial({
    color: 0x76482f,
    roughness: 0.44,
    metalness: 0.06,
  }),
  hairDarkBrown: new THREE.MeshStandardMaterial({
    color: 0x52311f,
    roughness: 0.46,
    metalness: 0.06,
  }),
  // Stylized Fitted Street Jackets (3 distinct gang squad jackets with smooth satin cloth PBR!)
  jacketTeal: new THREE.MeshStandardMaterial({
    color: 0x1c4b5e, // Exact rich teal-navy tone from reference!
    roughness: 0.62,
    metalness: 0.06,
  }),
  jacketOlive: new THREE.MeshStandardMaterial({
    color: 0x45543c,
    roughness: 0.66,
    metalness: 0.05,
  }),
  jacketRust: new THREE.MeshStandardMaterial({
    color: 0x7d3f2b,
    roughness: 0.62,
    metalness: 0.06,
  }),
  // Ribbed jacket collar / cuff / waist trim + inner crew-neck shirt peeking at chest
  jacketRibDark: new THREE.MeshStandardMaterial({
    color: 0x1a222b,
    roughness: 0.78,
    metalness: 0.04,
  }),
  innerShirt: new THREE.MeshStandardMaterial({
    color: 0x233542,
    roughness: 0.74,
    metalness: 0.02,
  }),
  zipperMetal: new THREE.MeshStandardMaterial({
    color: 0x9aa4b0,
    roughness: 0.3,
    metalness: 0.82,
  }),
  // Long fitted midnight-navy pants matching reference dark-navy bottoms!
  longPantsNavy: new THREE.MeshStandardMaterial({
    color: 0x16202e,
    roughness: 0.72,
    metalness: 0.04,
  }),
  // Crisp peeking white ankle socks & smooth grey-taupe low-top sneakers with white rubber soles (100% Reference!)
  sockWhite: new THREE.MeshStandardMaterial({
    color: 0xf4f6f9,
    roughness: 0.82,
  }),
  shoeGrey: new THREE.MeshStandardMaterial({
    color: 0x87838b,
    roughness: 0.56,
    metalness: 0.04,
  }),
  shoeSoleWhite: new THREE.MeshStandardMaterial({
    color: 0xf1f3f6,
    roughness: 0.68,
  }),
  gunDark: new THREE.MeshStandardMaterial({ color: 0x171b21, roughness: 0.55, metalness: 0.42, flatShading: true }),
  gunMetal: new THREE.MeshStandardMaterial({ color: 0x252b34, roughness: 0.45, metalness: 0.58, flatShading: true }),
  opticDot: new THREE.MeshBasicMaterial({ color: 0x4dff9b }),
  flashMat: new THREE.MeshBasicMaterial({
    color: 0xffa533,
    transparent: true,
    opacity: 0.95,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  }),
};

function flatBox(w: number, h: number, d: number, mat: THREE.Material, x = 0, y = 0, z = 0): THREE.Mesh {
  const geo = new THREE.BoxGeometry(w, h, d).toNonIndexed();
  geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

function smoothMesh(geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

/**
 * Builds a 100% Reference-Style Smooth Stylized 3D Enemy Character:
 * - Smooth faceless warm-peach oval head (proportionally scaled down so it fits naturally!)
 * - Iconic swept-back smooth sculpted brown pompadour hair wrapping down temples & nape
 * - Fitted smooth Street/Bomber Jacket with raised collar, zipper, inner crew-neck tee, pockets & full sleeves
 * - Smooth long midnight-navy trousers all the way down articulated knees to cuffed ankles
 * - Exact reference peeking white socks & rounded grey sneakers with white rubber soles!
 */
function buildBotModel(id: string, role: SmartBot['role']) {
  const group = new THREE.Group();
  const bodyPivot = new THREE.Group();
  group.add(bodyPivot);

  const hitMeshes: THREE.Object3D[] = [];
  const jacketMat =
    role === 'marksman' ? BMAT.jacketRust : role === 'flanker' ? BMAT.jacketOlive : BMAT.jacketTeal;
  const hairMat = role === 'flanker' ? BMAT.hairDarkBrown : BMAT.hairBrown;

  const markHit = (mesh: THREE.Object3D, hitbox: 'head' | 'body') => {
    mesh.userData = { botId: id, hitbox };
    hitMeshes.push(mesh);
    return mesh;
  };

  // =========================================================================
  // 1. ARTICULATED SMOOTH LONG-PANTS LEGS + WHITE SOCKS + REFERENCE GREY SNEAKERS
  // =========================================================================
  const makeLeg = (xOff: number): BotLegRig => {
    const hip = new THREE.Group();
    hip.position.set(xOff, 0.88, 0);

    // Smooth sculpted trouser thigh (CapsuleGeometry = seamless round hip & knee transition!)
    const thigh = smoothMesh(new THREE.CapsuleGeometry(0.095, 0.25, 8, 16), BMAT.longPantsNavy, 0, -0.21, 0);
    thigh.scale.set(0.98, 1.0, 1.04);
    markHit(thigh, 'body');
    hip.add(thigh);

    // Articulated Knee Joint at Y = -0.42
    const knee = new THREE.Group();
    knee.position.set(0, -0.42, 0);

    // Smooth long pant lower leg / calf tapering cleanly to ankle cuff
    const calf = smoothMesh(new THREE.CylinderGeometry(0.088, 0.068, 0.34, 16), BMAT.longPantsNavy, 0, -0.17, 0);
    markHit(calf, 'body');
    const kneeCap = smoothMesh(new THREE.SphereGeometry(0.088, 14, 12), BMAT.longPantsNavy, 0, 0, 0);
    const pantCuff = smoothMesh(new THREE.CylinderGeometry(0.072, 0.072, 0.036, 16), BMAT.jacketRibDark, 0, -0.34, 0);

    // Peeking Crisp White Ankle Sock (iconic reference touch right above the sneaker!)
    const sock = smoothMesh(new THREE.CylinderGeometry(0.056, 0.058, 0.065, 14), BMAT.sockWhite, 0, -0.38, 0);

    // Exact Reference Rounded Grey-Taupe Sneaker with Clean White Rubber Sole (100% flush on concrete floor Y=0!)
    const shoeGroup = new THREE.Group();
    shoeGroup.position.set(0, -0.45, -0.045);
    const shoeUpper = smoothMesh(new THREE.SphereGeometry(0.085, 16, 12), BMAT.shoeGrey, 0, 0.032, 0);
    shoeUpper.scale.set(0.86, 0.66, 1.58);
    const shoeHeel = smoothMesh(new THREE.CylinderGeometry(0.064, 0.068, 0.068, 14), BMAT.shoeGrey, 0, 0.044, 0.052);
    const shoeSole = smoothMesh(new THREE.CapsuleGeometry(0.066, 0.12, 8, 14), BMAT.shoeSoleWhite, 0, 0.015, 0);
    shoeSole.rotation.x = Math.PI / 2;
    shoeSole.scale.set(1.06, 1.0, 0.36);
    shoeGroup.add(shoeUpper, shoeHeel, shoeSole);

    knee.add(kneeCap, calf, pantCuff, sock, shoeGroup);
    hip.add(knee);
    return { hip, knee };
  };

  const leftLeg = makeLeg(-0.115);
  const rightLeg = makeLeg(0.115);
  bodyPivot.add(leftLeg.hip, rightLeg.hip);

  // =========================================================================
  // 2. SMOOTH SCULPTED PELVIS & FITTED STREET JACKET TORSO (Y = 0.88..1.52)
  // =========================================================================
  const upperBodyPivot = new THREE.Group();
  upperBodyPivot.position.set(0, 0.88, 0);
  bodyPivot.add(upperBodyPivot);

  // Smooth rounded trouser pelvis bridging hips cleanly
  const pelvis = smoothMesh(new THREE.SphereGeometry(0.205, 18, 14), BMAT.longPantsNavy, 0, 0.02, 0);
  pelvis.scale.set(1.08, 0.62, 0.72);
  markHit(pelvis, 'body');
  upperBodyPivot.add(pelvis);

  // Ribbed Elastic Jacket Waist Hem
  const waistHem = smoothMesh(new THREE.CylinderGeometry(0.198, 0.195, 0.075, 20), BMAT.jacketRibDark, 0, 0.1, 0);
  waistHem.scale.set(1.12, 1.0, 0.72);
  upperBodyPivot.add(waistHem);

  // Smooth Fitted Street Jacket Body (sculpted broad chest tapering organically to waist!)
  const jacketCore = smoothMesh(new THREE.CylinderGeometry(0.228, 0.196, 0.45, 20), jacketMat, 0, 0.355, 0);
  jacketCore.scale.set(1.12, 1.0, 0.72);
  markHit(jacketCore, 'body');

  // Smooth rounded upper chest / shoulder yoke dome
  const shoulderYoke = smoothMesh(new THREE.SphereGeometry(0.232, 20, 14), jacketMat, 0, 0.54, 0);
  shoulderYoke.scale.set(1.15, 0.46, 0.74);
  markHit(shoulderYoke, 'body');

  // Sculpted Left & Right Jacket Front Panels (slight raised relief creating a real open-zip jacket silhouette!)
  const frontPanelL = smoothMesh(new THREE.CapsuleGeometry(0.088, 0.31, 8, 14), jacketMat, -0.095, 0.34, -0.092);
  frontPanelL.scale.set(1.15, 1.0, 0.78);
  const frontPanelR = smoothMesh(new THREE.CapsuleGeometry(0.088, 0.31, 8, 14), jacketMat, 0.095, 0.34, -0.092);
  frontPanelR.scale.set(1.15, 1.0, 0.78);

  // Inner Crew-Neck T-Shirt peeking smoothly in the center V-neck & zipper gap!
  const innerChest = smoothMesh(new THREE.CylinderGeometry(0.11, 0.09, 0.42, 14), BMAT.innerShirt, 0, 0.37, -0.075);
  innerChest.scale.set(1.0, 1.0, 0.82);

  // Crisp Metallic Center Zipper Strip + Zipper Pull
  const zipperTrack = smoothMesh(new THREE.BoxGeometry(0.016, 0.36, 0.018), BMAT.zipperMetal, 0, 0.30, -0.158);
  const zipperPull = smoothMesh(new THREE.BoxGeometry(0.022, 0.036, 0.022), BMAT.zipperMetal, 0, 0.46, -0.162);

  // Angled Jacket Hip Welt Pockets on Front Left & Right
  const pocketL = smoothMesh(new THREE.BoxGeometry(0.095, 0.024, 0.025), BMAT.jacketRibDark, -0.135, 0.21, -0.145);
  pocketL.rotation.z = 0.28;
  const pocketR = smoothMesh(new THREE.BoxGeometry(0.095, 0.024, 0.025), BMAT.jacketRibDark, 0.135, 0.21, -0.145);
  pocketR.rotation.z = -0.28;

  // Turned-Up Rounded Bomber/Street Jacket Collar hugging the back & sides of the smooth neck!
  const collarBack = smoothMesh(new THREE.TorusGeometry(0.098, 0.036, 12, 22, Math.PI * 1.48), jacketMat, 0, 0.62, 0.008);
  collarBack.rotation.x = Math.PI / 2 + 0.12;
  collarBack.rotation.z = -Math.PI * 0.24;

  // Inner Crew-Neck Collar Rim (dark navy ring around neck base just like reference!)
  const crewNeckRing = smoothMesh(new THREE.TorusGeometry(0.072, 0.014, 10, 20), BMAT.jacketRibDark, 0, 0.625, -0.005);
  crewNeckRing.rotation.x = Math.PI / 2;

  upperBodyPivot.add(
    jacketCore,
    shoulderYoke,
    frontPanelL,
    frontPanelR,
    innerChest,
    zipperTrack,
    zipperPull,
    pocketL,
    pocketR,
    collarBack,
    crewNeckRing
  );

  // =========================================================================
  // 3. PROPORTIONALLY SCALED SMOOTH FACELESS HEAD + SCULPTED SWEPT-BACK BROWN HAIR!
  //    (100% Reference Clay Character Aesthetic — Head scaled slightly smaller to crisp ~1:5.8 ratio!)
  // =========================================================================
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.635, 0);

  // Smooth Stylized Cylindrical Neck flaring gently into collar
  const neck = smoothMesh(new THREE.CylinderGeometry(0.052, 0.062, 0.095, 16), BMAT.skinPeach, 0, 0.035, 0);
  headGroup.add(neck);

  // Smooth Faceless Sculpted Oval Egg-Shaped Head (slightly fuller brow/cheeks, soft tapered chin!)
  const headCranium = smoothMesh(new THREE.SphereGeometry(0.118, 24, 18), BMAT.skinPeach, 0, 0.195, -0.004);
  headCranium.scale.set(0.95, 1.16, 1.0);
  markHit(headCranium, 'head');

  const headChin = smoothMesh(new THREE.SphereGeometry(0.092, 20, 14), BMAT.skinPeach, 0, 0.135, -0.014);
  headChin.scale.set(0.88, 0.92, 0.94);
  markHit(headChin, 'head');
  headGroup.add(headCranium, headChin);

  // Iconic Sculpted Smooth Swept-Back Brown Hairdo (exact reference silhouette facing -Z forward!)
  const hairGroup = new THREE.Group();
  // Main crown hair volume covering top & back of skull
  const hairCrown = smoothMesh(new THREE.SphereGeometry(0.125, 22, 16), hairMat, 0, 0.232, 0.024);
  hairCrown.scale.set(1.02, 0.88, 1.06);
  markHit(hairCrown, 'head');

  // Signature Front Swept Pompadour Wave rising smoothly above the forehead (-Z) & sweeping back-right!
  const hairQuiff = smoothMesh(new THREE.CapsuleGeometry(0.062, 0.105, 12, 18), hairMat, -0.014, 0.305, -0.022);
  hairQuiff.rotation.set(0.28, -0.22, 1.24);
  hairQuiff.scale.set(1.05, 1.0, 1.18);
  markHit(hairQuiff, 'head');

  // Secondary smooth sweeping crest blending wave into crown
  const hairWave = smoothMesh(new THREE.SphereGeometry(0.088, 18, 14), hairMat, 0.024, 0.295, -0.002);
  hairWave.scale.set(1.22, 0.72, 1.28);

  // Smooth sculpted Back-of-Head Hair Shell wrapping down neatly to nape of neck (+Z)
  const hairBack = smoothMesh(new THREE.SphereGeometry(0.116, 20, 14), hairMat, 0, 0.185, 0.052);
  hairBack.scale.set(0.98, 1.08, 0.78);

  // Smooth Left & Right Temple / Sideburn Sweeps framing the faceless peach cheeks!
  const hairSideL = smoothMesh(new THREE.CapsuleGeometry(0.042, 0.09, 10, 14), hairMat, -0.102, 0.215, 0.024);
  hairSideL.rotation.set(0.24, 0, 0.16);
  const hairSideR = smoothMesh(new THREE.CapsuleGeometry(0.042, 0.09, 10, 14), hairMat, 0.102, 0.215, 0.024);
  hairSideR.rotation.set(0.24, 0, -0.16);

  hairGroup.add(hairCrown, hairQuiff, hairWave, hairBack, hairSideL, hairSideR);
  headGroup.add(hairGroup);
  upperBodyPivot.add(headGroup);

  // Rounded Jacket Shoulder Caps fused seamlessly onto upperBodyPivot so shoulders NEVER detach during sprint/ADS!
  const shoulderL = smoothMesh(new THREE.SphereGeometry(0.095, 16, 12), jacketMat, -0.235, 0.515, -0.005);
  const shoulderR = smoothMesh(new THREE.SphereGeometry(0.095, 16, 12), jacketMat, 0.235, 0.515, -0.005);
  upperBodyPivot.add(shoulderL, shoulderR);

  // =========================================================================
  // 4. SMOOTH LONG-SLEEVE JACKET ARMS, PEACH HANDS & TACTICAL CARBINE RIFLE!
  // =========================================================================
  const armGroup = new THREE.Group();
  armGroup.position.set(0.02, 0.50, -0.02);

  // Helper building a smooth articulated Jacket Sleeve + Ribbed Wrist Cuff + Smooth Peach Hand!
  const buildJacketArm = (from: THREE.Vector3, elbow: THREE.Vector3, handPos: THREE.Vector3) => {
    const seg = (a: THREE.Vector3, b: THREE.Vector3, rA: number, rB: number, mat: THREE.Material) => {
      const dir = b.clone().sub(a);
      const len = dir.length();
      const mid = a.clone().add(b).multiplyScalar(0.5);
      const m = smoothMesh(new THREE.CylinderGeometry(rB, rA, len, 14), mat, mid.x, mid.y, mid.z);
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
      return m;
    };
    const upper = seg(from, elbow, 0.072, 0.062, jacketMat);
    const elbowJoint = smoothMesh(new THREE.SphereGeometry(0.062, 12, 10), jacketMat, elbow.x, elbow.y, elbow.z);
    const fore = seg(elbow, handPos, 0.06, 0.048, jacketMat);
    const cuff = smoothMesh(new THREE.SphereGeometry(0.052, 12, 10), BMAT.jacketRibDark, handPos.x, handPos.y, handPos.z);
    // Smooth warm-peach stylized hand wrapping the rifle!
    const handDir = handPos.clone().sub(elbow).normalize();
    const palmPos = handPos.clone().addScaledVector(handDir, 0.045);
    const palm = smoothMesh(new THREE.SphereGeometry(0.048, 14, 12), BMAT.skinPeach, palmPos.x, palmPos.y, palmPos.z);
    palm.scale.set(0.92, 0.82, 1.18);
    armGroup.add(upper, elbowJoint, fore, cuff, palm);
  };

  // Left Jacket Arm reaching smoothly forward cradling rifle handguard; Right Jacket Arm gripping trigger grip!
  buildJacketArm(
    new THREE.Vector3(-0.245, 0.015, 0.015),
    new THREE.Vector3(-0.24, -0.14, -0.21),
    new THREE.Vector3(0.02, -0.04, -0.51)
  );
  buildJacketArm(
    new THREE.Vector3(0.215, 0.015, 0.015),
    new THREE.Vector3(0.225, -0.14, -0.11),
    new THREE.Vector3(0.065, -0.075, -0.23)
  );

  // Bot Tactical Rifle (Buttstock + Receiver + Mag + Optic Sight + Barrel)
  const rifleStock = flatBox(0.062, 0.105, 0.24, BMAT.gunDark, 0.06, -0.02, -0.08);
  const rifleBody = flatBox(0.078, 0.115, 0.58, BMAT.gunMetal, 0.06, -0.02, -0.42);
  const rifleMag = flatBox(0.046, 0.21, 0.092, BMAT.gunDark, 0.06, -0.15, -0.44);
  rifleMag.rotation.x = -0.22;
  const rifleOptic = flatBox(0.052, 0.062, 0.11, BMAT.gunDark, 0.06, 0.07, -0.36);
  const rifleBarrel = flatBox(0.034, 0.034, 0.36, BMAT.gunMetal, 0.06, 0.0, -0.86);
  armGroup.add(rifleStock, rifleBody, rifleMag, rifleOptic, rifleBarrel);

  // Subtle Illuminated Optic Glint when Bot is actively ADSing ("ngeker")!
  const opticGlow = new THREE.Mesh(new THREE.SphereGeometry(0.024, 8, 8), BMAT.opticDot);
  opticGlow.position.set(0.06, 0.07, -0.43);
  opticGlow.visible = false;
  armGroup.add(opticGlow);

  const muzzleSocket = new THREE.Object3D();
  muzzleSocket.position.set(0.06, 0.0, -1.06);
  armGroup.add(muzzleSocket);

  const flashGeo = new THREE.OctahedronGeometry(0.16, 0).toNonIndexed();
  const muzzleFlash = new THREE.Mesh(flashGeo, BMAT.flashMat);
  muzzleFlash.scale.set(1.0, 1.0, 1.9);
  muzzleFlash.visible = false;
  muzzleSocket.add(muzzleFlash);

  upperBodyPivot.add(armGroup);

  return {
    group,
    bodyPivot,
    upperBodyPivot,
    headGroup,
    armGroup,
    leftLeg,
    rightLeg,
    opticGlow,
    muzzleSocket,
    muzzleFlash,
    hitMeshes,
  };
}

export class BotSquadManager {
  private scene: THREE.Scene;
  private compound: CompoundContext;
  private bots: SmartBot[] = [];
  public hitMeshes: THREE.Object3D[] = [];
  public enabled = true;
  public wave = 1;
  public totalKills = 0;

  private raycaster = new THREE.Raycaster();
  private waveClearDelay = 0;
  private tmpV1 = new THREE.Vector3();
  private tmpV2 = new THREE.Vector3();
  private tmpV3 = new THREE.Vector3();

  constructor(scene: THREE.Scene, compound: CompoundContext) {
    this.scene = scene;
    this.compound = compound;
    this.spawnWave(1);
  }

  public getAliveCount(): number {
    return this.bots.filter((b) => b.alive).length;
  }

  public resetSquad() {
    this.wave = 1;
    this.totalKills = 0;
    this.waveClearDelay = 0;
    this.clearBots();
    if (this.enabled) {
      this.spawnWave(1);
    }
  }

  public setEnabled(en: boolean) {
    this.enabled = en;
    this.bots.forEach((b) => {
      b.group.visible = en;
    });
    if (en && this.bots.length === 0) {
      this.spawnWave(this.wave);
    }
  }

  private clearBots() {
    for (const b of this.bots) {
      this.scene.remove(b.group);
    }
    this.bots = [];
    this.hitMeshes = [];
  }

  private spawnWave(waveNum: number) {
    this.clearBots();
    this.wave = waveNum;

    const spawnSpecs: { nodeId: number; role: SmartBot['role'] }[] = [
      { nodeId: 6, role: 'breacher' }, // Central Atrium cover
      { nodeId: 10, role: 'flanker' }, // West Security Office (behind framed windows & door!)
      { nodeId: 14, role: 'flanker' }, // East Boiler / Generator Room
      { nodeId: 18, role: 'breacher' }, // North Back Corridor
      { nodeId: 27, role: 'marksman' }, // 2nd Floor Enclosed Gang Boss Office Overlook!
      { nodeId: 31, role: 'marksman' }, // 2nd Floor Enclosed Radio Overwatch Room!
    ];

    spawnSpecs.forEach((spec, idx) => {
      const id = `bot-w${waveNum}-${idx}`;
      const node = this.compound.navNodes[spec.nodeId] ?? this.compound.navNodes[6];
      const model = buildBotModel(id, spec.role);
      // FPS: ~90 tiny rigid meshes per bot → a few merged meshes per pivot (muzzle flash / optic glow stay separate)
      batchGroupsLocal(model.group, [model.muzzleFlash, model.opticGlow]);
      model.group.position.copy(node.pos);
      model.group.visible = this.enabled;
      this.scene.add(model.group);
      this.hitMeshes.push(...model.hitMeshes);

      const bot: SmartBot = {
        id,
        role: spec.role,
        ...model,
        pos: node.pos.clone(),
        vel: new THREE.Vector3(),
        yaw: Math.PI,
        hp: 100,
        maxHp: 100,
        alive: true,
        state: 'patrol',
        path: [],
        pathIdx: 0,
        targetNodeId: node.id,
        lastKnownPlayerPos: null,
        hasLos: false,
        losCheckTimer: Math.random() * 0.18,
        stateTimer: 1.5 + Math.random() * 2.5,
        reactionTimer: 0,
        burstRemaining: 0,
        fireCooldown: 0,
        ammo: 20,
        strafeDir: idx % 2 === 0 ? 1 : -1,
        strafeTimer: 1.2,
        wantSprint: false,
        wantAds: false,
        wantCrouch: false,
        combatCrouchTimer: 1.6 + Math.random() * 2.0,
        sprintBlend: 0,
        adsBlend: 0,
        crouchBlend: 0,
        walkPhase: 0,
        lastStepIdx: 0,
        staggerTimer: 0,
        muzzleFlashTimer: 0,
        recoilKick: 0,
        deathAngle: 0,
        deathVel: 0,
        deathRoll: (Math.random() - 0.5) * 0.4,
      };
      this.bots.push(bot);
    });
  }

  public notifyPlayerGunshot(origin: THREE.Vector3, hearingRadius: number) {
    if (!this.enabled) return;
    let directChasers = 0;

    for (const bot of this.bots) {
      if (!bot.alive) continue;
      const dist = bot.pos.distanceTo(origin);
      if (dist > hearingRadius) continue;

      bot.lastKnownPlayerPos = origin.clone();

      if (bot.state === 'patrol' || bot.state === 'investigate') {
        if (bot.role === 'flanker' || directChasers >= 2) {
          this.enterFlankState(bot, origin);
        } else {
          directChasers++;
          bot.state = 'investigate';
          bot.stateTimer = 7.5;
          const destNode = this.findNearestNode(origin);
          this.assignPath(bot, destNode.id);
        }
      }
    }
  }

  public applyDamage(
    botId: string,
    damage: number,
    isHeadshot: boolean,
    attackerPos: THREE.Vector3
  ): { killed: boolean; botPos: THREE.Vector3; label: string } | null {
    const bot = this.bots.find((b) => b.id === botId);
    if (!bot || !bot.alive) return null;

    bot.hp -= isHeadshot ? Math.max(damage, 120) : damage;
    bot.lastKnownPlayerPos = attackerPos.clone();
    bot.staggerTimer = 0.2;

    if (bot.hp <= 0) {
      bot.alive = false;
      bot.state = 'dead';
      bot.deathVel = 5.6;
      bot.muzzleFlash.visible = false;
      bot.opticGlow.visible = false;
      this.totalKills++;
      return {
        killed: true,
        botPos: bot.pos.clone(),
        label: isHeadshot ? 'BOT HEADSHOT!' : 'BOT ELIMINATED',
      };
    }

    // Smart human-like reflex: when hit, either drop straight into crouch-ADS to return fire OR sprint to nearest cover!
    if (bot.state !== 'take_cover' && (bot.hp < 65 || Math.random() < 0.6)) {
      this.enterCoverState(bot, attackerPos);
    } else if (bot.state === 'patrol' || bot.state === 'investigate') {
      bot.state = 'engage';
      bot.wantCrouch = Math.random() < 0.5;
      bot.reactionTimer = 0.16;
    }

    return {
      killed: false,
      botPos: bot.pos.clone(),
      label: isHeadshot ? 'HEAD HIT' : 'BOT HIT',
    };
  }

  public applyExplosionDamage(center: THREE.Vector3, radius: number): number {
    let kills = 0;
    for (const bot of this.bots) {
      if (!bot.alive) continue;
      const d = bot.pos.distanceTo(center);
      if (d < radius) {
        bot.hp = 0;
        bot.alive = false;
        bot.state = 'dead';
        bot.deathVel = 7.5;
        bot.muzzleFlash.visible = false;
        bot.opticGlow.visible = false;
        this.totalKills++;
        kills++;
      }
    }
    return kills;
  }

  public update(
    dt: number,
    playerPos: THREE.Vector3,
    playerAlive: boolean,
    playerInCompound: boolean,
    playerIsCrouching: boolean,
    onBotShot: (ev: BotShotEvent) => void
  ) {
    if (!this.enabled) return;

    const aliveCount = this.getAliveCount();
    if (aliveCount === 0) {
      this.waveClearDelay += dt;
      if (this.waveClearDelay >= 2.8) {
        this.waveClearDelay = 0;
        this.spawnWave(this.wave + 1);
      }
    }

    for (const bot of this.bots) {
      if (bot.muzzleFlashTimer > 0) {
        bot.muzzleFlashTimer -= dt;
        if (bot.muzzleFlashTimer <= 0) {
          bot.muzzleFlash.visible = false;
        }
      }

      if (!bot.alive) {
        bot.deathVel += 16 * dt;
        bot.deathAngle = Math.min(Math.PI * 0.48, bot.deathAngle + bot.deathVel * dt);
        bot.bodyPivot.rotation.x = bot.deathAngle;
        bot.bodyPivot.rotation.z = bot.deathRoll * (bot.deathAngle / (Math.PI * 0.48));
        bot.bodyPivot.position.y = -Math.sin(bot.deathAngle) * 0.14;
        continue;
      }

      if (bot.staggerTimer > 0) bot.staggerTimer = Math.max(0, bot.staggerTimer - dt);
      if (bot.fireCooldown > 0) bot.fireCooldown = Math.max(0, bot.fireCooldown - dt);
      bot.recoilKick = Math.max(0, bot.recoilKick - dt * 7.5);
      bot.stateTimer -= dt;

      // Real Raycast LOS check against Player's ACTUAL live standing/crouched camera height!
      bot.losCheckTimer -= dt;
      if (bot.losCheckTimer <= 0) {
        bot.losCheckTimer = 0.13 + Math.random() * 0.06;
        if (playerAlive && playerInCompound) {
          // Player crouching lowers their profile & stealth detection radius!
          const maxSight = playerIsCrouching ? 34 : 46;
          const dist = bot.pos.distanceTo(playerPos);
          bot.hasLos = dist < maxSight && this.checkLos(bot.pos, playerPos, bot.crouchBlend);
          if (bot.hasLos) {
            bot.lastKnownPlayerPos = playerPos.clone();
          }
        } else {
          bot.hasLos = false;
        }
      }

      const distToPlayer = bot.pos.distanceTo(playerPos);

      // Reset stance intents cleanly before writing active tactical behavior
      bot.wantSprint = false;
      bot.wantAds = false;

      // =========================================================================
      // PLAYER-PARITY SMART BOT AI: SPRINT, NGEKER (ADS), & TACTICAL CROUCH!
      // =========================================================================
      if (bot.state === 'patrol') {
        bot.wantCrouch = false;
        if (bot.hasLos) {
          bot.state = 'engage';
          bot.reactionTimer = 0.26 + Math.random() * 0.14;
          bot.stateTimer = 4.6;
          bot.combatCrouchTimer = 1.2 + Math.random() * 1.6;
          this.alertSquadmates(bot, playerPos);
        } else {
          // Patrol smoothly at walk pace (sprints occasionally between distant wings)
          const farDest = bot.path.length > 2;
          bot.wantSprint = farDest;
          this.followPath(bot, dt, farDest ? 4.4 : 2.45);
          if (bot.path.length === 0 || bot.stateTimer <= 0) {
            const pool =
              bot.role === 'marksman'
                ? this.compound.navNodes.filter((n) => n.floor === 1 && n.isCover)
                : this.compound.navNodes;
            const pick = pool[Math.floor(Math.random() * pool.length)];
            this.assignPath(bot, pick.id);
            bot.stateTimer = 4.5 + Math.random() * 3.8;
          }
        }
      } else if (bot.state === 'investigate') {
        bot.wantCrouch = false;
        if (bot.hasLos) {
          bot.state = 'engage';
          bot.reactionTimer = 0.2;
          bot.stateTimer = 4.5;
        } else {
          // Sprint when closing long distance, then switch to cautious ADS-ready walk near last known corner!
          const distLast = bot.lastKnownPlayerPos ? bot.pos.distanceTo(bot.lastKnownPlayerPos) : 99;
          if (distLast > 11) {
            bot.wantSprint = true;
            this.followPath(bot, dt, 4.95);
          } else {
            // Pie the corner with rifle raised in ADS just like a real tactical operator!
            bot.wantAds = true;
            this.followPath(bot, dt, 2.4);
          }
          if (bot.path.length === 0 || bot.stateTimer <= 0) {
            bot.state = 'patrol';
            bot.stateTimer = 2.0;
          }
        }
      } else if (bot.state === 'flank') {
        bot.wantCrouch = false;
        if (bot.hasLos && distToPlayer < 26 && bot.pathIdx >= Math.max(1, bot.path.length - 2)) {
          bot.state = 'engage';
          bot.reactionTimer = 0.16;
          bot.stateTimer = 4.8;
        } else {
          // Full tactical SPRINT along alternate flanking path / stairs!
          bot.wantSprint = true;
          this.followPath(bot, dt, 5.25);
          if (bot.path.length === 0 || bot.stateTimer <= 0) {
            if (bot.lastKnownPlayerPos) {
              bot.state = 'investigate';
              this.assignPath(bot, this.findNearestNode(bot.lastKnownPlayerPos).id);
              bot.stateTimer = 5.0;
            } else {
              bot.state = 'patrol';
            }
          }
        }
      } else if (bot.state === 'take_cover') {
        if (bot.path.length > 0) {
          // Full SPRINT to get behind nearest pillar/wall!
          bot.wantSprint = true;
          bot.wantCrouch = false;
          this.followPath(bot, dt, 5.35);
        } else {
          // Reached cover -> DROP INTO FULL CROUCH (jongkok) behind cover while reloading!
          bot.vel.multiplyScalar(Math.exp(-10 * dt));
          bot.wantCrouch = true;
          bot.wantAds = false;
          if (bot.lastKnownPlayerPos) {
            this.turnToward(bot, bot.lastKnownPlayerPos, dt * 6.5);
          }
          if (bot.stateTimer <= 0) {
            bot.ammo = 20;
            if (bot.lastKnownPlayerPos && Math.random() < 0.5) {
              this.enterFlankState(bot, bot.lastKnownPlayerPos);
            } else {
              // Peek back out into ADS (sometimes staying crouched for a sneaky crouch-peek!)
              bot.state = bot.hasLos ? 'engage' : 'investigate';
              bot.wantCrouch = Math.random() < 0.45;
              bot.reactionTimer = 0.2;
              bot.stateTimer = 4.2;
              if (!bot.hasLos && bot.lastKnownPlayerPos) {
                this.assignPath(bot, this.findNearestNode(bot.lastKnownPlayerPos).id);
              }
            }
          }
        }
      } else if (bot.state === 'engage') {
        if (!bot.hasLos) {
          bot.wantCrouch = false;
          if (bot.lastKnownPlayerPos) {
            if (bot.role === 'flanker' || Math.random() < 0.48) {
              this.enterFlankState(bot, bot.lastKnownPlayerPos);
            } else {
              bot.state = 'investigate';
              bot.stateTimer = 6.5;
              this.assignPath(bot, this.findNearestNode(bot.lastKnownPlayerPos).id);
            }
          } else {
            bot.state = 'patrol';
          }
        } else {
          // BOT IS ACTIVELY NGEKER (ADS) AT THE PLAYER!
          bot.wantAds = true;
          bot.wantSprint = false;
          this.turnToward(bot, playerPos, dt * 10.0);

          // Dynamic human-like tactical crouch-peek toggling during firefights!
          bot.combatCrouchTimer -= dt;
          if (bot.combatCrouchTimer <= 0) {
            bot.combatCrouchTimer = 1.6 + Math.random() * 2.2;
            // Marksmen on balconies and mid-range bots frequently crouch-ADS to steady aim!
            const crouchProb = bot.role === 'marksman' ? 0.62 : 0.42;
            const nextCrouch = Math.random() < crouchProb;
            // Only stay crouched if crouched LOS still clears obstacles!
            bot.wantCrouch = nextCrouch && this.checkLos(bot.pos, playerPos, 1.0);
          }

          // Slower steady ADS strafe (extra steady when crouched!)
          this.performCombatStrafe(bot, playerPos, dt, bot.wantCrouch ? 1.1 : 1.75);

          // Wait until rifle is raised in ADS before firing accurate controlled bursts!
          if (bot.reactionTimer > 0) {
            bot.reactionTimer -= dt;
          } else if (bot.adsBlend > 0.65 && bot.fireCooldown <= 0 && bot.staggerTimer <= 0) {
            if (bot.ammo <= 0) {
              this.enterCoverState(bot, playerPos);
            } else {
              if (bot.burstRemaining <= 0) {
                bot.burstRemaining = 2 + Math.floor(Math.random() * 3);
              }
              this.fireBotWeapon(bot, playerPos, playerIsCrouching, onBotShot);
              bot.ammo--;
              bot.burstRemaining--;
              bot.fireCooldown = bot.burstRemaining > 0 ? 0.135 : 0.62 + Math.random() * 0.5;

              if (bot.burstRemaining === 0 && (bot.ammo <= 4 || Math.random() < 0.34)) {
                this.enterCoverState(bot, playerPos);
              }
            }
          }
        }
      }

      // Smart Bots automatically swing open closed doors as they move through doorways!
      if (bot.path.length > 0) {
        const botFloor: 0 | 1 = bot.pos.y > 2.4 ? 1 : 0;
        for (const door of this.compound.doors) {
          if (door.isOpen || door.floor !== botFloor) continue;
          const dDoor = Math.hypot(bot.pos.x - door.center.x, bot.pos.z - door.center.z);
          if (dDoor < 2.05) {
            door.isOpen = true;
            soundEngine.playDoorToggle(true, door.center.distanceTo(playerPos));
          }
        }
      }

      // Smoothly blend human-like stance states (Sprint, ADS Ngeker, Crouch Jongkok)
      const stanceSpeed = 1 - Math.exp(-9.5 * dt);
      bot.sprintBlend = THREE.MathUtils.lerp(bot.sprintBlend, bot.wantSprint ? 1 : 0, stanceSpeed);
      bot.adsBlend = THREE.MathUtils.lerp(bot.adsBlend, bot.wantAds ? 1 : 0, 1 - Math.exp(-11.0 * dt));
      bot.crouchBlend = THREE.MathUtils.lerp(bot.crouchBlend, bot.wantCrouch ? 1 : 0, 1 - Math.exp(-10.5 * dt));

      this.animateBotPose(bot, playerPos, dt);
    }
  }

  private alertSquadmates(sourceBot: SmartBot, playerPos: THREE.Vector3) {
    let flankersAssigned = 0;
    for (const mate of this.bots) {
      if (!mate.alive || mate.id === sourceBot.id) continue;
      if (mate.state !== 'patrol') continue;
      if (mate.pos.distanceTo(sourceBot.pos) < 22) {
        mate.lastKnownPlayerPos = playerPos.clone();
        if (flankersAssigned < 2) {
          flankersAssigned++;
          this.enterFlankState(mate, playerPos);
        } else {
          mate.state = 'investigate';
          mate.stateTimer = 6.5;
          this.assignPath(mate, this.findNearestNode(playerPos).id);
        }
      }
    }
  }

  private enterCoverState(bot: SmartBot, threatPos: THREE.Vector3) {
    bot.state = 'take_cover';
    bot.stateTimer = 1.6 + Math.random() * 1.1;

    let bestNode: NavNode | null = null;
    let bestScore = -9999;

    for (const node of this.compound.navNodes) {
      if (!node.isCover) continue;
      const distBot = node.pos.distanceTo(bot.pos);
      if (distBot > 20) continue;
      const distThreat = node.pos.distanceTo(threatPos);
      if (distThreat < 4.5) continue;

      const exposed = this.checkLos(node.pos, threatPos, 0.9);
      const score = (exposed ? -45 : 42) - distBot * 1.3 + Math.min(18, distThreat * 0.6);
      if (score > bestScore) {
        bestScore = score;
        bestNode = node;
      }
    }

    if (bestNode) {
      this.assignPath(bot, bestNode.id);
    } else {
      bot.path = [];
    }
  }

  private enterFlankState(bot: SmartBot, playerPos: THREE.Vector3) {
    bot.state = 'flank';
    bot.stateTimer = 9.0;

    const candidates = this.compound.navNodes.filter((n) => {
      const d = n.pos.distanceTo(playerPos);
      if (d < 7 || d > 28) return false;
      if (bot.role === 'marksman') return n.floor === 1 && n.isCover;
      return n.isCover && (Math.abs(n.pos.x - playerPos.x) > 5.5 || n.floor === 1);
    });

    if (candidates.length > 0) {
      const pick = candidates[Math.floor(Math.random() * candidates.length)];
      this.assignPath(bot, pick.id);
    } else {
      const fallback = this.findNearestNode(playerPos);
      this.assignPath(bot, fallback.id);
    }
  }

  private checkLos(fromFootPos: THREE.Vector3, playerCameraPos: THREE.Vector3, crouch = 0): boolean {
    const eyeY = fromFootPos.y + THREE.MathUtils.lerp(1.56, 1.06, crouch);
    this.tmpV1.set(fromFootPos.x, eyeY, fromFootPos.z);
    this.tmpV2.copy(playerCameraPos).sub(this.tmpV1);
    const dist = this.tmpV2.length();
    if (dist < 0.5) return true;
    if (dist > 48) return false;
    this.tmpV2.divideScalar(dist);

    this.raycaster.set(this.tmpV1, this.tmpV2);
    this.raycaster.far = dist - 0.32;
    const hits = this.raycaster.intersectObjects(this.compound.losMeshes, false);
    return hits.length === 0;
  }

  private findNearestNode(pos: THREE.Vector3): NavNode {
    let best = this.compound.navNodes[0];
    let bestD = Infinity;
    for (const n of this.compound.navNodes) {
      const dy = (n.pos.y - Math.max(0, pos.y - 1.1)) * 2.5;
      const d = Math.hypot(n.pos.x - pos.x, n.pos.z - pos.z, dy);
      if (d < bestD) {
        bestD = d;
        best = n;
      }
    }
    return best;
  }

  private assignPath(bot: SmartBot, goalId: number) {
    const startId = this.findNearestNode(bot.pos).id;
    bot.targetNodeId = goalId;
    if (startId === goalId) {
      bot.path = [goalId];
      bot.pathIdx = 0;
      return;
    }

    const nodes = this.compound.navNodes;
    const goalPos = nodes[goalId].pos;
    const open = new Set<number>([startId]);
    const cameFrom = new Map<number, number>();
    const gScore = new Map<number, number>([[startId, 0]]);
    const fScore = new Map<number, number>([[startId, nodes[startId].pos.distanceTo(goalPos)]]);

    while (open.size > 0) {
      let current = -1;
      let lowestF = Infinity;
      for (const id of open) {
        const f = fScore.get(id) ?? Infinity;
        if (f < lowestF) {
          lowestF = f;
          current = id;
        }
      }
      if (current === goalId) {
        const reconstructed: number[] = [current];
        let cur = current;
        while (cameFrom.has(cur)) {
          cur = cameFrom.get(cur)!;
          reconstructed.push(cur);
        }
        reconstructed.reverse();
        bot.path = reconstructed;
        bot.pathIdx = reconstructed.length > 1 ? 1 : 0;
        return;
      }

      open.delete(current);
      const curG = gScore.get(current) ?? Infinity;
      for (const nb of nodes[current].neighbors) {
        const tentative = curG + nodes[current].pos.distanceTo(nodes[nb].pos);
        if (tentative < (gScore.get(nb) ?? Infinity)) {
          cameFrom.set(nb, current);
          gScore.set(nb, tentative);
          fScore.set(nb, tentative + nodes[nb].pos.distanceTo(goalPos));
          open.add(nb);
        }
      }
    }

    bot.path = [goalId];
    bot.pathIdx = 0;
  }

  private followPath(bot: SmartBot, dt: number, speed: number) {
    if (bot.pathIdx >= bot.path.length) {
      bot.path = [];
      bot.vel.multiplyScalar(Math.exp(-10 * dt));
      return;
    }

    const target = this.compound.navNodes[bot.path[bot.pathIdx]].pos;
    const dx = target.x - bot.pos.x;
    const dz = target.z - bot.pos.z;
    const distXZ = Math.hypot(dx, dz);

    if (distXZ < 0.65) {
      bot.pathIdx++;
      if (bot.pathIdx >= bot.path.length) {
        bot.path = [];
      }
      return;
    }

    const dirX = dx / distXZ;
    const dirZ = dz / distXZ;
    bot.vel.x = THREE.MathUtils.lerp(bot.vel.x, dirX * speed, Math.min(1, dt * 8));
    bot.vel.z = THREE.MathUtils.lerp(bot.vel.z, dirZ * speed, Math.min(1, dt * 8));

    bot.pos.x += bot.vel.x * dt;
    bot.pos.z += bot.vel.z * dt;

    const targetY = this.compound.getFloorHeight(bot.pos.x, bot.pos.z, Math.max(bot.pos.y, target.y - 0.5));
    bot.pos.y = THREE.MathUtils.lerp(bot.pos.y, targetY, Math.min(1, dt * 12));

    const lookTarget =
      bot.wantAds && bot.lastKnownPlayerPos
        ? bot.lastKnownPlayerPos
        : this.tmpV3.set(target.x, bot.pos.y, target.z);
    this.turnToward(bot, lookTarget, dt * 8.0);
  }

  private performCombatStrafe(bot: SmartBot, playerPos: THREE.Vector3, dt: number, speed: number) {
    bot.strafeTimer -= dt;
    if (bot.strafeTimer <= 0) {
      bot.strafeTimer = 0.85 + Math.random() * 1.1;
      bot.strafeDir = Math.random() < 0.5 ? -1 : 1;
    }

    const toPlayerX = playerPos.x - bot.pos.x;
    const toPlayerZ = playerPos.z - bot.pos.z;
    const len = Math.max(0.1, Math.hypot(toPlayerX, toPlayerZ));
    const rightX = -toPlayerZ / len;
    const rightZ = toPlayerX / len;

    const strafeSpeed = speed * bot.strafeDir;
    const candX = bot.pos.x + rightX * strafeSpeed * dt;
    const candZ = bot.pos.z + rightZ * strafeSpeed * dt;

    const sameFloorY = this.compound.getFloorHeight(candX, candZ, bot.pos.y);
    if (
      Math.abs(sameFloorY - bot.pos.y) < 0.65 &&
      !this.collidesWall(candX, bot.pos.y, candZ, this.compound.colliders3D)
    ) {
      bot.pos.x = candX;
      bot.pos.z = candZ;
      bot.vel.x = rightX * strafeSpeed;
      bot.vel.z = rightZ * strafeSpeed;
    } else {
      bot.strafeDir *= -1;
      bot.vel.set(0, 0, 0);
    }
  }

  private collidesWall(x: number, footY: number, z: number, colliders: BoxCollider3D[]): boolean {
    for (const c of colliders) {
      if (c.disabled) continue;
      if (footY + 1.5 > c.minY && footY + 0.35 < c.maxY) {
        if (x > c.minX && x < c.maxX && z > c.minZ && z < c.maxZ) {
          return true;
        }
      }
    }
    return false;
  }

  private turnToward(bot: SmartBot, target: THREE.Vector3, lerpSpeed: number) {
    const dx = target.x - bot.pos.x;
    const dz = target.z - bot.pos.z;
    if (dx * dx + dz * dz < 0.01) return;
    const desired = Math.atan2(-dx, -dz);
    let diff = desired - bot.yaw;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    bot.yaw += diff * Math.min(1, lerpSpeed);
  }

  private fireBotWeapon(
    bot: SmartBot,
    playerPos: THREE.Vector3,
    playerIsCrouching: boolean,
    onBotShot: (ev: BotShotEvent) => void
  ) {
    bot.muzzleFlash.visible = true;
    bot.muzzleFlash.rotation.z = Math.random() * Math.PI * 2;
    bot.muzzleFlashTimer = 0.065;
    bot.recoilKick = 1.0;

    bot.muzzleSocket.updateWorldMatrix(true, false);
    const muzzlePos = new THREE.Vector3();
    bot.muzzleSocket.getWorldPosition(muzzlePos);

    const dist = muzzlePos.distanceTo(playerPos);

    // ADS + Crouch increases bot precision, while Player Crouching shrinks player target profile!
    const stanceBonus = (bot.adsBlend > 0.7 ? 0.06 : 0) + (bot.crouchBlend > 0.6 ? 0.04 : 0);
    const crouchDefense = playerIsCrouching ? 0.78 : 1.0;
    const hitChance = THREE.MathUtils.clamp((0.44 + stanceBonus - dist * 0.011) * crouchDefense, 0.1, 0.44);
    const hitPlayer = Math.random() < hitChance;
    soundEngine.playBotShot(dist, !hitPlayer);

    const targetPos = playerPos.clone();
    if (!hitPlayer) {
      targetPos.x += (Math.random() - 0.5) * 2.2;
      targetPos.y += (Math.random() - 0.5) * 1.15;
      targetPos.z += (Math.random() - 0.5) * 1.1;
    } else {
      targetPos.y -= 0.12;
    }

    onBotShot({
      muzzlePos,
      targetPos,
      hitPlayer,
      damage: bot.role === 'marksman' ? 13 : 9,
      distance: dist,
    });
  }

  private animateBotPose(bot: SmartBot, playerPos: THREE.Vector3, dt: number) {
    bot.group.position.copy(bot.pos);
    bot.group.rotation.y = bot.yaw;

    const speed = Math.hypot(bot.vel.x, bot.vel.z);
    const isMoving = speed > 0.25;
    const crouch = bot.crouchBlend;
    const sprint = bot.sprintBlend * (isMoving ? 1 : 0);
    const ads = bot.adsBlend;

    // 1. REAL ARTICULATED KNEE-BEND CROUCH & ATHLETIC SPRINT LEG STRIDE!
    const pelvisDrop = crouch * 0.34 + (isMoving ? Math.abs(Math.sin(bot.walkPhase)) * (0.03 + sprint * 0.045) : 0);
    bot.bodyPivot.position.y = -pelvisDrop;
    bot.leftLeg.hip.position.y = 0.88;
    bot.rightLeg.hip.position.y = 0.88;

    if (isMoving) {
      bot.walkPhase += dt * (4.6 + speed * 2.0 + sprint * 2.4);
      const bStepIdx = Math.floor(bot.walkPhase / Math.PI);
      if (bStepIdx > bot.lastStepIdx) {
        bot.lastStepIdx = bStepIdx;
        if (crouch < 0.5) {
          const distToP = bot.pos.distanceTo(playerPos);
          if (distToP < 18) {
            soundEngine.playBotFootstep(distToP, sprint > 0.4);
          }
        }
      }
      const strideAmp = Math.min(0.88, speed * 0.15 + sprint * 0.24) * (1 - crouch * 0.42);
      const sL = Math.sin(bot.walkPhase);
      const sR = Math.sin(bot.walkPhase + Math.PI);

      // Hip swing + crouch thigh lift
      bot.leftLeg.hip.rotation.x = sL * strideAmp + crouch * 0.88;
      bot.rightLeg.hip.rotation.x = sR * strideAmp + crouch * 0.88;

      // Knee bend during swing-through AND deep bend while crouched!
      bot.leftLeg.knee.rotation.x = -Math.max(0, -sL) * (0.58 + sprint * 0.65) - crouch * 1.48;
      bot.rightLeg.knee.rotation.x = -Math.max(0, -sR) * (0.58 + sprint * 0.65) - crouch * 1.48;
    } else {
      // Tactical crouched kneeling/squat stance or composed standing ready stance
      bot.leftLeg.hip.rotation.x = THREE.MathUtils.lerp(bot.leftLeg.hip.rotation.x, crouch * 0.96, Math.min(1, dt * 10));
      bot.rightLeg.hip.rotation.x = THREE.MathUtils.lerp(bot.rightLeg.hip.rotation.x, crouch * 0.72, Math.min(1, dt * 10));
      bot.leftLeg.knee.rotation.x = THREE.MathUtils.lerp(bot.leftLeg.knee.rotation.x, -crouch * 1.56, Math.min(1, dt * 10));
      bot.rightLeg.knee.rotation.x = THREE.MathUtils.lerp(bot.rightLeg.knee.rotation.x, -crouch * 1.38, Math.min(1, dt * 10));
    }

    // 2. UPPER BODY LEAN (Athletic Sprint Forward Lean, Crouch Hunch, & Stagger Flinch!)
    const sprintLean = -sprint * 0.24;
    const crouchLean = -crouch * 0.18;
    const flinch = bot.staggerTimer > 0 ? 0.22 : 0;
    bot.upperBodyPivot.rotation.x = sprintLean + crouchLean + flinch;
    // Slight tactical shooter bladed shoulder stance when ADSing ("ngeker")
    bot.upperBodyPivot.rotation.y = ads * 0.18;

    // 3. WEAPON & ARM STANCE: RELAXED PATROL vs SPRINT TUCK vs CHEEK-WELD ADS ("NGEKER")!
    let targetAimPitch = 0;
    if (ads > 0.2 && bot.hasLos) {
      const dy = playerPos.y - (bot.pos.y + 1.38 - pelvisDrop);
      const dxz = Math.max(1, Math.hypot(playerPos.x - bot.pos.x, playerPos.z - bot.pos.z));
      targetAimPitch = THREE.MathUtils.clamp(Math.atan2(dy, dxz), -0.68, 0.58);
    }

    // Arm position & rotation smoothly blend across Sprint / Patrol / ADS while keeping shoulders anchored cleanly!
    const armX = THREE.MathUtils.lerp(0.02, -0.02, ads) - sprint * 0.03;
    const armY = THREE.MathUtils.lerp(0.495, 0.548, ads) - sprint * 0.045 - (bot.state === 'take_cover' ? 0.04 : 0);
    const armZ = THREE.MathUtils.lerp(-0.02, -0.065, ads) + bot.recoilKick * 0.06;
    bot.armGroup.position.set(armX, armY, armZ);

    const armPitch =
      targetAimPitch * ads +
      bot.recoilKick * 0.14 -
      sprint * 0.18 -
      (bot.state === 'take_cover' && bot.path.length === 0 ? 0.42 : 0);
    const armYaw = sprint * 0.58 - ads * 0.16;
    const armRoll = -sprint * 0.36;
    bot.armGroup.rotation.set(
      THREE.MathUtils.lerp(bot.armGroup.rotation.x, armPitch, Math.min(1, dt * 12)),
      THREE.MathUtils.lerp(bot.armGroup.rotation.y, armYaw, Math.min(1, dt * 10)),
      THREE.MathUtils.lerp(bot.armGroup.rotation.z, armRoll, Math.min(1, dt * 10))
    );

    // Head cheek-weld tilt onto rifle stock when bot is ADSing ("ngeker")!
    bot.headGroup.rotation.x = THREE.MathUtils.lerp(bot.headGroup.rotation.x, targetAimPitch * 0.65 * ads - sprintLean * 0.5, Math.min(1, dt * 10));
    bot.headGroup.rotation.z = THREE.MathUtils.lerp(bot.headGroup.rotation.z, ads * 0.16, Math.min(1, dt * 10));
    bot.headGroup.rotation.y = THREE.MathUtils.lerp(bot.headGroup.rotation.y, -ads * 0.14, Math.min(1, dt * 10));

    // Show tiny illuminated optic sight glow whenever bot is actively ngeker (ADS) at the player!
    bot.opticGlow.visible = ads > 0.65 && bot.hasLos;
  }
}
