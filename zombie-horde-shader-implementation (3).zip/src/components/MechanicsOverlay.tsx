import React from 'react';
import { CalloutPin, WEAPON_SPECS, WeaponId } from '../game/types';

interface MechanicsOverlayProps {
  weaponId: WeaponId;
  pins: CalloutPin[];
  lastEventText: string;
}

const PIN_OFFSETS: Record<CalloutPin['id'], { dx: number; dy: number; align: 'left' | 'right'; color: string }> = {
  muzzle: { dx: -155, dy: -66, align: 'right', color: '#f97316' },
  ejection: { dx: 125, dy: -56, align: 'left', color: '#eab308' },
  action: { dx: 138, dy: 28, align: 'left', color: '#38bdf8' },
  mag: { dx: -145, dy: 64, align: 'right', color: '#a855f7' },
};

export const MechanicsOverlay: React.FC<MechanicsOverlayProps> = ({
  weaponId,
  pins,
  lastEventText,
}) => {
  const spec = WEAPON_SPECS[weaponId];

  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden">
      {/* SVG Leader Lines connecting exact 3D socket points to clean callout cards */}
      <svg className="absolute inset-0 h-full w-full">
        {pins.map((pin) => {
          if (!pin.visible) return null;
          const off = PIN_OFFSETS[pin.id];
          const tx = pin.x + off.dx;
          const ty = pin.y + off.dy;
          const stroke = pin.active ? '#ffffff' : off.color;

          return (
            <g key={`line-${pin.id}`}>
              <line
                x1={pin.x}
                y1={pin.y}
                x2={tx}
                y2={ty}
                stroke={stroke}
                strokeWidth={pin.active ? 2.4 : 1.5}
                strokeDasharray={pin.active ? undefined : '4 3'}
                opacity={pin.active ? 1 : 0.82}
              />
              <circle
                cx={pin.x}
                cy={pin.y}
                r={pin.active ? 7 : 4.5}
                fill={pin.active ? off.color : '#0f172a'}
                stroke={stroke}
                strokeWidth={2}
              />
              {pin.active && (
                <circle
                  cx={pin.x}
                  cy={pin.y}
                  r={14}
                  fill="none"
                  stroke={off.color}
                  strokeWidth={2}
                  opacity={0.75}
                />
              )}
            </g>
          );
        })}
      </svg>

      {/* Live Screen-Space Callout Labels */}
      {pins.map((pin) => {
        if (!pin.visible) return null;
        const off = PIN_OFFSETS[pin.id];
        const tx = pin.x + off.dx;
        const ty = pin.y + off.dy;

        return (
          <div
            key={`label-${pin.id}`}
            style={{
              left: tx,
              top: ty,
              transform: off.align === 'right' ? 'translate(-100%, -50%)' : 'translate(0%, -50%)',
              borderColor: pin.active ? '#ffffff' : off.color,
            }}
            className={`absolute max-w-[215px] rounded-lg border bg-slate-950/82 px-2.5 py-1.5 backdrop-blur-md transition-transform duration-75 ${
              pin.active ? 'scale-105 shadow-[0_0_20px_rgba(255,180,60,0.45)]' : 'shadow-lg'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <span
                className="h-2 w-2 rounded-full"
                style={{ backgroundColor: off.color }}
              />
              <span className="text-[10px] font-black tracking-wider text-white">
                {pin.title}
              </span>
            </div>
            <p className="mt-0.5 text-[10px] leading-tight text-slate-300">{pin.subtitle}</p>
          </div>
        );
      })}

      {/* Sleek Live Ballistics Summary Card (Left-Middle, non-blocking) */}
      <div className="absolute left-4 top-22 w-[295px] rounded-xl border border-white/15 bg-slate-950/78 p-3 text-white shadow-xl backdrop-blur-md">
        <div className="flex items-center justify-between border-b border-white/10 pb-1.5">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
              Simulasi Mekanik • {spec.fireMode}
            </span>
            <h3 className="text-sm font-black tracking-wide">
              {spec.label} — {spec.name}
            </h3>
          </div>
          <span className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[10px] text-slate-200">
            {spec.caliber}
          </span>
        </div>

        <div className="mt-2 space-y-1.5 text-[11px] leading-snug text-slate-200">
          <div>
            <span className="font-bold text-orange-400">Keluar di Muzzle: </span>
            {spec.muzzleFxLabel}
          </div>
          <div>
            <span className="font-bold text-yellow-300">Selongsong (Ejection Port): </span>
            {spec.shellLabel}
          </div>
          <div>
            <span className="font-bold text-sky-300">Animasi Tembak: </span>
            {spec.actionAnimLabel}
          </div>
        </div>

        <div className="mt-2 rounded-md border border-emerald-400/25 bg-emerald-500/12 px-2 py-1 text-[10px] font-medium text-emerald-200">
          {lastEventText}
        </div>
      </div>
    </div>
  );
};
