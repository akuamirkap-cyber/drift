import { Heart, Shield, Skull, Trophy } from 'lucide-react';
import type { HudSnapshot } from '../game/types';

interface Props {
  hud: HudSnapshot;
  onAgain: () => void;
  onLobby: () => void;
}

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

/** Always-visible 5v5 HUD: team score, timer, kill feed, +points per kill, HP, K/D and the end-of-match board. */
export function TdmOverlay({ hud, onAgain, onLobby }: Props) {
  const t = hud.tdm;
  if (!t.active) return null;
  const hp = Math.max(0, Math.min(100, hud.playerHp));
  const hpColor = hp < 30 ? 'bg-red-500' : hp < 60 ? 'bg-amber-400' : 'bg-emerald-400';
  const fb = hud.hitFeedback;

  return (
    <>
      {/* ---- scoreboard */}
      <div className="pointer-events-none fixed left-1/2 top-3 z-30 flex -translate-x-1/2 flex-col items-center gap-1">
        <div className="flex items-stretch overflow-hidden rounded-xl border border-white/15 bg-black/65 text-white shadow-lg backdrop-blur-md">
          <div className="flex items-center gap-2 bg-sky-500/25 px-4 py-1.5">
            <Shield className="h-4 w-4 text-sky-300" />
            <span className="font-mono text-2xl font-black text-sky-200">{t.blue}</span>
          </div>
          <div className="flex flex-col items-center justify-center px-3">
            <span className="font-mono text-sm font-black tracking-wider">{mmss(t.timeLeft)}</span>
            <span className="text-[9px] font-bold uppercase tracking-widest text-slate-400">FT {t.target}</span>
          </div>
          <div className="flex items-center gap-2 bg-red-500/25 px-4 py-1.5">
            <span className="font-mono text-2xl font-black text-red-200">{t.red}</span>
            <Skull className="h-4 w-4 text-red-300" />
          </div>
        </div>
        {t.protectT > 0 && (
          <div className="rounded-md bg-emerald-500/85 px-2.5 py-0.5 text-[10px] font-black tracking-widest text-slate-950">
            PROTEKSI SPAWN
          </div>
        )}
      </div>

      {/* ---- kill feed (shows points per kill) */}
      <div className="pointer-events-none fixed left-4 top-20 z-30 flex w-[270px] flex-col gap-1">
        {t.feed.slice(-5).map((f) => (
          <div
            key={f.id}
            className={`animate-feed-slide flex items-center gap-1.5 rounded-md border px-2 py-1 text-[11px] font-bold backdrop-blur-sm ${
              f.mine ? 'border-amber-300/60 bg-amber-400/20' : 'border-white/10 bg-black/55'
            }`}
          >
            <span className={f.killerTeam === 'blue' ? 'text-sky-300' : 'text-red-300'}>{f.killer}</span>
            <span className="text-slate-400">{f.headshot ? '◎' : '✕'}</span>
            <span className={f.victimTeam === 'blue' ? 'text-sky-300' : 'text-red-300'}>{f.victim}</span>
            {f.points > 0 && <span className="ml-auto font-mono text-emerald-300">+{f.points}</span>}
          </div>
        ))}
      </div>

      {/* ---- +POINTS popup under the crosshair */}
      {fb && fb.isKill && (
        <div className="pointer-events-none fixed inset-x-0 top-[58%] z-30 flex justify-center">
          <div key={`kp-${fb.id}`} className="animate-feed-slide flex items-baseline gap-2 text-center drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
            <span className={`text-3xl font-black ${fb.isHeadshot ? 'text-amber-300' : 'text-white'}`}>+{fb.points}</span>
            <span className={`text-sm font-black tracking-wider ${fb.isHeadshot ? 'text-amber-200' : 'text-slate-200'}`}>{fb.label}</span>
          </div>
        </div>
      )}

      {/* ---- bottom HUD: HP + K/D */}
      <div className="pointer-events-none fixed bottom-5 left-1/2 z-30 flex -translate-x-1/2 items-center gap-3">
        <Heart className={`h-4 w-4 ${hp < 35 ? 'animate-pulse text-red-400' : 'text-emerald-300'}`} />
        <div className="h-2.5 w-52 overflow-hidden rounded-full bg-black/65 ring-1 ring-white/20">
          <div style={{ width: `${hp}%` }} className={`h-full transition-all duration-150 ${hpColor}`} />
        </div>
        <span className="w-8 font-mono text-xs font-black text-white drop-shadow">{hud.playerHp}</span>
        <div className="ml-2 flex items-center gap-2 rounded-lg bg-black/55 px-2.5 py-1 font-mono text-[11px] font-black">
          <span className="text-emerald-300">{t.playerKills}K</span>
          <span className="text-red-300">{t.playerDeaths}D</span>
          <span className="text-amber-300">{hud.score}</span>
          {t.playerStreak > 1 && <span className="text-orange-300">🔥{t.playerStreak}</span>}
        </div>
      </div>

      {/* ---- end of match */}
      {t.phase === 'over' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-[3px]">
          <div className="w-[min(94vw,40rem)] rounded-2xl border border-white/15 bg-slate-950/92 p-5 text-white shadow-2xl">
            <div className="flex flex-col items-center">
              <Trophy className={`h-9 w-9 ${t.winner === 'blue' ? 'text-sky-300' : 'text-red-300'}`} />
              <h2 className={`mt-1 text-3xl font-black tracking-[0.12em] ${t.winner === 'blue' ? 'text-sky-300' : 'text-red-300'}`}>
                {t.winner === 'blue' ? 'TIM BIRU MENANG' : 'TIM MERAH MENANG'}
              </h2>
              <div className="mt-1 font-mono text-lg font-black">
                <span className="text-sky-300">{t.blue}</span> <span className="text-slate-500">—</span>{' '}
                <span className="text-red-300">{t.red}</span>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              {(['blue', 'red'] as const).map((team) => (
                <div key={team} className="rounded-xl bg-white/5 p-2">
                  <div className={`mb-1 text-[10px] font-black uppercase tracking-widest ${team === 'blue' ? 'text-sky-300' : 'text-red-300'}`}>
                    Tim {team === 'blue' ? 'Biru' : 'Merah'}
                  </div>
                  {t.roster
                    .filter((r) => r.team === team)
                    .sort((a, b) => b.kills - a.kills)
                    .map((r) => (
                      <div key={r.name} className={`flex items-center justify-between rounded px-1.5 py-0.5 text-[12px] ${r.isPlayer ? 'bg-amber-400/20 font-black' : ''}`}>
                        <span>{r.name}</span>
                        <span className="font-mono text-slate-300">
                          {r.kills}/{r.deaths}
                        </span>
                      </div>
                    ))}
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-center justify-center gap-2.5">
              <button onClick={onAgain} className="rounded-xl bg-amber-400 px-5 py-2.5 text-sm font-black text-slate-950 transition hover:scale-[1.03] hover:bg-amber-300 active:scale-95">
                MAIN LAGI
              </button>
              <button onClick={onLobby} className="rounded-xl border border-white/20 bg-white/5 px-4 py-2.5 text-xs font-bold text-slate-200 transition hover:bg-white/15">
                Ganti Skin
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
