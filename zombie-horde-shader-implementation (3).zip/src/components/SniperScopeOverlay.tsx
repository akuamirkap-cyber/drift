import React from 'react';

interface SniperScopeOverlayProps {
  rangeMeters: number | null;
  ammo: number;
  magSize: number;
  showTelemetry: boolean;
}

export const SniperScopeOverlay: React.FC<SniperScopeOverlayProps> = ({
  rangeMeters,
  ammo,
  magSize,
  showTelemetry,
}) => {
  return (
    <div className="pointer-events-none fixed inset-0 z-20 flex items-center justify-center overflow-hidden">
      {/* Dark outer optical housing mask with crystal-clear central lens */}
      <svg
        className="h-full w-full"
        viewBox="0 0 1000 1000"
        preserveAspectRatio="xMidYMid slice"
      >
        <defs>
          <radialGradient id="scopeLensEdge" cx="50%" cy="50%" r="50%">
            <stop offset="82%" stopColor="rgba(0,0,0,0)" />
            <stop offset="96%" stopColor="rgba(7,12,18,0.55)" />
            <stop offset="100%" stopColor="rgba(5,8,12,0.98)" />
          </radialGradient>
          <mask id="scopeHole">
            <rect width="1000" height="1000" fill="white" />
            <circle cx="500" cy="500" r="355" fill="black" />
          </mask>
        </defs>

        {/* Solid Matte Scope Housing outside circular lens */}
        <rect width="1000" height="1000" fill="#070a0f" mask="url(#scopeHole)" />

        {/* Subtle inner lens edge darkening & glass rim */}
        <circle cx="500" cy="500" r="356" fill="url(#scopeLensEdge)" />
        <circle cx="500" cy="500" r="355" fill="none" stroke="#1f2937" strokeWidth="5" />

        {/* Main Stadia Thick Outer Posts */}
        <line x1="145" y1="500" x2="365" y2="500" stroke="#0d1117" strokeWidth="4.5" />
        <line x1="635" y1="500" x2="855" y2="500" stroke="#0d1117" strokeWidth="4.5" />
        <line x1="500" y1="145" x2="500" y2="375" stroke="#0d1117" strokeWidth="4.5" />
        <line x1="500" y1="645" x2="500" y2="855" stroke="#0d1117" strokeWidth="4.5" />

        {/* Fine Inner Precision Crosshair Lines */}
        <line x1="365" y1="500" x2="635" y2="500" stroke="#111827" strokeWidth="1.5" />
        <line x1="500" y1="375" x2="500" y2="645" stroke="#111827" strokeWidth="1.5" />

        {/* Mil-Dot Windage Hashmarks */}
        {[-110, -82, -55, -28, 28, 55, 82, 110].map((dx) => (
          <line
            key={`wx-${dx}`}
            x1={500 + dx}
            y1="494"
            x2={500 + dx}
            y2="506"
            stroke="#111827"
            strokeWidth="1.6"
          />
        ))}

        {/* Mil-Dot Bullet-Drop Elevation Hashmarks */}
        {[-90, -60, -30, 30, 60, 90, 120].map((dy, i) => (
          <line
            key={`ey-${dy}`}
            x1={500 - (i > 2 ? 12 + (i - 2) * 3 : 7)}
            y1={500 + dy}
            x2={500 + (i > 2 ? 12 + (i - 2) * 3 : 7)}
            y2={500 + dy}
            stroke="#111827"
            strokeWidth="1.6"
          />
        ))}

        {/* Glowing Precision Red Center Aim Dot */}
        <circle cx="500" cy="500" r="2.8" fill="#ef4444" />
        <circle cx="500" cy="500" r="5.5" fill="none" stroke="rgba(239,68,68,0.45)" strokeWidth="1" />
      </svg>

      {showTelemetry && (
        <div className="absolute bottom-[22%] right-[31%] flex flex-col items-end gap-0.5 font-mono text-xs tracking-wider text-emerald-300 drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
          <span className="text-[10px] uppercase text-emerald-400/80">6.0x • .338 LAPUA</span>
          <span className="text-sm font-bold">
            JARAK: {rangeMeters !== null ? `${rangeMeters} m` : '--- m'}
          </span>
          <span className="text-[11px] text-amber-300">
            MAG: {ammo}/{magSize}
          </span>
        </div>
      )}
    </div>
  );
};
