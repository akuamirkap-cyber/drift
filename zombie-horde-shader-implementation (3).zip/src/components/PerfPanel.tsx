import { Gauge } from 'lucide-react';
import type { PerfSnapshot } from '../game/perfGovernor';

const LEVEL_NAMES = ['ULTRA', 'TINGGI', 'SEDANG', 'RENDAH', 'HEMAT'];

export function fpsColor(fps: number) {
  return fps >= 57 ? 'text-emerald-300' : fps >= 45 ? 'text-amber-300' : 'text-red-400';
}

/** Tiny always-available FPS readout (toggle with F3) */
export function FpsChip({ perf }: { perf: PerfSnapshot }) {
  return (
    <div className="pointer-events-none fixed left-4 top-16 z-30 flex items-center gap-2 rounded-lg border border-white/15 bg-slate-950/78 px-2.5 py-1 font-mono text-[11px] font-bold text-white shadow-lg backdrop-blur-md">
      <Gauge className="h-3.5 w-3.5 text-sky-300" />
      <span className={`${fpsColor(perf.fps)} w-[3.2ch] text-right text-sm font-black`}>{perf.fps}</span>
      <span className="text-slate-400">FPS</span>
      <span className="text-white/20">|</span>
      <span className="text-sky-200">{perf.ms.toFixed(1)}ms</span>
      <span className="text-white/20">|</span>
      <span className="text-amber-200">
        {perf.auto ? 'AUTO ' : ''}
        {perf.levelName} {Math.round(perf.scale * 100)}%
      </span>
      <span className="text-white/20">|</span>
      <span className="text-slate-300">{perf.draws} draw</span>
      <span className="text-white/20">|</span>
      <span className="text-emerald-200">
        {perf.internalW}×{perf.internalH}
        {perf.internalW !== perf.outW ? ` → ${perf.outW}×${perf.outH}` : ''}
      </span>
    </div>
  );
}

interface Props {
  perf: PerfSnapshot;
  onMode: (m: 'auto' | number) => void;
  onScale: (v: number) => void;
  onSharpen: (v: number) => void;
}

const RES_PRESETS: { v: number; label: string; sub: string }[] = [
  { v: 0.75, label: '75%', sub: 'Hemat' },
  { v: 1.0, label: '100%', sub: 'HD' },
  { v: 1.25, label: '125%', sub: 'HD+' },
  { v: 1.5, label: '150%', sub: 'Full' },
  { v: 2.0, label: '200%', sub: 'Ultra' },
];

/** Quality governor controls: Auto (locked 60 FPS) or fixed presets */
export function PerfPanel({ perf, onMode, onScale, onSharpen }: Props) {
  return (
    <div className="mt-3 border-b border-white/10 pb-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-sky-200">
          <Gauge className="h-3.5 w-3.5 text-sky-300" />
          Kualitas & FPS
        </div>
        <span className={`rounded bg-white/10 px-1.5 py-0.5 font-mono text-[11px] font-black ${fpsColor(perf.fps)}`}>
          {perf.fps} FPS
        </span>
      </div>
      <div className="mt-0.5 text-[9px] leading-snug text-slate-400">
        Otomatis menjaga 60 FPS: resolusi dinamis, shadow adaptif, tetap HD tajam. [F3] tampilkan FPS.
      </div>
      <div className="mt-2 grid grid-cols-3 gap-1">
        <button
          onClick={() => onMode('auto')}
          className={`col-span-3 rounded-md border py-1 text-[10px] font-black transition ${
            perf.auto
              ? 'border-emerald-300 bg-emerald-400/25 text-emerald-100'
              : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/15 hover:text-white'
          }`}
        >
          OTOMATIS • KUNCI 60 FPS {perf.auto ? `(${perf.levelName} ${Math.round(perf.scale * 100)}%)` : ''}
        </button>
        {LEVEL_NAMES.map((n, i) => (
          <button
            key={n}
            onClick={() => onMode(i)}
            className={`rounded-md border py-0.5 text-[10px] font-bold transition ${
              !perf.auto && perf.level === i
                ? 'border-sky-300 bg-sky-400/25 text-sky-100'
                : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/15 hover:text-white'
            }`}
          >
            {n}
          </button>
        ))}
      </div>

      {/* ===== RESOLUSI HD ===== */}
      <div className="mt-3 border-t border-white/10 pt-2.5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-black uppercase tracking-wider text-emerald-200">Resolusi Render HD</span>
          <span className="rounded bg-emerald-400/15 px-1.5 py-0.5 font-mono text-[10px] font-black text-emerald-200">
            {perf.internalW}×{perf.internalH}
          </span>
        </div>
        <div className="mt-0.5 text-[9px] leading-snug text-slate-400">
          Layar selalu {perf.outW}×{perf.outH} (native). &gt;100% = supersampling: tepi halus & detail lebih tajam.
        </div>
        <div className="mt-1.5 grid grid-cols-5 gap-1">
          {RES_PRESETS.map((r) => (
            <button
              key={r.v}
              onClick={() => onScale(r.v)}
              className={`rounded-md border py-0.5 leading-tight transition ${
                Math.abs(perf.renderScale - r.v) < 0.02
                  ? 'border-emerald-300 bg-emerald-400/25 text-emerald-100'
                  : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/15 hover:text-white'
              }`}
            >
              <div className="text-[10px] font-black">{r.label}</div>
              <div className="text-[8px] opacity-70">{r.sub}</div>
            </button>
          ))}
        </div>

        <div className="mt-2.5 flex items-center justify-between text-[10px] font-bold text-slate-200">
          <span>Ketajaman gambar</span>
          <span className="font-mono">{Math.round(perf.sharpen * 100)}%</span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          step={1}
          value={Math.round(perf.sharpen * 100)}
          onChange={(e) => onSharpen(parseInt(e.target.value, 10) / 100)}
          className="mt-0.5 h-1.5 w-full cursor-pointer accent-emerald-400"
        />
      </div>
    </div>
  );
}
