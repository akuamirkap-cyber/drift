export type SkinId =
  | 'boonie'
  | 'venom'
  | 'gold'
  | 'reaper'
  | 'police'
  | 'gunner'
  | 'skill'
  | 'spetsnaz'
  | 'silat';

export type FaceId = 'grin' | 'smirk' | 'fierce' | 'cool' | 'neutral' | 'faceless';

export type PartSlot = 'head' | 'face' | 'torso' | 'pants' | 'shoes';

export type AnimMode = 'idle' | 'walk' | 'chase' | 'crouch';

export type HitZone = 'head' | 'chest' | 'leftArm' | 'rightArm' | 'leftLeg' | 'rightLeg';

export type HitTargetGroup = 'head' | 'chest' | 'arm' | 'leg';

export interface CharacterHealthSummary {
  hp: number;
  maxHp: number;
  lastHitZone: HitZone | null;
  knockedOut: boolean;
}

export type ViewSelection = 'squad9' | 'wave1' | 'wave2' | number;

export type StudioBgMode = 'terracotta' | 'dark' | 'clay' | 'transparent';

export type CameraPreset = 'front' | 'threeQuarter' | 'back' | 'closeup';

export interface CharacterLoadout {
  head: SkinId;
  face: FaceId;
  torso: SkinId;
  pants: SkinId;
  shoes: SkinId;
}

export interface FaceMeta {
  id: FaceId;
  index: string;
  name: string;
  shortName: string;
  accentHex: string;
  detail: string;
}

export const FACES_META: FaceMeta[] = [
  {
    id: 'grin',
    index: 'F1',
    name: 'Veteran Grin',
    shortName: 'Grin',
    accentHex: '#d99e7e',
    detail: 'Alis 3D ramping, mata winged, stubble abu & senyum lebar gigi putih',
  },
  {
    id: 'smirk',
    index: 'F2',
    name: 'Striker Smirk',
    shortName: 'Smirk',
    accentHex: '#e2ab8a',
    detail: 'Alis 3D melengkung tegas, mata winged & seringai gigi putih pede',
  },
  {
    id: 'fierce',
    index: 'F3',
    name: 'Battle Snarl',
    shortName: 'Snarl',
    accentHex: '#c95c48',
    detail: 'Alis V garang, luka pipi komando & gertakan gigi putih tajam',
  },
  {
    id: 'cool',
    index: 'F4',
    name: 'Tactical Cool',
    shortName: 'Cool',
    accentHex: '#7fa1bf',
    detail: 'Alis fokus asimetris, mata tajam berkilau, plester hidung & senyum tipis',
  },
  {
    id: 'neutral',
    index: 'F5',
    name: 'Stoic Neutral',
    shortName: 'Netral',
    accentHex: '#a87d63',
    detail: 'Ekspresi tegas serius, mata fokus tajam & mulut datar netral tanpa senyum',
  },
  {
    id: 'faceless',
    index: 'F0',
    name: 'Classic Faceless',
    shortName: 'Polos',
    accentHex: '#8d837b',
    detail: 'Gaya low-poly polos klasik tanpa mata & mulut',
  },
];

export const FACE_META_MAP: Record<FaceId, FaceMeta> = {
  grin: FACES_META[0],
  smirk: FACES_META[1],
  fierce: FACES_META[2],
  cool: FACES_META[3],
  neutral: FACES_META[4],
  faceless: FACES_META[5],
};

export const OPEN_FACE_HEADS: SkinId[] = ['boonie', 'police', 'gunner', 'skill', 'silat'];

export interface MeshStats {
  triangles: number;
  vertices: number;
  meshes: number;
  materials: number;
}

export interface SkinMeta {
  id: SkinId;
  index: string;
  wave: 1 | 2;
  name: string;
  shortName: string;
  codename: string;
  role: string;
  accentHex: string;
  headLabel: string;
  torsoLabel: string;
  pantsLabel: string;
  shoesLabel: string;
  palette: { label: string; hex: string }[];
  gear: string[];
  weapon: string;
  description: string;
}

export const ALL_SKIN_IDS: SkinId[] = [
  'boonie',
  'venom',
  'gold',
  'reaper',
  'police',
  'gunner',
  'skill',
  'spetsnaz',
  'silat',
];

const DEFAULT_FACE_BY_SKIN: Record<SkinId, FaceId> = {
  boonie: 'grin',
  venom: 'fierce',
  gold: 'cool',
  reaper: 'fierce',
  police: 'cool',
  gunner: 'fierce',
  skill: 'smirk',
  spetsnaz: 'grin',
  silat: 'neutral',
};

export const DEFAULT_SQUAD_LOADOUTS: CharacterLoadout[] = ALL_SKIN_IDS.map((id) => ({
  head: id,
  face: DEFAULT_FACE_BY_SKIN[id],
  torso: id,
  pants: id,
  shoes: id,
}));

export const PART_SLOT_LABELS: Record<PartSlot, { title: string; subtitle: string }> = {
  head: { title: 'Kepala / Helm / Topeng', subtitle: 'Ganti headgear & helm' },
  face: { title: 'Ekspresi Wajah (4 Variasi)', subtitle: 'Alis 3D, mata, stubble & senyum' },
  torso: { title: 'Baju / Jas / Jaket', subtitle: 'Atasan, rompi, lengan & senjata' },
  pants: { title: 'Celana & Gear Kaki', subtitle: 'Celana, knee pad, pouch & holster' },
  shoes: { title: 'Sepatu / Sport / Boots', subtitle: 'Alas kaki taktis, sport & formal' },
};

export const SKINS_META: SkinMeta[] = [
  {
    id: 'boonie',
    index: '01',
    wave: 1,
    name: 'Captain Boonie',
    shortName: 'Boonie',
    codename: 'WOODLAND_LEAD',
    role: 'Recon Commander',
    accentHex: '#7d8a4e',
    headLabel: 'Boonie Hat & Mustache',
    torsoLabel: 'Black Jacket + Tan 4-Mag Rig',
    pantsLabel: 'Woodland Camo Cargo Pants',
    shoesLabel: 'Olive Combat Boots',
    palette: [
      { label: 'Boonie Olive', hex: '#687747' },
      { label: 'Tan Rig', hex: '#948b5f' },
      { label: 'Combat Black', hex: '#1c1e21' },
      { label: 'Camo Brown', hex: '#5c4530' },
      { label: 'Mustache', hex: '#462c22' },
    ],
    gear: [
      'Sloped Woodland Camo Boonie Hat',
      'Sculpted Handlebar Mustache & Jaw Beard',
      'Olive-Tan Plate Carrier + 4 Mag Pouches',
      '4x Angled Rifle Magazines',
      'Angular Woodland Camo Cargo Trousers',
      'Sleek Olive Tactical Combat Boots',
    ],
    weapon: 'Heroic Unarmed Stance',
    description:
      'Komandan recon low-poly bertopi boonie melengkung woodland camo, kumis handlebar presisi, plate carrier olive-tan 4 magazine, dan celana loreng geometris.',
  },
  {
    id: 'venom',
    index: '02',
    wave: 1,
    name: 'Venom Fang Ops',
    shortName: 'Venom',
    codename: 'FANG_ASSAULT',
    role: 'Heavy Breacher',
    accentHex: '#b82528',
    headLabel: 'Horned Fang Visor Helmet',
    torsoLabel: 'Breacher Armor + Pack + AK-47',
    pantsLabel: 'Tactical Pants + Thigh Pouch',
    shoesLabel: 'Matte Black Assault Boots',
    palette: [
      { label: 'Armor Slate', hex: '#282b2f' },
      { label: 'Visor Matte', hex: '#141619' },
      { label: 'Fang Crimson', hex: '#a11e24' },
      { label: 'AK Walnut', hex: '#834526' },
      { label: 'Teeth Ivory', hex: '#f4f2ee' },
    ],
    gear: [
      'Aerodynamic Horned Helmet w/ Crimson Sweep',
      'Angular V-Notch Glossy Visor',
      '3D Sculpted Crescent Fang Grin',
      'Wrapped Charcoal Shemagh Scarf',
      'X-Patch Plate Carrier + Assault Backpack',
      'Walnut-Furniture Low-Poly AK-47',
    ],
    weapon: 'AK-47 Assault Rifle',
    description:
      'Breacher black-ops berhelm visor V-notch dengan tanduk sapuan merah crimson, senyum taring 3D tajam, syal taktis tebal, ransel tempur, dan senapan AK-47.',
  },
  {
    id: 'gold',
    index: '03',
    wave: 1,
    name: 'Golden Enforcer',
    shortName: 'Gold Mask',
    codename: 'MIDAS_HEIST',
    role: 'Syndicate Specialist',
    accentHex: '#d4ac3d',
    headLabel: 'Sculpted Metallic Gold Mask',
    torsoLabel: 'Navy Waistcoat + Blue Shirt + SMG',
    pantsLabel: 'Tailored Navy Dress Trousers',
    shoesLabel: 'Black Oxford Dress Shoes',
    palette: [
      { label: 'Burnished Gold', hex: '#d3aa3c' },
      { label: 'Navy Suit', hex: '#283652' },
      { label: 'Powder Shirt', hex: '#a7c2e4' },
      { label: 'Leather Rig', hex: '#714028' },
      { label: 'Carbine Black', hex: '#23262b' },
    ],
    gear: [
      'Sculpted Faceted Metallic Gold Mask',
      'Recessed Almond Eye Cutouts',
      'Tailored Navy Waistcoat, Tie & Gold Buckle',
      'Powder-Blue Rolled-Sleeve Dress Shirt',
      'Sleek Brown Leather Shoulder Holster',
      'Gold Gloves + Black Tactical Carbine',
    ],
    weapon: 'Black Tactical Carbine SMG',
    description:
      'Spesialis sindikat bertopeng emas metalik berfaset anatomis, rompi jas navy rapi, kemeja biru lengan tergulung, shoulder holster kulit cokelat, dan tactical carbine.',
  },
  {
    id: 'reaper',
    index: '04',
    wave: 1,
    name: 'Red-Eye Trooper',
    shortName: 'Red-Eye',
    codename: 'BIO_REAPER',
    role: 'Hazard Extraction',
    accentHex: '#ee221b',
    headLabel: 'PASGT Helmet & Red Gas Mask',
    torsoLabel: 'Multi-Pouch Hazard Chest Rig',
    pantsLabel: 'Drop-Leg Holster + Knee Pads',
    shoesLabel: 'Stealth Extraction Boots',
    palette: [
      { label: 'Crimson Lens', hex: '#f4241c' },
      { label: 'PASGT Charcoal', hex: '#34393d' },
      { label: 'Stealth Black', hex: '#1e2024' },
      { label: 'Rig Graphite', hex: '#2d3137' },
      { label: 'Buckle Steel', hex: '#6c727a' },
    ],
    gear: [
      'Flared PASGT Military Combat Helmet',
      'Gas Mask w/ Glowing Domed Red Lenses',
      'Ribbed Respirator Snout & Angled Canister',
      '5-Pouch Heavy Chest Rig & H-Buckle Belt',
      'Drop-Leg Pistol Holster & Mag Pouch',
      'Molded Hard-Shell Tactical Knee Pads',
    ],
    weapon: 'Holstered Tactical Sidearm',
    description:
      'Pasukan ekstraksi biohazard berhelm PASGT melebar, masker gas berlensa merah menyala dengan filter samping miring, chest rig 5 pouch, dan drop-leg pistol holster.',
  },
  {
    id: 'police',
    index: '05',
    wave: 2,
    name: 'SWAT Police Unit',
    shortName: 'Police',
    codename: 'SWAT_DMR',
    role: 'Tactical Marksman',
    accentHex: '#3b588c',
    headLabel: 'SWAT Helmet, Goggles & Chinstrap',
    torsoLabel: 'Navy BDU + POLICE Vest + Scoped DMR',
    pantsLabel: 'Navy Tactical Pants + Knee Pads',
    shoesLabel: 'Matte Black SWAT Boots',
    palette: [
      { label: 'SWAT Navy', hex: '#283654' },
      { label: 'Kevlar Black', hex: '#212429' },
      { label: 'Goggle Chrome', hex: '#a4adb8' },
      { label: 'POLICE White', hex: '#f2f4f7' },
      { label: 'Gunmetal', hex: '#2a2e34' },
    ],
    gear: [
      'Tactical Riot Helmet w/ Glossy Brow Goggles',
      'Chinstrap Retention Harness & Chin Cup',
      'Kevlar Vest w/ Crisp White POLICE Patch',
      'Long Scoped Marksman DMR Rifle',
      'Navy BDU Trousers w/ Thigh Holster & Straps',
      'Heavy Molded SWAT Knee Pads',
    ],
    weapon: 'Scoped Tactical DMR Rifle',
    description:
      'Unit taktis SWAT polisi berhelm gelap dengan goggle perak mengkilat, tali pengikat dagu, rompi kevlar bertuliskan POLICE, dan senapan marksman DMR ber-scope panjang.',
  },
  {
    id: 'gunner',
    index: '06',
    wave: 2,
    name: 'Heavy LMG Gunner',
    shortName: 'Gunner',
    codename: 'SAW_HEAVY',
    role: 'Suppression Specialist',
    accentHex: '#637641',
    headLabel: 'Olive Beanie, Goggles & Beard',
    torsoLabel: 'Sleeveless Rig + Tattoo Arms + M249',
    pantsLabel: 'Woodland Camo Pants + Hip Pouch',
    shoesLabel: 'Olive-Tan Heavy Boots',
    palette: [
      { label: 'Beanie Olive', hex: '#4f5c3a' },
      { label: 'MOLLE Green', hex: '#6c7349' },
      { label: 'Ammo Box', hex: '#5f6f3b' },
      { label: 'Beard Brown', hex: '#493124' },
      { label: 'Tattoo Ink', hex: '#2a2320' },
    ],
    gear: [
      'Ribbed Olive Knit Beanie & Glossy Goggles',
      'Sculpted Rugged Beard & Mustache',
      'Sleeveless Olive MOLLE Chest Rig',
      'Muscular Bare Arms w/ Sleeve & Wrist Tattoos',
      'Shoulder-Mounted M249 SAW LMG + Bipod + Ammo Drum',
      'Woodland Camo Trousers + Hip Utility Pouch',
    ],
    weapon: 'M249 SAW Light Machine Gun',
    description:
      'Penembak berat berkupluk olive, kacamata goggle mengkilat & berewok tebal, rompi taktis tanpa lengan dengan lengan bertato memanggul senapan mesin M249 SAW ber-bipod.',
  },
  {
    id: 'skill',
    index: '07',
    wave: 2,
    name: 'Skill Issue Agent',
    shortName: 'Skill Issue',
    codename: 'TECH_STREET',
    role: 'Urban Techwear Striker',
    accentHex: '#d9dfe6',
    headLabel: 'Black "SKILL" Baseball Cap',
    torsoLabel: 'White Techwear Anorak + Gold Pistol',
    pantsLabel: 'Black "SKILL ISSUE" Cargo Joggers',
    shoesLabel: 'Black Street Sneakers (White Laces)',
    palette: [
      { label: 'Tech White', hex: '#dcdfe5' },
      { label: 'Cap Black', hex: '#1c1e22' },
      { label: 'Shadow Grey', hex: '#454a54' },
      { label: 'Pistol Gold', hex: '#e2b93e' },
      { label: 'Jogger Matte', hex: '#1b1d21' },
    ],
    gear: [
      'Black Baseball Cap w/ Crisp White SKILL Print',
      'Oversized High-Collar White Techwear Anorak',
      '4 Front Flap Cargo Pockets + SKILL ISSUE Sleeve',
      'Raised Black & Gold Tactical Handgun',
      'Cropped Black Cargo Joggers w/ Side Typography',
      'Low-Top Street Sneakers w/ Criss-Cross White Laces',
    ],
    weapon: 'Black & Gold Tactical Pistol',
    description:
      'Agen techwear streetwear bertopi baseball SKILL, jaket anorak putih berkerah tinggi bertuliskan SKILL ISSUE di lengan, celana jogger kargo hitam, sneaker bertali putih, dan pistol hitam-emas.',
  },
  {
    id: 'spetsnaz',
    index: '08',
    wave: 2,
    name: 'Level-3 Survivor',
    shortName: 'Level-3',
    codename: 'ALTYN_WASTELAND',
    role: 'Armored Scavenger',
    accentHex: '#c92629',
    headLabel: 'Level-3 Altyn Helmet & Red Bandana',
    torsoLabel: 'Rolled Charcoal Jacket + White Tee + Pack',
    pantsLabel: 'Distressed Blue Jeans + Leather Pouch',
    shoesLabel: 'Laced Brown Leather Survival Boots',
    palette: [
      { label: 'Altyn Steel', hex: '#454b52' },
      { label: 'Bandana Red', hex: '#be2328' },
      { label: 'Denim Blue', hex: '#3d5878' },
      { label: 'Boot Leather', hex: '#6b472f' },
      { label: 'Tee Offwhite', hex: '#dedcd8' },
    ],
    gear: [
      'Armored Level-3 Spetsnaz Helmet w/ Eye-Slit Visor',
      'Layered Crimson-Red Cloth Neck Bandana',
      'Contoured Rolled-Sleeve Charcoal Jacket + White Tee',
      'Survival Backpack & Leather Hip Utility Belt',
      'Distressed Faded Blue Jeans w/ Rugged Knee Pads',
      'Chunky Laced Brown Leather Survival Boots',
    ],
    weapon: 'Survival Field Kit',
    description:
      'Penyintas tempur berhelm legendaris Level-3 Spetsnaz berpelindung baja, syal bandana merah berlapis, jaket gelap melengkung lengan digulung, jeans biru pudar, dan boot kulit cokelat bertali.',
  },
  {
    id: 'silat',
    index: '09',
    wave: 2,
    name: 'Silat Striker',
    shortName: 'Silat',
    codename: 'RAID_BRAWLER',
    role: 'CQB Martial Artist',
    accentHex: '#2f5a87',
    headLabel: 'Military Buzzcut, Neutral & Right-Cheek Claw Scar',
    torsoLabel: 'Black Zip Track Jacket + Grey Hem + Watch',
    pantsLabel: 'Worn Dark Indigo Slim Jeans',
    shoesLabel: 'Black Athletic Sport Sneakers',
    palette: [
      { label: 'Jacket Black', hex: '#1b1d22' },
      { label: 'Heather Grey', hex: '#b7bcc4' },
      { label: 'Dark Denim', hex: '#2b3e58' },
      { label: 'SEA Skin', hex: '#d49673' },
      { label: 'Claw Scar', hex: '#8f2422' },
    ],
    gear: [
      'Tight Shaved Military Buzzcut Hairline',
      'Stoic Neutral Face & Right-Cheek Claw Scratch Scar',
      'Black Stand-Collar Zip Jacket w/ Side Zip Pockets',
      'Heather-Grey Undershirt Hem & Black Sport Watch',
      'Worn Dark-Indigo Slim Fighter Jeans',
      'Black Athletic Running Sport Sneakers (Non-Boot)',
    ],
    weapon: 'Unarmed Combat Stance',
    description:
      'Petarung bela diri pria Asia Tenggara berambut botak cepak tentara, rahang tegas, ekspresi mulut netral serius dengan luka cakar di pipi kanan, jaket zip hitam berkaos abu, jam tangan hitam, jeans indigo, dan sepatu sport hitam.',
  },
];

export const SKIN_META_MAP: Record<SkinId, SkinMeta> = {
  boonie: SKINS_META[0],
  venom: SKINS_META[1],
  gold: SKINS_META[2],
  reaper: SKINS_META[3],
  police: SKINS_META[4],
  gunner: SKINS_META[5],
  skill: SKINS_META[6],
  spetsnaz: SKINS_META[7],
  silat: SKINS_META[8],
};
