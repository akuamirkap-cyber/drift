import * as THREE from 'three';
import { createMat, makeStylizedMesh, PALETTE } from './materials';
import { createBeveledBoxGeometry } from './common';

/**
 * Stylized low-poly AK-47 Rifle.
 * Local orientation: Buttstock towards -X, Barrel/Muzzle towards +X, Top +Y, Mag -Y.
 */
export function createAK47(): THREE.Group {
  const gun = new THREE.Group();
  gun.name = 'Weapon_AK47';

  const metalDark = createMat({ color: PALETTE.gunMetalDark, roughness: 0.56, metalness: 0.35 });
  const metalMid = createMat({ color: PALETTE.gunMetalMid, roughness: 0.52, metalness: 0.42 });
  const wood = createMat({ color: PALETTE.akWood, roughness: 0.72, metalness: 0.04 });
  const woodDark = createMat({ color: PALETTE.akWoodDark, roughness: 0.75, metalness: 0.04 });

  const ol = 0.0036;

  // Receiver body
  const receiver = makeStylizedMesh(
    createBeveledBoxGeometry(0.24, 0.068, 0.042, 0.004),
    metalDark,
    { outline: ol, edgeThreshold: 26 }
  );
  receiver.position.set(0.0, 0.0, 0);
  gun.add(receiver);

  // Dust cover sloped top ridge
  const dustCover = makeStylizedMesh(
    createBeveledBoxGeometry(0.21, 0.026, 0.036, 0.004),
    metalMid,
    { outline: ol * 0.8, edgeThreshold: 28 }
  );
  dustCover.position.set(-0.01, 0.040, 0);
  gun.add(dustCover);

  // Rear sight block
  const rearSight = makeStylizedMesh(
    createBeveledBoxGeometry(0.048, 0.028, 0.034, 0.003),
    metalMid,
    { outline: ol * 0.75, edgeThreshold: 28 }
  );
  rearSight.position.set(0.115, 0.042, 0);
  gun.add(rearSight);

  // Angled wooden buttstock (classic AK downward slope)
  const stockShape = new THREE.Shape();
  stockShape.moveTo(0.0, 0.026);
  stockShape.lineTo(-0.245, 0.006);
  stockShape.lineTo(-0.252, -0.092);
  stockShape.lineTo(-0.09, -0.056);
  stockShape.lineTo(0.0, -0.028);
  stockShape.closePath();

  const stockGeom = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.032,
    bevelEnabled: true,
    bevelThickness: 0.004,
    bevelSize: 0.004,
    bevelSegments: 1,
  });
  stockGeom.translate(0, 0, -0.016);

  const stock = makeStylizedMesh(stockGeom, wood, { outline: ol, edgeThreshold: 24 });
  stock.position.set(-0.115, 0.002, 0);
  gun.add(stock);

  // Buttplate cap
  const buttPlate = makeStylizedMesh(
    createBeveledBoxGeometry(0.016, 0.104, 0.040, 0.002),
    metalDark,
    { outline: ol * 0.7, edgeThreshold: 28 }
  );
  buttPlate.position.set(-0.365, -0.042, 0);
  buttPlate.rotation.z = 0.07;
  gun.add(buttPlate);

  // Pistol grip
  const grip = makeStylizedMesh(
    createBeveledBoxGeometry(0.038, 0.112, 0.032, 0.004),
    woodDark,
    { outline: ol * 0.85, edgeThreshold: 28 }
  );
  grip.position.set(-0.068, -0.078, 0);
  grip.rotation.z = -0.26;
  gun.add(grip);

  // Trigger guard
  const trigGuard = makeStylizedMesh(
    createBeveledBoxGeometry(0.068, 0.026, 0.018, 0.002),
    metalDark,
    { outline: ol * 0.6, edgeThreshold: 30 }
  );
  trigGuard.position.set(-0.018, -0.042, 0);
  gun.add(trigGuard);

  // Iconic curved AK-47 banana magazine (segmented 2-part curve)
  const magTop = makeStylizedMesh(
    createBeveledBoxGeometry(0.058, 0.108, 0.030, 0.004),
    metalDark,
    { outline: ol * 0.9, edgeThreshold: 26 }
  );
  magTop.position.set(0.068, -0.082, 0);
  magTop.rotation.z = 0.16;
  gun.add(magTop);

  const magBot = makeStylizedMesh(
    createBeveledBoxGeometry(0.056, 0.105, 0.029, 0.004),
    metalDark,
    { outline: ol * 0.9, edgeThreshold: 26 }
  );
  magBot.position.set(0.100, -0.172, 0);
  magBot.rotation.z = 0.42;
  gun.add(magBot);

  // Wooden lower & upper handguard
  const handguardLower = makeStylizedMesh(
    createBeveledBoxGeometry(0.165, 0.038, 0.040, 0.005),
    wood,
    { outline: ol, edgeThreshold: 26 }
  );
  handguardLower.position.set(0.202, -0.005, 0);
  gun.add(handguardLower);

  const handguardUpper = makeStylizedMesh(
    createBeveledBoxGeometry(0.148, 0.028, 0.034, 0.005),
    woodDark,
    { outline: ol * 0.85, edgeThreshold: 26 }
  );
  handguardUpper.position.set(0.198, 0.024, 0);
  gun.add(handguardUpper);

  // Metal handguard retainer collar
  const retainer = makeStylizedMesh(
    createBeveledBoxGeometry(0.022, 0.062, 0.044, 0.003),
    metalMid,
    { outline: ol * 0.75, edgeThreshold: 28 }
  );
  retainer.position.set(0.285, 0.008, 0);
  gun.add(retainer);

  // Gas tube + gas block
  const gasTubeGeom = new THREE.CylinderGeometry(0.011, 0.011, 0.115, 6);
  gasTubeGeom.rotateZ(Math.PI / 2);
  const gasTube = makeStylizedMesh(gasTubeGeom, metalMid, {
    outline: ol * 0.7,
    edgeThreshold: 32,
  });
  gasTube.position.set(0.34, 0.026, 0);
  gun.add(gasTube);

  const gasBlock = makeStylizedMesh(
    createBeveledBoxGeometry(0.034, 0.052, 0.026, 0.003),
    metalDark,
    { outline: ol * 0.75, edgeThreshold: 26 }
  );
  gasBlock.position.set(0.395, 0.012, 0);
  gasBlock.rotation.z = -0.22;
  gun.add(gasBlock);

  // Main slender barrel
  const barrelGeom = new THREE.CylinderGeometry(0.012, 0.013, 0.30, 6);
  barrelGeom.rotateZ(Math.PI / 2);
  const barrel = makeStylizedMesh(barrelGeom, metalDark, {
    outline: ol * 0.75,
    edgeThreshold: 32,
  });
  barrel.position.set(0.435, -0.002, 0);
  gun.add(barrel);

  // Cleaning rod beneath barrel
  const rodGeom = new THREE.CylinderGeometry(0.0045, 0.0045, 0.25, 5);
  rodGeom.rotateZ(Math.PI / 2);
  const rod = makeStylizedMesh(rodGeom, metalMid, {
    outline: ol * 0.45,
    edgeThreshold: 40,
  });
  rod.position.set(0.415, -0.018, 0);
  gun.add(rod);

  // Front sight post tower
  const frontSight = makeStylizedMesh(
    createBeveledBoxGeometry(0.024, 0.052, 0.018, 0.002),
    metalDark,
    { outline: ol * 0.7, edgeThreshold: 26 }
  );
  frontSight.position.set(0.545, 0.022, 0);
  gun.add(frontSight);

  // Slant muzzle brake
  const muzzleGeom = new THREE.CylinderGeometry(0.015, 0.015, 0.042, 6);
  muzzleGeom.rotateZ(Math.PI / 2);
  const muzzle = makeStylizedMesh(muzzleGeom, metalMid, {
    outline: ol * 0.75,
    edgeThreshold: 30,
  });
  muzzle.position.set(0.595, -0.002, 0);
  gun.add(muzzle);

  return gun;
}

/**
 * Stylized low-poly Tactical Carbine / SMG (held by Golden Agent).
 * Local orientation: Stock towards -X, Barrel/Muzzle towards +X, Top +Y, Mag -Y.
 */
export function createTacticalCarbine(): THREE.Group {
  const gun = new THREE.Group();
  gun.name = 'Weapon_TacticalCarbine';

  const bodyDark = createMat({ color: 0x222428, roughness: 0.60, metalness: 0.28 });
  const bodyMid = createMat({ color: 0x33373d, roughness: 0.54, metalness: 0.36 });
  const boltSilver = createMat({ color: PALETTE.gunMetalLight, roughness: 0.38, metalness: 0.65 });

  const ol = 0.0036;

  // Main upper + lower receiver
  const upperRec = makeStylizedMesh(
    createBeveledBoxGeometry(0.245, 0.052, 0.046, 0.004),
    bodyDark,
    { outline: ol, edgeThreshold: 26 }
  );
  upperRec.position.set(0.015, 0.014, 0);
  gun.add(upperRec);

  const lowerRec = makeStylizedMesh(
    createBeveledBoxGeometry(0.205, 0.042, 0.042, 0.004),
    bodyMid,
    { outline: ol * 0.9, edgeThreshold: 26 }
  );
  lowerRec.position.set(0.012, -0.022, 0);
  gun.add(lowerRec);

  // Silver bolt / ejection port panel visible on front (+Z) side of receiver!
  const bolt = makeStylizedMesh(
    createBeveledBoxGeometry(0.068, 0.018, 0.008, 0.001),
    boltSilver,
    { outline: ol * 0.4, edgeThreshold: 30 }
  );
  bolt.position.set(0.048, 0.016, 0.024);
  gun.add(bolt);

  // Top picatinny rail strip
  const topRail = makeStylizedMesh(
    createBeveledBoxGeometry(0.42, 0.014, 0.026, 0.002),
    bodyMid,
    { outline: ol * 0.6, edgeThreshold: 28 }
  );
  topRail.position.set(0.115, 0.044, 0);
  gun.add(topRail);

  // Compact folding / tactical stock (triangular cutaway look matching reference)
  const stockShape = new THREE.Shape();
  stockShape.moveTo(0.0, 0.032);
  stockShape.lineTo(-0.22, 0.030);
  stockShape.lineTo(-0.228, -0.088);
  stockShape.lineTo(-0.185, -0.088);
  stockShape.lineTo(-0.085, -0.026);
  stockShape.lineTo(0.0, -0.020);
  stockShape.closePath();

  const stockGeom = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.032,
    bevelEnabled: true,
    bevelThickness: 0.004,
    bevelSize: 0.004,
    bevelSegments: 1,
  });
  stockGeom.translate(0, 0, -0.016);
  const stock = makeStylizedMesh(stockGeom, bodyDark, { outline: ol, edgeThreshold: 24 });
  stock.position.set(-0.105, 0.006, 0);
  gun.add(stock);

  // Angled pistol grip
  const grip = makeStylizedMesh(
    createBeveledBoxGeometry(0.040, 0.108, 0.034, 0.005),
    bodyDark,
    { outline: ol * 0.85, edgeThreshold: 26 }
  );
  grip.position.set(-0.068, -0.078, 0);
  grip.rotation.z = -0.28;
  gun.add(grip);

  // Straight tactical box magazine (slightly canted forward)
  const mag = makeStylizedMesh(
    createBeveledBoxGeometry(0.064, 0.155, 0.032, 0.004),
    bodyDark,
    { outline: ol * 0.9, edgeThreshold: 26 }
  );
  mag.position.set(0.072, -0.102, 0);
  mag.rotation.z = 0.12;
  gun.add(mag);

  // Ventilated railed handguard shroud
  const handguard = makeStylizedMesh(
    createBeveledBoxGeometry(0.215, 0.056, 0.048, 0.006),
    bodyDark,
    { outline: ol, edgeThreshold: 26 }
  );
  handguard.position.set(0.238, 0.008, 0);
  gun.add(handguard);

  // Side rail ribs on handguard
  for (let i = 0; i < 4; i++) {
    const rib = makeStylizedMesh(
      createBeveledBoxGeometry(0.022, 0.016, 0.054, 0.002),
      bodyMid,
      { outline: 0, edgeThreshold: 32 }
    );
    rib.position.set(0.168 + i * 0.044, 0.008, 0);
    gun.add(rib);
  }

  // Barrel extending forward from handguard
  const barrelGeom = new THREE.CylinderGeometry(0.014, 0.014, 0.135, 6);
  barrelGeom.rotateZ(Math.PI / 2);
  const barrel = makeStylizedMesh(barrelGeom, bodyMid, {
    outline: ol * 0.8,
    edgeThreshold: 32,
  });
  barrel.position.set(0.395, 0.010, 0);
  gun.add(barrel);

  // Low-profile iron sights (rear & front)
  const rearSight = makeStylizedMesh(
    createBeveledBoxGeometry(0.028, 0.024, 0.022, 0.002),
    bodyMid,
    { outline: ol * 0.65, edgeThreshold: 28 }
  );
  rearSight.position.set(-0.072, 0.058, 0);
  gun.add(rearSight);

  const frontSight = makeStylizedMesh(
    createBeveledBoxGeometry(0.024, 0.032, 0.020, 0.002),
    bodyMid,
    { outline: ol * 0.65, edgeThreshold: 28 }
  );
  frontSight.position.set(0.355, 0.034, 0);
  gun.add(frontSight);

  // Flash hider muzzle brake
  const muzzleGeom = new THREE.CylinderGeometry(0.018, 0.017, 0.052, 6);
  muzzleGeom.rotateZ(Math.PI / 2);
  const muzzle = makeStylizedMesh(muzzleGeom, bodyDark, {
    outline: ol * 0.8,
    edgeThreshold: 28,
  });
  muzzle.position.set(0.468, 0.010, 0);
  gun.add(muzzle);

  return gun;
}

/**
 * Compact low-poly holstered pistol & drop-leg tactical holster (for Red-Eye Trooper).
 */
export function createDropLegHolster(): THREE.Group {
  const g = new THREE.Group();
  const holsterMat = createMat({ color: 0x26292e, roughness: 0.78 });
  const gunMat = createMat({ color: 0x1c1e22, roughness: 0.56, metalness: 0.3 });
  const ol = 0.0036;

  // Holster outer shell
  const shell = makeStylizedMesh(
    createBeveledBoxGeometry(0.054, 0.165, 0.105, 0.005),
    holsterMat,
    { outline: ol, edgeThreshold: 26 }
  );
  g.add(shell);

  // Pistol grip sticking up out of holster
  const grip = makeStylizedMesh(
    createBeveledBoxGeometry(0.034, 0.088, 0.048, 0.004),
    gunMat,
    { outline: ol * 0.85, edgeThreshold: 28 }
  );
  grip.position.set(0.004, 0.085, -0.024);
  grip.rotation.x = -0.32;
  g.add(grip);

  // Pistol rear slide protruding slightly
  const slide = makeStylizedMesh(
    createBeveledBoxGeometry(0.032, 0.042, 0.075, 0.003),
    gunMat,
    { outline: ol * 0.8, edgeThreshold: 28 }
  );
  slide.position.set(0.002, 0.088, 0.014);
  g.add(slide);

  return g;
}

/**
 * Stylized low-poly Scoped Tactical SWAT Marksman DMR / M4 Rifle (Skin 05: SWAT Police).
 * Local orientation: Stock -> -X, Muzzle -> +X, Scope -> +Y, Mag -> -Y.
 */
export function createSWATMarksmanRifle(): THREE.Group {
  const gun = new THREE.Group();
  gun.name = 'Weapon_SWAT_DMR';

  const darkMat = createMat({ color: 0x202328, roughness: 0.56, metalness: 0.34 });
  const midMat = createMat({ color: 0x333840, roughness: 0.48, metalness: 0.42 });
  const opticLens = createMat({ color: 0x4b5c70, roughness: 0.22, metalness: 0.6 });
  const ol = 0.0034;

  // Receiver
  const rec = makeStylizedMesh(createBeveledBoxGeometry(0.24, 0.068, 0.044, 0.004), darkMat, {
    outline: ol,
  });
  gun.add(rec);

  // Buffer tube + Collapsible tactical stock
  const tubeGeom = new THREE.CylinderGeometry(0.015, 0.015, 0.14, 8);
  tubeGeom.rotateZ(Math.PI / 2);
  const tube = makeStylizedMesh(tubeGeom, midMat, { outline: ol * 0.8 });
  tube.position.set(-0.18, 0.016, 0);
  gun.add(tube);

  const stockShape = new THREE.Shape();
  stockShape.moveTo(0, 0.028);
  stockShape.lineTo(-0.15, 0.028);
  stockShape.lineTo(-0.155, -0.088);
  stockShape.lineTo(-0.115, -0.088);
  stockShape.lineTo(-0.02, -0.020);
  stockShape.closePath();
  const stockGeom = new THREE.ExtrudeGeometry(stockShape, {
    depth: 0.032,
    bevelEnabled: true,
    bevelThickness: 0.004,
    bevelSize: 0.004,
    bevelSegments: 1,
  });
  stockGeom.translate(0, 0, -0.016);
  const stock = makeStylizedMesh(stockGeom, darkMat, { outline: ol });
  stock.position.set(-0.145, 0.006, 0);
  gun.add(stock);

  // Pistol grip
  const grip = makeStylizedMesh(createBeveledBoxGeometry(0.036, 0.106, 0.032, 0.004), darkMat, {
    outline: ol * 0.85,
  });
  grip.position.set(-0.068, -0.078, 0);
  grip.rotation.z = -0.28;
  gun.add(grip);

  // Curved tactical rifle magazine
  const mag = makeStylizedMesh(createBeveledBoxGeometry(0.060, 0.165, 0.030, 0.004), darkMat, {
    outline: ol * 0.9,
  });
  mag.position.set(0.062, -0.108, 0);
  mag.rotation.z = 0.18;
  gun.add(mag);

  // Long quad-rail handguard
  const handguard = makeStylizedMesh(createBeveledBoxGeometry(0.275, 0.054, 0.048, 0.005), darkMat, {
    outline: ol,
  });
  handguard.position.set(0.258, 0.004, 0);
  gun.add(handguard);

  // Tactical handguard rail notches
  for (let i = 0; i < 6; i++) {
    const rib = makeStylizedMesh(createBeveledBoxGeometry(0.020, 0.016, 0.055, 0.002), midMat, {
      outline: 0,
    });
    rib.position.set(0.145 + i * 0.044, 0.004, 0);
    gun.add(rib);
  }

  // Prominent Telescopic Marksman Optic Scope on top rail!
  for (const mx of [-0.038, 0.058]) {
    const mount = makeStylizedMesh(createBeveledBoxGeometry(0.022, 0.034, 0.028, 0.002), midMat, {
      outline: ol * 0.65,
    });
    mount.position.set(mx, 0.050, 0);
    gun.add(mount);
  }
  const scopeTubeGeom = new THREE.CylinderGeometry(0.018, 0.018, 0.16, 10);
  scopeTubeGeom.rotateZ(Math.PI / 2);
  const scopeTube = makeStylizedMesh(scopeTubeGeom, darkMat, { outline: ol * 0.8 });
  scopeTube.position.set(0.012, 0.072, 0);
  gun.add(scopeTube);

  // Scope flared front bell + rear eyepiece
  const frontBellGeom = new THREE.CylinderGeometry(0.026, 0.020, 0.068, 10);
  frontBellGeom.rotateZ(Math.PI / 2);
  const frontBell = makeStylizedMesh(frontBellGeom, midMat, { outline: ol * 0.8 });
  frontBell.position.set(0.112, 0.072, 0);
  gun.add(frontBell);

  const rearEyeGeom = new THREE.CylinderGeometry(0.023, 0.019, 0.046, 10);
  rearEyeGeom.rotateZ(Math.PI / 2);
  const rearEye = makeStylizedMesh(rearEyeGeom, darkMat, { outline: ol * 0.8 });
  rearEye.position.set(-0.082, 0.072, 0);
  gun.add(rearEye);

  const lensCapGeom = new THREE.CylinderGeometry(0.021, 0.021, 0.008, 10);
  lensCapGeom.rotateZ(Math.PI / 2);
  const lensCap = makeStylizedMesh(lensCapGeom, opticLens, { outline: 0 });
  lensCap.position.set(0.146, 0.072, 0);
  gun.add(lensCap);

  // Front A-frame tactical iron sight tower
  const frontSight = makeStylizedMesh(createBeveledBoxGeometry(0.034, 0.054, 0.018, 0.002), midMat, {
    outline: ol * 0.7,
  });
  frontSight.position.set(0.415, 0.026, 0);
  gun.add(frontSight);

  // Extended long fluted marksman barrel / perforated suppressor shroud (iconic long SWAT look!)
  const barrelGeom = new THREE.CylinderGeometry(0.014, 0.015, 0.28, 8);
  barrelGeom.rotateZ(Math.PI / 2);
  const barrel = makeStylizedMesh(barrelGeom, midMat, { outline: ol * 0.78 });
  barrel.position.set(0.515, 0.004, 0);
  gun.add(barrel);

  const shroudGeom = new THREE.CylinderGeometry(0.021, 0.021, 0.165, 8);
  shroudGeom.rotateZ(Math.PI / 2);
  const shroud = makeStylizedMesh(shroudGeom, darkMat, { outline: ol * 0.82 });
  shroud.position.set(0.578, 0.004, 0);
  gun.add(shroud);

  return gun;
}

/**
 * Stylized Heavy M249 SAW Light Machine Gun (Skin 06: Heavy Gunner).
 * Carried proudly resting over the shoulder with olive green ammo drum & twin bipod legs!
 * Local orientation: Stock -> -X, Muzzle -> +X, Feed cover -> +Y, Bipod -> -Y.
 */
export function createM249LMG(): THREE.Group {
  const gun = new THREE.Group();
  gun.name = 'Weapon_M249_LMG';

  const darkMat = createMat({ color: 0x222529, roughness: 0.56, metalness: 0.34 });
  const midMat = createMat({ color: 0x353a41, roughness: 0.50, metalness: 0.42 });
  const ammoMat = createMat({ color: PALETTE.gunnerAmmoGreen, roughness: 0.78, metalness: 0.08 });
  const brassMat = createMat({ color: 0xcfa43c, roughness: 0.38, metalness: 0.55 });
  const ol = 0.0036;

  // Heavy boxy SAW receiver body
  const receiver = makeStylizedMesh(createBeveledBoxGeometry(0.32, 0.092, 0.068, 0.006), darkMat, {
    outline: ol,
  });
  gun.add(receiver);

  // Ribbed top feed tray cover
  const feedCover = makeStylizedMesh(createBeveledBoxGeometry(0.24, 0.028, 0.062, 0.004), midMat, {
    outline: ol * 0.8,
  });
  feedCover.position.set(0.015, 0.056, 0);
  gun.add(feedCover);

  // Heavy skeletal buttstock + rear grip
  const stock = makeStylizedMesh(createBeveledBoxGeometry(0.20, 0.084, 0.044, 0.005), darkMat, {
    outline: ol,
  });
  stock.position.set(-0.245, -0.008, 0);
  gun.add(stock);

  const grip = makeStylizedMesh(createBeveledBoxGeometry(0.040, 0.115, 0.036, 0.004), darkMat, {
    outline: ol * 0.85,
  });
  grip.position.set(-0.105, -0.092, 0);
  grip.rotation.z = -0.22;
  gun.add(grip);

  // ICONIC OLIVE-GREEN AMMO DRUM BOX MOUNTED PROMINENTLY BESIDE BEANIE (exact Image 1!)
  const ammoBox = makeStylizedMesh(createBeveledBoxGeometry(0.118, 0.150, 0.094, 0.007), ammoMat, {
    outline: ol,
  });
  ammoBox.position.set(-0.072, 0.118, 0.028);
  ammoBox.rotation.z = 0.08;
  gun.add(ammoBox);

  // Subtle brass bullet belt links feeding into receiver
  for (let i = 0; i < 4; i++) {
    const bullet = makeStylizedMesh(
      createBeveledBoxGeometry(0.012, 0.032, 0.014, 0.002),
      brassMat,
      { outline: 0 }
    );
    bullet.position.set(-0.012 + i * 0.018, 0.058, 0.044);
    gun.add(bullet);
  }

  // Perforated heat-shield handguard
  const handguard = makeStylizedMesh(createBeveledBoxGeometry(0.26, 0.068, 0.060, 0.006), midMat, {
    outline: ol,
  });
  handguard.position.set(0.275, 0.006, 0);
  gun.add(handguard);

  // Heavy long LMG barrel + gas tube
  const barrelGeom = new THREE.CylinderGeometry(0.016, 0.018, 0.36, 8);
  barrelGeom.rotateZ(Math.PI / 2);
  const barrel = makeStylizedMesh(barrelGeom, darkMat, { outline: ol * 0.8 });
  barrel.position.set(0.505, 0.012, 0);
  gun.add(barrel);

  const gasGeom = new THREE.CylinderGeometry(0.011, 0.011, 0.24, 6);
  gasGeom.rotateZ(Math.PI / 2);
  const gas = makeStylizedMesh(gasGeom, midMat, { outline: ol * 0.7 });
  gas.position.set(0.455, -0.016, 0);
  gun.add(gas);

  // Prominent Front Sight Tower & Flash Hider
  const frontSight = makeStylizedMesh(createBeveledBoxGeometry(0.026, 0.056, 0.022, 0.003), darkMat, {
    outline: ol * 0.7,
  });
  frontSight.position.set(0.605, 0.038, 0);
  gun.add(frontSight);

  const muzzleGeom = new THREE.CylinderGeometry(0.020, 0.019, 0.055, 8);
  muzzleGeom.rotateZ(Math.PI / 2);
  const muzzle = makeStylizedMesh(muzzleGeom, midMat, { outline: ol * 0.8 });
  muzzle.position.set(0.695, 0.012, 0);
  gun.add(muzzle);

  // ICONIC TWIN BIPOD LEGS EXTENDING DOWNWARD (instant M249 recognition in reference image!)
  const bipodMount = makeStylizedMesh(createBeveledBoxGeometry(0.044, 0.036, 0.044, 0.004), darkMat, {
    outline: ol * 0.7,
  });
  bipodMount.position.set(0.405, -0.038, 0);
  gun.add(bipodMount);

  for (const s of [-1, 1]) {
    const leg = makeStylizedMesh(createBeveledBoxGeometry(0.016, 0.215, 0.016, 0.003), darkMat, {
      outline: ol * 0.65,
    });
    leg.position.set(0.415 + s * 0.038, -0.140, s * 0.022);
    leg.rotation.z = s * 0.34;
    leg.rotation.x = s * 0.16;
    gun.add(leg);

    const foot = makeStylizedMesh(createBeveledBoxGeometry(0.032, 0.016, 0.026, 0.002), midMat, {
      outline: ol * 0.6,
    });
    foot.position.set(0.448 + s * 0.068, -0.236, s * 0.038);
    gun.add(foot);
  }

  return gun;
}

/**
 * Sleek Black & Metallic-Gold Tactical Handgun (Skin 07: Skill Issue Agent — Image 1 exact!).
 * Local origin (0, 0, 0) sits right at the palm grip center; barrel points straight UP (+Y),
 * grip extends cleanly down-left, gleaming slim gold upper slide stripe runs along front-top!
 */
export function createSkillPistol(): THREE.Group {
  const gun = new THREE.Group();
  gun.name = 'Weapon_SkillGoldPistol';

  const darkMat = createMat({ color: 0x1d1f24, roughness: 0.46, metalness: 0.38 });
  const gripBrownMat = createMat({ color: 0x5c4734, roughness: 0.72, metalness: 0.08 });
  const goldMat = createMat({
    color: PALETTE.skillPistolGold,
    roughness: 0.22,
    metalness: 0.58,
    emissive: 0x3a2906,
    emissiveIntensity: 0.22,
  });
  const ol = 0.0028;

  // Ergonomic angled handgun grip centered cleanly at origin (0, 0, 0) so hand wraps it naturally!
  const grip = makeStylizedMesh(createBeveledBoxGeometry(0.038, 0.096, 0.026, 0.005), gripBrownMat, {
    outline: ol,
  });
  grip.position.set(-0.014, -0.008, 0);
  grip.rotation.z = -0.34;
  gun.add(grip);

  // Matte black lower receiver & barrel rail rising straight UP (+Y)
  const lowerFrame = makeStylizedMesh(
    createBeveledBoxGeometry(0.032, 0.195, 0.028, 0.004),
    darkMat,
    { outline: ol }
  );
  lowerFrame.position.set(0.022, 0.118, 0);
  gun.add(lowerFrame);

  // Sleek slim metallic-gold upper slide bar gleaming along the top/front edge (exact Image 1!)
  const goldSlide = makeStylizedMesh(
    createBeveledBoxGeometry(0.015, 0.185, 0.031, 0.002),
    goldMat,
    { outline: ol * 0.8 }
  );
  goldSlide.position.set(0.038, 0.124, 0);
  gun.add(goldSlide);

  // Distinct compact trigger guard loop
  const guardTop = makeStylizedMesh(createBeveledBoxGeometry(0.032, 0.009, 0.014, 0.002), darkMat, {
    outline: ol * 0.5,
  });
  guardTop.position.set(-0.006, 0.068, 0);
  gun.add(guardTop);

  const guardFront = makeStylizedMesh(createBeveledBoxGeometry(0.009, 0.034, 0.014, 0.002), darkMat, {
    outline: ol * 0.5,
  });
  guardFront.position.set(-0.020, 0.052, 0);
  gun.add(guardFront);

  // Front iron sight pip
  const sight = makeStylizedMesh(createBeveledBoxGeometry(0.010, 0.014, 0.010, 0.001), darkMat, {
    outline: ol * 0.5,
  });
  sight.position.set(0.044, 0.208, 0);
  gun.add(sight);

  return gun;
}
