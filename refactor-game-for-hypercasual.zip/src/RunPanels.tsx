// Roguelite panels: card pick, "ONE MORE RUN" death screen, in-run HUD chips, toasts, and the 3 one-click upgrades.
// Same style as the old panels (dark-blue g-panel, g-ribbon, g-btn buttons, font-game).
import { ReactNode, useEffect, useRef, useState } from 'react';
import type { RagWorld, RUi } from './game/ragdoll/game';
import { CFG, CardId, cardName, unlockName } from './game/ragdoll/config';
import { CARD_BY, cardText } from './game/ragdoll/cards';
import { SimpleUpId, unlockOf } from './game/ragdoll/meta';
import { audioInit, snd } from './game/ragdoll/audio';
import { SkillGlyph } from './SkillTreeArt';
import { CARD_ART } from './cardArt';
import { tx, useLang } from './i18n';
import GameOverScreen from './GameOver';

type W = () => RagWorld | undefined;
const TYPE_COL: Record<string, string> = { PANAH: '#ffb02e', BERTAHAN: '#5cf08a', JALUR: '#69d5ff', RISIKO: '#ff5a4f', KHUSUS: '#b98cff', LANGKA: '#9ff0ff' };
const PATH_COL: Record<string, string> = { speed: '#69d5ff', accuracy: '#ffd34e', vitality: '#85e271' };
const pct = (x: number) => Math.round(x * 100);

function Chip({ children, col = 'text-white' }: { children: ReactNode; col?: string }) {
  return <span className={`g-chip font-game flex items-center gap-1 px-2.5 py-1 text-xs leading-none ${col}`}>{children}</span>;
}

export function CardChip({ id, lv }: { id: CardId; lv: number }) {
  useLang();
  const d = CARD_BY[id];
  const art = CARD_ART[id];
  return (
    <span title={`${cardName(d)} LV${lv}: ${cardText(id, lv)}`} className="g-chip font-game flex items-center gap-1.5 px-2 py-0.5 text-[11px] leading-none text-white" style={{ boxShadow: `inset 0 0 0 1px ${d.path ? PATH_COL[d.path] : TYPE_COL[d.type]}` }}>
      {art ? (
        <img src={art} alt={cardName(d)} referrerPolicy="no-referrer" className="h-4 w-4 rounded-sm object-cover" />
      ) : d.glyph ? (
        <SkillGlyph icon={d.glyph} className="h-4 w-4" />
      ) : (
        <span className="text-sm">{d.icon}</span>
      )}
      {lv}
    </span>
  );
}

// The reward cards ("LEVEL X CLEARED!" / boss reward) live in their own file.
export { CardPickPanel } from './RewardCards';

/* ---------------- the 3 one-click upgrades (ATTACK / HP / COINS) ---------------- */

const UPS: { id: SimpleUpId; en: string; idn: string; col: string; dark: string; icon: ReactNode; stat: [string, string] }[] = [
  {
    id: 'atk', en: 'ATTACK', idn: 'SERANGAN', col: '#ff7a5c', dark: '#8a1f12',
    icon: <svg viewBox="0 0 24 24" className="h-8 w-8" aria-hidden><path d="M4 20l9-9M13 11l6-8 2 2-8 6M4 20l3 1-1-3z" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" /></svg>,
    stat: ['ARROW DAMAGE', 'DAMAGE PANAH'],
  },
  {
    id: 'hp', en: 'HEALTH', idn: 'NYAWA', col: '#5cf08a', dark: '#0f6b35',
    icon: <svg viewBox="0 0 24 24" className="h-8 w-8" aria-hidden><path d="M12 20.5S3.5 15 3.5 9a4.5 4.5 0 0 1 8.5-2 4.5 4.5 0 0 1 8.5 2c0 6-8.5 11.5-8.5 11.5z" fill="#fff" /></svg>,
    stat: ['MAX HP', 'HP MAKS'],
  },
  {
    id: 'gold', en: 'COINS', idn: 'KOIN', col: '#ffd23f', dark: '#8a5a00',
    icon: <svg viewBox="0 0 24 24" className="h-8 w-8" aria-hidden><circle cx="12" cy="12" r="9" fill="#fff" /><path d="M12 7v10M9.5 9.5h4a2 2 0 0 1 0 4h-4" stroke="#b86a00" strokeWidth="2.2" strokeLinecap="round" fill="none" /></svg>,
    stat: ['GOLD EARNED', 'EMAS DIDAPAT'],
  },
];

/**
 * Three upgrade cards. Each shows what you have now (big number), a segmented level bar, and one BUY button
 * that lights up when you can afford it. Paid with the coins banked from your runs - shown on game over & the title.
 */
export function QuickUpgrades({ ui, w, compact = false }: { ui: RUi | null; w: W; compact?: boolean }) {
  useLang();
  const g = w(); const m = g?.meta;
  const [flash, setFlash] = useState<SimpleUpId | null>(null);
  void ui?.metaRev;
  if (!g || !m) return null;
  const S = CFG.simpleUp;
  const buy = (id: SimpleUpId) => { audioInit(); if (g.buySimple(id)) { setFlash(id); window.setTimeout(() => setFlash(null), 650); } };
  return (
    <div className={`up-wrap ${compact ? 'compact' : ''}`}>
      <div className="up-title font-game">
        <span className="up-coin" aria-hidden><svg viewBox="0 0 24 24" className="h-5 w-5"><circle cx="12" cy="12" r="9.5" fill="#ffb61f" stroke="#0a1a52" strokeWidth="1.8" /><circle cx="12" cy="12" r="6" fill="#ffe27a" /><path d="M12 8.2v7.6" stroke="#e98a00" strokeWidth="2.2" strokeLinecap="round" /></svg></span>
        <b className="tabular-nums">{m.coins}</b>
        <span className="up-title-sub">{tx('UPGRADE COINS · PERMANENT · NEVER RESET', 'KOIN UPGRADE · PERMANEN · TAK PERNAH RESET')}</span>
      </div>
      <div className="up-grid">
        {UPS.map((u) => {
          const lv = m.simple[u.id] ?? 0; const cost = g.simpleCost(u.id); const maxed = cost === null; const can = !maxed && m.coins >= cost;
          const now = pct(S[u.id] * lv); const step = pct(S[u.id]);
          return (
            <div key={u.id} className={`up-card ${flash === u.id ? 'bought' : ''} ${can ? 'can' : ''}`} style={{ ['--c' as string]: u.col, ['--d' as string]: u.dark }}>
              <div className="up-top">
                <span className="up-icon">{u.icon}</span>
                <span className="up-name font-game">{tx(u.en, u.idn)}</span>
                <span className="up-lv font-game">LV {lv}</span>
              </div>
              <div className="up-now">
                <b className="font-game tabular-nums">+{now}%</b>
                <small>{tx(u.stat[0], u.stat[1])}</small>
              </div>
              <div className="up-bar" aria-label={`${lv}/${S.maxLv}`}>
                {Array.from({ length: S.maxLv }, (_, i) => <i key={i} className={i < lv ? 'on' : ''} />)}
              </div>
              <button type="button" disabled={maxed} onClick={() => buy(u.id)} className={`up-buy font-game ${maxed ? 'maxed' : can ? 'ok' : 'poor'}`}>
                {maxed ? (
                  <span>★ {tx('MAXED', 'MAKS')}</span>
                ) : (
                  <>
                    <span className="up-buy-l">▲ +{step}%</span>
                    <span className="up-buy-r"><svg viewBox="0 0 24 24" className="h-3.5 w-3.5" aria-hidden><circle cx="12" cy="12" r="9.5" fill="#ffb61f" stroke="#0a1a52" strokeWidth="1.8" /><circle cx="12" cy="12" r="6" fill="#ffe27a" /></svg><b className="tabular-nums">{cost}</b></span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/** the small modal around QuickUpgrades (from the title or the pause menu) */
export function UpgradeModal({ ui, w, onClose }: { ui: RUi | null; w: W; onClose: () => void }) {
  useLang();
  const closeRef = useRef(onClose); closeRef.current = onClose;
  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); closeRef.current(); } };
    window.addEventListener('keydown', key, true);
    return () => window.removeEventListener('keydown', key, true);
  }, []);
  return (
    <div className="absolute inset-0 z-50 grid place-items-center bg-[#030a2a]/70 p-4 backdrop-blur-[2px]" onClick={onClose}>
      <div className="g-panel g-pop relative w-full max-w-md rounded-3xl p-5 pt-8" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
        <div className="g-ribbon font-game absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-1.5 text-base text-white">{tx('UPGRADES', 'UPGRADE')}</div>
        <p className="mb-3 text-center text-[11px] font-black tracking-wider text-cyan-100/80">{tx('PERMANENT · 1 CLICK · PAID WITH COINS FROM YOUR RUNS', 'PERMANEN · 1 KLIK · BAYAR DENGAN KOIN HASIL RUN')}</p>
        <QuickUpgrades ui={ui} w={w} />
        <button type="button" onClick={() => { audioInit(); snd.tap(); onClose(); }} className="g-btn g-orange font-game mt-4 h-11 w-full text-base">{tx('DONE', 'SELESAI')}</button>
      </div>
    </div>
  );
}

/** "GAME OVER": the night forest of the menu, big logo, our archer lying on his island — and instant RETRY */
export function DeathPanel({ ui, w, onMenu }: { ui: RUi; w: W; onMenu: () => void }) {
  useLang();
  const r = ui.run;
  return (
    <GameOverScreen
      level={ui.level} kills={ui.totalKills} gold={r.goldEarned} meta={r.metaGain} killedBy={r.killedBy} daily={r.daily || undefined}
      skin={ui.skin.id} bow={ui.bow}
      unlocks={r.unlocks.length > 0 ? r.unlocks.map((id) => { const u = unlockOf(id); return u ? unlockName(u) : id; }).join(', ') : undefined}
      cards={r.cards.length > 0 ? <div className="mt-3 flex flex-wrap justify-center gap-1">{r.cards.map(([id, lv]) => <CardChip key={id} id={id} lv={lv} />)}</div> : null}
      upgrades={<QuickUpgrades ui={ui} w={w} compact />}
      onRetry={() => w()?.newRun(!!r.daily)} onMenu={onMenu}
    />
  );
}

/** a card you own, as its picture with a level badge (hover for the effect) */
function CardThumb({ id, lv }: { id: CardId; lv: number }) {
  const d = CARD_BY[id]; const art = CARD_ART[id]; const col = d.path ? PATH_COL[d.path] : TYPE_COL[d.type];
  return (
    <span title={`${cardName(d)} LV${lv}: ${cardText(id, lv)}`} className="g-pop relative block h-9 w-9 shrink-0 overflow-hidden rounded-lg border-2 border-[#031a24] bg-[#0a1a52] shadow-[0_2px_0_#031a24] sm:h-10 sm:w-10" style={{ boxShadow: `0 2px 0 #031a24, inset 0 0 0 1.5px ${col}` }}>
      {art ? <img src={art} alt={cardName(d)} className="h-full w-full object-cover" /> : d.glyph ? <span className="grid h-full w-full place-items-center"><SkillGlyph icon={d.glyph} className="h-6 w-6" /></span> : <span className="grid h-full w-full place-items-center text-lg">{d.icon}</span>}
      <span className="font-game absolute -bottom-0.5 -right-0.5 rounded-tl-md px-1 text-[9px] leading-[13px] text-[#031a24]" style={{ background: col }}>{lv}</span>
    </span>
  );
}

const META_BADGES: { id: SimpleUpId; en: string; idn: string; col: string; glyph: string }[] = [
  { id: 'atk', en: 'ATK', idn: 'SRG', col: '#ff6a4f', glyph: '⚔' },
  { id: 'hp', en: 'HP', idn: 'HP', col: '#5cf08a', glyph: '♥' },
  { id: 'gold', en: 'GOLD', idn: 'EMAS', col: '#ffd23f', glyph: '🪙' },
];

/** in-run HUD under the HP bar: permanent upgrade levels, the pictures of every card owned, status chips, SLOW TIME & the [M] rare offer */
export function RunHud({ ui, w }: { ui: RUi; w: W; onSkin?: () => void }) {
  useLang();
  const r = ui.run; const m = w()?.meta; void ui.metaRev;
  return (
    <>
      <div className="pointer-events-none absolute left-2 top-[5.9rem] z-10 flex max-w-[60%] flex-col gap-1.5 sm:left-3.5 sm:top-[6.6rem]">
        {/* permanent upgrades: ⚔ LV · ♥ LV · 🪙 LV */}
        {m && (
          <div className="flex flex-wrap gap-1" aria-label={tx('Permanent upgrades', 'Upgrade permanen')}>
            {META_BADGES.map((b) => {
              const lv = m.simple[b.id] ?? 0;
              return (
                <span key={b.id} title={`${tx(b.en, b.idn)} LV${lv}`} className="font-game flex h-6 items-center gap-1 rounded-full border-2 border-[#031a24] bg-black/70 px-2 text-[11px] leading-none text-white" style={{ boxShadow: `inset 0 0 0 1px ${b.col}` }}>
                  <span style={{ color: b.col }}>{b.glyph}</span>
                  <span className="text-[9px] tracking-wider text-white/70">{tx(b.en, b.idn)}</span>
                  <span style={{ color: b.col }}>LV{lv}</span>
                </span>
              );
            })}
          </div>
        )}
        {/* the cards you hold this run, as pictures */}
        {r.cards.length > 0 && (
          <div className="flex flex-wrap gap-1" aria-label={tx('Cards owned', 'Kartu yang dimiliki')}>
            {r.cards.map(([id, lv]) => <CardThumb key={id} id={id} lv={lv} />)}
          </div>
        )}
        <div className="flex flex-wrap gap-1">
          {r.gandaMax > 0 && <Chip col={r.ganda ? 'text-[#b98cff]' : 'text-white/40'}>🏹 {r.ganda}/{r.gandaMax}</Chip>}
          {r.hunter > 1 && <Chip col="text-[#ffe14d]">🎯 x{r.hunter}</Chip>}
          {r.shieldOn && <Chip col={r.shield >= 1 ? 'text-[#7fe9f2]' : 'text-white/50'}>🔰 {r.shield >= 1 ? tx('READY', 'SIAP') : `${pct(r.shield)}%`}</Chip>}
          {r.daily && <Chip col="text-[#7fe9f2]">📅 {r.daily}</Chip>}
        </div>
      </div>
      {/* rare arrow cards: cooldown rings (fill = ready) */}
      {(r.echoRdy >= 0 || r.spreadRdy >= 0 || r.frostRdy >= 0 || r.mirrorRdy >= 0 || r.cannonRdy >= 0 || r.dome >= 0) && (
        <div className="pointer-events-none absolute bottom-20 right-3 z-10 flex gap-1.5 sm:bottom-24" style={{ right: r.hasSlow ? '5.5rem' : undefined }}>
          {([['dobel', r.echoRdy, '#c6f6ff'], [r.cards.some(([c]) => c === 'sebar3') ? 'sebar3' : 'sebar2', r.spreadRdy, '#c6f6ff'], ['beku', r.frostRdy, '#9fe4ff'], ['meriam', r.cannonRdy, '#ffb347'], ['cermin', r.mirrorRdy, '#e8f6ff'], ['kubah', r.dome >= 0 ? r.dome / Math.max(1, r.domeMax) : -1, '#9fd8ff']] as [CardId, number, string][]).filter(([, v]) => v >= 0).map(([id, rdy, col]) => {
            const d = CARD_BY[id]; const art = CARD_ART[id];
            // cannon: the ring fills shot by shot and lights up when the NEXT arrow is the charged one
            const ready = id === 'meriam' ? r.cannonN >= r.cannonEvery - 1 : rdy >= 1;
            return (
              <span key={id} title={`${cardName(d)} · ${ready ? tx('READY', 'SIAP') : tx('COOLDOWN', 'COOLDOWN')}`} className={`relative grid h-12 w-12 place-items-center rounded-full border-[3px] border-[#031a24] ${ready ? 'g-pulse' : ''}`} style={{ background: `conic-gradient(${col} ${Math.max(0, Math.min(1, rdy)) * 360}deg, #0b2a3a 0deg)` }}>
                <span className="relative h-9 w-9 overflow-hidden rounded-full bg-[#041926]">
                  {art ? <img src={art} alt={cardName(d)} className="h-full w-full object-cover" style={{ filter: ready ? 'none' : 'grayscale(1) brightness(0.55)' }} /> : <span className="grid h-full w-full place-items-center text-lg">{d.icon}</span>}
                  {!ready && <span className="font-game absolute inset-0 grid place-items-center text-[11px] text-white">{Math.ceil((1 - rdy) * 10) / 10 > 0 ? '' : ''}</span>}
                </span>
                {id === 'kubah' ? <span className="font-game absolute -bottom-1.5 rounded bg-[#031a24] px-1 text-[8px] leading-3 tracking-wider" style={{ color: col }}>{r.dome}</span> : ready && <span className="font-game absolute -bottom-1.5 rounded bg-[#031a24] px-1 text-[8px] leading-3 tracking-wider" style={{ color: col }}>{id === 'meriam' ? tx('NEXT!', 'BERIKUT!') : tx('READY', 'SIAP')}</span>}
              </span>
            );
          })}
        </div>
      )}
      {/* level 1 only: the rare offer */}
      {ui.rareReady && (
        <button
          onClick={() => { audioInit(); w()?.offerRare(); }}
          className="g-btn g-dark font-game g-pulse absolute bottom-20 left-3 z-10 flex h-12 items-center gap-2 rounded-2xl px-3 text-sm text-[#c6f6ff] sm:bottom-24"
          style={{ boxShadow: 'inset 0 0 0 2px #9ff0ff' }}
          aria-label={tx('Rare cards (M)', 'Kartu langka (M)')}
        >
          <span className="text-lg">✦</span>
          <span className="flex flex-col items-start leading-none"><span>{tx('RARE CARDS', 'KARTU LANGKA')}</span><span className="text-[9px] tracking-[0.2em] text-white/70">{tx('PRESS [M]', 'TEKAN [M]')}</span></span>
        </button>
      )}
      {r.hasSlow && (
        <button
          onClick={() => w()?.activateSlow()}
          aria-label={tx('Slow Time (Q)', 'Waktu melambat (Q)')}
          className="font-game absolute bottom-20 right-3 z-10 grid h-16 w-16 place-items-center rounded-full border-4 border-[#031a24] text-[11px] text-white shadow-lg active:scale-95 sm:bottom-24"
          style={{ background: `conic-gradient(#5cc8ff ${r.slow * 360}deg, #0b2a3a 0deg)` }}
        >
          <span className="grid h-11 w-11 place-items-center rounded-full bg-[#041926]">{r.slowOn ? tx('ACTIVE', 'AKTIF') : r.slow >= 1 ? '⏳ Q' : `${pct(r.slow)}%`}</span>
        </button>
      )}
    </>
  );
}

/** on-screen notifications: unlocks, synergies, rewards */
export function Toasts({ ui }: { ui: RUi }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-24 z-40 flex flex-col items-center gap-1.5 px-3">
      {ui.toasts.map((t) => (
        <div key={t.id} className="g-pop rounded-2xl border-2 border-[#031a24] bg-gradient-to-b from-[#165770] to-[#082736] px-4 py-2 text-center shadow-lg ring-2 ring-[#ffd23f]/60">
          <div className="font-game text-sm text-[#ffd23f]">{t.title}</div>
          {t.sub && <div className="text-xs font-black tracking-wider text-cyan-100">{t.sub}</div>}
        </div>
      ))}
    </div>
  );
}
