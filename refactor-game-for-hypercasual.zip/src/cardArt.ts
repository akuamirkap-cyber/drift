import type { CardId } from './game/ragdoll/config';

// Imported (not string paths) so the images are bundled and inlined into the single-file build.
import ledak from './assets/images/skill_blast_full_1795576743152.jpg';
import petir from './assets/images/skill_chain_lightning_1795576721707.jpg';
import paku from './assets/images/icon_nail_arrow_1795576018490.jpg';
import tameng from './assets/images/icon_shield_breaker_1795576018697.jpg';
import tembus from './assets/images/skill_piercing_arrow_1795576722579.jpg';
import pemburu from './assets/images/icon_headhunter_1795576019473.jpg';
import lifesteal from './assets/images/skill_lifesteal_full_1795576741697.jpg';
import perisai from './assets/images/icon_barrier_1795576020270.jpg';
import nyawa2 from './assets/images/skill_second_life_1795576723672.jpg';
import lambat from './assets/images/icon_slow_time_1795576021128.jpg';
import pedang from './assets/images/skill_blade_full_1795576741478.jpg';
import kontrak from './assets/images/skill_contract_full_1795576742865.jpg';
import j_lesat from './assets/images/card_swift_flight_1795574881775.jpg';
import j_tarik from './assets/images/card_tempest_draw_1795574881604.jpg';
import j_fokus from './assets/images/card_eagle_focus_1795574881992.jpg';
import j_incar from './assets/images/card_golden_aim_1795574882674.jpg';
import j_zirah from './assets/images/card_iron_armor_1795574880374.jpg';
import j_jantung from './assets/images/card_steel_heart_1795574880363.jpg';
import ganda from './assets/images/card_double_arrow_1795574883671.jpg';
import kritis from './assets/images/card_critical_hit.jpg';
import bakar from './assets/images/card_fire_arrow.jpg';
import momentum from './assets/images/card_momentum.jpg';
import duri from './assets/images/card_thorn_mail.jpg';
import amuk from './assets/images/card_berserk.jpg';
import dobel from './assets/images/card_echo_shot.jpg';
import sebar2 from './assets/images/card_split_shot.jpg';
import sebar3 from './assets/images/card_triple_shot.jpg';
import beku from './assets/images/card_frost_arrow.jpg';
import cermin from './assets/images/card_mirror_shield.jpg';
import kubah from './assets/images/card_aegis_dome.svg';
import meriam from './assets/images/card_cannon_arrow.svg';
import badai from './assets/images/card_static_storm.svg';

export const CARD_ART: Partial<Record<CardId, string>> = {
  ledak, petir, paku, tameng, tembus, pemburu, lifesteal, perisai, nyawa2, lambat, pedang, kontrak,
  j_lesat, j_tarik, j_fokus, j_incar, j_zirah, j_jantung, ganda,
  kritis, bakar, momentum, duri, amuk,
  dobel, sebar2, sebar3, beku,
  cermin, kubah, meriam, badai,
};
