import { useEffect, useState } from 'react';
import RagdollArcher from './RagdollArcher';
import { audioMute } from './game/ragdoll/audio';
import { useLang } from './i18n';

/**
 * One game, one identity: Ragdoll Archer.
 * `menu`  — the self-playing title backdrop with PLAY / BOW / SKIN / CODEX
 * `play`  — the run: Win level → pick 1 of 3 cards → next level (no route map, no chest menu)
 */
type Mode = 'menu' | 'play';

const MUTE_KEY = 'perfectshot.ragdoll.mute';

export default function App() {
  useLang();
  const [mode, setMode] = useState<Mode>('menu');
  const [mute, setMute] = useState<boolean>(() => {
    try { return localStorage.getItem(MUTE_KEY) === '1'; } catch { return false; }
  });

  useEffect(() => {
    audioMute(mute);
    try { localStorage.setItem(MUTE_KEY, mute ? '1' : '0'); } catch { /* storage unavailable */ }
  }, [mute]);

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#0c44bb] font-sans text-neutral-900 select-none">
      <RagdollArcher
        title={mode === 'menu'}
        onStart={() => setMode('play')}
        onExit={() => setMode('menu')}
        mute={mute}
        onMute={() => setMute((m) => !m)}
      />
    </div>
  );
}
