// The title-screen night forest, painted onto the arena's parallax bitmaps, plus the grassy floating
// islands that stand in for the title screen's cliffs. Theme 0 is an exact match of the menu palette;
// the other themes recolour the very same composition.
import type { CanvasLike, MakeCanvas, Scene, Theme } from './scenery';

type C2 = CanvasRenderingContext2D;

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------------- colour helpers ---------------- */
const hex = (c: string): [number, number, number] => {
  const m = c.replace('#', '');
  const f = m.length === 3 ? m.split('').map((x) => x + x).join('') : m;
  return [parseInt(f.slice(0, 2), 16), parseInt(f.slice(2, 4), 16), parseInt(f.slice(4, 6), 16)];
};
export const mix = (a: string, b: string, t: number) => {
  const A = hex(a); const B = hex(b);
  const k = (i: number) => Math.round(A[i] + (B[i] - A[i]) * t).toString(16).padStart(2, '0');
  return `#${k(0)}${k(1)}${k(2)}`;
};

export interface MenuPal {
  s0: string; s1: string; s2: string; s3: string; glow: string; glow2: string;
  far: string; mid: string; treeA: string; treeB: string; treeC: string; treeD: string;
  bush: string; bush2: string; cloud: [string, string, string];
  rock: [string, string]; rockDark: string; ray: string; moon: [string, string, string];
}

const MENU_PAL: MenuPal = {
  s0: '#0c44bb', s1: '#1259d4', s2: '#0f4bc0', s3: '#082d86', glow: '#3a90fb', glow2: '#82beff',
  far: '#1556cb', mid: '#0f47b4', treeA: '#0e43ad', treeB: '#1049b6', treeC: '#0e42aa', treeD: '#0a3594',
  bush: '#072a7c', bush2: '#051f62', cloud: ['#1a5fd3', '#2069dc', '#1857c9'],
  rock: ['#2f80d6', '#11458f'], rockDark: '#082a66', ray: '150,205,255', moon: ['#f6f7e6', '#dde3cf', '#b3c0bf'],
};

const palCache = new Map<string, MenuPal>();
export function menuPal(th: Theme): MenuPal {
  if (th.moon) return MENU_PAL;
  const hit = palCache.get(th.name); if (hit) return hit;
  const p: MenuPal = {
    s0: th.top, s1: th.mid, s2: mix(th.mid, th.bot, 0.55), s3: mix(th.bot, th.tree, 0.45), glow: mix(th.mid, '#ffffff', 0.22), glow2: mix(th.bot, '#ffffff', 0.3),
    far: mix(th.mid, th.tree, 0.38), mid: mix(th.mid, th.tree, 0.62), treeA: mix(th.tree, th.mid, 0.3), treeB: mix(th.tree, th.mid, 0.42), treeC: mix(th.tree, th.mid, 0.22), treeD: th.tree,
    bush: th.fg, bush2: mix(th.fg, '#000000', 0.35), cloud: [mix(th.mid, '#ffffff', 0.12), mix(th.mid, '#ffffff', 0.2), mix(th.mid, '#ffffff', 0.08)],
    rock: [mix(th.mid, '#ffffff', 0.2), mix(th.hill, th.tree, 0.4)], rockDark: mix(th.tree, '#000000', 0.2), ray: th.ray, moon: [mix(th.disc[3], '#ffffff', 0.5), th.disc[3], mix(th.disc[3], th.mid, 0.4)],
  };
  palCache.set(th.name, p);
  return p;
}

/* ---------------- shared geometry (same numbers as the title screen) ---------------- */
function bumps(seed: number, from: number, to: number, baseY: number, minR: number, maxR: number) {
  const r = rng(seed);
  const out: { x: number; y: number; r: number }[] = [];
  for (let x = from; x < to; ) {
    const rad = minR + r() * (maxR - minR);
    out.push({ x, y: baseY - r() * rad * 0.85, r: rad });
    x += rad * (0.85 + r() * 0.55);
  }
  return out;
}

const ACACIA = new Path2D('M-18 6C-12-60-7-120-11-170C-30-208-70-228-98-244L-90-256C-58-242-24-224-3-196C0-232 14-264 40-292L52-284C32-258 21-226 19-190C40-206 76-216 112-218L114-205C78-200 42-186 23-160C19-110 20-50 28 6Z');
function pad(c: C2, cx: number, cy: number, rx: number, ry: number) {
  c.beginPath();
  c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  c.moveTo(cx - rx * 0.46 + rx * 0.42, cy - ry * 0.55); c.ellipse(cx - rx * 0.46, cy - ry * 0.55, rx * 0.42, ry * 0.85, 0, 0, Math.PI * 2);
  c.moveTo(cx + rx * 0.08 + rx * 0.5, cy - ry * 0.85); c.ellipse(cx + rx * 0.08, cy - ry * 0.85, rx * 0.5, ry, 0, 0, Math.PI * 2);
  c.moveTo(cx + rx * 0.55 + rx * 0.36, cy - ry * 0.42); c.ellipse(cx + rx * 0.55, cy - ry * 0.42, rx * 0.36, ry * 0.75, 0, 0, Math.PI * 2);
  c.fill();
}
function acacia(c: C2, x: number, y: number, s: number, fill: string, flip = false) {
  c.save();
  c.translate(x, y); c.scale(flip ? -s : s, s);
  c.fillStyle = fill;
  c.fill(ACACIA);
  pad(c, -104, -256, 92, 25); pad(c, 48, -300, 118, 31); pad(c, 124, -224, 82, 23);
  c.restore();
}
function cloud(c: C2, x: number, y: number, width: number, fill: string, alpha: number) {
  c.save();
  c.translate(x, y); c.scale(width / 240, width / 240);
  c.globalAlpha = alpha; c.fillStyle = fill;
  c.beginPath();
  c.roundRect(14, 40, 212, 22, 11);
  c.moveTo(70 + 42, 40); c.ellipse(70, 40, 42, 20, 0, 0, Math.PI * 2);
  c.moveTo(124 + 48, 30); c.ellipse(124, 30, 48, 26, 0, 0, Math.PI * 2);
  c.moveTo(176 + 36, 42); c.ellipse(176, 42, 36, 17, 0, 0, Math.PI * 2);
  c.fill();
  c.restore();
}

/** the twinkling stars of the title sky (percent of the screen), shared with the arena's per-frame pass */
export const MENU_STARS = (() => {
  const r = rng(7);
  return Array.from({ length: 64 }, () => ({ x: r(), y: r() * 0.62, s: 1 + r() * 2.2, d: r() * 5, o: 0.35 + r() * 0.6 }));
})();

/** centre of the light behind the title (fractions of the screen) */
export const MENU_LIGHT = { x: 0.52, y: 0.4 };

export function paintMenuScene(w: number, h: number, th: Theme, _seed: number, make: MakeCanvas): Scene {
  const P = menuPal(th);
  const u = Math.max(0.5, Math.min(w, h * 1.5) / 1100);
  const padPx = Math.round(46 * u);
  const W = w + padPx * 2;
  const sky = make(W, h); const near = make(W, h); const hills = make(W, h);
  const cs = sky.getContext('2d') as C2; const cn = near.getContext('2d') as C2; const ch = hills.getContext('2d') as C2;

  /* ---------- sky ---------- */
  const lg = cs.createLinearGradient(0, 0, 0, h);
  lg.addColorStop(0, P.s0); lg.addColorStop(0.38, P.s1); lg.addColorStop(0.68, P.s2); lg.addColorStop(1, P.s3);
  cs.fillStyle = lg; cs.fillRect(0, 0, W, h);
  const ell = (cx: number, cy: number, rx: number, ry: number, stops: [number, string][]) => {
    cs.save(); cs.translate(cx, cy); cs.scale(rx, ry);
    const g = cs.createRadialGradient(0, 0, 0, 0, 0, 1);
    for (const [o, col] of stops) g.addColorStop(o, col);
    cs.fillStyle = g; cs.fillRect(-W, -h * 2, W * 2, h * 4);
    cs.restore();
  };
  const rgba = (c: string, a: number) => { const [r, g, b] = hex(c); return `rgba(${r},${g},${b},${a})`; };
  const lx = padPx + w * MENU_LIGHT.x; const ly = h * MENU_LIGHT.y;
  ell(lx, ly, w * 0.58, h * 0.66, [[0, P.glow], [0.34, rgba(P.glow, 0.55)], [0.72, rgba(P.glow, 0)], [1, rgba(P.glow, 0)]]);
  ell(padPx + w * 0.04, h * 0.16, w * 0.46, h * 0.62, [[0, rgba(P.glow2, 0.6)], [0.7, rgba(P.glow2, 0)], [1, rgba(P.glow2, 0)]]);

  /* ---------- the moon (or sun) ---------- */
  const M = Math.max(Math.min(h * 0.46, w * 0.34), h * 0.2);
  let mx: number; let my: number; let R: number;
  if (th.moon) { R = M / 2; mx = padPx - M * 0.1 + R; my = M * 0.035 + R; } else { [mx, my, R] = [padPx + th.disc[0] * w, th.disc[1] * h, th.disc[2] * Math.min(w, h * 1.4) * 1.5]; }
  const halo = cs.createRadialGradient(mx, my, R * 0.9, mx, my, R * 2.4);
  halo.addColorStop(0, 'rgba(190,225,255,0.5)'); halo.addColorStop(1, 'rgba(140,195,255,0)');
  cs.fillStyle = th.moon ? halo : rgba(th.disc[3], 0.35); if (th.moon) cs.fillRect(0, 0, W, h);
  const face = cs.createRadialGradient(mx - R * 0.16, my - R * 0.24, R * 0.05, mx, my, R);
  face.addColorStop(0, P.moon[0]); face.addColorStop(0.62, P.moon[1]); face.addColorStop(1, P.moon[2]);
  cs.fillStyle = face; cs.beginPath(); cs.arc(mx, my, R, 0, Math.PI * 2); cs.fill();
  const craters: [number, number, number, number][] = [[-0.35, -0.35, 0.25, 0.21], [0.29, -0.5, 0.135, 0.115], [0.42, 0.125, 0.27, 0.24], [-0.23, 0.375, 0.177, 0.146], [-0.6, 0.1, 0.094, 0.083], [0.125, 0.645, 0.115, 0.083], [0.69, -0.25, 0.073, 0.083]];
  const crDark = mix(P.moon[2], P.moon[1], 0.2);
  for (const [ox, oy, rx, ry] of craters) {
    cs.globalAlpha = 0.75; cs.fillStyle = crDark;
    cs.beginPath(); cs.ellipse(mx + ox * R, my + oy * R, rx * R, ry * R, 0, 0, Math.PI * 2); cs.fill();
    cs.globalAlpha = 0.6; cs.fillStyle = mix(P.moon[0], P.moon[1], 0.35);
    cs.beginPath(); cs.ellipse(mx + (ox - 0.03) * R, my + (oy - 0.03) * R, rx * R * 0.62, ry * R * 0.6, 0, 0, Math.PI * 2); cs.fill();
  }
  cs.globalAlpha = 0.35; cs.strokeStyle = '#ffffff'; cs.lineWidth = Math.max(1.5, R * 0.03);
  cs.beginPath(); cs.arc(mx, my, R, 0, Math.PI * 2); cs.stroke();
  cs.globalAlpha = 1;
  // soft clouds drifting around the moon
  const cm = th.moon ? M : R * 2;
  const cx0 = th.moon ? padPx : mx - R;
  cloud(cs, cx0 + cm * -0.34, cm * 0.7, cm * 0.82, P.cloud[0], 0.92);
  cloud(cs, cx0 + cm * 0.62, cm * 0.5, cm * 0.66, P.cloud[1], 0.8);
  cloud(cs, cx0 + cm * 0.36, cm * 0.06, cm * 0.5, P.cloud[2], 0.55);

  /* ---------- far forest + umbrella trees (the `near` bitmap) ---------- */
  const Lw = Math.max(w, 1050 * u * 0.9); const sc = Lw / 1600;
  const ext = (padPx + (Lw - w) / 2) / sc + 70;
  cn.save();
  cn.translate(padPx + (w - Lw) / 2, h - 400 * sc); cn.scale(sc, sc);
  cn.globalAlpha = 0.95;
  cn.fillStyle = P.far;
  for (const c of bumps(3, -ext, 1600 + ext, 250, 34, 78)) { cn.beginPath(); cn.arc(c.x, c.y, c.r, 0, Math.PI * 2); cn.fill(); }
  cn.fillRect(-ext, 240, 1600 + ext * 2, 200);
  acacia(cn, 470, 300, 0.62, P.far); acacia(cn, 1010, 300, 0.7, P.far, true);
  cn.fillStyle = P.mid;
  for (const c of bumps(11, -ext, 1600 + ext, 318, 30, 62)) { cn.beginPath(); cn.arc(c.x, c.y, c.r, 0, Math.PI * 2); cn.fill(); }
  cn.fillRect(-ext, 310, 1600 + ext * 2, 120);
  cn.restore();
  cn.globalAlpha = 1;
  const hz = cn.createLinearGradient(0, h * 0.54, 0, h);
  hz.addColorStop(0, rgba(P.glow, 0)); hz.addColorStop(0.55, rgba(P.glow, 0.28)); hz.addColorStop(1, 'rgba(8,40,120,0.35)');
  cn.fillStyle = hz; cn.fillRect(0, h * 0.54, W, h * 0.46);
  // big umbrella trees framing both sides
  const trees = Math.max(250 * u, Math.min(w * 0.5, h * 0.96));
  const drawTrees = (x0: number, width: number, alpha: number, list: [number, number, number, string, boolean][]) => {
    const k = width / 700;
    cn.save(); cn.globalAlpha = alpha; cn.translate(x0, h - 620 * k); cn.scale(k, k);
    for (const [x, y, s, f, fl] of list) acacia(cn, x, y, s, f, fl);
    cn.restore();
  };
  const cliff = Math.max(185 * u, Math.min(w * 0.29, h * 0.62));
  drawTrees(padPx + cliff * 0.55, trees * 0.62, 0.85, [[500, 626, 0.8, P.treeA, true], [250, 630, 0.56, P.treeB, false]]);
  drawTrees(padPx + w - trees, trees, 1, [[250, 626, 1.22, P.treeC, false], [600, 640, 1.84, P.treeD, true]]);

  /* ---------- foreground bushes (the `hills` bitmap) ---------- */
  const Bw = Math.max(w, 900 * u * 0.9); const bs = Bw / 1600;
  const bext = (padPx + (Bw - w) / 2) / bs + 70;
  ch.save();
  ch.translate(padPx + (w - Bw) / 2, h - 160 * bs); ch.scale(bs, bs);
  const bush = bumps(5, -bext, 1600 + bext, 112, 26, 58);
  ch.fillStyle = P.bush;
  for (const c of bush) { ch.beginPath(); ch.arc(c.x, c.y, c.r, 0, Math.PI * 2); ch.fill(); }
  ch.fillRect(-bext, 104, 1600 + bext * 2, 120);
  ch.fillStyle = P.bush2;
  for (const c of bush) { ch.beginPath(); ch.arc(c.x + 46, c.y + 52, c.r * 0.9, 0, Math.PI * 2); ch.fill(); }
  ch.restore();
  ch.save(); // ellipse 85% 85% at 50% 45%
  ch.translate(W / 2, h * 0.45); ch.scale(W * 0.85, h * 0.85);
  const vg = ch.createRadialGradient(0, 0, 0, 0, 0, 1);
  vg.addColorStop(0.55, 'rgba(3,16,70,0)'); vg.addColorStop(1, 'rgba(3,16,70,0.5)');
  ch.fillStyle = vg; ch.fillRect(-3, -3, 6, 6);
  ch.restore();

  return { sky: sky as CanvasLike, near: near as CanvasLike, hills: hills as CanvasLike, pad: padPx };
}

/* ======================================================================
   Floating grassy islands: the title screen's cliff, carried through the air.
   ====================================================================== */

interface IslandPaths { grass: Path2D; blades: Path2D; rock: Path2D; facets: Path2D; shade: Path2D; hw: number; gt: number; depth: number }
const islandCache = new Map<string, IslandPaths>();

function islandPaths(w: number): IslandPaths {
  const key = String(Math.round(w));
  const hit = islandCache.get(key); if (hit) return hit;
  const hw = w / 2 + 9; // the grass hangs a little past the standing room
  const gt = 7;
  const depth = Math.max(46, Math.min(124, w * 0.55 + 24));
  const grass = new Path2D();
  const n = Math.max(4, Math.round((hw * 2) / 9)); const step = (hw * 2 - 10) / n; const r = step / 2;
  grass.moveTo(-hw + 4, 0); grass.lineTo(hw - 4, 0);
  grass.quadraticCurveTo(hw + 1, 0, hw, gt - 1);
  for (let i = 0; i < n; i++) { const cx = hw - 5 - step * (i + 0.5); grass.arc(cx, gt - 1, r, 0, Math.PI, false); }
  grass.lineTo(-hw, gt - 1);
  grass.quadraticCurveTo(-hw - 1, 0, -hw + 4, 0);
  grass.closePath();
  const blades = new Path2D();
  for (const f of [-0.42, -0.3, 0.3, 0.41]) {
    const x = f * w; const s = 0.8 + (Math.abs(f) % 0.07) * 6;
    blades.moveTo(x - 3, 1); blades.lineTo(x - 0.4, -9 * s); blades.lineTo(x + 1.5, 1);
    blades.moveTo(x, 1); blades.lineTo(x + 3.5, -7 * s); blades.lineTo(x + 5, 1);
  }
  const top = gt - 3;
  const rock = new Path2D();
  rock.moveTo(-hw + 3, top);
  rock.bezierCurveTo(-hw + 2, top + depth * 0.2, -hw * 0.66, top + depth * 0.4, -hw * 0.42, top + depth * 0.6);
  rock.bezierCurveTo(-hw * 0.26, top + depth * 0.76, -hw * 0.14, top + depth * 0.9, hw * 0.04, top + depth);
  rock.bezierCurveTo(hw * 0.1, top + depth * 0.86, hw * 0.28, top + depth * 0.68, hw * 0.5, top + depth * 0.54);
  rock.bezierCurveTo(hw * 0.8, top + depth * 0.38, hw - 2, top + depth * 0.2, hw - 3, top);
  rock.closePath();
  const shade = new Path2D();
  shade.moveTo(hw * 0.12, top); shade.lineTo(hw - 3, top);
  shade.bezierCurveTo(hw - 2, top + depth * 0.2, hw * 0.8, top + depth * 0.38, hw * 0.5, top + depth * 0.54);
  shade.bezierCurveTo(hw * 0.28, top + depth * 0.68, hw * 0.1, top + depth * 0.86, hw * 0.04, top + depth);
  shade.bezierCurveTo(hw * 0.06, top + depth * 0.7, hw * 0.1, top + depth * 0.4, hw * 0.12, top);
  shade.closePath();
  const facets = new Path2D();
  facets.moveTo(-hw * 0.46, top + depth * 0.26); facets.lineTo(-hw * 0.2, top + depth * 0.34); facets.lineTo(-hw * 0.36, top + depth * 0.5); facets.closePath();
  facets.moveTo(-hw * 0.78, top + depth * 0.14); facets.lineTo(-hw * 0.6, top + depth * 0.19); facets.lineTo(-hw * 0.7, top + depth * 0.3); facets.closePath();
  const out = { grass, blades, rock, facets, shade, hw, gt, depth };
  islandCache.set(key, out);
  return out;
}

/** depth of the island's rock below its surface, so crumbs can fall from the real underside */
export const islandDepth = (w: number) => islandPaths(w).depth + 4;

export function drawIsland(ctx: C2, x: number, y: number, w: number, th: Theme, time: number, phase: number) {
  const P = menuPal(th); const I = islandPaths(w);
  ctx.save();
  ctx.translate(x, y);
  // a cushion of moonlight under the tip, breathing slowly
  const pulse = 0.7 + 0.3 * Math.sin(time * 2.2 + phase);
  const gy = I.depth + 10;
  ctx.save(); ctx.translate(0, gy); ctx.scale(1, 0.26);
  const gl = ctx.createRadialGradient(0, 0, 0, 0, 0, I.hw * 0.95);
  gl.addColorStop(0, `rgba(150,205,255,${0.42 * pulse})`); gl.addColorStop(1, 'rgba(150,205,255,0)');
  ctx.fillStyle = gl; ctx.fillRect(-I.hw, -I.hw, I.hw * 2, I.hw * 2); ctx.restore();
  // rock
  const rg = ctx.createLinearGradient(0, 0, 0, I.depth);
  rg.addColorStop(0, P.rock[0]); rg.addColorStop(1, P.rock[1]);
  ctx.fillStyle = rg; ctx.fill(I.rock);
  ctx.save(); ctx.globalAlpha = 0.55; ctx.fillStyle = P.rockDark; ctx.fill(I.shade); ctx.restore();
  ctx.save(); ctx.globalAlpha = 0.5; ctx.fillStyle = P.rock[0]; ctx.fill(I.facets); ctx.restore();
  const sh = ctx.createLinearGradient(0, I.gt - 3, 0, I.gt + 16);
  sh.addColorStop(0, 'rgba(4,20,70,0.5)'); sh.addColorStop(1, 'rgba(4,20,70,0)');
  ctx.save(); ctx.clip(I.rock); ctx.fillStyle = sh; ctx.fillRect(-I.hw, I.gt - 3, I.hw * 2, 20); ctx.restore();
  // rim light on the rock's left lip
  ctx.save(); ctx.clip(I.rock); ctx.strokeStyle = 'rgba(190,225,255,0.28)'; ctx.lineWidth = 2; ctx.stroke(I.rock); ctx.restore();
  // grass: a dark underlay, then the bright cap with its scalloped lip
  ctx.save(); ctx.translate(0, 4); ctx.fillStyle = '#2a8c2c'; ctx.fill(I.grass); ctx.restore();
  const gg = ctx.createLinearGradient(0, 0, 0, I.gt + 4);
  gg.addColorStop(0, '#8cec48'); gg.addColorStop(1, '#3aaa2f');
  ctx.fillStyle = gg; ctx.fill(I.grass);
  ctx.fillStyle = '#8cec48'; ctx.fill(I.blades);
  ctx.strokeStyle = 'rgba(205,255,134,0.8)'; ctx.lineWidth = 1.6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-I.hw + 6, 1.4); ctx.lineTo(I.hw - 8, 1.4); ctx.stroke();
  ctx.restore();
}
