// CARD DICTIONARY: every power card in the game, grouped by type, with its effect at every level and its synergies.
import { useEffect, useState } from 'react';
import { CARDS, CardDef, CardType, SYNERGIES, cardName, cardTypeLabel, synergyDesc, synergyName } from './game/ragdoll/config';
import { CARD_BY, cardText } from './game/ragdoll/cards';
import { CARD_ART } from './cardArt';
import { SkillGlyph } from './SkillTreeArt';
import { Sym } from './CodexBook';
import { audioInit, snd } from './game/ragdoll/audio';
import { tx, useLang } from './i18n';
import './codex-book.css';

const TYPE_COL: Record<CardType, string> = { PANAH: '#ffb02e', BERTAHAN: '#5cf08a', JALUR: '#69d5ff', RISIKO: '#ff5a4f', KHUSUS: '#b98cff', LANGKA: '#9ff0ff' };
const TYPE_ORDER: CardType[] = ['PANAH', 'BERTAHAN', 'JALUR', 'RISIKO', 'LANGKA', 'KHUSUS'];
const TYPE_BLURB: Record<CardType, [string, string]> = {
  PANAH: ['What your arrows do on impact', 'Efek panahmu saat mengenai musuh'],
  BERTAHAN: ['Staying alive & active skills', 'Bertahan hidup & skill aktif'],
  JALUR: ['Stat boosts for the whole run (the old skill tree, now cards)', 'Bonus stat selama run (skill tree lama, kini jadi kartu)'],
  RISIKO: ['Big power, with a price', 'Kekuatan besar, ada harganya'],
  KHUSUS: ['Big-boss reward only, never offered', 'Hanya hadiah bos besar, tidak pernah ditawarkan'],
  LANGKA: ['Press [M] at level 1: pick 1 of 3 (once per run)', 'Tekan [M] di level 1: pilih 1 dari 3 (sekali per run)'],
};

function Art({ d, size = 'h-12 w-12' }: { d: CardDef; size?: string }) {
  const art = CARD_ART[d.id];
  if (art) return <img src={art} alt={cardName(d)} className={`${size} rounded-lg object-cover ring-2 ring-[#0a1a52]`} />;
  if (d.glyph) return <span className={`${size} grid place-items-center rounded-lg bg-[#0a1a52]`}><SkillGlyph icon={d.glyph} className="h-7 w-7" /></span>;
  return <span className={`${size} grid place-items-center rounded-lg bg-[#0a1a52] text-2xl`}>{d.icon}</span>;
}

interface Props { onClose: () => void; onEnemies: () => void; onBosses: () => void }

export default function CardCodexModal({ onClose, onEnemies, onBosses }: Props) {
  useLang();
  const [sel, setSel] = useState<CardDef>(CARDS[0]);
  const tap = (fn: () => void) => () => { audioInit(); snd.tap(); fn(); };
  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); onClose(); } };
    window.addEventListener('keydown', key, true);
    return () => window.removeEventListener('keydown', key, true);
  }, [onClose]);
  const col = TYPE_COL[sel.type];
  const syns = SYNERGIES.filter((s) => s.need.includes(sel.id));
  const total = CARDS.length;
  return (
    <div className="cx-overlay">
      <div className="cx-book g-pop">
        <div className="cx-plaque"><Sym icon="book" size={30} /><b>{tx('CARD DICTIONARY', 'KAMUS KARTU')}</b></div>
        <div className="cx-tabs">
          <button className="cx-tab" onClick={tap(onEnemies)}><Sym icon="demon" size={18} />{tx('ENEMIES', 'MUSUH')}</button>
          <button className="cx-tab" onClick={tap(onBosses)}><Sym icon="crown" size={18} />{tx('5 BOSSES', '5 BOS')}</button>
          <button className="cx-tab on">🃏 {tx('CARDS', 'KARTU')}</button>
        </div>
        <button className="cx-close" onClick={tap(onClose)} aria-label={tx('Close', 'Tutup')}>
          <svg viewBox="0 0 20 20" fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round"><path d="m4.5 4.5 11 11M15.5 4.5l-11 11" /></svg>
        </button>

        <div className="cx-spread" style={{ background: 'linear-gradient(180deg,#fbf3dc,#f1e2bb)' }}>
          {/* left: all cards grouped by type */}
          <div className="flex min-h-0 w-[58%] flex-col border-r-4 border-[#0a1a52]/20 p-3 sm:w-[60%]">
            <div className="mb-2 flex items-center justify-between text-[11px] font-black tracking-[0.18em] text-[#1d2a4a]/70">
              <span>{tx(`${total} POWER CARDS`, `${total} KARTU KEKUATAN`)}</span>
              <span>{tx('PICK 1 OF 3 AFTER EVERY LEVEL', 'PILIH 1 DARI 3 TIAP SELESAI LEVEL')}</span>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto pr-1">
              {TYPE_ORDER.map((t) => {
                const list = CARDS.filter((c) => c.type === t);
                if (!list.length) return null;
                return (
                  <section key={t} className="mb-3">
                    <div className="mb-1.5 flex items-baseline gap-2">
                      <span className="rounded-md px-2 py-0.5 text-[11px] font-black tracking-wider text-[#0a1a52]" style={{ background: TYPE_COL[t] }}>{cardTypeLabel(t)}</span>
                      <span className="text-[10px] font-bold text-[#1d2a4a]/60">{tx(TYPE_BLURB[t][0], TYPE_BLURB[t][1])}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-4 md:grid-cols-5">
                      {list.map((d) => {
                        const on = d.id === sel.id;
                        return (
                          <button key={d.id} type="button" onClick={tap(() => setSel(d))} title={cardName(d)}
                            className={`flex flex-col items-center gap-1 rounded-xl border-2 p-1.5 text-center transition active:scale-95 ${on ? 'border-[#0a1a52] bg-white shadow-[0_3px_0_#0a1a52]' : 'border-[#0a1a52]/15 bg-white/50 hover:bg-white'}`}
                            style={on ? { boxShadow: `0 3px 0 #0a1a52, inset 0 0 0 2px ${TYPE_COL[d.type]}` } : undefined}>
                            <Art d={d} />
                            <span className="line-clamp-2 text-[9px] font-black leading-tight text-[#1d2a4a]">{cardName(d)}</span>
                            <span className="text-[8px] font-bold text-[#1d2a4a]/55">{tx('MAX', 'MAKS')} LV{d.maxLv}</span>
                          </button>
                        );
                      })}
                    </div>
                  </section>
                );
              })}
            </div>
          </div>

          {/* right: the selected card in detail */}
          <div key={sel.id} className="g-pop flex min-h-0 flex-1 flex-col overflow-y-auto p-3 sm:p-4">
            <div className="flex items-center gap-3">
              <Art d={sel} size="h-20 w-20" />
              <div className="min-w-0">
                <span className="rounded-md px-2 py-0.5 text-[10px] font-black tracking-wider text-[#0a1a52]" style={{ background: col }}>{cardTypeLabel(sel.type)}{sel.path ? ` · ${sel.path.toUpperCase()}` : ''}</span>
                <h3 className="font-game mt-1 text-xl leading-tight text-[#0a1a52] sm:text-2xl">{cardName(sel)}</h3>
                <div className="text-[10px] font-bold text-[#1d2a4a]/60">{tx(`UPGRADES ${sel.maxLv}×`, `BISA DITINGKATKAN ${sel.maxLv}×`)}{sel.type === 'KHUSUS' ? ` · ${tx('BOSS REWARD', 'HADIAH BOS')}` : ''}</div>
              </div>
            </div>
            <div className="mt-3 flex flex-col gap-1.5">
              {Array.from({ length: sel.maxLv }, (_, i) => (
                <div key={i} className="flex items-start gap-2 rounded-xl border-2 border-[#0a1a52]/15 bg-white/70 px-2.5 py-1.5">
                  <span className="font-game mt-0.5 grid h-6 w-9 shrink-0 place-items-center rounded-md text-[11px] text-[#0a1a52]" style={{ background: col }}>LV{i + 1}</span>
                  <span className="text-[11px] font-black leading-snug text-[#1d2a4a]">{cardText(sel.id, i + 1)}</span>
                </div>
              ))}
            </div>
            {syns.length > 0 && (
              <div className="mt-3">
                <div className="mb-1 text-[10px] font-black tracking-[0.18em] text-[#1d2a4a]/70">⚡ {tx('SYNERGIES', 'SINERGI')}</div>
                {syns.map((s) => {
                  const other = s.need.find((id) => id !== sel.id)!;
                  return (
                    <button key={s.id} type="button" onClick={tap(() => setSel(CARD_BY[other]))} className="mb-1.5 flex w-full items-center gap-2 rounded-xl border-2 border-[#b98cff] bg-[#f3ecff] px-2 py-1.5 text-left transition hover:bg-[#ebe0ff]">
                      <Art d={CARD_BY[other]} size="h-9 w-9" />
                      <span className="min-w-0">
                        <span className="font-game block text-xs text-[#5b2bb8]">{synergyName(s)} <span className="text-[#1d2a4a]/60">· {tx('WITH', 'DENGAN')} {cardName(other)}</span></span>
                        <span className="block text-[10px] font-bold text-[#1d2a4a]">{synergyDesc(s)}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
            <div className="mt-auto pt-3 text-[10px] font-bold text-[#1d2a4a]/55">{tx('Cards last for the whole run. Dying ends the run — all cards reset.', 'Kartu berlaku sepanjang run. Mati = run berakhir, semua kartu di-reset.')}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
