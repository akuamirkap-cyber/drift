import { ReactNode } from 'react';
import { Sym } from './CodexBook';
import LangToggle from './LangToggle';
import { audioInit, snd } from './game/ragdoll/audio';
import { tx, useLang } from './i18n';
import './pause.css';

interface Props {
  level: number;
  theme: string;
  coins: number;
  kills: number;
  hp: number;
  maxHp: number;
  rangeMult: number;
  levelBadge: ReactNode;
  sound: ReactNode;
  onResume: () => void;
  onHome: () => void;
  onRetry: () => void;
  onBow: () => void;
  onSkin: () => void;
  onCodex: () => void;
  onSkill: () => void;
  onRange: () => void;
  onMute: () => void;
}

const tap = (fn: () => void) => () => { audioInit(); snd.tap(); fn(); };

/** The pause card: resume front and centre, the run at a glance, and every secondary menu one tap away. */
export default function PauseMenu(p: Props) {
  useLang();
  const hpPct = Math.max(0, Math.min(100, (p.hp / Math.max(1, p.maxHp)) * 100));
  return (
    <div className="pz-overlay">
      <div className="pz-card g-pop">
        <div className="pz-ribbon"><span>{tx('PAUSED', 'JEDA')}</span></div>

        <div className="pz-run">
          {p.levelBadge}
          <div className="pz-run-txt">
            <b>{tx('LEVEL', 'LEVEL')} {p.level}</b>
            <small>{p.theme.toUpperCase()}</small>
          </div>
          <div className="pz-chips">
            <span><Sym icon="coin" size={18} />{p.coins}</span>
            <span><Sym icon="skull" size={18} />{p.kills}</span>
          </div>
        </div>
        <div className="pz-hp" aria-label={`HP ${p.hp}/${p.maxHp}`}>
          <Sym icon="heart" size={20} />
          <div className="pz-bar"><i className={hpPct <= 30 ? 'low' : ''} style={{ width: `${hpPct}%` }} /></div>
          <b>{p.hp}</b>
        </div>

        <div className="pz-main">
          <button className="pz-round dark" onClick={tap(p.onHome)} aria-label={tx('Main Menu', 'Ke Menu Utama')}>
            <svg viewBox="0 0 24 24"><path d="M12 3l9 8h-2.5v9h-5v-6h-3v6h-5v-9H3z" fill="#fff" /></svg>
            <small>{tx('MENU', 'MENU')}</small>
          </button>
          <button className="pz-resume" onClick={tap(p.onResume)} aria-label={tx('Resume Game', 'Lanjutkan Permainan')}>
            <svg viewBox="0 0 24 24"><path d="M8 4.5v15l12-7.5z" fill="#fff" stroke="#0a1a52" strokeWidth="1.6" strokeLinejoin="round" /></svg>
            <small>{tx('RESUME', 'LANJUT')}</small>
          </button>
          <button className="pz-round dark" onClick={tap(p.onRetry)} aria-label={tx('Start new run', 'Mulai run baru')}>
            <svg viewBox="0 0 24 24"><path d="M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z" fill="#fff" /></svg>
            <small>{tx('RETRY', 'ULANG')}</small>
          </button>
        </div>

        <div className="pz-grid">
          <button className="pz-tile green" onClick={p.onBow}><Sym icon="bow" size={40} /><span>{tx('BOW', 'BUSUR')}</span></button>
          <button className="pz-tile blue" onClick={p.onSkin}><Sym icon="guard" size={40} /><span>SKIN</span></button>
          <button className="pz-tile red" onClick={p.onCodex}><Sym icon="book" size={40} /><span>{tx('CODEX', 'KAMUS')}</span></button>
          <button className="pz-tile gold" onClick={p.onSkill}><Sym icon="star" size={40} /><span>{tx('UPGRADE', 'UPGRADE')}</span></button>
        </div>

        <div className="pz-settings">
          <LangToggle compact />
          <button className="pz-set" onClick={tap(p.onRange)} aria-label={tx('Switch distance', 'Ubah jarak')}><Sym icon="eye" size={20} />{p.rangeMult}×</button>
          <button className="pz-set" onClick={p.onMute} aria-label={tx('Toggle sound', 'Atur suara')}>{p.sound}</button>
        </div>
      </div>
    </div>
  );
}
